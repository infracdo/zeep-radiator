This directory contains sample configurations for
Radiator RPM, deb and other packages.

To use these configuration samples, see the individual
configuration sample files for more information about
what the file does and how to use them.
