/* sql-test-data.sql */

/* Notes when using with different databases:
   o With SAP ASE (Sybase), set the command separator to semicolon:
     isql -U mikem -P fred -S server -D radius -c ';' -i goodies/sql-test-data.sql
*/

/* $Id$ */

/* The statement terminator ';' is the first thing on its own line for
   the maximum compatibility with different databases */

/* This is a sample user that is used for testing */
insert into SUBSCRIBERS (
	USERNAME,
	PASSWORD,
	ENCRYPTEDPASSWORD,
	CHECKATTR,
	REPLYATTR
	)
	values (
	'mikem',
	'fred',
	'1xMKc0GIVUNbE',
	'Service-Type = Framed-User',
	'Framed-Protocol = PPP,Framed-IP-Netmask = 255.255.255.0,cisco-avpair = "testing testing"'
)
;

/* This is a sample Client that is used for testing */
insert into RADCLIENTLIST (
	NASIDENTIFIER,
	SECRET,
	DUPINTERVAL
	)
	values (
	'203.63.154.1',
	'mysecret',
	10
)
;
