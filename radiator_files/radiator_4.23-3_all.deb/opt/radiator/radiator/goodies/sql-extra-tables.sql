/* sql-extra-tables.sql */

/* This file contains definitions for tables required by special or
   infrequently used configurations.

   See *Create.sql for more frequently used definitions for different
   databases.
*/

/* $Id$ */

/* Wipe any old versions. We don't try DROP TABLE IF EXISTS because
   not all DBs support it. For this reason there are likely errors
   when trying to drop tables that do not exist yet.
*/
drop table RADSQLAUTHBY;
drop table TBL_VASCODP;
drop table EAPFAST_PAC;
drop table GROUPS;

/* Contents of this table can used with AuthBy SQLAUTHBY to select an
   LDAP server based on the TARGETNAME realm. This table and the 2
   test LDAP servers below match the configuration sample in
   goodies/sqlauthby.cfg
*/
CREATE TABLE RADSQLAUTHBY (
       TARGETNAME			varchar(80),
       HOST				varchar(50),
       PORT				varchar(50),
       AUTHDN				varchar(100),
       AUTHPASSWORD			varchar(50),
       BASEDN				varchar(100),
       USERNAMEATTR			varchar(100),
       PASSWORDATTR			varchar(100),
       HOLDSERVERCONNECTION		int
);
/* You may want to have an unique index on TARGETNAME */

/*
insert into RADSQLAUTHBY
  (TARGETNAME, HOST, PORT, AUTHDN, AUTHPASSWORD, BASEDN, USERNAMEATTR, PASSWORDATTR, HOLDSERVERCONNECTION)
  values
  ('realm1', 'localhost', NULL, 'cn=Manager, dc=example, dc=com', 'secret', 'dc=example, dc=com', 'cn', 'userPassword', 1),
  ('realm2', 'someotherhost', '1234', 'cn=Manager, dc=anotherexample, dc=com', 'xxsecret', 'dc=anotherexample, dc=com', 'cn', 'userPassword', 1);
*/

/* This is similar to the example Vasco table from 'VACMAN Controller
   Integration Samples 3.0.0.1'. You can use it with the digipass.pl
   command line program included in the Authen-Digipass bundle to
   import, assign, list Digipass tokens. See goodies/digipass.cfg for
   an example config file that will authenticate Vasco Digipass token
   data in this table.
*/
CREATE TABLE TBL_VASCODP (
       DIGIPASS 	varchar(22) PRIMARY KEY,
       USER_ID		varchar(100),           /* NULL if not assigned */
       DP_TYPE		varchar(5),
       ALGO_TYPE 	varchar(2), 		/* Not used by Radiator */
       DP_DATA		varchar(248)
);
/* Index should be automatically created on DIGIPASS because of PRIMARY KEY */

/* This table can be used to hold EAP-FAST PACS that are either
   pre-provisioned or created on demand by Radiator.
   See goodies/sql.cfg for a sample configuration.

   PAC_OPAQUE is hex encoded key that is used to retrieve the actual session key
   PAC_LIFETIME is the expiry time in seconds from the UNIX epoch
   PAC_KEY is the session key hex encoded used to provision the EAP-FAST session
*/
CREATE TABLE EAPFAST_PAC (
       PAC_OPAQUE 	varchar(64) PRIMARY KEY,
       PAC_LIFETIME	int,
       PAC_KEY		varchar(64)
);
/* Index should be automatically created on PAC_OPAQUE because of PRIMARY KEY */

/* This table can be used to hold which group(s) a user belongs
   to. See the 2 test entries below.
   See goodies/sql.cfg for a sample configuration.

*/
CREATE TABLE GROUPS (
       USERNAME	    varchar(253) NOT NULL,
       GROUPNAME    varchar(50) NOT NULL
);

/*
insert into GROUPS (USERNAME, GROUPNAME) values ('mikem', 'group1'), ('mikem', 'group2');
*/
