#!/usr/bin/perl
#
# Simple test program for radius server
# This runs 2 servers. ONe is the main server under test, the 
# second is a server to test AuthBy RADIUS forwarding
#
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

use Getopt::Long;
use Config;
use IO::Handle;
use strict;
use warnings;

# Load exported constants from Windows-specific module but don't croak
# if it doesn't exist - there's a test for it if the module is actually needed.
BEGIN { eval { require Win32::Process; Win32::Process->import() } if ($^O eq 'MSWin32') }

my @MANDATORY_MODULES         = ();
my @MANDATORY_MODULES_WIN32   = ('Win32::Daemon');
my %TEST_SPECIFIC_MODULES =
(
 104 => ['Digest::MD4', 'Digest::MD4'],
);

my ($opt_s, $opt_h, $opt_tests, $opt_tap, $opt_randomize_ports);
my @options = (
    "s=s"             => \$opt_s,               # Test a remote server, dont run local ones
    "h|help"          => \$opt_h,               # Help
    "tests=s"         => \$opt_tests,           # List of test sets to run
    "tap"             => \$opt_tap ,            # Whether to print output in TAP format
    "randomize_ports" => \$opt_randomize_ports, # Whether to randomize auth and acct ports
    );

# Process command line parameters
&GetOptions(@options) || usage();
# Display help if requested
usage() if ($opt_h);

# Variables used throught this file
my ($perl, $tests, @tests, $perlargs, $rargs);
my $args = "";

# Windows process handles
my ($s1, $s2);

# Find where perl is installed
# VMS does not seem to set $Config{perlpath}
$perl = $Config{perlpath} || 'perl';

# This is the default set of tests to run
$tests = '1,2,3,4,5,6,7,8';
$tests = '1,2,4,5,6,7,8' if $^O eq 'MSWin32'; # DBM file is not working on Strawberry 5.20 or 5.22
$tests = $opt_tests if defined $opt_tests;

# @tests an array, each index is set of that set of tests is enabled
map {$tests[$_]++} (split(/[,\s+]/, $tests));

# Common args for radiusd and radpwtst
# Run the tests on a (hopefully) spare port, so it can be tested 
# on a live box
my $auth_port = 9721;
my $acct_port = 9722;

# randomize ports
if ($opt_randomize_ports) {
    my $rand_int = int(rand(256));
    $auth_port = $auth_port + $rand_int;
    $acct_port = $acct_port + $rand_int;
}

$args = "-auth_port $auth_port -acct_port $acct_port"
    unless $opt_s;

# Args to make radiusd get the right libraries
$perlargs = "-I./blib/arch -I./blib/lib";

$rargs = "$args -notrace";
#$rargs = "$args -trace 4 -noacct";

$rargs .= " -s $opt_s"
    if defined $opt_s;

local ($SIG{INT}) = \&cleanup;

my $errors = 0;
my $num_tests_run = 0;
print "Starting tests...\n";

# Test::More works with Perls as old as 5.8.1
# However done_testing was shipped in Perl in 5.10.1 so enable Test::More
# if Perl is new enough.
# see https://perldoc.perl.org/Test/More.html

$opt_tap = 1 if ($] >= 5.0101);

if (defined $opt_tap)
{
    if ($] < 5.0101)
    {
	print "Can not use -tap if perl is older than 5.10.1\n";
	undef $opt_tap;
    }
    else
    {
	eval{ require Test::More; Test::More->import()};
	die "Could not use Test::More: $@" if $@;
    }
}

# If not testing remote servers, check mandatory modules.
if (! defined $opt_s)
{
    print "Checking mandatory modules\n";

    # Add test specific mandatory modules
    for(my $i = 0; $i < @tests; $i++)
    {
	next unless $tests[$i];
	next unless $TEST_SPECIFIC_MODULES{$i};
	push @MANDATORY_MODULES, @{$TEST_SPECIFIC_MODULES{$i}};
    }

    # Remove duplicate modules possibly added above
    my %seen = ();
    my @dedup = grep { ! $seen{ $_ }++ } @MANDATORY_MODULES;
    @MANDATORY_MODULES = @dedup;

    foreach my $module (@MANDATORY_MODULES)
    {
	test_module($module);
    }
    if ($^O eq 'MSWin32')
    {
	foreach my $module (@MANDATORY_MODULES_WIN32)
	{
	    test_module($module);
	}
    }

    if ($errors)
    {
	print "Checking mandatory modules failed. Cannot continue.\n";
	cleanup();
    }
}

if (!defined $opt_s)
{
    # Run the test servers as daemons
    print "Starting 2 test servers.\n";

    if ($^O eq 'MSWin32')
    {
	my $module_errors = 0;
	foreach my $module ('Win32', 'Win32::Process')
	{
	    $module_errors++ if ! test_module($module);
	}
	if ($module_errors)
	{
	    print("Some modules to run tests on Windows platform are missing. Can not run tests any further.\n");
	    cleanup();
	}

	Win32::Process::Create($s1, $perl,
			       "$perlargs radiusd $args -config_file ./radius.cfg -pid_file ./radiusd.pid",
			       0, Win32::Process::DETACHED_PROCESS(), ".")
	    || die "Could not Create server 1:" . Win32::FormatMessage(Win32::GetLastError());
	Win32::Process::Create($s2, $perl,
			       "$perlargs radiusd -config_file ./radius2.cfg -pid_file ./radiusd2.pid",
			       0, Win32::Process::DETACHED_PROCESS(), ".")
	    || die "Could not Create server 1: " . Win32::FormatMessage(Win32::GetLastError());
    }
    else
    {
	system("$perl $perlargs radiusd $args -daemon -config_file ./radius.cfg -pid_file ./radiusd.pid");
	system("$perl $perlargs radiusd -daemon -config_file ./radius2.cfg -pid_file ./radiusd2.pid");
    }
    print "Please wait.";
    # Wait for the servers to start
    *STDOUT->autoflush();
    foreach (1 .. 10)
    {
	print '.';
	sleep 1;
    }
    print "\n";
}

if ($tests[1])
{
    ####################################################################
    # Build a DBM file called usersdb from a flat file called users
    unlink glob('usersdb*'); # some DBMs are platform sensitive: remove old ones
    test("$perl builddbm -z -f users usersdb",
	 "1a", 0);

    # This one should work for any username password, cause it goes to 
    # AuthTEST
    test("$perl radpwtst $rargs -user testuser\@test.realm -password fred",
	 "1b", 0);

    test("$perl radpwtst $rargs -user testuser\@test.realm -password jim",
	 "1c", 0);

    # Send a Status-Server
    test("$perl radpwtst $rargs -noacct -noauth -status -message_authenticator",
	 "1d", 0);

    # Send a Disconnect-Request
    test("$perl radpwtst $rargs -noacct -noauth -code Disconnect-Request NAS-Port=1234",
	 "1e", 0);
}

####################################################################
# These ones go to AuthFILE
if ($tests[2])
{
    # Also tests upper to lower RewriteUsername:
    test("$perl radpwtst $rargs -user testuser -password fred",
	 "2a", 0); 

    test("$perl radpwtst $rargs -user testuser -password jim",
	 "2b", 1);

    test("$perl radpwtst $rargs -user testuser\@unknown.realm -password fred",
	 "2c", 0);

    test("$perl radpwtst $rargs -user nosuchuser -password fred",
	 "2d", 1);

    test("$perl radpwtst $rargs -user nosuchuser\@any.realm -password fred",
	 "2e", 1);

    # Check chap
    test("$perl radpwtst $rargs -user testuser -password fred -chap",
	 "2f1", 0);

    test("$perl radpwtst $rargs -user testuser -password fred -chap_nc",
	 "2f2", 0);

    test("$perl radpwtst $rargs -user testuser -password jim -chap",
	 "2g", 1);

    # And these ones are to AuthFILE Nocache
    test("$perl radpwtst $rargs -user testuser\@file.nocache.realm -password fred",
	 "2h", 0);
    
    test("$perl radpwtst $rargs -user testuser\@file.nocache.realm -password jim",
	 "2i", 1);

    test("$perl radpwtst $rargs -user testuser\@file.nocache.realm",
	 "2j", 0);

    # Test DEFAULT user handling
    test("$perl radpwtst $rargs -user nosuchuser\@file.realm",
	 "2k", 1);

    test("$perl radpwtst $rargs -user nosuchuser\@file.realm -service_type Login-User",
	 "2l", 0);

    test("$perl radpwtst $rargs -user nosuchuser\@file.realm -service_type Outbound-User",
	 "2m", 0);

    # Check whether Auth-Type System falls through to UNIX 
    # This will fail on freebsd and similar systems that use MD5 based crypt
    # Replace passwd with passwd.md5 and it will succeed.
    test("$perl radpwtst $rargs -user testuser -service_type Administrative-User",
	 "2n", 0);
    
    # Check whether NAS-Address-Port-List works
    test("$perl radpwtst $rargs -user alice -nas_port 1234",
	 "2o", 0);

    test("$perl radpwtst $rargs -user alice -nas_port 1235",
	 "2p", 1);

    # Check multiple varieties of password encryption
    # Note, dont test SHA here, not everyone has it
    # Some of these test will fail on freebsd, because the
    # native crypt may be MD5
    test("$perl radpwtst $rargs -noacct -user pwtest1 -password fred",
	 "2q", 0);
#   test("$perl radpwtst $rargs -noacct -user pwtest2 -password fred",
#        "2ra", 0);
    test("$perl radpwtst $rargs -noacct -user pwtest3 -password fred",
	 "2r", 0);
    test("$perl radpwtst $rargs -noacct -user pwtest4 -password fred",
	 "2s", 0);
#   test("$perl radpwtst $rargs -noacct -user pwtest5 -password fred",
#        "2ta", 0);
    test("$perl radpwtst $rargs -noacct -user pwtest6 -password fred",
	 "2t", 0);
    test("$perl radpwtst $rargs -noacct -user pwtest7 -password fred",
	 "2u", 0);
    test("$perl radpwtst $rargs -noacct -user pwtest8 -password fred",
	 "2v", 0);
    # Rcrypt reversible encryption:
    # Caution, requires Mime::Base64
#   test("$perl radpwtst $rargs -noacct -user pwtest11 -password fred",
#        "2w", 0);
    # mysql crypt:
    test("$perl radpwtst $rargs -noacct -user pwtest12 -password fred",
	 "2w", 0);

    test("$perl radpwtst $rargs -noacct -user pwtest13 -password fred",
	 "2x", 0);

    # EAP MD5, expect an accept
    test("$perl radpwtst $rargs -noacct -eapmd5",
	 "2y", 0);

    # EAP MD5, expect a reject
    test("$perl radpwtst $rargs -noacct -eapmd5 -password wrong",
	 "2z", 1);

    # EAP request, using raw packet dumps captured before, expect an accept
#    test("$perl radpwtst $rargs -noacct -noauth -rawfile eaptest2.dat",
#	 "2z", 0);

    # HTTP Digest request
    # Strange password quoting so it works on Windows command shell too
    test("$perl radpwtst $rargs -noacct -user zz -password " . '"Digest username=\\"zz\\", realm=\\"Radius Test\\", qop=\\"auth\\", algorithm=\\"MD5\\", uri=\\"/test\\", nonce=\\"1018000482\\", nc=00000001, cnonce=\\"b798c628f3f2591529f3d599e33bd656\\", response=\\"a63541c566e0d2049f93a1af22577962\\", method=\\"GET\\""',
	 "2aa", 0);

    # flagged plaintext, expect an accept
    test("$perl radpwtst $rargs -noacct -user pwtest8 -password fred",
	 "2ab", 0);

}

####################################################################
# These ones go to AuthDBFILE
if ($tests[3])
{
    test("$perl radpwtst $rargs -user testuser\@dbfile.realm -password fred",
	 "3a", 0);
    
    test("$perl radpwtst $rargs -user testuser\@dbfile.realm -password jim",
	 "3b", 1);
    
    test("$perl radpwtst $rargs -user xyzzy\@dbfile.realm -password fred",
	 "3c", 1);
    
    # Check chap
    test("$perl radpwtst $rargs -user testuser\@dbfile.realm -password fred -chap",
	 "3d1", 0);
    
    test("$perl radpwtst $rargs -user testuser\@dbfile.realm -password fred -chap_nc",
	 "3d2", 0);
    
    test("$perl radpwtst $rargs -user testuser\@dbfile.realm -password jim -chap",
	 "3e", 1);
    
    # Test DEFAULT user handling
    test("$perl radpwtst $rargs -user nosuchuser\@dbfile.realm",
	 "3f", 1);

    test("$perl radpwtst $rargs -user nosuchuser\@dbfile.realm -service_type Login-User",
	 "3g", 0);

    test("$perl radpwtst $rargs -user nosuchuser\@dbfile.realm -service_type Outbound-User",
	 "3h", 0);

}

####################################################################
# These ones go to AuthUNIX
# This will fail on freebsd and similar systems that use MD5 based crypt
# Replace passwd with passwd.md5 and it will succeed.
if ($tests[4])
{
    test("$perl radpwtst $rargs -user testuser\@unix.realm -password fred",
	 "4a", 0);
    
    test("$perl radpwtst $rargs -user testuser\@unix.realm -password jim",
	 "4b", 1);
    
    test("$perl radpwtst $rargs -user xyzzy\@unix.realm -password jim",
	 "4c", 1);
}

####################################################################
# These ones are forwarded to the secondary server config with radius2.cfg
# Where they will be authed with AuthFILE and ./users
if ($tests[5])
{
    
    test("$perl radpwtst $rargs -user testuser\@radius.realm -password fred",
	 "5a", 0);
    
    test("$perl radpwtst $rargs -user testuser\@radius.realm -password jim",
	 "5b", 1);
    
    test("$perl radpwtst $rargs -user xyzzy\@radius.realm -password jim",
	 "5c", 1);

    # Check chap
    test("$perl radpwtst $rargs -user testuser\@radius.realm -password fred -chap",
	 "5d1", 0);

    test("$perl radpwtst $rargs -user testuser\@radius.realm -password fred -chap_nc",
	 "5d2", 0);

    test("$perl radpwtst $rargs -user testuser\@radius.realm -password jim -chap",
	 "5e", 1);

    # Check handlers, there is a handler in radius2.cfg  for 
    # NAS-IP-Address = 203.63.154.3 that will always reject, and one
    # for 203.63.154.2 tnat users the normal users file
    test("$perl radpwtst $rargs -user testuser\@radius.realm -password fred -nas_ip_address 203.63.154.2 ",
	 "5f", 0);

    test("$perl radpwtst $rargs -user testuser\@radius.realm -password fred -nas_ip_address 203.63.154.3 -noacct",
	 "5g", 1);
}


####################################################################
# Check whether the MaxSessions stuff works. Its set to 
# 2 in the DEFAULT realm. Send 2 accounting starts for different
# ports
if ($tests[6])
{
    # The first one should succeed
    test("$perl radpwtst $rargs -user testuser -password fred -noacct -nas_port 1233",
	 "6a", 0);
    
    # Start 2 sessions
    test("$perl radpwtst $rargs -user testuser -nostop -noauth -nas_port 1231",
	 "6b", 0);
    
    test("$perl radpwtst $rargs -user testuser -nostop -noauth -nas_port 1232",
	 "6c", 0);

    # Next one should fail
    test("$perl radpwtst $rargs -user testuser -password fred -noacct -nas_port 1233",
	 "6d", 1);

    # Now remove a session 
    test("$perl radpwtst $rargs -user testuser -nostart -noauth -nas_port 1232",
	 "6e", 0);
    
    # Now it should succeed
    test("$perl radpwtst $rargs -user testuser -password fred -noacct -nas_port 1233",
	 "6f", 0);

    # Now send the other stop
    test("$perl radpwtst $rargs -user testuser -noauth -nostart -nas_port 1231",
	 "6g", 0);

    # Now clear the session database for next time
    test("$perl radpwtst $rargs -noauth -nostop -session_id 00000000",
	 "6h", 0);

}


####################################################################
# Test AuthBy INTERNAL
if ($tests[7])
{
    # Everyone should accept
    test("$perl radpwtst $rargs -user xxxx\@internal.realm -noacct",
	 "7a", 0);

    test("$perl radpwtst $rargs -user yyyyy\@internal.realm -noacct",
	 "7b", 0);

    test("$perl radpwtst $rargs -user testuser\@internal.realm -noauth",
	 "7c", 0);

}

####################################################################
# Test AuthBy MOBILEIP
if ($tests[8])
{
    # This is a test HA Key Distribution request
    test("$perl radpwtst $rargs -noacct -user 1.2.3.4.10.0.0.1\@mobileip.realm -nas_ip_address 10.0.0.1",
	 "8a", 0);

    # This is a test FA user authentication, which includes a request
    # for a key
    test("$perl radpwtst $rargs -noacct -user miptest\@mobileip.realm -nas_ip_address 10.0.0.1 3GPP2-Pre-Shared-Secret-Request=Yes",
	 "8b", 0);
}

####################################################################
# Test SQL
if ($tests[100])
{
    # These ones go to AuthSQL
    # NOTE test 6a will fail unless you have set up DBD/DBI 
    # and a database
    # with suitably named tables, and configure radius.cfg 
    # appropriately
    test("$perl radpwtst $rargs -user testuser\@sql.realm -password fred",
	 "100a", 0);

    test("$perl radpwtst $rargs -user testuser\@sql.realm -password jim",
	 "100b", 1);

    test("$perl radpwtst $rargs -user xyzzy\@sql.realm -password jim",
	 "100c", 1);

# Check chap
    test("$perl radpwtst $rargs -user testuser\@sql.realm -password fred -chap",
	 "100d1", 0);

    test("$perl radpwtst $rargs -user testuser\@sql.realm -password jim -chap",
	 "100e1", 1);

    test("$perl radpwtst $rargs -user testuser\@sql.realm -password fred -chap_nc",
	 "100d2", 0);

    test("$perl radpwtst $rargs -user testuser\@sql.realm -password jim -chap_nc",
	 "100e2", 1);
}

####################################################################
# Test AuthLDAP
if ($tests[101])
{
    # Prime the LDAP connection. For distant hosts, 
    # it can be slow to get going
    test("$perl radpwtst $rargs -user testuser\@ldap.realm -password fred",
	 "101a", 0);

    test("$perl radpwtst $rargs -user testuser\@ldap.realm -password jim",
	 "101b", 1);

    test("$perl radpwtst $rargs -user xyzzy\@ldap.realm -password jim",
	 "101c", 1);

# Check chap
    test("$perl radpwtst $rargs -user testuser\@ldap.realm -password fred -chap",
	 "101d1", 0);

    test("$perl radpwtst $rargs -user testuser\@ldap.realm -password jim -chap",
	 "101e1", 1);

    test("$perl radpwtst $rargs -user testuser\@ldap.realm -password fred -chap_nc",
	 "101d2", 0);

    test("$perl radpwtst $rargs -user testuser\@ldap.realm -password jim -chap_nc",
	 "101e2", 1);
}

####################################################################
# test NT
if ($tests[102])
{
    # These are not exhaustive, because we dont know any real 
    # passwords for every NT system out there
    test("$perl radpwtst $rargs -user Administrator\@nt.realm -password wrongpassword",
	 "102a", 0);

    test("$perl radpwtst $rargs -user unknown\@nt.realm -password fred",
	 "102b", 0);
}

####################################################################
# These ones go to the external program goodies/testcommand.pl
# which only accepts fred, and rejects everyone else
if ($tests[103])
{
    # This should fail
    test("$perl radpwtst $rargs -user testuser\@external.realm -noacct",
	 "103a", 1);

    test("$perl radpwtst $rargs -user fred\@external.realm -noacct",
	 "103b", 0);

    # Try testuser again, just to be sure it still working properly
    test("$perl radpwtst $rargs -user testuser\@external.realm -noacct",
	 "103c", 1);

}

####################################################################
# Test plaintext and various types of NT Hashed passwords with PAP, MSCHAP and MSCHAPV2
if ($tests[104])
{
    test("$perl radpwtst $rargs -user pwtest1 -noacct",
	 "104a", 0);
    test("$perl radpwtst $rargs -user pwtest1 -noacct -password wrongpassword",
	 "104b", 1);
    test("$perl radpwtst $rargs -user pwtest1 -mschap -noacct",
	 "104c", 0);
    test("$perl radpwtst $rargs -user pwtest1 -mschap -noacct -password wrongpassword",
	 "104d", 1);
    test("$perl radpwtst $rargs -user pwtest1 -mschapv2 -noacct",
	 "104e", 0);
    test("$perl radpwtst $rargs -user pwtest1 -mschapv2 -noacct -password wrongpassword",
	 "104f", 1);


    test("$perl radpwtst $rargs -user pwtest14 -noacct",
	 "104g", 0);
    test("$perl radpwtst $rargs -user pwtest14 -noacct -password wrongpassword",
	 "104h", 1);
    test("$perl radpwtst $rargs -user pwtest14 -mschap -noacct",
	 "104i", 0);
    test("$perl radpwtst $rargs -user pwtest14 -mschap -noacct -password wrongpassword",
	 "104j", 1);
    test("$perl radpwtst $rargs -user pwtest14 -mschapv2 -noacct",
	 "104k", 0);
    test("$perl radpwtst $rargs -user pwtest14 -mschapv2 -noacct -password wrongpassword",
	 "104l", 1);

    test("$perl radpwtst $rargs -user pwtest15 -noacct",
	 "104m", 0);
    test("$perl radpwtst $rargs -user pwtest15 -noacct -password wrongpassword",
	 "104n", 1);
    test("$perl radpwtst $rargs -user pwtest15 -mschap -noacct",
	 "104o", 0);
    test("$perl radpwtst $rargs -user pwtest15 -mschap -noacct -password wrongpassword",
	 "104p", 1);
    test("$perl radpwtst $rargs -user pwtest15 -mschapv2 -noacct",
	 "104q", 0);
    test("$perl radpwtst $rargs -user pwtest15 -mschapv2 -noacct -password wrongpassword",
	 "104r", 1);
}

print "Tests completed. $num_tests_run tests, $errors errors\n";

&cleanup;

sub cleanup
{
    if (!defined $opt_s)
    {
	# Clean up processes. Sleep is because SIGINT may already have
	# started the shutdown of the processes.
	print "Cleaning up Radiator processes\n";
	sleep(2);
	if ($^O eq 'MSWin32')
	{
	    # Handle case if Win32::* modules do not exist
	    if (defined $s1)
	    {
		$s1->Kill(0)
		  || warn "Could not kill server 1";
	    }
	    if (defined $s2)
	    {
		$s2->Kill(0)
		  || warn "Could not kill server 2";
	    }
	}
	else
	{
	    system("kill `cat ./radiusd.pid`") if (-e './radiusd.pid');
	    system("kill `cat ./radiusd2.pid`") if (-e './radiusd2.pid');
	}
    }
    if (defined $opt_tap)
    {
	done_testing($num_tests_run);
    }

    # Remove files we created. All files are not created on all
    # systems.
    foreach my $file (qw(detail logfile logfile2 password.log radiusd.pid radiusd2.pid usersdb.db usersdb.pag usersdb.dir wtmp))
    {
	next unless -e $file;
	unlink $file or warn "Could not unlink $file: $!";
    }

    exit $errors ? 1 : 0;
}

sub test
{
    my ($cmd, $test, $shouldfail) = @_;
    $num_tests_run++;

    system($cmd);
    if (defined $opt_tap)
    {
        $errors++ if ! ok($shouldfail && $? || !$shouldfail && !$?, $test);
    }
    else
    {
	if (!$shouldfail && $? ||
	     $shouldfail && !$?)
	{
	    print "not ";
	    $errors++;
	}
	print "ok $test\n";
    }

    return;
}

sub test_module
{
    my ($module) = @_;
    $num_tests_run++;
    my $ok = 0;

    # If running with Perl newer than 5.10.1, use Test::More framework.
    # require_ok returns true or false depending on the result.
    # If Perl version is not new enough, use eval to require module.
    if (defined $opt_tap)
    {
	$ok++ if require_ok($module);
    }
    else
    {
	my $path = $module . '.pm';
	$path =~ s{::}{/}g;
	if (! eval{require $path;})
	{
	    print "not ";
	}
	else
	{
	    $ok++;
	}
	print "ok $module\n";
    }
    $errors++ if ! $ok;
    return $ok;
}

# Print usage and exit
sub usage
{
    print "usage: $0 [-s <server>] [-tests <list>] [-tap]\n";
    print "-h           Get help\n";
    print "-s           Test a remote server, dont run local ones\n";
    print "-tests       List of test sets to run. Use 104 for MSCHAP tests. Requires Digest::MD4 Perl module\n";
    print "-tap         Whether to print output in TAP format (enabled in Perls newer than 5.10.1)\n";
    exit (0);
}
