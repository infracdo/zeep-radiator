# AddressAllocatorDHCP
#
# Implements IP address allocation from DHCP.
# Called by AuthDYNADDRESS.pm
#
# AddressAllocatorDHCP.pm will work with any DHCP
# server, however it works best with the DHCP server
# from the Internet Software Consortium (www.isc.org).
# The ISC DHCP server implements a new option called
# the Subnet Selection Option (documented in RFC 3011),
# which allows inter-server operation such as that 
# implemented by Radiator.
# 
# If a DHCP server that does not implement the Subnet
# Selection Option is used, there is additional configuration
# required on the Radiator host such that virtual interfaces
# from each subnet defined in DHCP must be configured. This 
# virtual interface address must be used in the DHCP request
# to indicate which DHCP address range to allocate from.
#
# There is an example configuration file included in the Radiator
# distribution in the file "goodies/addressallocatordhcp.cfg".
#
# NOTE: the DHCP server cannot run on the same host as Radiator.
# This is due to the fact that Radiator as a DHCP proxy must use
# the same UDP port number as the DHCP server.  
#
# Author: Hugh Irvine (hugh@open.com.au)
# Copyright (C) 2000 Open System Consultants

package Radius::AddressAllocatorDHCP;
@ISA = qw(Radius::AddressAllocatorGeneric Radius::DHCPPeer);
use Radius::AddressAllocatorGeneric;
use Radius::DHCPPeer;
use Radius::DHCP;
use Radius::Radius;
use Radius::Select;
use Radius::Context;
use Socket;
use Fcntl;  
use strict;
use warnings;

%Radius::AddressAllocatorDHCP::ConfigKeywords = 
(

 'Host' =>
 ['string', 'Hostname of the DHCP server to use', 0],

 'Port' =>
 ['string', 'Destination UDP port of the DHCP server', 1],

 'ServerPort' =>
 ['string', 'Local DHCP port. Deprecated, use LocalPort instead', 1],

 'UseClassForAllocationInfo'    => 
 ['flag', 'Information about the allocation is kept in Class attribute instead of in memory. Required for server farm. Defaults to off.', 1],

 'DHCPClientIdentifier'  => 
 ['string', 'The attribute to use in the DHCPv6 Client-Identifier field to identify the RADIUS client to the DHCP server. Special characters are permitted.', 1],
 'DefaultLease'          => 
 ['integer', 'If SessionTimeout is set by a previous AuthBy then that is used as the expiry time. Otherwise DefaultLease (in seconds) is used.', 1],

 'TimeoutMinimum'        => 
 ['integer', 'The starting timeout in seconds', 2],
 'TimeoutMaximum'        => 
 ['integer', 'The maximum timeout in seconds', 2],
 'TimeoutFactor'         => 
 ['integer', 'The factor that the timeout increases by after each unaswered DHCP request', 2],

 'Synchronous'           => 
 ['flag', ' operate synchronously with the DHCP server', 2],

 'SubnetSelectionOption' => 
 ['integer', 'Early versions of the ISC DHCP server use the unofficial option 211', 1],
 'UserClass'             => 
 ['string', 'Optional user class identifier', 1],
 'ClientHardwareAddress'            => 
 ['string', 'The attribute in the incoming address which contains the hex encoded MAC address of the client. If present, it will be used as CHADDR in the DHCP request. If not present, and fake CHADDR based on the request XID will be used. The DHCP server may use this when allocating an address for the client.The MAC address can contain extraneous characters such as . or : as long as it contains the 12 hex characters (case insensitive) of the MAC address. Special characters are permitted.', 1],

 'DHCPHostName' =>
 ['string', "Sets the value to use for DHCP option 12 'Host Name'. There is no default.", 1],

 'DHCPVendorClass' =>
 ['string', "Sets the value to use for DHCP option 61 'Class Identifier', also known as 'Vendor class identifier'. There is no default.", 1],

);

# RCS version number of this module
$Radius::AddressAllocatorDHCP::VERSION = '$Revision$';

#####################################################################
# (Re)activate a new Dynamic address allocator for DHCP
sub activate
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::activate();
    $self->Radius::DHCPPeer::activate();

    # For backward compatibility
    $self->{LocalPort} = $self->{ServerPort} if defined $self->{ServerPort};

    $self->{NextIdentifier} = 0;
    $self->{SubnetSelectionOption} = $Radius::DHCP::SUBNET_SELECTION
	if defined $self->{SubnetSelectionOption}
           && !$self->{SubnetSelectionOption}; # Empty or 0 means use the default
}

#####################################################################
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initalize instance 
# variables that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::initialize();
    $self->Radius::DHCPPeer::initialize();

    $self->{Host} = '255.255.255.255';
    $self->{Port} = $Radius::DHCP::SERVER_PORT;
    $self->{LocalPort} = $Radius::DHCP::SERVER_PORT;
    $self->{DHCPClientIdentifier} = '%{User-Name}';
    $self->{DefaultLease} = 86400;
    $self->{TimeoutMinimum} = 2;
    $self->{TimeoutMaximum} = 16;
    $self->{TimeoutFactor} = 2;

    return;
}

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate.
sub check_config
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::check_config();
    $self->Radius::DHCPPeer::check_config();

    $self->log($main::LOG_WARNING, "Consider enabling UseClassForAllocationInfo in AddressAllocatorDHCP when configured with FarmSize")
      if $main::config->{FarmSize} && !$self->{UseClassForAllocationInfo};

    return;
}

#####################################################################
# Completely handle a reply from DHCP server. Returns (result,
# reason). The messages received here will be replies to requests we
# have forwarded to a DHCP server.  We have to reply to AuthDYNADDRESS
# and cross the original request off our timeout list.  We must also
# save some context for later deallocation.
sub handle_dhcp_server_reply
{
    my ($self, $whence, $request, $reply) = @_;

    # Extract the context parameters
    my $p = $request->{p};
    my $caller = $request->{caller};
    my $values = $request->{values};
    my $xid = $$reply{xid};

    # See if the reply values are acceptable
    my ($result, $reason) = $self->check_dhcp_server_reply($whence, $request, $reply);
    return ($result, $reason) unless ($result == $main::ACCEPT);

    my $message_type = $$reply{message_type};
    if ($message_type == $Radius::DHCP::DHCPOFFER)
    {
	# Check whether we have already sent a request.
	# This may happen if we are using the broadcast
	# address and another DHCP server has sent an offer.
	return if defined $request->{requested};
	$request->{requested}++;

	# We have received an offer from the DHCP server,
	# so prepare and send a DHCPREQUEST
	$$values{requested_ip_address} = $$reply{yiaddr};
	$$values{server_identifier} = $$reply{server_identifier};
	$$values{message_type} = $Radius::DHCP::DHCPREQUEST;

	$request->{timeout} = $self->{TimeoutMinimum};

	$self->send_dhcp_msg($request);

	# Do not return anything back to NAS yet
	$result = $main::IGNORE;
	$reason = "Waiting for DHCPACK";
    }
    elsif ($message_type == $Radius::DHCP::DHCPACK)
    {
	# We have received an ack from the DHCP server,
	# so reply to AuthDYNADDRESS with the details
	my %details;
	$details{yiaddr} = Socket::inet_ntoa($$reply{yiaddr})
	    if defined $$reply{yiaddr};
	$details{subnetmask} = Socket::inet_ntoa($$reply{subnet_mask})
	    if defined $$reply{subnet_mask};
	$details{dnsserver} = Socket::inet_ntoa($$reply{dns_server})
	    if defined $$reply{dns_server};

	if (defined $$reply{server_identifier})
	{
	    my $server = Socket::inet_ntoa($$reply{server_identifier});
	    $details{serveridentifier} = "DHCP-Server-Identifier = $server";
	}

	# Save some context for later use by deallocate()
	# Save the context in Class attribute or Context object.
	if ($self->{UseClassForAllocationInfo})
	{
	    my $hex_chaddr = unpack('H*', $$values{chaddr});
	    $p->{rp}->add_attr('Class', Socket::inet_ntoa("$$values{subnet}") . "-$hex_chaddr");
	}
	else
	{
	    my $context_key = "dhcp:$$values{client_identifier}:$details{yiaddr}";
	    my $context = Radius::Context->new($context_key, $$values{default_lease});
	    if (defined $context)
	    {
		$context->{subnet} = $$values{subnet};
		$context->{chaddr} = $$values{chaddr};
	    }
	}

	# Call the callers allocateDone() function to process the
	# results
	$caller->allocateDone($p, \%details);
	$result = $main::ACCEPT;
	$reason = "Received DHCPACK for request ID $xid";
    }
    elsif ($message_type == $Radius::DHCP::DHCPNAK)
    {
	$result = $main::REJECT;
	$reason = "Received DHCPNAK for request ID $xid";
	$self->log($main::LOG_WARNING, $reason, $p);
    }
    else
    {
	$result = $main::REJECT;
	my $dhcp_message_type_name = $Radius::DHCP::message_type_number_to_name{$message_type};
	$dhcp_message_type_name = 'Unknown' unless $dhcp_message_type_name;
	$reason = "Received unexpected DHCP message $message_type ($dhcp_message_type_name) for request ID $xid";
	$self->log($main::LOG_WARNING, $reason, $p);
    }

    return ($result, $reason);
}

# Check if the values in the reply are acceptable. Returns (result,
# reason)
sub check_dhcp_server_reply
{
    my ($self, $whence, $request, $reply) = @_;

    my $values = $request->{values};
    my $p = $request->{p};
    my $xid = $reply->{xid};
    my ($result, $reason) = ($main::ACCEPT, 'DHCP server reply check passed');

    # RFC3011 specifies that if the Subnet Selection Option is used,
    # the reply from the DHCP server MUST contain the identical
    # Subnet Selection Option as included in our original request.
    if ($$values{sso})
    {
	if (!$$reply{sso})
	{
	    ($result, $reason) = ($main::REJECT, "No Subnet Selection Option in DHCP reply for request ID $xid");
	}
	elsif ($$reply{sso} ne $$values{sso})
	{
	    ($result, $reason) = ($main::REJECT, "Incorrect Subnet Selection Option ($$reply{sso}) in DHCP reply for request ID $xid");
	}
	elsif ($$values{subnet} ne $$reply{subnet})
	{
	    ($result, $reason) = ($main::REJECT, "Subnet Selection Option value in DHCP reply does not match request value for request ID $xid");
	}
    }

    $self->log($main::LOG_WARNING, $reason, $p) if $result != $main::ACCEPT;

    return ($result, $reason);
}

# Our message to DHCP server timed out. Returns (result, reason)
sub handle_dhcp_server_timeout
{
    my ($self, $request) = @_;

    return ($main::REJECT, 'No reply from DHCP server');
}

# When Asynchronous or Synchronous is unset, this is called when a
# reply either times out or is received.
sub handle_non_synchronous_result
{
    my ($self, $p, $result, $reason) = @_;

    $p->{Handler}->handlerResult($p, $result, $reason);
    return;
}

#####################################################################
# Allocate an address for username with the given pool hint
# return a hash of interesting values for AuthBy DYNADDRESS
# to do stuff with
sub allocate
{
    my ($self, $caller, $username, $pool_hint, $p) = @_;

    unless ($self->{Socket})
    {
	$self->log($main::LOG_ERR, "AddressAllocator DHCP: DHCP socket not initialised in allocate.", $p);
	return ($main::REJECT, "AddressAllocator DHCP not correctly set up");
    }

    my $subnet;

    # Verify the pool_hint and if not correct Reject.
    if (&Radius::Util::isIP4Address($pool_hint))
    {
	$subnet = Socket::inet_aton($pool_hint);
    }
    else
    {
	return ($main::REJECT, "Incorrect PoolHint value $pool_hint");
    }

    # Build and send a DHCPDISCOVER
    my %values;
    $values{opcode} = $Radius::DHCP::CLIENT_OPCODE;
    $values{subnet} = $subnet;
    $values{client_identifier} = &Radius::Util::format_special
	($self->{DHCPClientIdentifier}, $p);
    $values{local_address} = $self->{dhcp_local_address_packed};
    $values{default_lease} = $self->{DefaultLease};
    my $xid = $self->next_identifier;
    $values{xid} = $xid;
    $values{secs} = 0;
    $values{$Radius::DHCP::HOST_NAME} = Radius::Util::format_special($self->{DHCPHostName}, $p, $self)
	if defined $self->{DHCPHostName};
    $values{$Radius::DHCP::VENDOR_CLASS_IDENTIFIER} = Radius::Util::format_special($self->{DHCPVendorClass}, $p, $self, $main::VERSION)
	if defined $self->{DHCPVendorClass};

    $values{chaddr} = pack 'C C N C10', 15, 255, $xid, 0;
    # Maybe create CHADDR from a MAC address in the request
    if ($self->{ClientHardwareAddress})
    {
	my $chaddr = &Radius::Util::format_special($self->{ClientHardwareAddress}, $p);
	my $chaddrhex = $chaddr;
	$chaddrhex =~ s/[^a-fA-F0-9]//g;
	if ($chaddrhex =~ m/([a-fA-F0-9]{12})/)
	{
	    $values{chaddr} = pack 'H32', $1;
	}
	else
	{
	    &main::log($main::LOG_WARNING, 
		       "ClientHardwareAddress $chaddr does not look like a MAC address. Reverting to XID for CHADDR");
	}
    }

    $values{sso} = $self->{SubnetSelectionOption}
        if $self->{SubnetSelectionOption};
    $values{user_class} = &Radius::Util::format_special($self->{UserClass}, $p)
        if (defined $self->{UserClass});
    $values{message_type} = $Radius::DHCP::DHCPDISCOVER;

    my %request;
    $request{p} = $p;
    $request{caller} = $caller;
    $request{host} = $self->{Host};
    $request{port} = $self->{Port};
    $request{values} = \%values;
    $request{timeout} = $self->{TimeoutMinimum};

    return $self->send_dhcp_msg(\%request);
}

#####################################################################
# Confirm a previously allocated address is in use
sub confirm
{    
    my ($self, $caller, $address, $p) = @_;

    return ($main::ACCEPT, 'confirm not implemented');
}

#####################################################################
# Free a previously allocated address
# Note that the DHCP server will not reply to a DHCPRELEASE
sub deallocate
{    
    my ($self, $caller, $address, $p) = @_;

    unless ($self->{Socket})
    {
	$self->log($main::LOG_ERR, "AddressAllocator DHCP: DHCP socket not initialised in deallocate.", $p);
	return ($main::REJECT, "AddressAllocator DHCP not correctly set up");
    }

    # build and send a DHCPRELEASE
    my %values;
    $values{opcode} = $Radius::DHCP::CLIENT_OPCODE;
    $values{client_identifier} = &Radius::Util::format_special
	($self->{DHCPClientIdentifier}, $p);
    $values{ciaddr} = Socket::inet_aton($address);
    $values{local_address} = $self->{dhcp_local_address_packed};
    my $xid = $self->next_identifier;
    $values{xid} = $xid;
    $values{$Radius::DHCP::HOST_NAME} = Radius::Util::format_special($self->{DHCPHostName}, $p, $self)
	if defined $self->{DHCPHostName};
    $values{$Radius::DHCP::VENDOR_CLASS_IDENTIFIER} = Radius::Util::format_special($self->{DHCPVendorClass}, $p, $self, $main::VERSION)
	if defined $self->{DHCPVendorClass};

    # Recover chaddr that was used with the allocation
    if ($self->{UseClassForAllocationInfo})
    {
	# Retrieve the saved values from the request Class attribute
	my $class = $p->get_attr('Class');
	unless (defined $class)
	{
	    my $nas = $p->get_attr('NAS-IP-Address') || 'unknown';
	    $self->log($main::LOG_WARNING, "deallocate: No Class from NAS $nas. Can not deallocate $address", $p);
	    return ($main::ACCEPT, 'No Class from NAS in deallocate');
	}

	my($subnet, $chaddr) = split(/-/, $class);
	unless (defined $chaddr &&
		defined $subnet &&
		length($chaddr) == 32 &&  # 16 bytes, 32 hex chars
		Radius::Util::isIP4Address($subnet))
	{
	    my $nas = $p->get_attr('NAS-IP-Address') || 'unknown';
	    $self->log($main::LOG_WARNING, "deallocate: Bad Class value '$class' from NAS $nas. Can not deallocate $address", $p);
	    return ($main::ACCEPT, 'Bad Class value from NAS in deallocate');
	}

	$values{chaddr} = pack('H*', $chaddr);
	$values{subnet} = Socket::inet_aton($subnet);
    } else {
	# Retrieve the chaddr saved when the address was allocated
	my $context_key = "dhcp:$values{client_identifier}:$address";
	my $context = &Radius::Context::find($context_key);
	if (!defined $context)
	{
	    # no context, so just return
	    # this may happen if we get a duplicate accounting stop
	    return ($main::ACCEPT, 'No context found in deallocate');
	}

	# Use the saved values
	$values{chaddr} = $context->{chaddr};
	$values{subnet} = $context->{subnet};

	# Remove the saved context
	&Radius::Context::destroy($context_key);
    }

    $values{sso} = $self->{SubnetSelectionOption}
        if $self->{SubnetSelectionOption};
    $values{user_class} = &Radius::Util::format_special($self->{UserClass}, $p)
        if (defined $self->{UserClass});
    $values{message_type} = $Radius::DHCP::DHCPRELEASE;

    my %request;
    $request{p} = $p;
    $request{caller} = $caller;
    $request{host} = $self->{Host};
    $request{port} = $self->{Port};
    $request{values} = \%values;

    # We will never get a reply from the DHCP server
    $self->send_dhcp_msg(\%request);
    return ($main::ACCEPT, 'deallocate succeeded');
}

#####################################################################
# Free all previously allocated address for the NAS
sub deallocate_by_nas
{
    my ($self, $caller, $p) = @_;

    # We do not currently know how to do this with DHCP
    return ($main::ACCEPT, 'deallocate_by_nas not implemented');
}

#####################################################################
# next_identifier
# Return the next identifier to be used 
sub next_identifier
{
    my ($self) = @_;

    return $self->{NextIdentifier} = ($self->{NextIdentifier} + 1);
}

1;






