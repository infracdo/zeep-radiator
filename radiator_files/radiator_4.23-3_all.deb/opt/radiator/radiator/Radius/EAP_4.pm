# EAP_4.pm
#
# Module for  handling Authentication via EAP type 4 (MD5-Challenge)
#
# See RFCs 2869 2284 1994
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2001 Open System Consultants
# $Id$

package Radius::EAP_4;
use strict;

# RCS version number of this module
$Radius::EAP_4::VERSION = '$Revision$';

#####################################################################
# Called by EAP.pm when the caller wants to know the EAP type name this class supports
sub type_name
{
    my ($classname) = @_;

    return 'MD5';
}

#####################################################################
# request
# Called by EAP.pm when a request is received for this protocol type
sub request
{
    my ($classname, $self, $context, $p, $data) = @_;

    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'Unexpected EAP request');
}

#####################################################################
# Called by EAP.pm when an EAP Response/Identity is received
sub response_identity
{
    my ($classname, $self, $context, $p) = @_;

    if (length($context->{identity}) < 1)
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP MD5-Challenge failed: Identity too short', $p);
    }

    # Generate a challenge into $context->{md5_challenge}
    unless ($self->md5_challenge($context, $p))
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP MD5-Challenge failed: Could not generate challenge', $p);
    }

    my $message = pack('C a16 a*', 
		       16,  # MD5 challenge length
		       $context->{md5_challenge},
		       $main::hostname);
    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_MD5_CHALLENGE, $message);
    return ($main::CHALLENGE, 'EAP MD5-Challenge');
}

#####################################################################
# Called by EAP.pm when an EAP Response (other than Identity)
# is received
# $id is the id of the received EAP response
sub response
{
    my ($classname, $self, $context, $p, $type, $typedata) = @_;

    # This should be a response to a challenge
    # we sent previously. The challenge is cached
    # in the challenges array, indexed by
    # challenge_id. The response should be the MD5 hash
    # the challenge_id, the password, the challenge
    my ($length, $response, $username) = unpack('C a16 a*', $typedata);

    my $identity = $context->{identity};

    $identity =~ s/@[^@]*$//
	if $self->{UsernameMatchesWithoutRealm};
    $identity = $self->eap_rewrite_identity($p, $identity, $self->{RewriteUsername})
	if (defined $self->{RewriteUsername});

    # OK, now we need the user details to check the password
    my ($user, $result, $reason) = $self->get_user($identity, $p);
    if ($user && $result == $main::ACCEPT)
    {
	my $correct_password = $self->get_stripped_plaintext_password($user);
	if ($self->check_md5($context, $p, $identity, $correct_password, chr($context->{this_id}), 
			     $context->{md5_challenge}, $response))
	{
	    $self->eap_success($p->{rp}, $context);
	    $self->authoriseUser($user, $p);
	    $self->adjustReply($p);
	    return ($main::ACCEPT, 'EAP MD5 Success');
	}
	else
	{
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'EAP MD5-Challenge failed: Bad password');
	}
    }
    else
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "EAP MD5-Challenge failed: $reason");
    }
}

1;
