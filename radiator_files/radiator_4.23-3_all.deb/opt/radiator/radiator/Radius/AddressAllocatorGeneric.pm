# AddressAllocatorGeneric.pm
#
# Object for handling generic address allocation
#
# Module for allocating addresses from an SQL database.
#
# Address allocation modules are required to implement these
# functions:
#
# allocate: takes a user name, pool hint and returns a hash of allocated
#   values. The keys in the returned hash may include:
#     yiaddr: the allocated IP address
#     subnetmask: a subnet mask that goes with the address
#     dnsserver: the address of a DNS server
#
# confirm: takes a previously allocated address and confirms that it
# is still in use
#
# deallocate: takes a previously allocated address and deallocates it
#
# deallocate_by_nas: deallocates all previously allocated address for the NAS.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::AddressAllocatorGeneric;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use strict;
use warnings;

# RCS version number of this module
$Radius::AddressAllocatorGeneric::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{ObjType} = 'AddressAllocator'; # Maintain an Identifier directory
}

#####################################################################
# Find the allocator module with the identifier name given
sub find
{
    return &Radius::Configurable::find('AddressAllocator', $_[0]);
}

#####################################################################
# Allocate an address for username with the given pool hint
# return a hash of interesting values for AuthBy DYNADDRESS
sub allocate
{
    my ($self, $caller, $username, $hint, $p) = @_;

    $self->log($main::LOG_ERR, "You forgot to override allocate() in " . ref($self), $p);
    return ($main::REJECT, "Method allocate() not implemented");
}

#####################################################################
# Confirm a previously allocated address is in use
sub confirm
{
    my ($self, $caller, $address, $p) = @_;

    $self->log($main::LOG_ERR, "You forgot to override confirm() in " . ref($self), $p);
    return ($main::REJECT, "Method confirm() not implemented");
}

#####################################################################
# Free a previously allocated address
sub deallocate
{
    my ($self, $caller, $address, $p) = @_;

    $self->log($main::LOG_ERR, "You forgot to override deallocate() in " . ref($self), $p);
    return ($main::REJECT, "Method deallocate() not implemented");
}

#####################################################################
# Free all previously allocated address for the NAS
sub deallocate_by_nas
{
    my ($self, $caller, $p) = @_;

    $self->log($main::LOG_ERR, "You forgot to override deallocate_by_nas() in " . ref($self), $p);
    return ($main::REJECT, "Method deallocate_by_nas() not implemented");
}

1;
