# ServGeneric.pm
#
# Generic object for handling service and subscription databases
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::ServGeneric;
use strict;
use warnings;
our @ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Service;
use Radius::Subscription;
use Radius::Util;

%Radius::ServGeneric::ConfigKeywords =
(
 'Tenant' =>
 ['string', 'Name of a tenant.', 1],
);

# RCS version number of this module
$Radius::ServGeneric::VERSION = '$Revision$';

# Global default instance handle
$Radius::ServGeneric::db = undef;

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    # Automatically register this object
    $self->{ObjType} = 'ServiceDatabase';

    $self->{Tenant} = 'default';

    return;
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # The last one in the config file is the default
    $Radius::ServGeneric::db = $self;

    return;
}

#####################################################################
sub find
{
    my ($identifier) = @_;

    my $ret = Radius::Configurable::find('ServiceDatabase', $identifier) || $Radius::ServGeneric::db;

    return $ret;
}

#####################################################################
sub flush
{
    my ($self) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override flush in ServGeneric");

    return 1;
}

#####################################################################
sub new_service
{
    my ($self, $id, $name, $tenant_id) = @_;

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    my $service = Radius::Service->new($id, $name, $tenant_id);
    if ($service)
    {
	$service->set_backend($self, $self->can('refresh_service'), $self->can('save_service'), $self->can('del_service'));
    }

    return $service;
}

#####################################################################
sub new_service_from_array
{
    my ($self, @array) = @_;

    # tenant_id
    my $tenant_id = $array[0];
    # id
    my $id = $array[1];
    # name
    my $name = $array[2];
    $id = $name if (!$id && $name);
    $name = $id if (!$name && $id);

    # price
    my $price = $array[3];
    # requireConfirm
    my $requires_confirmation = $array[4];
    $requires_confirmation = 1 unless defined $requires_confirmation;
    # checkItems
    my $check_items = $array[5];
    if ($check_items)
    {
	$check_items =~ s/^('|")//;
	$check_items =~ s/('|")$//;
    }
    # poolIPv4
    my $pool_v4 = $array[6];
    # poolIPv6
    my $pool_v6 = $array[7];
    # replyItems
    my $reply_items = $array[8];
    if ($reply_items)
    {
	$reply_items =~ s/^('|")//;
	$reply_items =~ s/('|")$//;
    }
    # expiry
    my $expiry = $array[9];
    $expiry = Radius::Util::convert_from_time_suffix($expiry) if defined $expiry;

    # prepaidTime
    my $prepaid_time = $array[10];
    $prepaid_time = Radius::Util::convert_from_time_suffix($prepaid_time) if defined $prepaid_time;
    # postpaidTime
    my $postpaid_time = $array[11];
    $postpaid_time = Radius::Util::convert_from_time_suffix($postpaid_time) if defined $postpaid_time;
    # prepaidQuota
    my $prepaid_data = $array[12];
    $prepaid_data = Radius::Util::convert_from_metric_prefix($prepaid_data) if defined $prepaid_data;
    # postpaidQuota
    my $postpaid_data = $array[13];
    $postpaid_data = Radius::Util::convert_from_metric_prefix($postpaid_data) if defined $postpaid_data;
    # allowQuotaToExceed
    my $allow_to_exceed = $array[14];
    # disallowResubscribe
    my $disallow_resubscribe = $array[15];
    # throtUpRate
    my $ul_throt = $array[16];
    $ul_throt = Radius::Util::convert_from_metric_prefix($ul_throt) if defined $ul_throt;
    # postpaidUpRate
    my $ul_rate = $array[17];
    $ul_rate = Radius::Util::convert_from_metric_prefix($ul_rate) if defined $ul_rate;
    # prepaidUpRate
    my $ul_max = $array[18];
    $ul_max = Radius::Util::convert_from_metric_prefix($ul_max) if defined $ul_max;
    # throtDownRate
    my $dl_throt = $array[19];
    $dl_throt = Radius::Util::convert_from_metric_prefix($dl_throt) if defined $dl_throt;
    # postpaidDownRate
    my $dl_rate = $array[20];
    $dl_rate = Radius::Util::convert_from_metric_prefix($dl_rate) if defined $dl_rate;
    # prepaidDownRate
    my $dl_max = $array[21];
    $dl_max = Radius::Util::convert_from_metric_prefix($dl_max) if defined $dl_max;

    my $service = $self->new_service($id, $name);
    return undef unless $service;

    $service->set_params($price, $pool_v4, $pool_v6, $check_items, $reply_items, !$requires_confirmation, $expiry, $allow_to_exceed, $disallow_resubscribe);
    $service->set_quotas($prepaid_time, $postpaid_time, $prepaid_data, $postpaid_data);
    $service->set_rates($ul_throt, $ul_rate, $ul_max, $dl_throt, $dl_rate, $dl_max);

    $service->{dirty} = 0;

    return $service;
}

#####################################################################
sub new_service_from_string
{
    my ($self, $service_definition, $id, $name) = @_;

    # E.g.
    # name:free price:0 prepaidTime:1h prepaidQuota:100M replyItems:"OSC-AVPAIR=Test1,OSC-AVPAIR=Test2"
    # name:premium price:1000 prepaidTime:24h prepaidUpRate:10M prepaidDownRate:100M

    my @def_keys = qw/id name price poolIPv4 poolIPv6 checkItems replyItems
	requireConfirm expiry prepaidTime
	postpaidTime prepaidQuota postpaidQuota allowQuotaToExceed disallowResubscribe prepaidUpRate prepaidDownRate
	postpaidUpRate postpaidDownRate throtUpRate throtDownRate/;
    my %definitions = map { $_ => undef } @def_keys;

    unless (index($service_definition, '{'))
    {
	# JSON beginning with '{'
	my $defs = Radius::Util::decode_json($service_definition);
	return undef unless ($defs && ref($defs) eq 'HASH');
	foreach my $key (keys %{$defs})
	{
	    my $value = $defs->{$key};
	    if (exists $definitions{$key} && defined $value)
	    {
		$definitions{$key} = $value;
	    }
	}
    }
    else
    {
	my @defs = split(/\s+/, $service_definition);
	foreach my $def (@defs)
	{
	    my ($key, $value) = split(/:/, $def, 2);
	    if (exists $definitions{$key} && defined $value)
	    {
		$definitions{$key} = $value;
	    }
	}
    }

    # id
    $id = $definitions{id} if $definitions{id};
    # name
    $name = $definitions{name} if $definitions{name};
    $id = $name if (!$id && $name);
    $name = $id if (!$name && $id);
    # price
    my $price = $definitions{price};
    # poolIPv4
    my $pool_v4 = $definitions{poolIPv4};
    # poolIPv6
    my $pool_v6 = $definitions{poolIPv6};
    # checkItems
    my $check_items = $definitions{checkItems};
    if ($check_items)
    {
	$check_items =~ s/^('|")//;
	$check_items =~ s/('|")$//;
    }
    # replyItems
    my $reply_items = $definitions{replyItems};
    if ($reply_items)
    {
	$reply_items =~ s/^('|")//;
	$reply_items =~ s/('|")$//;
    }

    # requireConfirm
    my $requires_confirmation = $definitions{requireConfirm};
    $requires_confirmation = 1 unless defined $requires_confirmation;
    # expiry
    my $expiry = $definitions{expiry};
    $expiry = Radius::Util::convert_from_time_suffix($expiry) if defined $expiry;
    # prepaidTime
    my $prepaid_time = $definitions{prepaidTime};
    $prepaid_time = Radius::Util::convert_from_time_suffix($prepaid_time) if defined $prepaid_time;
    # postpaidTime
    my $postpaid_time = $definitions{postpaidTime};
    $postpaid_time = Radius::Util::convert_from_time_suffix($postpaid_time) if defined $postpaid_time;
    # prepaidQuota
    my $prepaid_data = $definitions{prepaidQuota};
    $prepaid_data = Radius::Util::convert_from_metric_prefix($prepaid_data) if defined $prepaid_data;
    # postpaidQuota
    my $postpaid_data = $definitions{postpaidQuota};
    $postpaid_data = Radius::Util::convert_from_metric_prefix($postpaid_data) if defined $postpaid_data;
    # allowQuotaToExceed
    my $allow_to_exceed = $definitions{allowQuotaToExceed};
    # disallowResubscribe
    my $disallow_resubscribe = $definitions{disallowResubscribe};
    # throtUpRate
    my $ul_throt = $definitions{throtUpRate};
    $ul_throt = Radius::Util::convert_from_metric_prefix($ul_throt) if defined $ul_throt;
    # postpaidUpRate
    my $ul_rate = $definitions{postpaidUpRate};
    $ul_rate = Radius::Util::convert_from_metric_prefix($ul_rate) if defined $ul_rate;
    # prepaidUpRate
    my $ul_max = $definitions{prepaidUpRate};
    $ul_max = Radius::Util::convert_from_metric_prefix($ul_max) if defined $ul_max;
    # throtDownRate
    my $dl_throt = $definitions{throtDownRate};
    $dl_throt = Radius::Util::convert_from_metric_prefix($dl_throt) if defined $dl_throt;
    # postpaidDownRate
    my $dl_rate = $definitions{postpaidDownRate};
    $dl_rate = Radius::Util::convert_from_metric_prefix($dl_rate) if defined $dl_rate;
    # prepaidDownRate
    my $dl_max = $definitions{prepaidDownRate};
    $dl_max = Radius::Util::convert_from_metric_prefix($dl_max) if defined $dl_max;

    my $service = $self->new_service($id, $name);
    return undef unless $service;

    $service->set_params($price, $pool_v4, $pool_v6, $check_items, $reply_items, !$requires_confirmation, $expiry, $allow_to_exceed, $disallow_resubscribe);
    $service->set_quotas($prepaid_time, $postpaid_time, $prepaid_data, $postpaid_data);
    $service->set_rates($ul_throt, $ul_rate, $ul_max, $dl_throt, $dl_rate, $dl_max);

    return $service;
}

#####################################################################
sub get_service
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override get_service in ServGeneric");

    return undef;
}

#####################################################################
sub get_services
{
    my ($self, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override get_services in ServGeneric");

    return undef;
}

#####################################################################
sub refresh_service
{
    my ($self, $service, $child, $cb) = @_;

    return 0 unless $service;

    if (ref($service))
    {
	my ($id, $name, $tenant_id);
	if ($child)
	{
	    $id = $child->{parent_id};
	    $name = $child->{parent_name};
	    $tenant_id = $child->{tenant_id};
	}

	if (!${$service})
	{
	    ${$service} = Radius::Service->new($id, $name, $tenant_id);
	}
	$service = ${$service};
    }

    my $rc = 0;
    my $new_service = $self->get_service($service->{id}, $service->{name}, $service->{tenant_id});
    if ($new_service)
    {
	$service->set_from_service($new_service);
	$service->set_backend($self, $self->can('refresh_service'), $self->can('save_service'), $self->can('del_service'));
	$rc = 1;
    }

    if ($cb)
    {
	return;
    }

    return $rc;
}

#####################################################################
sub save_service
{
    my ($self, $service, $cb) = @_;

    return 0 unless $service;
    return 1 unless $service->{dirty};
    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override save_service in ServGeneric");

    return 1;
}

#####################################################################
sub del_service
{
    my ($self, $service, $cb) = @_;

    return 0 unless $service;
    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override del_service in ServGeneric");

    return 1;
}

#####################################################################
sub new_subscription_from_service_name
{
    my ($self, $id, $name, $service_id, $service_name, $tenant_id, $cb) = @_;

    return undef unless (defined $service_id || defined $service_name);

    if ($cb)
    {
	my $get_service_reply_cb = sub {
	    my ($service) = @_;
	    if ($service)
	    {
		my $subscription = $self->new_subscription_from_service($id, $name, $service);
		&{$cb}($subscription);
		return;
	    }
	};
	$self->get_service($service_id, $service_name, $tenant_id, $get_service_reply_cb);
	return;
    }

    my $subscription;
    my $service = $self->get_service($service_id, $service_name, $tenant_id);
    if ($service)
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Creating a new subscription of service '$service_name' for '$name'");
	$subscription = $self->new_subscription_from_service($id, $name, $service);
    }

    return $subscription;
}

#####################################################################
sub new_subscription_from_service
{
    my ($self, $id, $name, $service) = @_;

    return undef unless $service;

    my $subscription = Radius::Subscription->new_from_service($id, $name, $service);
    if ($subscription)
    {
	$subscription->set_backend($self, $self->can('refresh_subscription'), $self->can('save_subscription'), $self->can('del_subscription'));
    }

    return $subscription;
}

#####################################################################
sub new_subscription
{
    my ($self, $id, $name, $service_id, $service_name, $tenant_id) = @_;

    $tenant_id = $self->{Tenant} unless defined $tenant_id;
    my $subscription = Radius::Subscription->new($id, $name, $service_id, $service_name, $tenant_id);

    if ($subscription)
    {
	$subscription->set_backend($self, $self->can('refresh_subscription'), $self->can('save_subscription'), $self->can('del_subscription'));
    }

    return $subscription;
}

#####################################################################
sub new_subscription_from_array
{
    my ($self, @array) = @_;

    # tenant_id
    my $tenant_id = $array[0];
    # id
    my $id = $array[1];
    # name
    my $name = $array[2];
    $id = $name if (!$id && $name);
    $name = $id if (!$name && $id);
    # parent_id
    my $parent_id = $array[3];
    # parent_name
    my $parent_name = $array[4];

    # checkItems
    my $check_items = $array[5];
    if ($check_items)
    {
	$check_items =~ s/^('|")//;
	$check_items =~ s/('|")$//;
    }
    # poolIPv4
    my $pool_v4 = $array[6];
    # poolIPv6
    my $pool_v6 = $array[7];
    # replyItems
    my $reply_items = $array[8];
    if ($reply_items)
    {
	$reply_items =~ s/^('|")//;
	$reply_items =~ s/('|")$//;
    }
    # expiry
    my $expiry = $array[9];
    # allow_to_exceed
    my $allow_to_exceed = $array[10];
    # disallow_resubscribe
    my $disallow_resubscribe = $array[11];

    # quota_time_pre_left
    my $quota_time_pre_left = $array[12];
    # quota_time_post_left
    my $quota_time_post_left = $array[13];
    # quota_octets_pre_left
    my $quota_octets_pre_left = $array[14];
    # quota_octets_post_left
    my $quota_octets_post_left = $array[15];
    # refill_number
    my $refill_number = $array[16];
    # refilled_at
    my $refilled_at = $array[17];
    # user_name
    my $user_name = $array[18];
    # user_ref
    my $user_ref = $array[19];
    # charged_price
    my $charged_price = $array[20];
    # charge_ref
    my $charge_ref = $array[21];
    # charged_at
    my $charged_at = $array[22];
    # created_at
    my $created_at = $array[23];
    # confirmed_at
    my $confirmed_at = $array[24];
    # deleted_at
    my $deleted_at = $array[25];
    # updated_at
    my $updated_at = $array[26];
    # saved_at
    my $saved_at = $array[27];

    my $subscription = $self->new_subscription($id, $name, $parent_id, $parent_name);
    return undef unless $subscription;

    $subscription->set_params(undef, $pool_v4, $pool_v6, $check_items, $reply_items, $confirmed_at, $expiry, $allow_to_exceed, $disallow_resubscribe);
    $subscription->set_quotas_left($quota_time_pre_left, $quota_time_post_left, $quota_octets_pre_left, $quota_octets_post_left);
    $subscription->{refill_number} = $refill_number;
    $subscription->{refilled_at} = $refilled_at;
    $subscription->{user_name} = $user_name;
    $subscription->{user_ref} = $user_ref;
    $subscription->{charged_price} = $charged_price;
    $subscription->{charge_ref} = $charge_ref;
    $subscription->{charged_at} = $charged_at;
    $subscription->{created_at} = $created_at;
    $subscription->{confirmed_at} = $confirmed_at;
    $subscription->{deleted_at} = $deleted_at;
    $subscription->{updated_at} = $updated_at;
    $subscription->{saved_at} = $saved_at;
    $subscription->{dirty} = 0;

    return $subscription;
}

#####################################################################
sub get_subscription
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override get_subscription in ServGeneric");

    return undef;
}

#####################################################################
sub get_or_create_subscription
{
    my ($self, $id, $name, $service, $dont_create, $resubscribe, $tenant_id, $cb) = @_;

    my $subscription = $self->get_subscription($id, $name, $tenant_id);

    my $create_subscription = !$dont_create;
    if ($subscription)
    {
	$create_subscription = $resubscribe ? 1 : 0;
	if ($service && $subscription->{parent_id} ne $service->{id})
	{
	    # When no subscription for a service is found
	    # and $dont_create prevents from creating a new subscription,
	    # return an existing subscription
	    return undef if $dont_create;
	    # Else, create a new subscription with a new service if
	    # a new service has a higher price than existing subscription
	    if ($service->{price} > $subscription->{charged_price})
	    {
		$create_subscription = 1;
	    }
	}
    }

    if ($create_subscription)
    {
	if ($subscription)
	{
	    # Delete a previous subscription
	    my $rc = $subscription->expunge();
	    if ($rc)
	    {
		$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Deleted an old '$subscription->{parent_name}' subscription for '$name'");
		$subscription = undef;
	    }
	    else
	    {
		$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Deleting an old '$subscription->{parent_name}' subscription for '$name' failed");
	    }
	}
	if ($service)
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Creating a new '$service->{name}' subscription for '$name'");
	    $subscription = $self->new_subscription_from_service($id, $name, $service, $tenant_id);
	}
	else
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Creating a new subscription for '$name' failed, no service given");
	}
    }

    return $subscription;
}

#####################################################################
sub get_subscriptions
{
    my ($self, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override get_subscriptions in ServGeneric");

    return undef;
}

#####################################################################
sub refresh_subscription
{
    my ($self, $subscription, $child, $cb) = @_;

    return 0 unless $subscription;

    if (ref($subscription))
    {
	my ($id, $name, $tenant_id);
	if ($child)
	{
	    $id = $child->{parent_id};
	    $name = $child->{parent_name};
	    $tenant_id = $child->{tenant_id};
	}
	if (!${$subscription})
	{
	    ${$subscription} = Radius::Subscription->new($id, $name, $tenant_id);
	}
	$subscription = ${$subscription};
    }

    my $rc = 0;
    my $new_subscription = $self->get_subscription($subscription->{id}, $subscription->{name}, $subscription->{tenant_id});
    if ($new_subscription)
    {
	$subscription->set_from_subscription($new_subscription);
	$subscription->set_backend($self, $self->can('refresh_subscription'), $self->can('save_subscription'), $self->can('del_subscription'));
	$rc = 1;
    }

    if ($cb)
    {
	return;
    }

    return $rc;
}

#####################################################################
sub save_subscription
{
    my ($self, $subscription, $cb) = @_;

    return 0 unless $subscription;
    return 1 unless $subscription->{dirty};
    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override save_subscription in ServGeneric");

    return 1;
}

#####################################################################
sub del_subscription
{
    my ($self, $subscription, $cb) = @_;

    return 0 unless $subscription;
    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override del_subscription in ServGeneric");

    return 1;
}

#####################################################################
sub charge_subscription
{
    my ($self, $user_name, $id, $price, $subscription, $cb, @args) = @_;

    return 0 unless $subscription;
    return 1 if $subscription->{charged_at};

    $price = $subscription->{price} unless defined $price;
    my ($user_ref, $charge_ref);
    if ($cb)
    {
	($user_ref, $charge_ref, $price) = &{$cb}($user_name, $id, $price, $subscription, @args);
    }

    if (defined $user_ref)
    {
	$subscription->set_user_charge($user_name, $user_ref, time(), $price, $charge_ref);
	my $rc = $subscription->save();
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Saving a subscription failed: $subscription->{id}, $subscription->{name}") unless $rc;
	return $rc;
    }

    return 0;
}

1;
