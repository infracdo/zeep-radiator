# EAP_6.pm
#
# Module for  handling Authentication via EAP type 6 
# (Generic Token Card)
#
# Requires an AuthBy method that is compatible.
#
# See RFCs 2869 2284 1994
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2001 Open System Consultants
# $Id$

package Radius::EAP_6;
use strict;
use warnings;

# RCS version number of this module
$Radius::EAP_6::VERSION = '$Revision$';

#####################################################################
# Called by EAP.pm when the caller wants to know the EAP type name this class supports
sub type_name
{
    my ($classname) = @_;

    return 'GTC';
}

#####################################################################
# request
# Called by EAP.pm when a request is received for this protocol type
sub request
{
    my ($classname, $self, $context, $p, $data) = @_;

    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'Unexpected EAP request');
}

#####################################################################
# Called by EAP.pm when an EAP Response/Identity is received
sub response_identity
{
    my ($classname, $self, $context, $p) = @_;

    my $identity = $context->{identity};
    if (length($identity) < 1)
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP GTC failed: Identity too short', $p);
    }

   $identity =~ s/@[^@]*$//
	if $self->{UsernameMatchesWithoutRealm};
    my ($result, $message) = $self->gtc_start($context, $identity, $p);
    return &gtc_reply($self, $result, $message, $p, $context);
}

#####################################################################
# Called by EAP.pm when an EAP Response (other than Identity)
# is received
sub response
{
    my ($classname, $self, $context, $p, $type, $typedata) = @_;

    my $identity = $context->{identity};

    # Some EAP-GTC clients put the response in this format. This is
    # documented in RFC 5421 as EAP-FAST-GTC for use within EAP-FAST
    # tunnel. However, for example Cisco's PEAP implementation shipped
    # with some Windows laptops uses this format within PEAP.
    if ($typedata =~ /^RESPONSE=/ && $typedata =~ /\x00/)
    {
	# Remove prefix and split from first NUL octet
	$typedata =~ s/^RESPONSE=//;
	($identity, $typedata) = split(/\x00/, $typedata, 2);
    }

    my $max_gtc_length = (defined $self->{EAP_GTC_MaxLength}) ? $self->{EAP_GTC_MaxLength} : 253;
    if (length($typedata) > $max_gtc_length)
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "EAP_GTC_MaxLength $max_gtc_length exceeded. Received length " . length($typedata), $p);
    }

    if ($identity ne $context->{identity})
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "EAP GTC failed: Identity in response $identity does not match EAP identity $context->{identity}", $p);
    }

    return convert_to_pap($self, $context,$identity,$typedata, $p)
	if $self->{EAP_GTC_PAP_Convert};

    $identity =~ s/@[^@]*$//
	if $self->{UsernameMatchesWithoutRealm};
    my ($result, $message) = $self->gtc_continue($context, $identity, $typedata, $p);
    return &gtc_reply($self, $result, $message, $p, $context);
}

#####################################################################
# Convert this EAP-GTC into a conventional Radius PAP request and
# redispatch it for proxying (or perhaps local handling)
sub convert_to_pap
{
    my ($self, $context, $identity, $typedata, $p) = @_;

    # Make a new fake packet that contains something that looks like
    # an ordinary Radius PAP request
    my $tp = Radius::Radius->new($main::dictionary);

    # Add information from the original request
    foreach ($Radius::Radius::NAS_IP_ADDRESS,
	     $Radius::Radius::NAS_IDENTIFIER,
	     $Radius::Radius::NAS_PORT,
	     $Radius::Radius::NAS_PORT_TYPE,
	     $Radius::Radius::SERVICE_TYPE,
	     $Radius::Radius::CALLED_STATION_ID,
	     $Radius::Radius::CALLING_STATION_ID,
	     $Radius::Radius::STATE)
    {
	my $val = $p->getAttrByNum($_);
	$tp->addAttrByNum($_, $val) if defined $val;
    }

    $tp->set_code('Access-Request');

    $tp->{Client} = $p->{Client};
    $tp->{RecvTime} = $p->{RecvTime};
    $tp->{StatsTrail} = $p->{StatsTrail};
    $tp->{CachedAttrs}{NasId} = $p->getNasId();

    $tp->set_authenticator(&Radius::Util::random_string(16));
    # Arrange to call our reply function when we get a reply
    $tp->{replyFn} = [\&Radius::EAP_6::replyFn, $context];
    $tp->{outerRequest} = $p;

    # Now add the attributes to make it a fake radius request
    $tp->changeUserName($identity);
    $tp->add_attr('ConvertedFromGTC', 1); # Pseudo attribute to signal dispatcher

    $tp->{DecodedPassword} = $typedata;
    $tp->changeAttrByNum($Radius::Radius::USER_PASSWORD, '**obscured**');

    $context->{parent} = $self;

    # Call the PreHandlerHook, if there is one
    $self->runHook('PreHandlerHook', $tp, \$tp);
    main::log($main::LOG_DEBUG,"Converted EAP GTC PAP Packet dump:\n" . $tp->dump, $p)
	if (main::willLog($main::LOG_DEBUG, $p));

    my ($user, $realmName) = split(/@/, $identity);
    my ($handler, $result);
    foreach my $finder (@Radius::Client::handlerFindFn)
    {
	if ($handler = &$finder($tp, $user, $realmName))
	{
	    # Make sure the handler is updated with stats
	    push(@{$p->{StatsTrail}}, $handler->{Statistics});

	    # replyFn will be called from inside the handler when the
	    # reply is available
	    ($result, undef) = $handler->handle_request($tp);
	    last;
	}
    }
    unless ($handler)
    {
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "No Handler for converted EAP GTC PAP authentication");
    }

    $p->{proxied} = $tp->{proxied}; # Make sure stats are kept correct

   return ($result, "EAP GTC converted to Radius PAP and redispatched to a Handler");
}

#####################################################################
# This is called when a the EAP-GTC repsonse is converted
# into a conventional Radius PAP request, proxied or handled locally and then completed
# $tp is the (fake) request packet containing the Radius PAP request
sub replyFn
{
    my ($tp, $context) = @_;

    my $reply_code = $tp->{rp}->code();	 # The result of the inner auth
    my $self = $context->{parent};
    my $op = $tp->{outerRequest}; # This is the EAP-GTC request that was converted
    $op->{proxied} = $tp->{proxied};

    main::log($main::LOG_DEBUG,"Returned converted EAP GTC PAP Packet dump:\n" . $tp->{rp}->dump, $op)
	if (main::willLog($main::LOG_DEBUG, $op));
    if ($reply_code eq 'Access-Accept')
    {
	my $identity = $context->{identity};
	# copy reply attributes to outer reply
	$op->{rp}->add_attr_list($tp->{rp});

	$self->gtc_end($context, $identity, $op);
	$self->eap_success($op->{rp}, $context);
	$self->adjustReply($op);

	$op->{Handler}->handlerResult
	    ($op, $main::ACCEPT, 'Converted EAP GTC PAP authentication success')
	    if $tp->{proxied};
    }
    elsif ($reply_code eq 'Access-Reject')
    {
	my $identity = $context->{identity};
	$self->gtc_end($context, $identity, $op);
	$self->eap_failure($op->{rp}, $context);

	$op->{Handler}->handlerResult
	    ($op, $main::REJECT, 'Converted EAP GTC PAP authentication failed')
	    if $tp->{proxied};
    }
    elsif ($reply_code eq 'Access-Challenge')
    {
	my $message = $tp->{rp}->get_attr ('Reply-Message');
	# copy reply attributes to outer reply
	$op->{rp}->add_attr_list($tp->{rp});
	$self->eap_request($op->{rp}, $context, $Radius::EAP::EAP_TYPE_TOKEN, $message);

	$op->{Handler}->handlerResult
	    ($op, $main::CHALLENGE, 'Converted EAP GTC PAP authentication challenge')
	    if $tp->{proxied};
    }
}

#####################################################################
# Handle the result of a gtc_start or gtc_continue
sub gtc_reply
{
    my ($self, $result, $message, $p, $context) = @_;

    my $identity = $context->{identity};
    $identity =~ s/@[^@]*$//
	if $self->{UsernameMatchesWithoutRealm};
    if ($result == 2)
    {
	$self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_TOKEN, $message);
	return ($main::CHALLENGE, 'EAP GTC Challenge');
    }
    elsif ($result == 1)
    {
	$self->gtc_end($context, $identity, $p);
	$self->eap_success($p->{rp}, $context);
	$self->adjustReply($p);
	return ($main::ACCEPT, 'EAP GTC Success');
    }
    else
    {
	$self->gtc_end($context, $identity, $p);
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "EAP GTC failed: $message");
    }
}

1;
