# StatsLogFILE.pm
#
# Log statistics to a file.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002 Open System Consultants
# $Id$

package Radius::StatsLogFILE;
use strict;
use warnings;
our @ISA = qw(Radius::StatsLogGeneric);
use Radius::StatsLogGeneric;
use Radius::Util;

%Radius::StatsLogFILE::ConfigKeywords = 
('Filename' => 
 ['string', 'This is the name of the file to log statistics to. Defaults to %L/statistics. The file name can include special formatting characters as described in Section 5.2 on page 16, although data from the current request or reply are never available (logging is never done in the context of a current request).', 0],

 'Format'   => 
 ['string', 'This optional parameter specifies the format for each logging line. You can use this to control exactly what statistics are logged and in what order they appear.<p>
If Format is not defined, statistics data will be logged in the following order (also shown is the special character that is available for that data in the Format specification). All fields will be colon separated.
<p>See the Radiator Reference manual for more information', 1],

 'Header'   => 
 ['string', 'This optional parameter allows you to customize the Header line that is logged before each set of statistics. It can be useful for describing the contents of each column when importing into Excel etc.', 1],

 );

# RCS version number of this module
$Radius::StatsLogFILE::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Filename} = '%L/statistics';
}

sub check_config
{
    my ($self) = @_;

    # Warn user if OutputFormat is something else than text and Header/Format
    # is used.
    if (lc($self->{OutputFormat}) ne 'text')
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Format is ignored when using OutputFormat other than text.")
	    if (exists $self->{Format});
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Header is ignored when using OutputFormat other than text.")
	    if (exists $self->{Header});
    }
}

#####################################################################
# Open a logging file, call the superclass to do the object
# traversal. Our sub log will be called for each object
# requiring logging
sub logAll
{
    my ($self) = @_;

    # Process filename and store it
    $self->{stats_filename} = Radius::Util::format_special($self->{Filename});

    if ($self->{stats_filename} eq '-')
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Filename '-' is no longer supported in StatsLogFILE");
	return;
    }

    # Header is not supported when using custom output formatting
    if (lc($self->{OutputFormat}) eq 'text')
    {
	# Print a header line, if there is one
	if (defined $self->{Header})
	{
	    # Let them eliminate the header
	    Radius::Util::append($self->{stats_filename}, $self->{Header} . "\n")
		if $self->{Header} ne '';
	}
	else
	{
	    # Set default header. If StatsType is All, add an extra column that tells the statistics type.
	    my $default_header = '#time_stamp:type:identifier:';
	    $default_header .= 'stat_type:' if $self->{StatsType} eq $Radius::StatsLog::Type::All;
	    Radius::Util::append($self->{stats_filename}, $default_header . join(':', sort keys %Radius::StatsLogGeneric::statistic_names) . "\n");
	}
    }

    $self->SUPER::logAll();
}

#####################################################################
# Log all the Statistics from one object
sub logObject
{
    my ($self, $object) = @_;

    my $time = time;
    my $type = $object->{ObjType} || (split(/:/, ref($object)))[2];
    my $id = $object->{Identifier} || $object->{Name} || 'unknown';
    my $object_id = $main::config->{Identifier} . "/$type:$id";
    my $stats_href;

    unless (lc($self->{OutputFormat}) eq 'text')
    {
	my $values = { };
	if ($self->{StatsType} eq $Radius::StatsLog::Type::All)
	{
	    $self->get_all_statistics($object, $values);
	}
	else
	{
	    map { $values->{$_} = $self->get_statistics($object, $_) } keys %Radius::StatsLogGeneric::statistic_names;
	}
	my $entry = {
	    log_type => "radiator",
	    stats_type => $self->{StatsType},
	    time_elapsed => $self->{statistics}->{time_elapsed},
	    timestamp => $time,
	    object => $object_id,
	    main_pps => $self->{statistics}->{packet_rate},
	    %{$values},
	};
	Radius::Util::append($self->{stats_filename}, $self->format_output($entry) . "\n");
	return;
    }

    # StatsType All is is treated differently from the other types
    if ($self->{StatsType} eq $Radius::StatsLog::Type::All)
    {
	my $line;
	$stats_href = $self->get_all_statistics($object);
	foreach my $stat_type (@Radius::StatsLog::Types)
	{
	    if (defined $self->{Format})
	    {
		$line = Radius::Util::format_special($self->{Format}, undef, undef,
						     $time, $type, $id, $stat_type, @{$stats_href->{$stat_type}});
	    }
	    else
	    {
		$line = "$time:$type:$id:$stat_type:" . join(':', @{$stats_href->{$stat_type}});
	    }
	    Radius::Util::append($self->{stats_filename}, $line . "\n");
	}
    }
    else
    {
	my $line;
	my @values = map { $self->get_statistics($object, $_) } sort keys %Radius::StatsLogGeneric::statistic_names;
	if (defined $self->{Format})
	{
	    $line = Radius::Util::format_special($self->{Format}, undef, undef, $time, $type, $id, @values);
	}
	else
	{
	    $line = "$time:$type:$id:" . join(':', @values);
	}
	Radius::Util::append($self->{stats_filename}, $line . "\n");
    }
}

1;
