# AuthFIDELIOHOTSPOT.pm
#
# Object for handling hotspot Authentication and prepaid billing by
# Micros Fidelio Opera Hotel Property Management System (PMS)
# Superseded by AuthBy HOTSPOTFIDELIO
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2011 Open System Consultants
# $Id$

package Radius::AuthFIDELIOHOTSPOT;
use strict;
our @ISA = qw(Radius::AuthFIDELIO Radius::SqlDb);
use Radius::AuthFIDELIO;
use Radius::SqlDb;

%Radius::AuthFIDELIOHOTSPOT::ConfigKeywords = 
(
 'BlockDuration'     => 
 ['integer', 'Specifies a number of seconds a prepaid block of time will last for, from the time it is first purchased. Defaults to 86400 (1 day).', 1],

 'BlockPrice'     => 
 ['integer', 'Specifies a number without decimal indicator a prepaid block of time costs. Defaults to 900 (for example, USD 9.00).', 1],

 'ServiceAttribute'     =>
 ['string', 'Specifies RADIUS attribute that is used to detect different service rates', 1],

 'ServiceAttributePrefix'     =>
 ['string', 'Specifies the prefix in ServiceAttribute. You need to specify this if there is possibility to have multiple RADIUS attributes that are defined to be ServiceAttribute', 1],

 'ConfirmUpgradeOrRenew'     =>
 ['flag', 'Use Access-Reject to ask for confirmation of the upgrade or renewal charge. Disabled by default.', 1],

 'ConfirmationMessage'     =>
 ['string', 'Specifies the message that will ask the guest to confirm the upgrade or renwal charge', 1],

 'ConfirmationQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the query used to add the record about the upgrade or renewal confirmation.', 1],

 'ConfirmationQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with ConfirmationQuery.', 1],

 'PostSendQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the insert query used to insert Posting record data.', 1],

 'PostSendQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with PostSendQuery.', 1],

 'PostAnswerQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the insert query used to insert Posting Answer (PA) data.', 1],

 'PostAnswerQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables (where supported by the SQL server) and query caching. If you specify one or more PostAnswerQuery parameters, they will be used in order to replace parameters named with a question mark (\`?\') in PostAnswerQuery, and the query will be cached for future reuse by the SQL server. Only the first QueryCacheSize queries will be cached.', 1],

 'GetServiceQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the query used to fetch information about a service.', 1],

 'GetServiceQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with GetServiceQuery.', 1],

 'GetCurrentServiceQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the query used to fetch information about the current prepaid session and service.', 1],

 'GetCurrentServiceQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with GetCurrentServiceQuery.', 1],

 'AddSessionQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the query used to add information about current prepaid and postpaid session.', 1],

 'AddSessionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with AddSessionQuery.', 1],

 'GetSessionQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the query used to fetch information about the current postpaid session.', 1],

 'GetSessionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with GetSessionQuery.', 1],

 'UpdateSessionQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the query used to update information about the current prepaid and postpaid session.', 1],

 'UpdateSessionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with UpdateSessionQuery.', 1],

);

# RCS version number of this module
$Radius::AuthFIDELIOHOTSPOT::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->Radius::AuthFIDELIO::initialize;
    $self->Radius::SqlDb::initialize;

    $self->{BlockDuration} = 86400; # One day
    $self->{BlockPrice} = 900; # Cents
    $self->{ConfirmUpgradeOrRenew} = 0;
    $self->{ConfirmationMessage} = "You are going to upgrade or renew your plan, please login again to confirm the charge";

    $self->{ConfirmationQuery} = "UPDATE sessions SET confirmation_requested=1 WHERE roomNumber=%0 AND guestNumber=%1 AND macAddress=%2";

    $self->{PostSendQuery} = "INSERT INTO posts (roomNumber, guestNumber, macAddress, postNumber, posted, cost) VALUES (%0, %1, %2, %3, %4, %5)";
    $self->{PostAnswerQuery} = "INSERT INTO postacks (roomNumber, postNumber, transactionNumber, received) VALUES (%0, %1, %2, %3)";

    $self->{GetServiceQuery} = "SELECT price, duration, replyattributes FROM services WHERE serviceclass=%0";
    $self->{GetCurrentServiceQuery} = "SELECT expiry,replyattributes,price,sessions.serviceclass,confirmation_requested FROM sessions LEFT JOIN services ON sessions.serviceclass=services.serviceclass WHERE roomNumber=%0 AND guestNumber=%1 AND macAddress=%2";

    $self->{AddSessionQuery} = "INSERT INTO sessions (roomNumber, guestNumber, macAddress, serviceclass, expiry) VALUES (%0, %1, %2, %3, %4)";
    $self->{GetSessionQuery} = "SELECT expiry FROM sessions WHERE roomNumber=%0 AND guestNumber=%1 AND macAddress=%2";
    $self->{UpdateSessionQuery} = "UPDATE sessions SET serviceclass=%3, expiry=%4, confirmation_requested=0 where roomNumber=%0 AND guestNumber=%1 AND macAddress=%2";
 }

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->Radius::AuthFIDELIO::activate;
    $self->Radius::SqlDb::activate;
}

sub check_config
{
    my ($self) = @_;

    $self->Radius::AuthFIDELIO::check_config();
    $self->Radius::SqlDb::check_config();

    $self->log($main::LOG_INFO, "AuthBy FIDELIOHOTSPOT is superseded by AuthBy HOTSPOTFIDELIO. See Radiator reference for more about upgrading");

    return;
}

#####################################################################
# Overrides handle_message in AuthFIDELIO
sub handle_message
{
    my ($self, $type, $record) = @_;

    $self->SUPER::handle_message($type, $record);

    # Special local handling for PA, record to SQL database
    if ($type eq 'PA' && $record->{AS} eq 'OK')
    {
	# Posting was accepted, log it
	my $postNumber = $record->{'P#'};
	my ($transactionNumber) = $record->{CT} =~ /Interface transaction number\/s - (\d+)/;
	$transactionNumber = 0 unless defined $transactionNumber;
	my $timestamp_now = Radius::Util::strftime('%Y-%m-%d %T', time());

	if ($self->{PostAnswerQueryParam})
	{
	    my @bind_values;
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, undef, $self,
			  $record->{RN},
			  $postNumber,
			  $transactionNumber,
			  $timestamp_now)),
		 @{$self->{PostAnswerQueryParam}});
	    $self->prepareAndExecute($self->{PostAnswerQuery}, @bind_values);
	}
	else
	{
	    $self->do(Radius::Util::format_special(
			  $self->{PostAnswerQuery}, undef, $self,
			  $self->quote($record->{RN}),
			  $postNumber,
			  $transactionNumber,
			  $self->quote($timestamp_now)));
	}
    }
}

#####################################################################
# Overrides handle_request in AuthGENERIC
# Authenticates with AuthFIDELIO then checks for prepaid block time, billing to Fidelio if a new one is required.
sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    # First authenticate using the standard AuthFIDELIO
    my ($result, $reason) = $self->Radius::AuthFIDELIO::handle_request($p, $dummy, $extra_checks);
    return ($result, $reason)
	unless $p->code eq 'Access-Request' && $result == $main::ACCEPT;

    # Auth is complete, now look for a prepaid session
    my $room = $p->getUserName();   # Room number
    my $gn = $p->decodedPassword(); # Guest number
    if ($gn eq '')
    {
	# CHAP? Recover the correct G# from the users User-Password
	# First find the right user record
	my ($user,  $checkResult, $reason, $authenticated, $found) = $self->Radius::AuthFIDELIO::get_user($room, $p);
	if (!$user)
	{
	    $self->log($main::LOG_ERR, "Could not recover guest number for $room", $p);
	    return ($main::IGNORE, 'Could not recover guest number');
	}
	$gn = $user->{fidelio_gn}; # AuthFIDELIO::find_user caches this for us
    }

    my $mac = $p->getAttrByNum($Radius::Radius::CALLING_STATION_ID);
    my $duration = $self->{BlockDuration};
    my $cost = $self->{BlockPrice};
    my ($serviceclass) = ''; # Value depends on ServiceAttribute parameter
    my ($price, $replyattrs, $expiry, $confirmation_requested);
    my $timenow = time();
    my $timestamp_now = Radius::Util::strftime('%Y-%m-%d %T', $timenow);

    if (defined $self->{ServiceAttribute})
    {
	my ($current_replyattrs, $current_price, $current_serviceclass);
	my ($q, @bind_values);

	# The user is charged by services they buy. First get the
	# service they are ordering from the RADIUS request.
	my @serviceclass= $p->get_attr($self->{ServiceAttribute});
	unless (@serviceclass)
	{
	    # Now get information about their session state and current service.
	    @bind_values = ();
	    if ($self->{GetCurrentServiceQueryParam})
	    {
		$q = $self->{GetCurrentServiceQuery};
		@bind_values = ();
		map (push(@bind_values, Radius::Util::format_special(
			      $_, $p, $self,
			      $room, $gn, $mac)),
		     @{$self->{GetCurrentServiceQueryParam}});
	    }
	    else
	    {
		$q = Radius::Util::format_special($self->{GetCurrentServiceQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac));
	    }

	    my $sth = $self->prepareAndExecute($q, @bind_values);
	    return ($main::IGNORE, 'GetCurrentServiceQuery failed for session') unless $sth;

	    ($expiry, $current_replyattrs, $current_price, $current_serviceclass, $confirmation_requested) = $self->getOneRow($sth);
	    $expiry = Radius::Util::parseDate($expiry) - $timenow if defined $expiry;

	    unless (defined $current_serviceclass)
	    {
		$self->log($main::LOG_ERR, "Access-Request doesn't contain ServiceAttribute: $self->{ServiceAttribute}");
		return ($main::REJECT, "Error processing request");
	    }

	    $serviceclass = $current_serviceclass;
	}
	else
	{
	    foreach my $sc (@serviceclass)
	    {
		next unless $sc =~ /^$self->{ServiceAttributePrefix}(.*)$/;
		$serviceclass = $1;
		last;
	    }
	    unless ($serviceclass)
	    {
		$self->log($main::LOG_ERR, "Unable to find ServiceAttribute: $self->{ServiceAttribute} that begins $self->{ServiceAttributePrefix}");
		return ($main::REJECT, "Error processing request");
	    }
	}

	# Got the service. Now fetch the service information from the DB.
	@bind_values = ();
	if ($self->{GetServiceQueryParam})
	{
	    $q = $self->{GetServiceQuery};
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, $p, $self,
			  $serviceclass)),
		 @{$self->{GetServiceQueryParam}});
	}
	else
	{
	    $q = Radius::Util::format_special($self->{GetServiceQuery}, $p, $self, $self->quote($serviceclass));
	}

	my $sth = $self->prepareAndExecute($q, @bind_values);
	return ($main::IGNORE, 'GetServiceQuery failed') unless $sth;

	($price, $duration, $replyattrs) = $self->getOneRow($sth);
	$duration = $self->{BlockDuration} unless $duration;
	unless (defined $price)
	{
	    $self->log($main::LOG_ERR, "Unable to find service class $serviceclass from the services table");
	    return ($main::REJECT, "Error processing request");
	}

	unless (defined $current_serviceclass)
	{
	    # Now get information about their session state and current
	    # service. Then check for changes that require charging.
	    @bind_values = ();
	    if ($self->{GetCurrentServiceQueryParam})
	    {
		$q = $self->{GetCurrentServiceQuery};
		@bind_values = ();
		map (push(@bind_values, Radius::Util::format_special(
			      $_, $p, $self,
			      $room, $gn, $mac)),
		     @{$self->{GetCurrentServiceQueryParam}});
	    }
	    else
	    {
		$q = Radius::Util::format_special($self->{GetCurrentServiceQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac));
	    }

	    $sth = $self->prepareAndExecute($q, @bind_values);
	    return ($main::IGNORE, 'GetCurrentServiceQuery failed') unless $sth;

	    ($expiry, $current_replyattrs, $current_price, $current_serviceclass, $confirmation_requested) = $self->getOneRow($sth);
	    $expiry = Radius::Util::parseDate($expiry) - $timenow if defined $expiry;
	}

    	if (defined $current_serviceclass && $serviceclass ne $current_serviceclass)
    	{
	    if (defined $current_price && $current_price < $price)
	    {
		$expiry = 0;
	    }
	    elsif ($expiry > 0)
	    {
		$replyattrs = $current_replyattrs;
	    }
    	}

	$cost = $price; # Price might be 0 too.
    }
    else
    {
	my ($q, @bind_values);
	if ($self->{GetSessionQueryParam})
	{
	    $q = $self->{GetSessionQuery};
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, $p, $self,
			  $room, $gn, $mac)),
		 @{$self->{GetSessionQueryParam}});
	}
	else
	{
	    $q = Radius::Util::format_special($self->{GetSessionQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac));
	}

	my $sth = $self->prepareAndExecute($q, @bind_values);
	return ($main::IGNORE, 'GetSessionQuery failed') unless $sth;

	($expiry) = $self->getOneRow($sth);
	$expiry = Radius::Util::parseDate($expiry) - $timenow if defined $expiry;
    }

    if (!defined $expiry)
    {
	# Not previously logged in, bill them and create a new session

	# Insert into sessions table
	my $expirytime = $timenow + $duration;
	my $expirytimestamp = Radius::Util::strftime('%Y-%m-%d %T', $expirytime);
	my ($q, @bind_values);
	if ($self->{AddSessionQueryParam})
	{
	    $q = $self->{AddSessionQuery};
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, $p, $self,
			  $room, $gn, $mac, $serviceclass, $expirytimestamp)),
		 @{$self->{AddSessionQueryParam}});
	}
	else
	{
	    $q = Radius::Util::format_special($self->{AddSessionQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac), $self->quote($serviceclass), $self->quote($expirytimestamp));
	}

	return ($main::IGNORE, 'AddSessionQuery failed') unless $self->do($q, @bind_values);

	# Send post to Fidelio
	return ($main::IGNORE, 'Post to Fidelio failed') unless $self->post($room, $gn, $cost, $duration, $p);

	# Insert into posts table
	return ($main::IGNORE, 'PostSendQuery failed') unless $self->do_post_send_query($p, $room, $gn, $mac, $self->{posting_sequence}, $timestamp_now, $cost);

	# Set the Session-Timeout to the available duration
	$p->{rp}->addAttrByNum($Radius::Radius::SESSION_TIMEOUT, $duration);
    }
    elsif ($expiry > 0)
    {
	# Some prepaid time left, let them use it
	# Set the Session-Timeout to the remaining time
	$p->{rp}->addAttrByNum($Radius::Radius::SESSION_TIMEOUT, $expiry);
    }
    else
    {
	# Prepaid time has been exhausted or guest wants to change the service. Buy some more

	# If prepaid services are enabled, check if the guest needs to
	# confirm the purchase first.
	if ($self->{ServiceAttribute} && $self->{ConfirmUpgradeOrRenew} && $confirmation_requested == 0 && $price != 0)
	{
	    my ($q, @bind_values);
	    if ($self->{ConfirmationQueryParam})
	    {
		$q = $self->{ConfirmationQuery};
		map (push(@bind_values, Radius::Util::format_special(
			      $_, $p, $self,
			      $room, $gn, $mac)),
		     @{$self->{ConfirmationQueryParam}});
	    }
	    else
	    {
		$q = Radius::Util::format_special($self->{ConfirmationQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac));
	    }
	    return ($main::IGNORE, 'ConfirmationQuery failed') unless $self->do($q, @bind_values);
	    return ($main::REJECT, $self->{ConfirmationMessage});
	}

	# Update the sessions table
	my $expirytime = $timenow + $duration;
	my $expirytimestamp = Radius::Util::strftime('%Y-%m-%d %T', $expirytime);
	my ($q, @bind_values);
	if ($self->{UpdateSessionQueryParam})
	{
	    $q = $self->{UpdateSessionQuery};
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, $p, $self,
			  $room, $gn, $mac, $serviceclass, $expirytimestamp)),
		 @{$self->{UpdateSessionQueryParam}});
	}
	else
	{
	    $q = Radius::Util::format_special($self->{UpdateSessionQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac), $self->quote($serviceclass), $self->quote($expirytimestamp));
	}
	return ($main::IGNORE, 'UpdateSessionQuery failed') unless $self->do($q, @bind_values);

	# Send post to Fidelio
	return $main::IGNORE unless $self->post($room, $gn, $cost, $duration, $p);

	# Insert into posts table
	return $main::IGNORE unless $self->do_post_send_query($p, $room, $gn, $mac, $self->{posting_sequence}, $timestamp_now, $cost);

	# Set the Session-Timeout to the available duration
	$p->{rp}->addAttrByNum($Radius::Radius::SESSION_TIMEOUT, $duration);
    }

    # Add the service's reply attributes
    $p->{rp}->parse($replyattrs);
    return $main::ACCEPT;
}

# Store information about the Posting message we are sending
sub do_post_send_query
{
    my ($self, $p, $room, $gn, $mac, $posting_sequence, $timestamp_now, $cost) = @_;

    my ($q, @bind_values);
    if ($self->{PostSendQueryParam})
    {
	$q = $self->{PostSendQuery};
	map (push(@bind_values, Radius::Util::format_special(
		      $_, $p, $self,
		      $room, $gn, $mac, $posting_sequence, $timestamp_now, $cost)),
	     @{$self->{PostSendQueryParam}});
    }
    else
    {
	$q = Radius::Util::format_special($self->{PostSendQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac), $posting_sequence, "'$timestamp_now'", $cost);
    }

    return $self->do($q, @bind_values);
}
1;
