# Gossip.pm
#
# Object for Radiator cluster communication.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::Gossip;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Util;
use Radius::Select;
use Radius::Log;
use Data::MessagePack;

use strict;
use warnings;

%Radius::Gossip::ConfigKeywords =
(

 'Debug' =>
 ['flag', 'This optional flag enables debugging within the Radius::Gossip and its derived modules. It will enable the logging of the details of all messages sent and received. Defaults to no debugging', 1],

 'Secret' =>
 ['stringhash', 'This optional passphrase enables encryption/decryption of sent Gossip messages.', 1],

 'EncryptedSecret' =>
 ['stringhash', 'This optional passphrase enables encryption/decryption of sent Gossip messages. EncryptedSecret is in encrypted format and is preferred over Secret.', 1],

);

# RCS version number of this module
$Radius::Gossip::VERSION = '$Revision$';

# There is only one instance currently
$Radius::Gossip::handle = undef;

# Predefined destinations
$Radius::Gossip::Destination::ALL = "Gossip-All";
$Radius::Gossip::Destination::ANY = "Gossip-Any";

# Message types
$Radius::Gossip::Message::REPLY = 0x00;
$Radius::Gossip::Message::REQUEST = 0x01;
$Radius::Gossip::Message::NOTIFICATION = 0x02;
$Radius::Gossip::Message::KEEPALIVE = 0x04;

$Radius::Gossip::Message::ENCRYPTED = 0x10;
$Radius::Gossip::Message::WAITING_SINGLE_REPLY = 0x20;

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{message_handlers} = {};
    $self->{pull_message_timers} = {};
    $self->{use_message_header} = 0;
    $self->{msg_counter} = 0;
    $self->{encryption_keys} = undef;
    $self->{use_encryption} = 0;
    $self->{curr_encryption_keyid} = undef;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    if ($self->{Debug})
    {
	eval {
	    require Data::Printer;
	    Data::Printer->import;
	};
	if ($@)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_name}: Configuration parameter Debug requires Perl Data::Printer module. Disabling Debug.");
	    undef $self->{Debug};
	}
    }

    if ($self->{EncryptedSecret} || $self->{Secret})
    {
	# Encryption is required. Even if we don't have usable keys
	# we won't change this.
	$self->{use_encryption} = 1;

	# Prefer EncryptedSecret but fall back to Secret
	my $secrets = $self->{EncryptedSecret};
	my $param_name = 'EncryptedSecret';
	unless ($secrets)
	{
	    $secrets = $self->{Secret};
	    $param_name = 'Secret';
	}
	# Copy the keys and secrets. We may modify the keys below.
	$self->{gossip_secrets} = { %$secrets };

	eval {
	    require Radius::AES_GCM;
	    Radius::AES_GCM->import();
	};
	if ($@)
	{
	    my $msg = "$self->{log_class_name}: Configuration parameter $param_name requires Radius::AES_GCM module. Confirm you have its dependencies installed:\n$@";
	    $self->log($main::LOG_ERR, $msg);
	    die "$msg";
	}

	# Catches non-existing, empty, zero and non-numeric key indices which are all suspicious
	my @nans = grep { !$self->{gossip_secrets}->{$_} || !/^\d+$/ || $_ == 0} keys (%{$self->{gossip_secrets}});
	foreach my $nan (@nans)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_name}: Ignoring bad value for parameter $param_name with key index $nan");
	    delete $self->{gossip_secrets}->{$nan};
	}

	if ($param_name eq 'EncryptedSecret')
	{
	    # Decrypt the encrypted secrets. Skip those that fail
	    # decryption.
	    foreach my $keyid (keys(%{$self->{gossip_secrets}}))
	    {
		my $encrypted = $self->{gossip_secrets}->{$keyid};
		my $plaintext = Radius::Util::decrypt_value($encrypted);
		if (defined $plaintext)
		{
		    $self->{gossip_secrets}->{$keyid} = $plaintext;
		    next;
		}
		delete $self->{gossip_secrets}->{$keyid};
		$self->log($main::LOG_ERR, "$self->{log_class_name}: Could not decrypt EncryptedSecret key, index: $keyid");
	    }
	}

	$self->log($main::LOG_ERR, "$self->{log_class_name}: No usable keys. Check Gossip $param_name parameters")
	    unless %{$self->{gossip_secrets}};
    }

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    my $prev_keyid;
    foreach my $keyid (sort {$a <=> $b} keys %{$self->{gossip_secrets}})
    {
	$self->{encryption_keys}->{$keyid} = Radius::AES_GCM::make_key($self->{gossip_secrets}->{$keyid});
        $prev_keyid = $self->{curr_encryption_keyid};
        $self->{curr_encryption_keyid} = $keyid;
    }

    # For key rollover: Use the second last when there are multiple
    $self->{curr_encryption_keyid} = $prev_keyid
	if (keys (%{$self->{encryption_keys}}) > 1);

    return;
}

# Tell everybody (aka. publish)
sub tell_others
{
    my ($self, $message_hash) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Publishing message to everybody: " . np($message_hash)) if $self->{Debug};

    my $header = $self->make_header($message_hash);
    my $packed_message = eval {Data::MessagePack->pack($message_hash)};

    unless ($packed_message)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to pack a message in tell_others() !");
	return;
    }

    if ($self->{use_encryption})
    {
	my $encrypted_message = $self->encrypt_message($header, $packed_message);
	return unless $encrypted_message;
	$self->handle_message_publish($header . $encrypted_message);
    }
    else
    {
	$self->handle_message_publish($header . $packed_message);
    }
}

# Tell just one destination
sub tell
{
    my ($self, $destination, $message_hash) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Sending message to '$destination': " . np($message_hash)) if $self->{Debug};

    my $header = $self->make_header($message_hash);
    my $packed_message = eval {Data::MessagePack->pack($message_hash)};

    unless ($packed_message)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to pack a message in tell() !");
	return;
    }

    if ($self->{use_encryption})
    {
	my $encrypted_message = $self->encrypt_message($header, $packed_message);
	return unless $encrypted_message;
	$self->handle_message_publish($header . $encrypted_message, $destination);
    }
    else
    {
	$self->handle_message_publish($header . $packed_message, $destination);
    }
}

# Send a note (others have to ask for it later)
# Asynchronous operation is done when $callback is undef
sub note
{
    my ($self, $destination, $message_hash, $time_to_live, $callback) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Sending note for '$destination': " . np($message_hash)) if $self->{Debug};

    my $header = $self->make_header($message_hash);
    my $packed_message = eval {Data::MessagePack->pack($message_hash)};

    unless ($packed_message)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to pack a message in note() !");
	return;
    }

    if ($self->{use_encryption})
    {
	my $encrypted_message = $self->encrypt_message($header, $packed_message);
	return unless $encrypted_message;
	$self->handle_message_send($destination, $header . $encrypted_message, $time_to_live, $callback);
    }
    else
    {
	$self->handle_message_send($destination, $header . $packed_message, $time_to_live, $callback);
    }
}

# Push a note (others have to pop it later)
# Asynchronous operation is done when $callback is undef
sub push
{
    my ($self, $destination, $message_hash, $time_to_live, $callback) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Pushing a message to '$destination': " . np($message_hash)) if $self->{Debug};

    my $header = $self->make_header($message_hash);
    my $packed_message = eval {Data::MessagePack->pack($message_hash)};

    unless ($packed_message)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to pack a message in note() !");
	return;
    }

    if ($self->{use_encryption})
    {
	my $encrypted_message = $self->encrypt_message($header, $packed_message);
	return unless $encrypted_message;
	$self->handle_message_push($destination, $header . $encrypted_message, $time_to_live, $callback);
    }
    else
    {
	$self->handle_message_push($destination, $header . $packed_message, $time_to_live, $callback);
    }
}

# Delete a note
# Asynchronous operation is done when $callback is undef
sub forget
{
    my ($self, $destination, $callback) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Deleting note for '$destination'") if $self->{Debug};

    $self->handle_message_delete($destination, $callback);
}

# Something was told me, this function is called by handle_message_received
sub hear
{
    my ($self, $packed_message) = @_;

    my $header = $self->strip_header($packed_message);

    if ($self->{use_encryption})
    {
	$packed_message = $self->decrypt_message($header, $packed_message);
	return unless $packed_message;
    }

    my $unpacked_message = eval {Data::MessagePack->unpack($packed_message)};

    if (! $unpacked_message)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to unpack a message in hear() !");
	return;
    }
    elsif (ref($unpacked_message) ne 'HASH')
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: incorrect message format in hear(): " . ref($unpacked_message));
	return;
    }

    my $message_type = $unpacked_message->{type};
    unless (defined $message_type)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: No message type defined in hear() !");
	return;
    }

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Heard message: " . np($unpacked_message)) if $self->{Debug};

    $unpacked_message->{orig_header} = $header if $header;
    # call all handlers registered for this message type
    foreach my $callback (@{$self->{message_handlers}{$message_type}})
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_name}: Calling callback for message type '$message_type'") if $self->{Debug};
	&$callback($unpacked_message) if (defined $callback && ref($callback) eq 'CODE');
    }
}

# I would like to know something
# Asynchronous operation is done when $callback is undef
sub ask
{
    my ($self, $destination, $callback) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Asking for message for '$destination'") if $self->{Debug};

    my $packed_message = $self->handle_message_fetch($destination, $callback);

    if (! $callback && $packed_message)
    {
	my $header = $self->strip_header($packed_message);

	if ($self->{use_encryption})
	{
	    $packed_message = $self->decrypt_message($header, $packed_message);
	    return unless $packed_message;
	}

	my $unpacked_message = eval {Data::MessagePack->unpack($packed_message)};
	unless ($unpacked_message)
	{
	    $self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to unpack a message in ask() !");
	    return;
	}

	$self->log($main::LOG_DEBUG, "$self->{log_class_name}: Received message: " . np($unpacked_message)) if $self->{Debug};

	return $unpacked_message;
    }

    return;
}

# I would like to know something
# Synchronous operation is done when $callback is undef
sub pop
{
    my ($self, $destination, $callback) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Popping a message from '$destination'") if $self->{Debug};

    my $packed_message = $self->handle_message_pop($destination, $callback);

    if (! $callback && $packed_message)
    {
	my $header = $self->strip_header($packed_message);

	if ($self->{use_encryption})
	{
	    $packed_message = $self->decrypt_message($header, $packed_message);
	    return unless $packed_message;
	}

	my $unpacked_message = eval {Data::MessagePack->unpack($packed_message)};
	unless ($unpacked_message)
	{
	    $self->log($main::LOG_WARNING, "$self->{log_class_name}: Unable to unpack a message in pop()!");
	    return;
	}

	$self->log($main::LOG_DEBUG, "$self->{log_class_name}: Popped message: " . np($unpacked_message)) if $self->{Debug};

	return $unpacked_message;
    }

    return;
}

sub register_message_handle
{
    my ($self, $message_type, $handler_handle) = @_;

    CORE::push @{$self->{message_handlers}{$message_type}}, $handler_handle;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Registered handle for message type '$message_type'");

    return;
}

sub register_pull_message_handle
{
    my ($self, $message_type, $timeout, $count, $handler_handle) = @_;

    $count = 1 unless $count;

    # For now, support only a single timer per $message_type
    if (exists $self->{pull_message_timers}->{$message_type})
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: A message type '$message_type' already has a pull handler timer registered");
	return;
    }
    else
    {
	$self->{pull_message_timers}->{$message_type} =
	    Radius::Select::add_timeout(time + 1 + $timeout, \&Radius::Gossip::handle_pull_message_timeout, $self, $message_type, $count, $timeout);
    }

    $self->register_message_handle($message_type, $handler_handle);

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Registered pull handler timer for message type '$message_type'");

    return;
}

sub deregister_message_handle
{
    my ($self, $message_type, $handler_handle) = @_;

    @{$self->{message_handlers}{$message_type}} = grep {$_ != $handler_handle} @{$self->{message_handlers}{$message_type}};

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Deregistered handle for message type '$message_type'");

    return;
}

sub deregister_pull_message_handle
{
    my ($self, $message_type, $handler_handle) = @_;

    if (exists $self->{pull_message_timers}->{$message_type})
    {
	Radius::Select::remove_timeout($self->{pull_message_timers}->{$message_type})
	    || $self->log($main::LOG_ERR, "$self->{log_class_name}: Timeout $self->{pull_message_timers}->{$message_type} was not in the timeout list");
    }
    else
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: A message type '$message_type' did not have a pull handler timer registered");
    }

    $self->deregister_message_handle($message_type, $handler_handle);

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Deregistered pull handle for message type '$message_type'");

    return;
}

sub handle_message_received
{
    my ($self, $message) = @_;

    # Don't process further if message is empty
    unless ($message)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: handle_message_received() received an empty message!");
	return;
    }

    $self->hear($message);
}

sub handle_message_send
{
    my ($self, $destination, $message, $time_to_live, $callback) = @_;

    my $type = ref($self);
    $self->log($main::LOG_ERR, "$self->{log_class_name}: Method handle_message_send is not implemented for $type");

    return;
}

sub handle_message_push
{
    my ($self, $destination, $message, $time_to_live, $callback) = @_;

    my $type = ref($self);
    $self->log($main::LOG_ERR, "$self->{log_class_name}: Method handle_message_push is not implemented for $type");

    return;
}

sub handle_message_fetch
{
    my ($self, $destination, $callback) = @_;

    my $type = ref($self);
    $self->log($main::LOG_ERR, "$self->{log_class_name}: Method handle_message_fetch is not implemented for $type");

    return;
}

sub handle_message_pop {
    my ($self, $source, $callback) = @_;

    my $type = ref($self);
    $self->log($main::LOG_ERR, "$self->{log_class_name}: Method handle_message_pop is not implemented for $type");

    return;
}

sub handle_message_delete
{
    my ($self, $destination, $callback) = @_;

    my $type = ref($self);
    $self->log($main::LOG_ERR, "$self->{log_class_name}: Method handle_message_delete is not implemented for $type");

    return;
}

sub handle_message_publish
{
    my ($self, $message, $destination) = @_;

    my $type = ref($self);
    $self->log($main::LOG_ERR, "$self->{log_class_name}: Method handle_message_publish is not implemented for $type");

    return;
}

sub handle_pull_message_timeout
{
    my ($handle, $self, $message_type, $count, $timeout) = @_;

    # Delete old timer
    delete $self->{pull_message_timers}->{$message_type};

    my $destination = $message_type;

    # Do pull/pop $count messages
    for (my $i = 0; $i < $count; $i++)
    {
	my $unpacked_message = $self->pop($destination);

	if ($unpacked_message)
	{
	    my $message_type_received = $unpacked_message->{type};

	    if ($message_type_received ne $message_type)
	    {
		$self->log($main::LOG_ERR, "$self->{log_class_name}: pop() returned an invalid message type ('$message_type_received' != '$message_type') !");
		return;
	    }

	    $unpacked_message->{pull_message} = 1;

	    foreach my $callback (@{$self->{message_handlers}{$message_type}})
	    {
		$self->log($main::LOG_DEBUG, "$self->{log_class_name}: Calling callback for message type '$message_type'") if $self->{Debug};
		&$callback($unpacked_message) if (defined $callback & ref($callback) eq 'CODE');
	    }
	}
	else
	{
	    last;
	}
    }

    # and set a new timer
    $self->{pull_message_timers}->{$message_type} =
	Radius::Select::add_timeout(time + $timeout, \&Radius::Gossip::handle_pull_message_timeout, $self, $message_type, $count, $timeout);
}

# Returns encrypted message or undef if message encryption failed
sub encrypt_message
{
    my ($self, $nonce, $message) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Encrypting a message") if $self->{Debug};

    my $keyid = $self->{curr_encryption_keyid};
    my $key = ($keyid && $self->{encryption_keys}) ? $self->{encryption_keys}->{$keyid} : undef;
    unless ($key)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_name}: Could not encrypt a message, did not find encryption key $keyid");
	return undef;
    }

    my $aad = $nonce;
    my ($enc_message, $tag) = Radius::AES_GCM::encrypt($key, $nonce, $message, $aad);

    return $tag . $enc_message;
}

# Returns decrypted message or undef if message decryption failed
sub decrypt_message
{
    my ($self, $nonce, $message) = @_;

    return undef unless length($message) > 16;

    my $aad = $nonce;
    my $dec_message;

    my ($tag, $enc_message) = unpack('a16 a*', $message);
    if (length($tag) == 16)
    {
        # get keyid from header
        my $keyid = unpack('x2 n', $nonce);
        if ($keyid && exists $self->{encryption_keys}->{$keyid})
	{
            $dec_message = Radius::AES_GCM::decrypt($self->{encryption_keys}->{$keyid}, $nonce, $enc_message, $aad, $tag);
        }
	else
	{
	    $self->log($main::LOG_WARNING, "$self->{log_class_name}: Could not decrypt a message, did not find encryption key $keyid");
	}

        if ($self->{Debug} && defined $dec_message)
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_name}: Decrypted a message with key $keyid");
	}
    }
    else
    {
        $self->log($main::LOG_WARNING, "$self->{log_class_name}: Could not decrypt a message, tag is not 16 bytes");
    }

    return $dec_message;
}

# Find a Gossip implementation with the given identifier
# If not found, return the main default one
sub find
{
    my ($identifier) = @_;

    my $ret = Radius::Configurable::find('Gossip', $identifier)
	|| $Radius::Gossip::handle;

    return $ret;
}

sub make_header
{
    my ($self, $message_hash) = @_;

    return "" unless ($self->{use_encryption} || $self->{use_message_header});

    my $msg_type = defined $message_hash->{msg_type} ? $message_hash->{msg_type} : $Radius::Gossip::Message::NOTIFICATION;
    $msg_type |= $Radius::Gossip::Message::WAITING_SINGLE_REPLY if $message_hash->{waiting_single_reply};

    my $keyid = 0x00;
    if ($self->{use_encryption})
    {
        $msg_type |= $Radius::Gossip::Message::ENCRYPTED;
        $keyid = $self->{curr_encryption_keyid} || 0x00;
    }

    my $msg_ttl = defined $message_hash->{msg_ttl} ? $message_hash->{msg_ttl} : 0x01;

    # Header also acts a nonce. Note: 0 is reserved encryption key id
    # used when encryption is off.
    # 1 byte flags, 1 byte ttl, 2 bytes encryption key id, 4 bytes message id, 4 bytes local time
    $self->{msg_counter} = 1 if ++$self->{msg_counter} > 4294967295;

    return pack('C C n N N', $msg_type, $msg_ttl, $keyid, $self->{msg_counter}, time());
}

sub strip_header
{
    my ($self, $message) = @_;

    return unless ($self->{use_encryption} || $self->{use_message_header});

    # strip header
    return substr($_[1], 0, 12, '');
}

1;
