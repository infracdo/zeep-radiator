# AuthDYNADDRESS.pm
#
# Object for allocating IP addresses
# Calls the subclass of AddressAllocatorGeneric named
# by the Allocator parameter. The allocator is required 
# to provide 3 functions: allocate(), confirm() and deallocate().
# allocate() is called when a new address is required during
#  an Access-Request.
# confirm() is called when an Accounting Start and Accounting Alive
#  packet is received
# deallocate() is called when an Accounting Stop is received and the
#  allocated address is no longer required.
#
# The allocator may behave in a synchronous (eg allocates an address
# immediately) or asynchronous fashion (eg make a request
# to a remote address allocator, which may reply some time later)
#
# The allocator should behave like this:
# For synchronous operation:
# allocate: find addresses and other interesting info, put them
# in a has, and call its caller's (ie our) allocateDone() function,
# passing the hash. allocate() returns ACCEPT or REJECT, telling
# the calling handler whether to accept or reject.
# confirm: Confirm the address is in use, call its caller's (ie our) 
# confirmDone() function. confirm() returns ACCEPT or REJECT, telling
# the calling handler whether to accept or reject.
# deallocate: Deallocate the address so it is availbale for future use,
# call its caller's (ie our) 
# deallocateDone() function. deallocate() returns ACCEPT or REJECT, 
# telling
# the calling handler whether to accept or reject.
#
# For an asynchronous operation:
# allocate: start the allocation process and return IGNORE or ASYNC.
# Some time later when the results of the allocation are available, call
# the callers (ie our) allocate done, then call sendReplyTo to
# send the reply to the original requester
# confirm: start the confirm process and return IGNORE. Some time
# later when any confirm is done, call
# the callers (ie our)  confirmDone, then call sendReplyTo to
# send the reply to the original requester.
# deallocate: start the deallocate process and return IGNORE. Some time
# later when any deallocation is complete, call
# the callers (ie our)  deallocateDone, then call sendReplyTo to
# send the reply to the original requester.
#
# It is permitted to mix synchronous and asynchronous operation,
# eg the allocator might do an async allocate() but a sync confirm()
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::AuthDYNADDRESS;
@ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use Radius::AddressAllocatorGeneric;
use Radius::DHCPv6;
use Radius::User;
use strict;
use warnings;

%Radius::AuthDYNADDRESS::ConfigKeywords =
(
 'PoolHint'         =>
 ['string', 'specifies how the pool hint is derived. A pool hint is generally used by an AddressAllocator to determine which pool to allocate an address from. The value of the pool hint will therefore depend on what type of Address Allocator you are using, and usually which pools are available.', 0],

 'MapAttribute' =>
 ['stringhash', 'This optional parameter allows you to specifiy how the results of the address allocation are to be placed in the reply. If the yiaddr attribute (usually Framed-IP-Address)  is already set in the reply, then AuthBy DYNADDRESS will not allocate an addresss, and will just ACCEPT the request. This means that if a user record has a fixed IP address in it, then AuthBy DYNADDRESS will not allocate an address for that user.', 1],

 'RunWhenMissing' =>
 ['flag', 'Run confirm or deallocate operations even if the address, as defined by MapAttribute yiaddr, is missing from the accounting request. Defaults to enabled.', 1],

 'AddressAllocator' =>
 ['formatobjectlist', 'List of AddressAllocator objects, specifies which Address Allocation engine will be used to allocate the addresses. Special formatting characters are permitted.', 0],

 'MapResultHook' =>
 ['hook', 'The hook will be called after the allocation results have been received, and before Radiator has processed MapAttribute definitions.', 2],
);

# RCS version number of this module
$Radius::AuthDYNADDRESS::VERSION = '$Revision$';

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->log($main::LOG_ERR, "No Allocator defined for AuthDYNADDRESS in '$main::config_file'")
	unless defined $self->{AddressAllocator};

    $self->SUPER::check_config();
    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Extract the DHCPv6 options for any possible DHCPv6 allocators
    $self->{dhcpv6_options} = [];
    foreach my $name (keys %{$self->{MapAttribute}})
    {
	my $num = $Radius::DHCPv6::option_name_to_type{uc $name};
	next unless $num;
	push(@{$self->{dhcpv6_options}}, $num);
    }
}

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    # By default, we derive the pool name from a pseudo reply
    # attribute defined by a previous AuthBy
    $self->{PoolHint} = '%{Reply:PoolHint}';

    # By default, we just use the allocated IP address
    # and put it into Framed-IP-Address. There are no
    # default mappings for IPv6 values.
    $self->{MapAttribute}{yiaddr} = 'Framed-IP-Address';
    $self->{MapAttribute}{subnetmask} = 'Framed-IP-Netmask';

    $self->{RunWhenMissing} = 1;
}

#####################################################################
# Override the keyword function in Configurable
sub keyword
{
    my ($self, $file, $keyword, $value) = @_;

    if ($keyword eq 'Allocator')
    {
	# Find the address allocator named. Deprecated, use
	# AddressAllocator instead.
	# REVISIT: remove support one day
	$self->findAndUse('AddressAllocator', $value);
    }
    else
    {
	return $self->SUPER::keyword($file, $keyword, $value);
    }
    return 1;
}

#####################################################################
# Handle a request
# This function is called for each packet. $p points to a Radius::
# packet
# REVISIT:should we fork before handling. There might be long timeouts?
sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    my $type = ref($self);
    $self->log($main::LOG_DEBUG, "Handling with $type", $p);

    my $user_name = $p->getUserName;
    if ($p->code eq 'Access-Request')
    {
	# REVISIT: first confirm that there is no 
	# address present yet in the reply. yiaddr gives the
	# name of the radius attribute where the allocated address
	# would be put if we got that far.
	return ($main::ACCEPT, 'Address already present in reply') # Do nothing
	    if $p->{rp}->get_attr($self->{MapAttribute}{yiaddr});

	$user_name =~ s/@[^@]*$//
	    if $self->{UsernameMatchesWithoutRealm};
	my $pool_hint = &Radius::Util::format_special($self->{PoolHint}, $p);
	return $self->allocate($user_name, $pool_hint, $p)
	    if $pool_hint ne '';

	# No pool hint: complain but return ACCEPT
	$self->log($main::LOG_DEBUG, "No PoolHint found. No address will be allocated", $p);
	return ($main::ACCEPT, 'No PoolHint found');
	
    }
    elsif ($p->code eq 'Accounting-Request')
    {
	my $address = $p->get_attr($self->{MapAttribute}{yiaddr});
	my $type = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE);

	if ($type eq 'Accounting-On' ||
	       $type eq 'Accounting-Off')
	{
	    # NAS is (re)booting
	    return $self->deallocate_by_nas($p);
	}
	elsif ($address || $self->{RunWhenMissing})
	{
	    if ($type eq 'Start')
	    {
		# Its a start, confirm the address is in use
		return $self->confirm($address, $p);
	    }
	    elsif ($type eq 'Alive')
	    {
		# Its an alive, confirm the address is still in use
		return $self->confirm($address, $p);
	    }
	    elsif ($type eq 'Stop')
	    {
		# Its a stop, deallocate the address
		return $self->deallocate($address, $p);
	    }
	}
	else
	{
	    $self->log($main::LOG_WARNING, "Received an Accounting-Request ($type) without an address attribute $self->{MapAttribute}{yiaddr}", $p);
	}
	# Catch everything else
	return ($main::ACCEPT, 'Accounting-Request accepted');
    }
    else
    {
	# Send a generic reply on our behalf
	return ($main::ACCEPT, 'Not a relevant request type');
    }
}

#####################################################################
# Called by the allocator when the allocation has been done
sub allocateDone
{
    my ($self, $p, $result, $reply_result) = @_;

    # Allocation succeeded, map the results to the reply
    $self->mapResult($result, $p->{rp});
    # Add any AuthBy specific attributes
    $self->adjustReply($p);

    if (defined $reply_result)
    {
	$p->{Handler}->handlerResult($p, $reply_result, 'Allocate done');
    }

    return;
}

#####################################################################
# Called by the allocator when the confirm has been done
sub confirmDone
{
    my ($self, $p, $reply_result) = @_;

    if (defined $reply_result)
    {
	$p->{Handler}->handlerResult($p, $reply_result, 'Confirm done');
    }

    return;
}

#####################################################################
# Called by the allocator when the deallocation has been done
sub deallocateDone
{
    my ($self, $p, $reply_result) = @_;

    if (defined $reply_result)
    {
	$p->{Handler}->handlerResult($p, $reply_result, 'Deallocate done');
    }

    return;
}

#####################################################################
# Take an allocation result, and map it into redius reply 
# attributes
sub mapResult
{
    my ($self, $result, $p) = @_;

    # Allow modifying the results before mapping them
    $self->runHook('MapResultHook', $p, $result);

    # Now go through the list of allocation results that
    # we have to map into radius reply attribtues
    foreach my $name (sort keys %{$self->{MapAttribute}})
    {
	# If there is a definition for this result,
	# and the corresponding radius reply attribute
	# is not already set in the reply, and we
	# actually have a value for it, then set it
	my $value = $result->{$name};
	if ($self->{MapAttribute}{$name}
	    && defined $value
	    && $value ne ''
	    && ! $p->get_attr($name))
	{
	    # Handle multi instance values too
	    $value = [$value] unless (ref($value) eq 'ARRAY');
	    map { $p->add_attr($self->{MapAttribute}{$name}, $_) } @$value;
	}
    }
}


#####################################################################
# Shortcuts for accessing our allocator
sub allocate
{
    my ($self, @args) = @_;
    return $self->{AddressAllocator}[0]->allocate($self, @args);
}

sub deallocate
{
    my ($self, @args) = @_;
    return $self->{AddressAllocator}[0]->deallocate($self, @args);
}

sub confirm
{
    my ($self, @args) = @_;
    return $self->{AddressAllocator}[0]->confirm($self, @args);
}

sub deallocate_by_nas
{
    my ($self, @args) = @_;
    return $self->{AddressAllocator}[0]->deallocate_by_nas($self, @args);
}

1;
