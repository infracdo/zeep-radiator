# AddressAllocatorDHCPv6
#
# Implements IP address allocation from a DHCPv6 server. Called by
# AuthDYNADDRESS.pm
#
# AddressAllocatorDHCPv6.pm will work with any DHCPv6 server.
#
# There is an example configuration file included in the Radiator
# distribution in the file "goodies/addressallocatordhcpv6.cfg".
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2011 Open System Consultants
# $Id$

package Radius::AddressAllocatorDHCPv6;
@ISA = qw(Radius::AddressAllocatorGeneric Radius::DHCPv6Client);
use Radius::AddressAllocatorGeneric;
use Radius::DHCPv6Client;
use Radius::Context;
use Radius::Util;
use strict;
use warnings;

%Radius::AddressAllocatorDHCPv6::ConfigKeywords =
(
 'RapidCommit' =>
 ['flag', 'Use the Rapid Commit option with DHCPv6 Solicit messages when allocating addresses and prefixes. Defaults to off.', 1],

 'DHCPClientIdentifier' =>
 ['string', 'The attribute to use in the DHCPv6 Client-Identifier field to identify the RADIUS client to the DHCPv6 server. Special characters are permitted.', 1],

 'DefaultLease' =>
 ['integer', 'If SessionTimeout is set in a reply by a previous AuthBy then that is used as requested preferred-lifetime in DHCPv6 requests. Otherwise DefaultLease (in seconds) is used. Caution: the DHCPv6 server may ignore the requested preferred-lifetime, depending on type and configuration.', 1],

 'AllocateDoneHook' =>
 ['hook', 'AllocateDoneHook provides access to the received reply and allows modifying the results after Radiator has processed them, but before they are passed to AuthBy DYNADDRESS', 2],
);

#####################################################################
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initalize instance
# variables that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::initialize();
    $self->Radius::DHCPv6Client::initialize();

    $self->{DHCPClientIdentifier} = '%{User-Name}-%{Reply:PoolHint}';
    $self->{DefaultLease} = 86400;
}

#####################################################################
# (Re)activate a new Dynamic address allocator for DHCP
sub activate
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::activate();
    $self->Radius::DHCPv6Client::activate();
}

#####################################################################
# Called after DHCPv6 Solicit or Information Request succeeds in
# returning address or other information.
sub allocateDone
{
    my ($self, $caller, $p, $request, $reply) = @_;

    # Populate interesting details from the reply
    my %details;

    # If there is an IA_NA with an IAADDRESS, thats the address that was allocated
    my ($iaaddr, $iaaddr_preferred_lifetime, $iaaddr_valid_lifetime);
    my ($ia_na, @ia_na_options) = $reply->option($Radius::DHCPv6::OPTION_IA_NA);
    (undef, $iaaddr, $iaaddr_preferred_lifetime, $iaaddr_valid_lifetime) =
	Radius::DHCPv6::Message::get_option($Radius::DHCPv6::OPTION_IAADDR, $ia_na_options[3]) if (@ia_na_options);
    if ($iaaddr)
    {
	$details{iaaddr} = Radius::Util::inet_ntop($iaaddr);
    }

    # If there is an IA_PD with an IAPREFIX, thats a permanent? IPv6 prefix
    my ($iaprefix_preferred_lifetime, $iaprefix_valid_lifetime, $iaprefix_length, $iaprefix);
    my ($ia_pd, @ia_pd_options) = $reply->option($Radius::DHCPv6::OPTION_IA_PD);
    (undef, $iaprefix_preferred_lifetime, $iaprefix_valid_lifetime, $iaprefix_length, $iaprefix) =
	Radius::DHCPv6::Message::get_option($Radius::DHCPv6::OPTION_IAPREFIX, $ia_pd_options[3]) if (@ia_pd_options);
    if ($iaprefix)
    {
	$details{iaprefix} = Radius::Util::inet_ntop($iaprefix) . '/' . $iaprefix_length;
    }

    # Create an anonymous array with all DNS servers
    my (undef, @dns_servers_options) = $reply->option($Radius::DHCPv6::OPTION_DNS_SERVERS);
    $details{dns_servers} =[ map { Radius::Util::inet_ntop($_); } @dns_servers_options ]
	if @dns_servers_options;

    # Put server and client identifier in the details by default
    my (undef, $serverid) = $reply->option($Radius::DHCPv6::OPTION_SERVERID);
    $details{serverid} = $serverid;
    my (undef, $clientid) = $reply->option($Radius::DHCPv6::OPTION_CLIENTID);
    $details{clientid} = $clientid;

    # Allow modifying the details before passing to AuthDYNADDRESS
    $self->runHook('AllocateDoneHook', $p, \%details, $reply);

    # Save some context for later use by confirm() and deallocate()
    my $context_key = "dhcpv6:$clientid"; # This is the DUID

    my $context = Radius::Context->new($context_key, $self->{DefaultLease});
    $context->{serverid} = $serverid;
    $context->{iaprefix} = [$iaprefix_length, $iaprefix] if $iaprefix;
    $context->{iaaddr} = $iaaddr if $iaaddr;

    # Tell the AuthDNYADDRESS about them
    $caller->allocateDone($p, \%details);

    # And send a reply to the NAS
    $p->{Handler}->handlerResult($p, $main::ACCEPT, 'Allocate done') unless $self->{Synchronous};
}

#####################################################################
# Generate a per-client unique DUID to identify the client to the DHCPv6 server.
sub generateClientDUID
{
    my ($self, $p) = @_;

    return Radius::DHCPv6::DUID::encodeEN($Radius::Util::OSC_ENTERPRISE_NUMBER, Radius::Util::format_special($self->{DHCPClientIdentifier}, $p));
}

#####################################################################
# Allocate an address for username with the given pool hint
# return a hash of interesting values for AuthBy DYNADDRESS
# to do stuff with
sub allocate
{
    my ($self, $caller, $username, $pool_hint, $p) = @_;

    my $client_duid = $self->generateClientDUID($p);
    my $preferred_lifetime = $p->{rp}->get_attr('Session-Timeout');
    $preferred_lifetime = $self->{DefaultLease} unless $preferred_lifetime;

    # Remove request for IAADDR or IAPREFIX if the respective
    # attributes are already present in the reply.
    my $options = $caller->{dhcpv6_options};
    $options = [ grep { $_ != $Radius::DHCPv6::OPTION_IAADDR } @$options ]
	if $p->{rp}->get_attr($caller->{MapAttribute}{iaaddr});
    $options = [ grep { $_ != $Radius::DHCPv6::OPTION_IAPREFIX } @$options ]
	if $p->{rp}->get_attr($caller->{MapAttribute}{iaprefix});

    return ($main::ACCEPT, 'Nothing to request from DHCPv6') unless @$options;

    my $reply = $self->allocateRequest($client_duid, $preferred_lifetime, $options, $pool_hint, sub {$self->allocateDone($caller, $p, $_[1], $_[2]);});
    return ($main::ACCEPT, 'allocate done') if $self->{Synchronous};
    $p->{proxied}++;
    return ($main::IGNORE, 'Waiting for DHCPv6');
}

#####################################################################
# Confirm a previously allocated address is in use
# The $address may not be reliable in a DHCPv6 environment
sub confirm
{
    my ($self, $caller, $address, $p) = @_;

    my $client_duid = $self->generateClientDUID($p);
    # Recover the context
    my $context_key = "dhcpv6:$client_duid";
    my $context = Radius::Context::find($context_key);
    if (!defined $context)
    {
	$self->log($main::LOG_INFO, "AddressAllocatorDHCPv6::confirm could not recover a context");
    }
    else
    {
	# If an address or prefix was allocated, renew it. We dont
	# wait around for a reply
	$self->renewRequest($client_duid, $context->{serverid}, $context->{iaaddr}, $context->{iaprefix})
	    if ($context->{iaaddr} || $context->{iaprefix});
    }

    return ($main::ACCEPT, 'confirm succeeded');
}

#####################################################################
# Free a previously allocated address
# Note that the DHCP server will not reply to a DHCPRELEASE
sub deallocate
{
    my ($self, $caller, $address, $p) = @_;

    my $client_duid = $self->generateClientDUID($p);
    # Recover the context
    my $context_key = "dhcpv6:$client_duid";
    my $context = Radius::Context::find($context_key);
    if (!defined $context)
    {
	$self->log($main::LOG_INFO, "AddressAllocatorDHCPv6::deallocate could not recover a context. Duplicate STOP?");
    }
    else
    {
	# If an address or prefix was allocated, deallocate them. We
	# dont wait around for a reply
	$self->releaseRequest($client_duid, $context->{serverid}, $context->{iaaddr}, $context->{iaprefix})
	    if ($context->{iaaddr} || $context->{iaprefix});
    }
    # Remove the saved context
    Radius::Context::destroy($context_key);

    return ($main::ACCEPT, 'deallocate succeeded');
}

#####################################################################
# Free all previously allocated address for the NAS
sub deallocate_by_nas
{
    my ($self, $caller, $p) = @_;

    # We do not currently know how to do this with DHCPv6
    return ($main::ACCEPT, 'deallocate_by_nas not implemented');
}

1;
