# AuthLogEVENTLOG.pm
#
# Specific class for logging authentication to Windows Event Log
#
# Author: Sami Keski-Kasari (samikk@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::AuthLogEVENTLOG;
@ISA = qw(Radius::AuthLogGeneric);
use Radius::AuthLogGeneric;
use Win32::EventLog;
use strict;
use warnings;

%Radius::AuthLogEVENTLOG::ConfigKeywords =
(
 'SuccessFormat' =>
 ['string', 'The format for success messages. You can use any of the special characters. Defaults to \'Access-Accept for user %U\'.', 1],

 'FailureFormat' =>
 ['string', 'The format for failure messages. You can use any of the special characters. Defaults to \'Access-Reject for user %U\'.', 1],

 'IgnoreFormat' =>
 ['string', 'The format for ignore messages. You can use any of the special characters. Defaults to \'Ignore for user %U\'.', 1],

 );

# RCS version number of this module
$Radius::AuthLogEVENTLOG::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initialize instance
# variables
# that might get overridden when the config file is parsed.
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
    $self->{SuccessFormat} = 'Access-Accept for user %U';
    $self->{FailureFormat} = 'Access-Reject for user %U';
    $self->{IgnoreFormat} = 'Ignore for user %U';
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Log a message
sub authlog
{
    my ($self, $s, $reason, $p) = @_;

    my $message;
    my $trace_id = $p->{trace_id};
    if (defined($self->{SuccessFormat})
	and $self->{LogSuccess}
	and $s == $main::ACCEPT)
    {
	$message = &Radius::Util::format_special
	    ($self->{SuccessFormat}, $p, undef, $s, $reason, $trace_id);
    }
    elsif (defined($self->{FailureFormat})
	   and $self->{LogFailure}
	   and $s == $main::REJECT )
    {
	$message = &Radius::Util::format_special
	    ($self->{FailureFormat}, $p, undef, $s, $reason, $trace_id);
    }
    elsif (defined($self->{IgnoreFormat})
	   and $self->{LogIgnore}
	   and $s == $main::IGNORE )
    {
	$message = &Radius::Util::format_special
	    ($self->{IgnoreFormat}, $p, undef, $s, $reason, $trace_id);
    }
    else
    {
	return;
    }

    my $eventloghandle = Win32::EventLog->new("Radiator");
    unless ($eventloghandle)
    {
	main::log($main::LOG_ERR, "AuthLogEVENTLOG: Could not open EventLog for AuthLog", $p);
	return;
    }

    my %eventlogrecord = (
	'Source' => 'Radiator',
	'EventType' => $s == $main::ACCEPT ? EVENTLOG_AUDIT_SUCCESS : EVENTLOG_AUDIT_FAILURE,
	'Strings' => $message,
	'Data' => $message,
	);

    $eventloghandle->Report(\%eventlogrecord)
	|| main::log($main::LOG_ERR, "AuthLogEVENTLOG: Could not report AuthLog message", $p);

    $eventloghandle->Close();
}

1;
