# ServINTERNAL.pm
#
# Internal in-memory service and subscription databases
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::ServINTERNAL;
use strict;
use warnings;
our @ISA = qw(Radius::ServGeneric);
use Radius::ServGeneric;

%Radius::ServINTERNAL::ConfigKeywords =
(
 'Service' =>
 ['stringarray', 'Service definition. Format is "key1:value1 key2:value2 ...". Supported keys are: id,name,price,poolIPv4,poolIPv6,checkItems,replyItems,requireConfirm,expiry,prepaidTime,postpaidTime,prepaidQuota,postpaidQuota,allowQuotaToExceed,disallowResubscribe,prepaidUpRate,prepaidDownRate,postpaidUpRate,postpaidDownRate,throtUpRate,throtDownRate.', 1],
);

# RCS version number of this module
$Radius::ServINTERNAL::VERSION = '$Revision$';

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    # Services
    $self->{services} = {
	default => {
	    id => {},
	    name => {},
	},
    };

    # Subscriptions
    $self->{subscriptions} = {
	default => {
	    id => {},
	    name => {},
	},
    };

    # Timers for emulating async replies
    $self->{callback_timers} = {};

    return;
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    if ($self->{Service})
    {
	foreach my $serv_def (@{$self->{Service}})
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Adding a service '$serv_def'");
	    my $service = $self->new_service_from_string($serv_def);
	    if ($service)
	    {
		$service->save();
	    }
	    else
	    {
		$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Adding a service '$serv_def' failed");
	    }
	}
    }

    return;
}

#####################################################################
sub flush
{
    my ($self) = @_;

    foreach my $tenant (keys %{$self->{services}})
    {
	foreach my $key (keys %{$self->{services}->{$tenant}})
	{
	    foreach my $value (keys %{$self->{services}->{$tenant}->{$key}})
	    {
		my $service = $self->{services}->{$tenant}->{$key}->{$value};
		if ($service && $service->{dirty})
		{
		    my $rc = $service->save();
		    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Saving a service failed: $service->{id}, $service->{name}") unless $rc;
		}
	    }
	}
    }

    foreach my $tenant (keys %{$self->{subscriptions}})
    {
	foreach my $key (keys %{$self->{subscriptions}->{$tenant}})
	{
	    foreach my $value (keys %{$self->{subscriptions}->{$tenant}->{$key}})
	    {
		my $subscription = $self->{subscriptions}->{$tenant}->{$key}->{$value};
		if ($subscription && $subscription->{dirty})
		{
		    my $rc = $subscription->save();
		    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Saving a subscription failed: $subscription->{id}, $subscription->{name}") unless $rc;
		}
	    }
	}
    }

    return 1;
}

#####################################################################
sub schedule_callback
{
    my ($self, $callback, @args) = @_;

    my $timer_callback = sub {
	my ($c_handle, $c_self, $c_callback, @c_args) = @_;
	delete $c_self->{callback_timers}->{$c_handle} if $c_self;
	&{$c_callback}(@c_args);
	return;
    };

    my $timer = Radius::Select::add_timeout(time + 1, $timer_callback, $self, $callback, @args);
    $self->{callback_timers}->{$timer} = $timer;

    return;
}

#####################################################################
sub get_service
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    return undef unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    my ($ref, $service);
    if (exists $self->{services}->{$tenant_id})
    {
	$ref = $self->{services}->{$tenant_id};

	if (defined $id && exists $ref->{id}->{$id})
	{
	    $service = $ref->{id}->{$id};
	}
	elsif (defined $id && exists $ref->{name}->{$name})
	{
	    $service = $ref->{name}->{$name};
	}
    }

    if ($cb)
    {
	$self->schedule_callback($cb, $service);
	return;
    }

    return $service;
}

#####################################################################
sub add_service
{
    my ($self, $id, $name, $service, $tenant_id) = @_;

    return 0 unless $service;
    return 0 unless (defined $id || defined $name);

    $tenant_id = $service->{tenant_id} unless defined $tenant_id;
    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    if (exists $self->{services}->{$tenant_id})
    {
	my $ref = $self->{services}->{$tenant_id};
	$ref->{id}->{$id} = $service if defined $id;
	$ref->{name}->{$name} = $service if defined $name;
	return 1;
    }

    return 0;
}

#####################################################################
sub refresh_service
{
    my ($self, $service, $child, $cb) = @_;
    return 0 unless $service;

    my $rc = $self->SUPER::refresh_service($service, $child, $cb);

    if ($cb)
    {
	$self->schedule_callback($cb, $service, $rc);
	return;
    }

    return $rc;
}

#####################################################################
sub save_service
{
    my ($self, $service, $cb) = @_;

    return 0 unless $service;
    return 1 unless $service->{dirty};

    my $rc = $self->add_service($service->{id}, $service->{name}, $service);
    $service->{dirty} = 0 if $rc;

    if ($cb)
    {
	$self->schedule_callback($cb, $service, $rc);
	return;
    }

    return $rc;
}

#####################################################################
sub delete_service
{
    my ($self, $id, $name, $tenant_id) = @_;

    return 0 unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    my $rc = 0;
    if (exists $self->{services}->{$tenant_id})
    {
	my $ref = $self->{services}->{$tenant_id};

	if (defined $id)
	{
	    delete $ref->{id}->{$id};
	    $rc = 1;
	}
	if (defined $name)
	{
	    delete $ref->{name}->{$name};
	    $rc = 1;
	}
    }

    return $rc;
}

#####################################################################
sub del_service
{
    my ($self, $service, $cb) = @_;

    return 0 unless $service;

    my $rc = $self->delete_service($service->{id}, $service->{name}, $service->{tenant_id});
    $service->{dirty} = 0 if $rc;

    if ($cb)
    {
	$self->schedule_callback($cb, $service, $rc);
	return;
    }

    return $rc;
}

#####################################################################
sub get_subscription
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    return undef unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    my ($ref, $subscription);
    if (exists $self->{subscriptions}->{$tenant_id})
    {
	$ref = $self->{subscriptions}->{$tenant_id};

	if (defined $id && exists $ref->{id}->{$id})
	{
	    $subscription = $ref->{id}->{$id};
	}
	elsif (defined $name && exists $ref->{name}->{$name})
	{
	    $subscription = $ref->{name}->{$name};
	}
    }

    if ($cb)
    {
	$self->schedule_callback($cb, $subscription);
	return;
    }

    return $subscription;
}

#####################################################################
sub add_subscription
{
    my ($self, $id, $name, $subscription, $tenant_id) = @_;

    return 0 unless $subscription;
    return 0 unless (defined $id || defined $name);

    $tenant_id = $subscription->{tenant_id} unless defined $tenant_id;
    $tenant_id = $subscription->{Tenant} unless defined $tenant_id;

    if (exists $self->{subscriptions}->{$tenant_id})
    {
	my $ref = $self->{subscriptions}->{$tenant_id};
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Saving subscription $id, $name");
	$ref->{id}->{$id} = $subscription if defined $id;
	$ref->{name}->{$name} = $subscription if defined $name;
	return 1;
    }

    return 0;
}

#####################################################################
sub refresh_subscription
{
    my ($self, $subscription, $child, $cb) = @_;

    return 0 unless $subscription;

    my $rc = $self->SUPER::refresh_subscription($subscription, $child, $cb);

    if ($cb)
    {
	$self->schedule_callback($cb, $subscription, $rc);
	return;
    }

    return $rc;
}

#####################################################################
sub save_subscription
{
    my ($self, $subscription, $cb) = @_;
    return 0 unless $subscription;
    return 1 unless $subscription->{dirty};

    my $rc = $self->add_subscription($subscription->{id}, $subscription->{name}, $subscription);

    if ($cb)
    {
	$self->schedule_callback($cb, $subscription, $rc);
	return;
    }

    return $rc;
}

#####################################################################
sub delete_subscription
{
    my ($self, $id, $name, $tenant_id) = @_;

    return 0 unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    my $rc = 0;
    if (exists $self->{subscriptions}->{$tenant_id})
    {
	my $ref = $self->{subscriptions}->{$tenant_id};

	if (defined $id)
	{
	    delete $ref->{id}->{$id};
	    $rc = 1;
	}
	if (defined $name)
	{
	    delete $ref->{name}->{$name};
	    $rc = 1;
	}
    }

    return $rc;
}

#####################################################################
sub del_subscription
{
    my ($self, $subscription, $cb) = @_;

    return 0 unless $subscription;

    my $rc = $self->delete_subscription($subscription->{id}, $subscription->{name}, $subscription->{tenant_id});
    $subscription->{dirty} = 0 if $rc;

    if ($cb)
    {
	$self->schedule_callback($cb, $subscription, $rc);
	return;
    }

    return $rc;
}

1;
