# LogSYSLOG.pm
#
# Log to syslog
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::LogSYSLOG;
use strict;
use warnings;
our @ISA = qw(Radius::LogGeneric);
use English qw(-no_match_vars);
use File::Path;
use File::Basename;
use Radius::LogGeneric;
use Sys::Syslog qw(:DEFAULT setlogsock);

%Radius::LogSYSLOG::ConfigKeywords =
('Facility' =>
 ['string', 'The name of the syslog facility that will be logged to. The default is "user".', 0],

 'LogSock' =>
 ['string', 'This optional parameter specifies what type of socket to use to connect to the syslog server. Allowable values are unix, inet, tcp, udp. Defaults to unix. The option inet means to try tcp first, then udp. The default is to use the Sys::Syslog default of tcp, udp, unix, stream, console.', 1],

 'LogPort' =>
 ['integer', 'This optional parameter specifies the destination port for the syslog server.', 1],

 'LogIdent' =>
 ['string', 'This optional parameter specifies an alternative ident name to be used for logging. Defaults to the executable name used to run radiusd. Special characters are suported.', 1],

 'LogOpt' =>
 ['string', 'This optional comma separated parameter specifies an alternative set of options for openlog(3). Defaults to \'pid\'. Special characters are suported.', 1],

 'LogHost' =>
 ['string', 'When LogSock is set to tcp or udp or inet, this optional parameter specifies the name or address of the syslog host. Defaults to the local host. Special characters are suported.', 1],

 'LogPath' =>
 ['string', 'When LogSock is set to unix or stream or pipe, this optional parameter specifies the syslog path. Defaults to _PATH_LOG macro (if your system defines it).', 1],

 'LogFormat' =>
 ['string', 'This optional parameter permits you to customize the log string. Any special formatting character is permitted. %0 is replaced with the message severity as an integer, %1 with the severity as a string, %2 with the log message, and %3 with the tracing identifier.', 1],

 );

# RCS version number of this module
$Radius::LogSYSLOG::VERSION = '$Revision$';

# Maps our LOG_* numbers into Syslog priority levels
my @priorityToSyslog  = qw(ERR WARNING NOTICE INFO DEBUG DEBUG);


#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Facility} = 'user';
    $self->{LogIdent} = $PROGRAM_NAME;
    $self->{LogOpt} = 'pid';

    return;
}

sub check_config
{
    my ($self) = @_;

    # Validate LogOpt. LogOpt can be empty.
    foreach my $log_opt (split (m/,/s, $self->{LogOpt}))
    {
	main::log($main::LOG_ERR, "LogSYSLOG: Invalid LogOpt '$log_opt' in Log SYSLOG $self->{Identifier}")
	    unless grep { $log_opt eq $_ } qw(cons ndelay nofatal nowait perror pid);
    }

    # If perl version is newer than 5.10.0, compare Sys::Syslog versions.
    # Newer form of setlogsock should be used since it does not rely on
    # $Sys::Syslog::host notation.
    if ($] ge '5.010001') {
	if (version->parse($Sys::Syslog::VERSION) >= version->parse('0.28'))
	{
	    $self->{syslog_new_setlogsock} = 1;
	}
	elsif ($self->{LogPort})
	{
	    main::log($main::LOG_ERR, "LogSYSLOG: LogPort only works with Sys::Syslog 0.28 or later. Your Sys::Syslog version is $Sys::Syslog::VERSION. LogPort ignored");
	}
    }
    elsif ($self->{LogPort})
    {
	main::log($main::LOG_WARNING, "LogSYSLOG: LogPort only works with Sys::Syslog 0.28 or later. Your Sys::Syslog version is $Sys::Syslog::VERSION. Could not reliable compare versions, so make sure your Sys::Syslog is recent enough");
	# Trust the user to now the feature is available
	$self->{syslog_new_setlogsock} = 1;
    }

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Log a message
# $priority is the message priority, $s is the message
# $p is the current request packet, if any
# $trace_id is the tracing identifier
my $in_log;
sub log           ## no critic (Subroutines::ProhibitBuiltinHomonyms)
{
    my ($self, $priority, $s, $p, $trace_id) = @_;

    # Catch recursion
    return if $in_log++;
    if ($self->willLog($priority, $p))
    {
	if (defined $self->{LogFormatHook})
	{
	    ($s) = $self->runHook('LogFormatHook', $p, $priority, $s, $p, $trace_id);
	}
	elsif (defined $self->{LogFormat})
	{
	    $s = Radius::Util::format_special
		($self->{LogFormat},
		 $p, undef,
		 $priority,
		 $Radius::Log::priorityToString[$priority],
		 $s,
		 $trace_id);
	}

	$s = substr($s, 0, $self->{MaxMessageLength}) if $self->{MaxMessageLength};
	$s =~ s/%/%%/sg; # Make sure to escape any % signs that would be interpreted as printf
	$s =~ s/^/$trace_id /s if $self->{LogTraceId};  # No multiline as with Log FILE
	my $ident = Radius::Util::format_special($self->{LogIdent}, $p);
	my $logopt = Radius::Util::format_special($self->{LogOpt}, $p);
	my $loghost = Radius::Util::format_special($self->{LogHost}, $p);
	my $eval_ok = eval
	{
	    my $res = 1; # Reset by setlogsock, if called

	    # We reset these here in case there are multiple SYSLOG callers with different configs
	    # Caution: there is no way to reset logsock back to the default, so if you
	    # have multiple SYSLOG clauses, if any one has LogSock defined,
	    # they must all have LogSock defined
	    if ($self->{syslog_new_setlogsock})
	    {
		my $sock_opts = {};
		$sock_opts->{port} = $self->{LogPort} if defined $self->{LogPort};
		$sock_opts->{host} = $self->{LogHost} if $loghost;
		$sock_opts->{type} = $self->{LogSock} if defined $self->{LogSock};
		$sock_opts->{path} = $self->{LogPath} if defined $self->{LogPath};
		$res = setlogsock($sock_opts) if %{$sock_opts};
		# REVISIT: There is a bug in Sys::Syslog::setlogsock() which undefines $Sys::Syslog::host
		# when $self->{LogPort} is not defined.
		$Sys::Syslog::host = $loghost if $loghost;
	    }
	    else
	    {
		$res = setlogsock($self->{LogSock}) if defined $self->{LogSock};
		$Sys::Syslog::host = $loghost if $loghost;
	    }

	    # setlogsock, if called, has set res to true on success and undef on failure
	    if ($res)
	    {
		openlog($ident, $logopt, $self->{Facility});
		syslog("$priorityToSyslog[$priority]", $s);

		# closelog returns true on success
		unless (closelog())
		{
		    my $warn_msg = "LogSYSLOG: error in closing log";
		    warn($warn_msg);
		    main::log($main::LOG_ERR, $warn_msg);
		}
	    }
	    else
	    {
		my $warn_msg = "LogSYSLOG: error in setting socket type and/or options. Check logging parameters";
		warn($warn_msg);
		main::log($main::LOG_ERR, $warn_msg);
	    }

	    1; # Return value from eval
	};
	if (!$eval_ok)
	{
	    my $warn_msg = "LogSYSLOG: Error while doing Log SYSLOG: $EVAL_ERROR";
	    warn($warn_msg);
	    main::log($warn_msg);
	}
    }
    $in_log = 0;

    return;
}

1;
