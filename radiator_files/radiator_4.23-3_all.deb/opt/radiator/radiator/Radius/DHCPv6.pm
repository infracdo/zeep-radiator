# DHCPv6.pm
#
# Implements DHCPv6 package per RFC 3315, 3646, 1035, 3633
# See also http://www.nanog.org/meetings/nanog46/presentations/Tuesday/Brzozowski_introDHCP_N46.pdf
# and RFC 6911
#
# These routines do the low-level assembling and dis-assembling of
# DHCPv6 packets for AddressAllocatorDHCPv6.pm. See also
# DHCPv6Client.pm
#
# The options are returned as lists where the first element is the
# option-code. The rest of the elements depend on the option-code. For example:
# (OPTION_CLIENTID, DUID)
# (OPTION_IA_NA, IAID, T1, T2, (OPTION_IAADDR, IPv6 address, preferred-lifetime, valid-lifetime))
#
# Here IA_NA-options contains one option, OPTION_IAADDR, which has
# been recursively unpacked. RFC 3315 allows options for
# OPTION_IAADDR, but there were none in this example.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2011 Open System Consultants
# $Id$

package Radius::DHCPv6;
use Radius::Util;
use strict;
use warnings;

# RCS version number of this module
$Radius::DHCPv6::VERSION = '$Revision$';

# Multicast Addresses section 5.1
$Radius::DHCPv6::MULTICAST_ADDRESS_ALL_RELAY_AGENTS_AND_SERVERS = 'FF02::1:2';
$Radius::DHCPv6::MULTICAST_ADDRESS_ALL_SERVERS = 'FF05::1:3';

# UDP ports section 5.2
$Radius::DHCPv6::UDP_PORT_CLIENT = 546;
$Radius::DHCPv6::UDP_PORT_SERVER = 547;

# Message Types section 5.3
$Radius::DHCPv6::MESSAGE_TYPE_SOLICIT             = 1;
$Radius::DHCPv6::MESSAGE_TYPE_ADVERTISE           = 2;
$Radius::DHCPv6::MESSAGE_TYPE_REQUEST             = 3;
$Radius::DHCPv6::MESSAGE_TYPE_CONFIRM             = 4;
$Radius::DHCPv6::MESSAGE_TYPE_RENEW               = 5;
$Radius::DHCPv6::MESSAGE_TYPE_REBIND              = 6;
$Radius::DHCPv6::MESSAGE_TYPE_REPLY               = 7;
$Radius::DHCPv6::MESSAGE_TYPE_RELEASE             = 8;
$Radius::DHCPv6::MESSAGE_TYPE_DECLINE             = 9;
$Radius::DHCPv6::MESSAGE_TYPE_RECONFIGURE         = 10;
$Radius::DHCPv6::MESSAGE_TYPE_INFORMATION_REQUEST = 11;
$Radius::DHCPv6::MESSAGE_TYPE_RELAY_FORW          = 12;
$Radius::DHCPv6::MESSAGE_TYPE_RELAY_REPLY         = 13;

# Status codes section 5.4 and 24.4
$Radius::DHCPv6::STATUS_CODE_SUCCESS              = 0;
$Radius::DHCPv6::STATUS_CODE_UNSPEC_FAIL          = 1;
$Radius::DHCPv6::STATUS_CODE_NO_ADDRS_AVAIL       = 2;
$Radius::DHCPv6::STATUS_CODE_NO_BINDING           = 3;
$Radius::DHCPv6::STATUS_CODE_NOT_ON_LINK          = 4;
$Radius::DHCPv6::STATUS_CODE_USE_MULTICAST        = 5;
$Radius::DHCPv6::STATUS_CODE_NO_PREFIX_AVAIL      = 6;

# Default parameters section 5.5 et al
# In special circumstances you may want to alter these defaults
$Radius::DHCPv6::DEFAULT_SOL_MAX_DELAY            = 1;   # sec
$Radius::DHCPv6::DEFAULT_SOL_TIMEOUT              = 1;   # sec
$Radius::DHCPv6::DEFAULT_SOL_MAX_RT               = 120; # sec
$Radius::DHCPv6::DEFAULT_SOL_MAX_RC               = 0;   # attempts
$Radius::DHCPv6::DEFAULT_SOL_MAX_RD               = 0;   # sec
$Radius::DHCPv6::DEFAULT_REQ_TIMEOUT              = 1;   # sec
$Radius::DHCPv6::DEFAULT_REQ_MAX_RT               = 30;  # sec
$Radius::DHCPv6::DEFAULT_REQ_MAX_RC               = 10;  # attempts
$Radius::DHCPv6::DEFAULT_REQ_MAX_RD               = 0;   # sec
$Radius::DHCPv6::DEFAULT_CNF_MAX_DELAY            = 1;   # sec
$Radius::DHCPv6::DEFAULT_CNF_TIMEOUT              = 1;   # sec
$Radius::DHCPv6::DEFAULT_CNF_MAX_RT               = 4;   # sec
$Radius::DHCPv6::DEFAULT_CNF_MAX_RC               = 0;   # attempts
$Radius::DHCPv6::DEFAULT_CNF_MAX_RD               = 10;  # sec
$Radius::DHCPv6::DEFAULT_REN_TIMEOUT              = 10;  # sec
$Radius::DHCPv6::DEFAULT_REN_MAX_RT               = 600; # sec
$Radius::DHCPv6::DEFAULT_REB_TIMEOUT              = 10;  # sec
$Radius::DHCPv6::DEFAULT_REB_MAX_RT               = 600; # sec
$Radius::DHCPv6::DEFAULT_REB_MAX_RC               = 0;   # attempts
$Radius::DHCPv6::DEFAULT_INF_MAX_DELAY            = 1;   # sec
$Radius::DHCPv6::DEFAULT_INF_TIMEOUT              = 1;   # sec
$Radius::DHCPv6::DEFAULT_INF_MAX_RT               = 120; # sec
$Radius::DHCPv6::DEFAULT_INF_MAX_RC               = 0;   # attempts
$Radius::DHCPv6::DEFAULT_INF_MAX_RD               = 0;   # sec
$Radius::DHCPv6::DEFAULT_REL_TIMEOUT              = 1;   # sec
$Radius::DHCPv6::DEFAULT_REL_MAX_RT               = 0;   # sec
$Radius::DHCPv6::DEFAULT_REL_MAX_RC               = 5;   # attempts
$Radius::DHCPv6::DEFAULT_REL_MAX_RD               = 0;   # sec
$Radius::DHCPv6::DEFAULT_DEC_TIMEOUT              = 1;   # sec
$Radius::DHCPv6::DEFAULT_DEC_MAX_RT               = 0;   # sec
$Radius::DHCPv6::DEFAULT_DEC_MAX_RC               = 5;   # attempts
$Radius::DHCPv6::DEFAULT_DEC_MAX_RD               = 0;   # sec
$Radius::DHCPv6::DEFAULT_REC_TIMEOUT              = 2;   # sec
$Radius::DHCPv6::DEFAULT_REC_MAX_RC               = 8;   # attempts
$Radius::DHCPv6::DEFAULT_HOP_COUNT_LIMIT          = 32;  # hops

# Section 5.6
$Radius::DHCPv6::TIME_INFINITY                    = 0xffffffff;

# Section 24.3
$Radius::DHCPv6::OPTION_CLIENTID                  = 1;
$Radius::DHCPv6::OPTION_SERVERID                  = 2;
$Radius::DHCPv6::OPTION_IA_NA                     = 3;
$Radius::DHCPv6::OPTION_IA_TA                     = 4;
$Radius::DHCPv6::OPTION_IAADDR                    = 5;
$Radius::DHCPv6::OPTION_ORO                       = 6;
$Radius::DHCPv6::OPTION_PREFERENCE                = 7;
$Radius::DHCPv6::OPTION_ELAPSED_TIME              = 8;
$Radius::DHCPv6::OPTION_RELAY_MSG                 = 9;
$Radius::DHCPv6::OPTION_AUTH                      = 11;
$Radius::DHCPv6::OPTION_UNICAST                   = 12;
$Radius::DHCPv6::OPTION_STATUS_CODE               = 13;
$Radius::DHCPv6::OPTION_RAPID_COMMIT              = 14;
$Radius::DHCPv6::OPTION_USER_CLASS                = 15;
$Radius::DHCPv6::OPTION_VENDOR_CLASS              = 16;
$Radius::DHCPv6::OPTION_VENDOR_OPTS               = 17;
$Radius::DHCPv6::OPTION_INTERFACE_ID              = 18;
$Radius::DHCPv6::OPTION_RECONF_MSG                = 19;
$Radius::DHCPv6::OPTION_RECONF_ACCEPT             = 20;
$Radius::DHCPv6::OPTION_DNS_SERVERS               = 23;
$Radius::DHCPv6::OPTION_DOMAIN_LIST               = 24;
$Radius::DHCPv6::OPTION_IA_PD                     = 25; # RFC 3633
$Radius::DHCPv6::OPTION_IAPREFIX                  = 26; # RFC 3633

# Section 9.1
$Radius::DHCPv6::DUID_TYPE_LLT                    = 1;
$Radius::DHCPv6::DUID_TYPE_EN                     = 2;
$Radius::DHCPv6::DUID_TYPE_LL                     = 3;

%Radius::DHCPv6::message_type_to_name =
(
 $Radius::DHCPv6::MESSAGE_TYPE_SOLICIT             => 'SOLICIT',
 $Radius::DHCPv6::MESSAGE_TYPE_ADVERTISE           => 'ADVERTISE',
 $Radius::DHCPv6::MESSAGE_TYPE_REQUEST             => 'REQUEST',
 $Radius::DHCPv6::MESSAGE_TYPE_CONFIRM             => 'CONFIRM',
 $Radius::DHCPv6::MESSAGE_TYPE_RENEW               => 'RENEW',
 $Radius::DHCPv6::MESSAGE_TYPE_REBIND              => 'REBIND',
 $Radius::DHCPv6::MESSAGE_TYPE_REPLY               => 'REPLY',
 $Radius::DHCPv6::MESSAGE_TYPE_RELEASE             => 'RELEASE',
 $Radius::DHCPv6::MESSAGE_TYPE_DECLINE             => 'DECLINE',
 $Radius::DHCPv6::MESSAGE_TYPE_RECONFIGURE         => 'RECONFIGURE',
 $Radius::DHCPv6::MESSAGE_TYPE_INFORMATION_REQUEST => 'INFORMATION_REQUEST',
 $Radius::DHCPv6::MESSAGE_TYPE_RELAY_FORW          => 'RELAY_FORW',
 $Radius::DHCPv6::MESSAGE_TYPE_RELAY_REPLY         => 'RELAY_REPLY',
);

%Radius::DHCPv6::option_type_to_name =
(
 $Radius::DHCPv6::OPTION_CLIENTID                  => 'CLIENTID',
 $Radius::DHCPv6::OPTION_SERVERID                  => 'SERVERID',
 $Radius::DHCPv6::OPTION_IA_NA                     => 'IA_NA',
 $Radius::DHCPv6::OPTION_IA_TA                     => 'IA_TA',
 $Radius::DHCPv6::OPTION_IAADDR                    => 'IAADDR',
 $Radius::DHCPv6::OPTION_ORO                       => 'ORO',
 $Radius::DHCPv6::OPTION_PREFERENCE                => 'PREFERENCE',
 $Radius::DHCPv6::OPTION_ELAPSED_TIME              => 'ELAPSED_TIME',
 $Radius::DHCPv6::OPTION_RELAY_MSG                 => 'RELAY_MSG',
 $Radius::DHCPv6::OPTION_AUTH                      => 'AUTH',
 $Radius::DHCPv6::OPTION_UNICAST                   => 'UNICAST',
 $Radius::DHCPv6::OPTION_STATUS_CODE               => 'STATUS_CODE',
 $Radius::DHCPv6::OPTION_RAPID_COMMIT              => 'RAPID_COMMIT',
 $Radius::DHCPv6::OPTION_USER_CLASS                => 'USER_CLASS',
 $Radius::DHCPv6::OPTION_VENDOR_CLASS              => 'VENDOR_CLASS',
 $Radius::DHCPv6::OPTION_VENDOR_OPTS               => 'VENDOR_OPTS',
 $Radius::DHCPv6::OPTION_INTERFACE_ID              => 'INTERFACE_ID',
 $Radius::DHCPv6::OPTION_RECONF_MSG                => 'RECONF_MSG',
 $Radius::DHCPv6::OPTION_RECONF_ACCEPT             => 'RECONF_ACCEPT',
 $Radius::DHCPv6::OPTION_DNS_SERVERS               => 'DNS_SERVERS',
 $Radius::DHCPv6::OPTION_DOMAIN_LIST               => 'DOMAIN_LIST',
 $Radius::DHCPv6::OPTION_IA_PD                     => 'IA_PD',
 $Radius::DHCPv6::OPTION_IAPREFIX                  => 'IAPREFIX',
);

# A reverse map of option names to option numbers
%Radius::DHCPv6::option_name_to_type = reverse %Radius::DHCPv6::option_type_to_name;

%Radius::DHCPv6::status_code_to_name =
(
 $Radius::DHCPv6::STATUS_CODE_SUCCESS              => 'SUCCESS',
 $Radius::DHCPv6::STATUS_CODE_UNSPEC_FAIL          => 'UNSPEC_FAIL',
 $Radius::DHCPv6::STATUS_CODE_NO_ADDRS_AVAIL       => 'NO_ADDRS_AVAIL',
 $Radius::DHCPv6::STATUS_CODE_NO_BINDING           => 'NO_BINDING',
 $Radius::DHCPv6::STATUS_CODE_NOT_ON_LINK          => 'NOT_ON_LINK',
 $Radius::DHCPv6::STATUS_CODE_USE_MULTICAST        => 'USE_MULTICAST',
 $Radius::DHCPv6::STATUS_CODE_NO_PREFIX_AVAIL      => 'NO_PREFIX_AVAIL', # RFC 3633
);

package Radius::DHCPv6::DUID;

#####################################################################
# Make a DUID-LLT
sub encodeLLT
{
    my ($hw_type, $link_layer_address) = @_;

    return pack('n n N a*', $Radius::DHCPv6::DUID_TYPE_LLT, $hw_type, time, $link_layer_address);
}

#####################################################################
# Make a DUID-EN
sub encodeEN
{
    my ($enterprise_number, $identifier) = @_;

    return pack('n N a*', $Radius::DHCPv6::DUID_TYPE_EN, $enterprise_number, $identifier);
}

#####################################################################
# Make a DUID-LL
sub encodeLL
{
    my ($hw_type, $link_layer_address) = @_;

    return pack('n n a*', $Radius::DHCPv6::DUID_TYPE_LL, $hw_type, $link_layer_address);
}

package Radius::DHCPv6::Message;

#####################################################################
# transaction-id will be filled in when sending
sub new
{
    my ($class, $message_type, @options) = @_;

    my $self = {};
    bless $self, $class;
    $self->{message_type} = $message_type;
    @{$self->{options}} = @options;

    return $self;
}

#####################################################################
sub add_option
{
    my ($self, @args) = @_;

    push(@{$self->{options}}, [@args]);
    return 1;
}

#####################################################################
sub count_options
{
    my ($self) = @_;

    return scalar @{$self->{options}};
}

#####################################################################
sub options
{
    my ($self) = @_;

    return @{$self->{options}};
}

#####################################################################
# Returns the FIRST instance of the indicated option type from the
# option list
sub get_option
{
    my ($option_type, @option_list) = @_;

    my $index;
    for ($index = 0; $index < scalar @option_list; $index++)
    {
	return @{$option_list[$index]} if $option_list[$index][0] == $option_type;
    }
    return;
}

#####################################################################
# Returns the FIRST instance of the indicated option type in this
# message
sub option
{
    my ($self, $option_type) = @_;

    return &get_option($option_type, @{$self->{options}});
}

#####################################################################
# Returns the nth option from the option list
sub get_option_n
{
    my ($n, @option_list) = @_;

    return if $n >= scalar @option_list;
    return @{$option_list[$n]};
}

#####################################################################
# Returns the nth option in this message
sub option_n
{
    my ($self, $n) = @_;

    return &get_option_n($n, @{$self->{options}});
}

#####################################################################
sub encode_option
{
    my ($self, $option_type, @args) = @_;

    my $option_data = '';
    if ($option_type == $Radius::DHCPv6::OPTION_CLIENTID
	|| $option_type == $Radius::DHCPv6::OPTION_SERVERID
	|| $option_type == $Radius::DHCPv6::OPTION_DOMAIN_LIST)
    {
	# DUID
	# searchlist
	$option_data = $args[0];
    }
    elsif (   $option_type == $Radius::DHCPv6::OPTION_IA_NA
	   || $option_type == $Radius::DHCPv6::OPTION_IA_PD)
    {
	# IAID, T1, T2, IA_NA-options
	# IAID, T1, T2, IA_PD-options
	my $iaid = shift(@args);
	my $t1 = shift(@args);
	my $t2 = shift(@args);
	my $options = $self->encode_options(@args);
	$option_data = pack('N N N a*', $iaid, $t1, $t2, $options);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_IA_TA)
    {
	# IAID, IA_TA-options
	my $iaid = shift(@args);
	my $options = $self->encode_options(@args);
	$option_data = pack('N a*', $iaid, $options);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_IAADDR)
    {
	# address, preferred-lifetime, valid-lifetime, IAaddr-options
	my $address = shift(@args);
	my $preferred_lifetime = shift(@args);
	my $valid_lifetime = shift(@args);
	my $options = $self->encode_options(@args);
	$option_data = pack('a16 N N a*', $address, $preferred_lifetime, $valid_lifetime, $options);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_ORO)
    {
	# requested-option-code-1, requested-option-code-2, ....
	$option_data = pack('n*', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_PREFERENCE
	   || $option_type == $Radius::DHCPv6::OPTION_RECONF_MSG)
    {
	# pref-value
	# msg-type
	$option_data = pack('C', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_ELAPSED_TIME
	|| $option_type == $Radius::DHCPv6::OPTION_STATUS_CODE)
    {
	# elapsed-time
	# status-code
	$option_data = pack('n', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_RELAY_MSG)
    {
	# DHCP-relay-message
	$option_data = $args[0];
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_AUTH)
    {
	# protocol, algorithm, RDM, Replay-detection, authentication-information
	$option_data = pack('C C C a4 a*', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_UNICAST)
    {
	# server-address
	$option_data = pack('a16', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_RAPID_COMMIT
	|| $option_type == $Radius::DHCPv6::OPTION_RECONF_ACCEPT)
    {
	# ----
	$option_data = '';
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_USER_CLASS)
    {
	# opaque-data-1, opaque-data-2, ....
	$option_data = pack('(n/a*)*', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_VENDOR_CLASS)
    {
	# enterprise-number, opaque-data-1, opaque-data-2, ....
	$option_data = pack('N (n/a*)*', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_VENDOR_OPTS)
    {
	# enterprise-number, option-data
	$option_data = pack('N a*', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_DNS_SERVERS)
    {
	# name-server-1, name-server-2, ...
	$option_data = pack('(a16)*', @args);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_IAPREFIX)
    {
	# preferred-lifetime, valid-lifetime, prefix-length, prefix, IAprefix-options
	my $preferred_lifetime = shift(@args);
	my $valid_lifetime = shift(@args);
	my $prefix_length = shift(@args);
	my $prefix = shift(@args);
	my $options = $self->encode_options(@args);
	$option_data = pack('N N C a16 a*', $preferred_lifetime, $valid_lifetime, $prefix_length, $prefix, $options);
    }
    else
    {
	# Error
	return;
    }
    return pack('n n/a*', $option_type, $option_data);
}

#####################################################################
# Encode an array of option arrays
sub encode_options
{
    my ($self, @args) = @_;

    my $options = '';
    foreach (@args)
    {
	$options .= $self->encode_option(@$_);
    }
    return $options;
}

#####################################################################
sub decode_option
{
    my ($self, $option_type, $option_data) = @_;

    if ($option_type == $Radius::DHCPv6::OPTION_CLIENTID
	|| $option_type == $Radius::DHCPv6::OPTION_SERVERID
	|| $option_type == $Radius::DHCPv6::OPTION_DOMAIN_LIST)
    {
	# DUID
	# searchlist
	return $option_data;
    }
    elsif (   $option_type == $Radius::DHCPv6::OPTION_IA_NA
	   || $option_type == $Radius::DHCPv6::OPTION_IA_PD)
    {
	# IAID, T1, T2, IA_NA-options
	my ($iaid, $t1, $t2, $options) = unpack('N N N a*', $option_data);
	my @options = $self->decode_options($options);
	return ($iaid, $t1, $t2, @options);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_IA_TA)
    {
	# IAID, IA_TA-options
	my ($iaid, $options) = unpack('N a*', $option_data);
	my @options = $self->decode_options($options);
	return ($iaid, @options);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_IAADDR)
    {
	# address, preferred-lifetime, valid-lifetime, IAaddr-options
	my ($address, $preferred_lifetime, $valid_lifetime, $options) = unpack('a16 N N a*', $option_data);
	my @options = $self->decode_options($options);
	return ($address, $preferred_lifetime, $valid_lifetime, @options);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_ORO)
    {
	# requested-option-code-1, requested-option-code-2, ....
	return unpack('n*', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_PREFERENCE
	   || $option_type == $Radius::DHCPv6::OPTION_RECONF_MSG)
    {
	# pref-value
	# msg-type
	return unpack('C', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_ELAPSED_TIME)
    {
	# status-code
	return unpack('n', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_RELAY_MSG)
    {
	# DHCP-relay-message
	return $option_data;
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_AUTH)
    {
	# protocol, algorithm, RDM, Replay-detection, authentication-information
	return unpack('C C C a4 a*', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_UNICAST)
    {
	# server-address
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_STATUS_CODE)
    {
	# status-code, status-message
	return unpack('n a*', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_RAPID_COMMIT
	|| $option_type == $Radius::DHCPv6::OPTION_RECONF_ACCEPT)
    {
	# ----
	return;
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_USER_CLASS)
    {
	# opaque-data-1, opaque-data-2, ....
	my @ret;
	eval {@ret = unpack('(n/a*)*', $option_data)}; # Can die
	return @ret;
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_VENDOR_CLASS)
    {
	# enterprise-number, opaque-data-1, opaque-data-2, ....
	my @ret;
	eval {@ret = unpack('N (n/a*)*', $option_data)} ; # Can die
	return @ret;
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_VENDOR_OPTS)
    {
	# enterprise-number, option-data
	return unpack('N a*', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_DNS_SERVERS)
    {
	# name-server-1, name-server-2, ...
	return unpack('(a16)*', $option_data);
    }
    elsif ($option_type == $Radius::DHCPv6::OPTION_IAPREFIX)
    {
	# preferred-lifetime, valid-lifetime, prefix-length, prefix, IAprefix-options
	my ($preferred_lifetime, $valid_lifetime, $prefix_length, $prefix, $options) = unpack('N N C a16 a*', $option_data);
	my @options = $self->decode_options($options);
	return ($preferred_lifetime, $valid_lifetime, $prefix_length, $prefix, @options);
    }
    # Error
    return;
}

#####################################################################
sub decode_options
{
    my ($self, $options_data) = @_;

    my @options;
    eval { @options = unpack('(n n/a*)*', $options_data) }; # Can die

    my @decoded_options;
    while (@options > 1)
    {
	my $option_type = shift(@options);
	my $option_data = shift(@options);
	my @args = $self->decode_option($option_type, $option_data);

	push(@decoded_options, [$option_type, @args]);
    }
    return @decoded_options;
}

#####################################################################
sub encode
{
    my ($self) = @_;

    return pack('C a3 a*', $self->{message_type}, $self->{transaction_id}, $self->encode_options(@{$self->{options}}));
}

#####################################################################
sub decode
{
    my ($self, $data) = @_;

    return unless defined $data && length($data) >= 4;

    my $options_data;
    ($self->{message_type}, $self->{transaction_id}, $options_data) = unpack('C a3 a*', $data);

    @{$self->{options}} = $self->decode_options($options_data);
    return $self;
}

#####################################################################
# Dump an array of options. Dont drill into them
sub dump_options
{
    my ($self, @args) = @_;

    my $ret = '';
    foreach (@args)
    {
	my ($option_type, @option_args) = @$_;
	my $option_name = $Radius::DHCPv6::option_type_to_name{$option_type};
	$ret .= " $option_name: ";
	foreach (@option_args)
	{
	    if (/[[:^print:]]/)
	    {
		$ret .= unpack('H*', $_) . ' ';
	    }
	    else
	    {
		$ret .= $_ . ' ';
	    }
	}
	$ret .= "\n";
    }
    return $ret;
}

#####################################################################
# Pretty print options list
sub dump
{
    my ($self) = @_;

    my $type = $Radius::DHCPv6::message_type_to_name{$self->{message_type}};
    my $transaction_id = unpack('H*', $self->{transaction_id});
    return "$type transaction-id $transaction_id\n" . $self->dump_options(@{$self->{options}});
}

1;
