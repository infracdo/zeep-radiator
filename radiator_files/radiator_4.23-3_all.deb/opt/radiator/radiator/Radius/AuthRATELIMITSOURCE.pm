# AuthRATELIMITSOURCE.pm
#
# Object for limiting RADIUS request rates per sending source
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2017 Open System Consultants
# $Id$

package Radius::AuthRATELIMITSOURCE;
@ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use B;
use strict;
use warnings;

%Radius::AuthRATELIMITSOURCE::ConfigKeywords =
(
 'SourceKey1' =>
 ['string', 'Defines how to format first level policer key. Defaults to \'%{Request:Calling-Station-Id}:%n\'.', 1],

 'SourceKey2' =>
 ['string', 'Defines how to format second level policer key. Defaults to \'%{Client:Identifier}\'.', 1],

 'MaxRate1' =>
 ['integer', 'Maximum allowed rate for first level policer. Defaults to 10.', 1],

 'MaxRate2' =>
 ['integer', 'Maximum allowed rate for second level policer. Defaults to 2000.', 1],

 'Policer1_Size' =>
 ['integer', 'Number of first level policer counters. Defaults to 1000.', 1],

 'Policer2_Size' =>
 ['integer', 'Number of second level policer counters. Defaults to 100.', 1],

 'TimeWindow1' =>
 ['integer', 'Time window of first level policer. Defaults to 2.', 1],

 'TimeWindow2' =>
 ['integer', 'Time window of second level policer. Defaults to 10.', 1],

 'MaxRateResult' =>
 ['string', 'Result to use when MaxRate1 or MaxRate2 is exceeded. The possible case insensitive values are ACCEPT, REJECT, IGNORE and CHALLENGE. The default behaviour is to IGNORE the request.', 1],
);

# RCS version number of this module
$Radius::AuthRATELIMITSOURCE::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{SourceKey1} = '%{Request:Calling-Station-Id}:%n';
    $self->{SourceKey2} = '%{Client:Identifier}';
    $self->{MaxRate1} = 10;
    $self->{MaxRate2} = 2000;
    $self->{Policer1_Size} = 1000;
    $self->{Policer2_Size} = 100;
    $self->{TimeWindow1} = 2;
    $self->{TimeWindow2} = 10;
    $self->{MaxRateResult} = 'IGNORE';

    return;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    $self->{policer1_size} = $self->{Policer1_Size};
    if ($self->{Policer1_Size} < 1)
    {
	$self->{policer1_size} = 1000;
	$self->log($main::LOG_WARNING, "AuthBy RATELIMITSOURCE: Invalid value for Policer1_Size, using 1000");
    }

    $self->{policer2_size} = $self->{Policer2_Size};
    if ($self->{Policer2_Size} < 1)
    {
	$self->{policer2_size} = 100;
	$self->log($main::LOG_WARNING, "AuthBy RATELIMITSOURCE: Invalid value for Policer2_Size, using 100");
    }

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    $self->{max_rate_result} = $self->stringToResult($self->{MaxRateResult});

    $self->{policers1} = [];
    foreach (1 .. $self->{policer1_size})
    {
	push(@{$self->{policers1}}, {requests_in_window => 0, last_time => 0});
    }

    $self->{policers2} = [];
    foreach (1 .. $self->{policer2_size})
    {
	push(@{$self->{policers2}}, {requests_in_window => 0, last_time => 0});
    }

    return;
}

sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    my ($policer1, $policer2);

    my $index1 = 0;
    if ($self->{policer1_size} > 1)
    {
	my $key = Radius::Util::format_special($self->{SourceKey1}, $p);
	my $hash = substr(B::hash($key), 2, 8); # Skip leading 0x and truncate if needed
	$index1 = hex($hash) % $self->{policer1_size};
    }
    $policer1 = @{$self->{policers1}}[$index1];

    my $index2 = 0;
    if ($self->{policer2_size} > 1)
    {
	my $key = Radius::Util::format_special($self->{SourceKey2}, $p);
	my $hash = substr(B::hash($key), 2, 8); # Skip leading 0x and truncate if needed
	$index2 = hex($hash) % $self->{policer2_size};
    }
    $policer2 = @{$self->{policers2}}[$index2];

    my $time = time();

    if (!$policer1->{last_time} || $time >= ($policer1->{last_time} + $self->{TimeWindow1}))
    {
	$policer1->{requests_in_window} = 1;
	$policer1->{last_time} = $time;
    }
    else
    {
	$policer1->{requests_in_window}++;
    }

    if ($policer1->{requests_in_window} > $self->{MaxRate1})
    {
	return ($self->{max_rate_result}, 'Rate limit MaxRate1 exceeded');
    }

    if (!$policer2->{last_time} || $time  >= ($policer2->{last_time} + $self->{TimeWindow2}))
    {
	$policer2->{requests_in_window} = 1;
	$policer2->{last_time} = $time;
    }
    else
    {
	$policer2->{requests_in_window}++;
    }

    if ($policer2->{requests_in_window} > $self->{MaxRate2})
    {
	return ($self->{max_rate_result}, 'Rate limit MaxRate2 exceeded');
    }

    return ($main::ACCEPT, 'Both policers passed');
}

sub stringToResult
{
    my ($self, $s) = @_;

    if ($s =~ /accept/i)
    {
	return $main::ACCEPT;
    }
    elsif ($s =~ /reject/i)
    {
	return $main::REJECT;
    }
    elsif ($s =~ /ignore/i)
    {
	return $main::IGNORE;
    }
    elsif ($s =~ /challenge/i)
    {
	return $main::CHALLENGE;
    }

    $self->log($main::LOG_WARNING, "AuthRATELIMITSOURCE: Unknown result code string $s. Using IGNORE");
    return $main::IGNORE;
}

1;
