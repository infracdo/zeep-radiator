# UtilClient.pm
#
# Utility routines for client programs.
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2017 Open System Consultants
# $Id$

package Radius::UtilClient;
use Scalar::Util 'blessed';
use strict;
use warnings;

# RCS version number of this module
$Radius::UtilClient::VERSION = '$Revision$';

# Echo/No Echo password read depends on Prompt attribute in the
# message $p. The message can be an attribute container Diameter or
# RADIUS uses.
#
# Unknown types and non-objects result in no echo password read.
sub read_password
{
    my ($p, $prompt) = @_;

    my $prompt_attr;
    if (blessed($p))
    {
	$prompt_attr = 	$p->get_attr_d('Prompt') if $p->isa('Radius::DiaAttrList');
	$prompt_attr = 	$p->get_attr('Prompt')   if $p->isa('Radius::AttrVal');
    }

    return read_password_echo($prompt)
	if $prompt_attr && ($prompt_attr eq 'Echo' || $prompt_attr eq '1');

    return read_password_noecho($prompt);
}

# Read password from STDIN with local echo turned off
sub read_password_noecho
{
    my ($prompt) = @_;

    my $use_term_readkey = 1;
    my $stty_path;

    eval { require Term::ReadKey; };
    if ($@)
    {
	if ($^O eq 'MSWin32')
	{
	    main::log($main::LOG_WARNING, "Could not load library Term::ReadKey, unable to turn off the local echo of the terminal.");
	    exit(1);
	}
	main::log($main::LOG_DEBUG, "Could not load library Term::ReadKey, trying to turn off the local echo of the terminal with a command 'stty -echo'.");
	$use_term_readkey = 0;
    }

    $prompt = "Password (local echo disabled): " unless $prompt;
    print $prompt;
    if ($use_term_readkey)
    {
	Term::ReadKey::ReadMode('noecho');
    }
    else
    {
	if (-x '/usr/bin/stty')
	{
	    $stty_path = '/usr/bin/stty';
	    system("$stty_path", '-echo');
	}
	elsif (-x '/bin/stty')
	{
	    $stty_path = '/bin/stty';
	    system("$stty_path", '-echo');
	}
    }

    my $password = <STDIN>;
    print "\n";
    if ($use_term_readkey)
    {
	Term::ReadKey::ReadMode(0);
    }
    else
    {
	system("$stty_path", 'echo');
    }

    chomp $password;
    return $password;
}

# Read password from STDIN with local echo turned on
sub read_password_echo
{
    my ($prompt) = @_;

    $prompt = "Password (local echo enabled): " unless $prompt;
    print $prompt;

    my $password = <STDIN>;
    chomp $password;
    return $password;
}

1;
