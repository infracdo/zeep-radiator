# VSA.pm
#
# Routines for custom unpacking and packing of RADIUS VSAs.
#
# Looks for a vendor specific module in Radius/VSA/vendor.pm, and then
# tries to run a attribute's custom unpack/pack function in that module.
#
# This makes it easier to add support for custom VSA types.
# If you add support for your custom VSA, please consider sending
# it to Open System Consultants for inclusion in future releases.
#
# Copyright (C) 2017 Open System Consultants
# Author: Tuure Vartiainen (vartiait@open.com.au)
# $Id$

package Radius::VSA;
use Radius::Log;
use strict;
use warnings;

# RCS version number of this module
$Radius::VSA::VERSION = '$Revision$';

# Hash of loaded module class instances. Eventually this should replace %module_loaded use
%Radius::VSA::VendorClasses = ();

# Make sure we get reinitialized on sighup
push(@main::reinitFns, \&reinitialize);

# Make sure the vendor class instances will be re-created
sub reinitialize
{
    %Radius::VSA::VendorClasses = ();
    return;
}

#####################################################################
# Pack a custom VSA to binary
#
# Returns the packed value when successful.
# In case of error, missing capability in the vendor specific class or
# for any other reason, returns the original unpacked value.
sub packCustom
{
    my ($value, $name, $dict, $p) = @_;

    my ($aname, $anum, $atype, $avendor, $dflags) = $dict->attrByName($name);

    # Ex
    # value: 12345678, name: 3GPP-User-Location-Info, aname: 3GPP-User-Location-Info, anum: 22, atype: custom, avendor: 10415, dflags:

    main::log($main::LOG_DEBUG, "Packing custom RADIUS VSA $name ($avendor/$anum)");

    my $vendor = getVSAClass($avendor);
    if ($vendor)
    {
	my $pack_custom = $vendor->can("pack_$anum");
	my $packed_value = $pack_custom ? &$pack_custom($vendor, $value, $p) : undef;
	return $packed_value if defined $packed_value;
    }

    # Fail
    main::log($main::LOG_WARNING, "Attribute $name: Failed to parse custom: $value");
    return $value;
}

#####################################################################
# Unpack a custom VSA into string form
#
# Returns the unpacked value when successful.
# In case of error, missing capability in the vendor specific class or
# for any other reason, returns the original packed value.
sub unpackCustom
{
    my ($value, $type, $name, $dict, $p) = @_;

    my ($aname, $anum, $atype, $avendor, $dflags) = $dict->attrByName($name);

    # Ex
    # value: custom-encoded-attribute, type: custom, name: 3GPP-User-Location-Info, aname: 3GPP-User-Location-Info, anum: 22, atype: custom, avendor: 10415, dflags:

    main::log($main::LOG_DEBUG, "Unpacking custom RADIUS VSA $name ($avendor/$anum)", $p);

    my $vendor = getVSAClass($avendor);
    if ($vendor)
    {
	my $unpack_custom = $vendor->can("unpack_$anum");
	my $unpacked_value = $unpack_custom ? &$unpack_custom($vendor, $value, $p) : undef;
	return $unpacked_value if defined $unpacked_value;
    }

    # Fail
    main::log($main::LOG_WARNING, "Attribute $name: Failed to decode custom: $value", $p);
    return $value;
}

####################################################################
# Load the VSA/Vendor.pm
sub getVSAClass
{
    my ($vsa_vendor) = @_;

    # Strip all atypical characters
    $vsa_vendor =~ s/[^a-z0-9_-]//ig;

    return $Radius::VSA::VendorClasses{$vsa_vendor} if exists $Radius::VSA::VendorClasses{$vsa_vendor};

    my $class = "Radius::VSA::Vendor_$vsa_vendor";
    main::log($main::LOG_DEBUG, "Radius::VSA loads $class");
    my $path = Radius::Util::classname_to_path($class);
    if (eval{require $path;})
    {
	$Radius::VSA::VendorClasses{$vsa_vendor} = $class->new();
    }
    else
    {
	main::log($main::LOG_ERR, "Radius::VSA could not load vendor module $class: $@");
    }

    return $Radius::VSA::VendorClasses{$vsa_vendor};
}

1;
