# AuthLogSYSLOG.pm
#
# Specific class for logging authentication to SYSLOG
#
# Changed from AuthLogSQL.pm, AuthLogFILE.pm and LogSYSLOG.pm
# by Carlos Canau <canau@kpnqwest.pt>
# Copyright (C) Open System Consultants
#
# version 2000/12/11
#
# AuthLogSQL.pm Author: contributed by Dave Lloyd <david@freemm.org>
# $Id$

package Radius::AuthLogSYSLOG;
@ISA = qw(Radius::AuthLogGeneric);
use Radius::AuthLogGeneric;
use Radius::Configurable;
use Sys::Syslog qw(:DEFAULT setlogsock);
use strict;

%Radius::AuthLogSYSLOG::ConfigKeywords = 
('Facility'      => 
 ['string', 'The name of the syslog facility that will be logged to. The default is \'user\'.', 1],

 'Priority'      => 
 ['string', 'The syslog priority level that will be used for each log message. Default is \'info\'.', 1],

 'SuccessFormat' => 
 ['string', 'The format for success messages. You can use any of the special characters. Defaults to \'%l:%U:%P:OK\'.', 1],

 'FailureFormat' => 
 ['string', 'The format for failure messages. You can use any of the special characters. Defaults to \'%l:%U:%P:FAIL\'.', 1],

 'IgnoreFormat' => 
 ['string', 'The format for ignore messages. You can use any of the special characters. Defaults to \'%l:%U:%P:IGNORE\'.', 1],

 'LogSock'       => 
 ['string', 'This optional parameter specifies what type of socket to use to connect to the syslog server. Allowable values are unix, inet, tcp, udp. Defaults to unix. The option inet means to try tcp first, then udp. The default is to use the Sys::Syslog default of tcp, udp, unix, stream, console.', 1],

 'LogPort' =>
 ['integer', 'This optional parameter specifies the destination port for the syslog server.', 1],

 'LogIdent'      => 
 ['string', 'This optional parameter specifies an alternative ident name to be used for logging. Defaults to the executable name used to run radiusd. Special characters are suported.', 1],

 'LogOpt'      => 
 ['string', 'This optional comma separated parameter specifies an alternative set of options for openlog(3). Defaults to \'pid\'. Special characters are suported.', 1],

 'LogHost'       => 
 ['string', 'When LogSock is set to tcp or udp or inet, this optional parameter specifies the name or address of the syslog host. Defaults to the local host. Special characters are suported.', 0],

 'LogPath'  =>
 ['string', 'When LogSock is set to unix or stream or pipe, this optional parameter specifies the syslog path. Defaults to _PATH_LOG macro (if your system defines it).', 1],

 );

# RCS version number of this module
$Radius::AuthLogSYSLOG::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initialize instance 
# variables
# that might get overridden when the config file is parsed.
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Facility} = 'user';
    $self->{Priority} = 'info';
    $self->{SuccessFormat} = '%l:%U:%P:OK';
    $self->{FailureFormat} = '%l:%U:%P:FAIL';
    $self->{IgnoreFormat} = '%l:%U:%P:IGNORE';
    $self->{LogIdent} = $0;
    $self->{LogOpt} = 'pid';
}

sub check_config
{
    my ($self) = @_;

    # Validate LogOpt. LogOpt can be empty.
    map
    {
	main::log($main::LOG_ERR, "Invalid LogOpt '$_' in AuthLog SYSLOG $self->{Identifier}")
	    unless ($_ =~ /^(cons|ndelay|nofatal|nowait|perror|pid)$/)
    } split /,/, $self->{LogOpt};

    # LogPort works with Sys::Syslog 0.28 or later
    if ($self->{LogPort})
    {
	my $type = ref($self);
	eval { require version; }; # Should be in Perl 5.10 and later
	if ($@)
	{
	    main::log($main::LOG_WARNING, "$type: LogPort only works with Sys::Syslog 0.28 or later. Your Sys::Syslog version is $Sys::Syslog::VERSION. Could not reliable compare versions, so make sure your Sys::Syslog is recent enough");
	    # Trust the user to now the feature is available
	    $self->{syslog_new_setlogsock} = 1;
	}
	else
	{
	    if (version->parse($Sys::Syslog::VERSION) < version->parse('0.28'))
	    {
		main::log($main::LOG_ERR, "$type: LogPort only works with Sys::Syslog 0.28 or later. Your Sys::Syslog version is $Sys::Syslog::VERSION. LogPort ignored");
	    }
	    else
	    {
		# We know the feature is available
		$self->{syslog_new_setlogsock} = 1;
	    }
	}
    }

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Log a message 
sub authlog
{
    my ($self, $s, $reason, $p) = @_;

    # Leave now if this type of result should not be logged
    return unless
      ($s == $main::ACCEPT && $self->{LogSuccess} ||
       $s == $main::REJECT && $self->{LogFailure} ||
       $s == $main::IGNORE && $self->{LogIgnore});

    my $message;
    my $trace_id = $p->{trace_id};
    if (defined $self->{LogFormatHook})
    {
	($message) = $self->runHook('LogFormatHook', $p, $s, $reason, $p, $trace_id);
    }
    elsif (defined($self->{SuccessFormat})
	   && $s == $main::ACCEPT)
    {
	$message = &Radius::Util::format_special
	    ($self->{SuccessFormat}, $p, undef, $s, $reason, $trace_id);
    }
    elsif (defined($self->{FailureFormat})
	   && $s == $main::REJECT)
    {
	$message = &Radius::Util::format_special
	    ($self->{FailureFormat}, $p, undef, $s, $reason, $trace_id);
    }
    elsif (defined($self->{IgnoreFormat}) 
	   && $s == $main::IGNORE)
    {
    	$message = &Radius::Util::format_special
	    ($self->{IgnoreFormat}, $p, undef, $s, $reason, $trace_id);
    }
    else
    {
    	return;
    }

    # syslog can die:
    $message = substr($message, 0, $self->{MaxMessageLength}) if $self->{MaxMessageLength};
    $message =~ s/%/%%/g; # Make sure to escape any % signs that would be interpreted as printf
    my $ident = &Radius::Util::format_special($self->{LogIdent}, $p);
    my $logopt = &Radius::Util::format_special($self->{LogOpt}, $p);
    my $loghost = (length $self->{LogHost}) ? &Radius::Util::format_special($self->{LogHost}, $p) : undef;
    eval {
	my $res = 1; # Reset by setlogsock, if called

	# We reset these here in case there are multiple SYSLOG
	# callers with different configs.
	# Caution: there is no way to reset logsock back to the
	# default, so if you have multiple SYSLOG clauses, if any one
	# has LogSock defined, they must all have LogSock defined
	if ($self->{syslog_new_setlogsock})
	{
	    my $sock_opts = {};
	    $sock_opts->{port} = $self->{LogPort} if defined $self->{LogPort};
	    $sock_opts->{host} = $self->{LogHost} if $loghost;
	    $sock_opts->{type} = $self->{LogSock} if defined $self->{LogSock};
	    $sock_opts->{path} = $self->{LogPath} if defined $self->{LogPath};
	    $res = setlogsock($sock_opts) if %{$sock_opts};
	    # REVISIT: There is a bug in Sys::Syslog::setlogsock() which undefines $Sys::Syslog::host
	    # when $self->{LogPort} is not defined.
	    $Sys::Syslog::host = $loghost if $loghost;
	}
	else
	{
	    $res = setlogsock($self->{LogSock}) if defined $self->{LogSock};
	    $Sys::Syslog::host = $loghost if $loghost;
	}

	# setlogsock, if called, has set res to true on success and undef on failure
	if ($res)
	{
	    openlog($ident, $logopt, $self->{Facility});
	    syslog("$self->{Priority}", $message);

	    # closelog returns true on success
	    unless (closelog())
	    {
		my $warn_msg = "AuthLogSYSLOG: error in closing log";
		main::log($main::LOG_ERR, $warn_msg);
	    }
	}
	else
	{
	    my $warn_msg = "AuthLogSYSLOG: error in setting socket type and/or options. Check logging parameters";
	    main::log($main::LOG_ERR, $warn_msg);
	}
    };
    &main::log($main::LOG_ERR, "Error while doing AuthLog SYSLOG: $@")
	if $@;
}

1;
