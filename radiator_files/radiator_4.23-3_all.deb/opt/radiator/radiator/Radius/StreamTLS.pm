# StreamTLS.pm
#
# Radius module for supporting some TLS operations on stream connections
# including some that should really be available in openssl.
# Processes TLS and SSL streams
#
# Requires Net_SSLeay.pm-1.26 or later
# Requires openssl 0.9.8 or later
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002-2005 Open System Consultants
# $Id$
package Radius::StreamTLS;
use Radius::Util;
use Radius::TLS;
use strict;

# RCS version number of this module
$Radius::StreamTLS::VERSION = '$Revision$';

# Whether or not the TLS library has been initialised
$Radius::StreamTLS::initialised = undef;

# This is the closure to be called when a client certificate is to be verified
# There is only one, due to limitations in SSLeay, so it must be set and cleared
# during each call to openssl that might result in a ceritifacte verification 
# ie before calling accept().
# It is required to return 0 if there is no error in validating the certificate
# else an error code from the set X509_V_ERR* in openssl/include/x509_vfy.h
$Radius::StreamTLS::verifyFn = undef;

# This is the closure to be called when a client certificate verification failed.
# It is required to return 0 if there is no error in validating the certificate,
# or an error code from the set X509_V_ERR* in openssl/include/x509_vfy.h,
# or < 0 for a failure
$Radius::StreamTLS::verifyFailedFn = undef;

# This flag indicates whetehr the (one and only) password callback funciton has been set
$Radius::StreamTLS::password_callback_set = undef;


#####################################################################
sub init
{
    my ($self) = @_;

    &Radius::TLS::tlsInit();
    $Radius::StreamTLS::initialised++;

    if ($self->{TLS_Protocols})
    {
	my $options = Radius::TLS::tls_protocol_options($self, $self->{TLS_Protocols});
	return unless defined $options;

	$options |= Net::SSLeay::OP_SINGLE_DH_USE();
	$options |= $Radius::TLS::NSL::OP_NO_TICKET;

	$self->{TLS_Options} = $options;
	$self->{ssl_ctx_streamtls} = Net::SSLeay::CTX_new();
    }
    else
    {
	# UseSSL and UseTLS for backwards compatibility
	$self->{TLS_Options} = $self->{UseSSL} ?
	      (&Net::SSLeay::OP_NO_SSLv2
	       | &Net::SSLeay::OP_NO_TLSv1)
	    : (&Net::SSLeay::OP_NO_SSLv2
	       | &Net::SSLeay::OP_NO_SSLv3
	       | &Net::SSLeay::OP_SINGLE_DH_USE
	       | $Radius::TLS::NSL::OP_NO_TICKET)
	    unless defined $self->{TLS_Options};

	$self->{ssl_ctx_streamtls} = $self->{UseSSL}
	    ? &Net::SSLeay::CTX_v23_new()
	    : &Net::SSLeay::CTX_tlsv1_new();
    }

    if (!$self->{ssl_ctx_streamtls})
    {
	$self->log($main::LOG_ERR, 'StreamTLS could not CTX_tlsv1_new');
	return;
    }

    # Suppress sending Session-ID:s to clients and turn off caching completely
    Net::SSLeay::CTX_set_session_cache_mode($self->{ssl_ctx_streamtls}, $Radius::TLS::NSL::SESS_CACHE_OFF);

    # No use to support renegotiation
    $self->{TLS_Options} |= $Radius::TLS::NSL::OP_NO_RENEGOTIATION;
    # Set SSL_OP_NO_COMPRESSION in case we run on a system that still defaults using compression
    $self->{TLS_Options} |= $Radius::TLS::NSL::OP_NO_COMPRESSION;
    &Net::SSLeay::CTX_set_options($self->{ssl_ctx_streamtls}, $self->{TLS_Options});

    my $type = ref($self);
    my $tls_ciphers = defined $self->{TLS_Ciphers} ?
	Radius::Util::format_special($self->{TLS_Ciphers}) :
	"DEFAULT:!EXPORT:!LOW";
    $self->log($main::LOG_DEBUG, "$type $self->{Name} $self->{Identifier} setting TLS_Ciphers to: $tls_ciphers");
    if (Net::SSLeay::CTX_set_cipher_list($self->{ssl_ctx_streamtls}, $tls_ciphers) != 1)
    {
	my $errs = Net::SSLeay::print_errs();
	$self->log($main::LOG_ERR, "StreamTLS could not set_cipher_list to '$tls_ciphers'. Check TLS_Ciphers: $errs");
	$self->{ssl_ctx_streamtls} = undef;
	return;
    }

    $self->{TLS_VerifyMode} = &Net::SSLeay::VERIFY_PEER
	| &Net::SSLeay::VERIFY_CLIENT_ONCE
	unless defined $self->{TLS_VerifyMode};
    $self->{TLS_VerifyMode} |= &Net::SSLeay::VERIFY_FAIL_IF_NO_PEER_CERT
	if $self->{TLS_RequireClientCert};

    my $certtype = defined $self->{TLS_CertificateType} && $self->{TLS_CertificateType} eq 'PEM'
	? &Net::SSLeay::FILETYPE_PEM : &Net::SSLeay::FILETYPE_ASN1;

    # Only set up client cert verification if verify is not completely disabled
    if ($self->{TLS_VerifyMode})
    {
	my $ca_file = Radius::Util::format_special($self->{TLS_CAFile});
	my $ca_path = Radius::Util::format_special($self->{TLS_CAPath});

	if (&Net::SSLeay::CTX_load_verify_locations
	    ($self->{ssl_ctx_streamtls}, $ca_file, $ca_path)
	    != 1)
	{
	    $self->log($main::LOG_ERR, "StreamTLS could not load_verify_locations $ca_file, $ca_path: " . Net::SSLeay::print_errs());
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
	}

	if ($self->{TLS_UseCADefaultLocations} &&
	    &Net::SSLeay::CTX_set_default_verify_paths($self->{ssl_ctx_streamtls}) != 1)
	{
	    my $errs = &Net::SSLeay::print_errs();
	    $self->log($main::LOG_ERR, "StreamTLS could not set_default_verify_paths: $errs");
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
	}

	if ($self->{TLS_CAPartialChain})
	{
	    eval {&Net::SSLeay::X509_STORE_set_flags
		      (&Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx_streamtls}),
		       $Radius::TLS::NSL::X509_V_FLAG_PARTIAL_CHAIN | $Radius::TLS::NSL::X509_V_FLAG_TRUSTED_FIRST);};
	    if ($@)
	    {
		$self->log($main::LOG_WARNING, "TLS_CAPartialChain cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 and OpenSSL to 1.0.2 or later: $@");
	    }
	}

	if ($ca_file)
	{
	    my $cert_names = Net::SSLeay::load_client_CA_file($ca_file);
	    unless ($cert_names)
	    {
		$self->log($main::LOG_ERR, "StreamTLS could not load_client_CA_file $ca_file: " . Net::SSLeay::print_errs());
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }
	    Net::SSLeay::CTX_set_client_CA_list($self->{ssl_ctx_streamtls}, $cert_names);
	}
    }

    if ($self->{TLS_OCSPStapling})
    {
	$self->log($main::LOG_DEBUG, "StreamTLS setting OCSP staple callback");
	# Set a callback for OCSP stapling
	Net::SSLeay::CTX_set_tlsext_status_cb($self->{ssl_ctx_streamtls}, \&ocspCallback, $self);
    }

    # OCSP default values
    $self->{TLS_OCSPCacheSize} = 1000 unless defined $self->{TLS_OCSPCacheSize};
    $self->{TLS_OCSPCacheTime} = 20 * 60 unless defined $self->{TLS_OCSPCacheTime};

    # There is only one callback, but since the callback will
    # only be called once during the subsequent CTX_use_PrivateKey_file
    # we dont care if it is overwritten later. Also, versions of Net_SSLeay up to
    # at least 1.25 are not threadsafe if CTX_set_default_passwd_cb is called more
    # than once in different threads. Make sure the clear the callback after use
    # to prevent these problems.
    my $pw = &Radius::Util::format_special($self->{TLS_PrivateKeyPassword});
    &Net::SSLeay::CTX_set_default_passwd_cb($self->{ssl_ctx_streamtls}, sub {return $pw;});

    if (defined $self->{TLS_CertificateFile} 
	&& &Net::SSLeay::CTX_use_certificate_file
	($self->{ssl_ctx_streamtls}, &Radius::Util::format_special($self->{TLS_CertificateFile}),
	 $certtype) != 1)
    {
	$self->log($main::LOG_ERR, "StreamTLS could not use_certificate_file $self->{TLS_CertificateFile}, $certtype: " . &Net::SSLeay::print_errs());
	$self->{ssl_ctx_streamtls} = undef;
	return;
    }
    
    # Versions of openssl up to 0.9.8e and perhaps later get a bogus 
    # 'file not found' error from 
    # CTX_use_certificate_chain_file unless we clear the error stack first.
    &Net::SSLeay::ERR_clear_error();

    if (defined $self->{TLS_CertificateChainFile} 
	&& &Net::SSLeay::CTX_use_certificate_chain_file
	($self->{ssl_ctx_streamtls}, &Radius::Util::format_special($self->{TLS_CertificateChainFile})) != 1)
    {
	$self->log($main::LOG_ERR, "StreamTLS could not use_certificate_chain_file $self->{TLS_CertificateFile}: " . &Net::SSLeay::print_errs());
	$self->{ssl_ctx_streamtls} = undef;
	return;
    }
    
    if (defined $self->{TLS_PrivateKeyFile}
	&& &Net::SSLeay::CTX_use_PrivateKey_file
	($self->{ssl_ctx_streamtls}, &Radius::Util::format_special($self->{TLS_PrivateKeyFile}), 
	 $certtype) != 1)
    {
	$self->log($main::LOG_ERR, "StreamTLS could not use_PrivateKey_file $self->{TLS_PrivateKeyFile}, $certtype: " . &Net::SSLeay::print_errs());
	$self->{ssl_ctx_streamtls} = undef;
	return;
    }
    # Remove the callback to prevent thread problems that can cause crashes at exit.
    &Net::SSLeay::CTX_set_default_passwd_cb($self->{ssl_ctx_streamtls}, undef);

    if (defined $self->{TLS_RandomFile})
    {
	my $rand_file = Radius::Util::format_special($self->{TLS_RandomFile});
	if (Net::SSLeay::RAND_load_file($rand_file, 1024*1024) < 1)
	{
	    $self->log($main::LOG_ERR, "StreamTLS Could not load randomness from $rand_file: " . Net::SSLeay::print_errs());
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
	}
    }

    # Maybe load the DH group file
    if (defined $self->{TLS_DHFile})
    {
	my $dh_file = Radius::Util::format_special($self->{TLS_DHFile});
	my $bio = &Net::SSLeay::BIO_new_file($dh_file, 'r');
	unless($bio)
	{
	    $self->log($main::LOG_ERR, "StreamTLS BIO_new_file failed for ephemeral DH key file $dh_file: " . Net::SSLeay::print_errs());
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
	}
	my $dh = &Net::SSLeay::PEM_read_bio_DHparams($bio);
	unless($dh)
	{
	    $self->log($main::LOG_ERR, "StreamTLS PEM_read_bio_DHparams failed for ephemeral DH key file $dh_file: " . Net::SSLeay::print_errs());
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
	}
	if (Net::SSLeay::CTX_set_tmp_dh($self->{ssl_ctx_streamtls}, $dh) != 1)
	{
	    $self->log($main::LOG_ERR, "StreamTLS Could not set ephemeral DH key from file $dh_file");
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
	}
	&Net::SSLeay::BIO_free($bio);
	&Net::SSLeay::DH_free($dh);
    }

    if (defined $self->{TLS_ECDH_Curve})
    {
	if (defined &Net::SSLeay::CTX_set_tmp_ecdh)
    	{
	    my $curve_config = $self->{TLS_ECDH_Curve};
	    my $curve = Net::SSLeay::OBJ_txt2nid($curve_config);
	    if ($curve == Net::SSLeay::NID_undef())
	    {
		$self->log($main::LOG_ERR, "StreamTLS Could not find NID for curve '$curve_config'");
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }
	    my $ecdh = Net::SSLeay::EC_KEY_new_by_curve_name($curve);
	    unless ($ecdh)
	    {
		$self->log($main::LOG_ERR, "StreamTLS Could not create curve $curve_config with NID '$curve': " . Net::SSLeay::print_errs());
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }
	    if (Net::SSLeay::CTX_set_tmp_ecdh($self->{ssl_ctx_streamtls}, $ecdh) != 1)
	    {
		$self->log($main::LOG_ERR, "StreamTLS Could not set ephemeral EC key for curve $curve_config: " . Net::SSLeay::print_errs());
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }

	    Net::SSLeay::CTX_set_options($self->{ssl_ctx_streamtls}, Net::SSLeay::OP_SINGLE_ECDH_USE());
	    Net::SSLeay::EC_KEY_free($ecdh);
        }
	else
	{
            $self->log($main::LOG_WARNING, 'StreamTLS Could not use Ephemeral ECDH: too old Net::SSLEAY and/or OpenSSL');
	    $self->{ssl_ctx_streamtls} = undef;
	    return;
        }
    }

    # Maybe check a certificate revocation file (CRL)
    # Caution: if this flag is turned on, we must be able to find a CRL
    # file in TLS_CAPath. CRL files are conventionally named with the hash
    # of the subject name and a suffix that depends on the serial number.
    # eg ab1331b2.r0, ab1331b2.r1 etc.
    # You can find out the hash of the issuer name in a CRL with
    #  openssl crl -in crl.pem -hash -noout
    # If a CRL file cant be found for a given client certificate, the client
    # authentication will fail with a n error:
    #   SSL3_GET_CLIENT_CERTIFICATE:no certificate returned
    if ($self->{TLS_CRLCheck})
    {
	# Sigh, some versions of Net::SSLeay dont have this necessary function
	eval {&Net::SSLeay::X509_STORE_set_flags
		  (&Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx_streamtls}), 
		   &Net::SSLeay::X509_V_FLAG_CRL_CHECK);};
	if ($@)
	{
	    $self->log($main::LOG_ERR, "StreamTLS TLS_CRLCheck cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 or later");
	}

	if ($self->{TLS_CRLCheckUseDeltas})
	{
	    eval {Net::SSLeay::X509_STORE_set_flags
		      (Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx_streamtls}),
		       (Net::SSLeay::X509_V_FLAG_USE_DELTAS() | Net::SSLeay::X509_V_FLAG_EXTENDED_CRL_SUPPORT()));};
	    if ($@)
	    {
		$self->log($main::LOG_ERR, "StreamTLS TLS_CRLCheckUseDeltas cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 or later");
	    }
	}
    }

    # X509_V_FLAG_CRL_CHECK_ALL turns on CRL checking for the entire
    # certificate chain. X509_V_FLAG_CRL_CHECK above is also needed
    # for any CRL check to happen.
    if ($self->{TLS_CRLCheckAll})
    {
	# Sigh, some versions of Net::SSLeay dont have this necessary function
	eval {&Net::SSLeay::X509_STORE_set_flags
		  (&Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx_streamtls}),
		   &Net::SSLeay::X509_V_FLAG_CRL_CHECK_ALL);};
	if ($@)
	{
	    $self->log($main::LOG_ERR, "StreamTLS TLS_CRLCheckAll cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 or later");
	}
    }
    &Radius::StreamTLS::reloadCrls($self);

    # Maybe set policy OIDs that are required to be in the certificate path
    # Caution, this requires a number of functions that were added to Net-SSLeay SVN in 1.36, and 
    # 1.37 and later
    if (defined $self->{TLS_PolicyOID})
    {
	my $pm;
	eval {$pm = &Net::SSLeay::X509_VERIFY_PARAM_new()};
	if ($@ || !$pm)
	{
	    $self->log($main::LOG_ERR, "StreamTLS TLS_PolicyOID cannot be enabled since the installed version of Net::SSLeay does not support X509_VERIFY_PARAM_new. Upgrade Net::SSLeay to 1.37 or later");
	}
	else
	{
	    # Required Net-SSLeay functions must be present
	    foreach my $oid (@{$self->{TLS_PolicyOID}})
	    {
		my $pobject = &Net::SSLeay::OBJ_txt2obj($oid, 0);
		if ($pobject)
		{
		    next if Net::SSLeay::X509_VERIFY_PARAM_add0_policy($pm, $pobject) == 1;
		    $self->log($main::LOG_WARNING, "StreamTLS X509_VERIFY_PARAM_add0_policy failed for TLS_PolicyOID: $oid: " . Net::SSLeay::print_errs());
		    $self->{ssl_ctx_streamtls} = undef;
		    return;
		}
		$self->log($main::LOG_WARNING, "StreamTLS Could not resolve TLS_PolicyOID: $oid: " . Net::SSLeay::print_errs());
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }
	    if (Net::SSLeay::X509_VERIFY_PARAM_set_flags($pm, Net::SSLeay::X509_V_FLAG_POLICY_CHECK() | Net::SSLeay::X509_V_FLAG_EXPLICIT_POLICY()) != 1)
	    {
		$self->log($main::LOG_WARNING, "StreamTLS X509_VERIFY_PARAM_set_flags failed when setting TLS_PolicyOID");
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }
	    my $store = &Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx_streamtls});
	    if (Net::SSLeay::X509_STORE_set1_param($store, $pm) != 1)
	    {
		$self->log($main::LOG_WARNING, "StreamTLS X509_STORE_set1_param failed when setting TLS_PolicyOID: " . Net::SSLeay::print_errs());
		$self->{ssl_ctx_streamtls} = undef;
		return;
	    }
	    Net::SSLeay::X509_VERIFY_PARAM_free($pm);
	}
    }

    return 1;
}

#####################################################################
# Load for the first time all the CRL files configured.
# Subsequently, if the CRL files timestamp has changed, releoad it.
# Reloading will replace the previous version
sub reloadCrls
{
    my ($self) = @_;

    # Maybe load some additional CRL files. If defined, openssl will look in these
    # before looking for file named with the issuer name hash
    if (defined $self->{TLS_CRLFile})
    {
	my $cert_store = &Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx_streamtls});
	foreach my $fileglob (@{$self->{TLS_CRLFile}})
	{
	    $fileglob = &Radius::Util::format_special($fileglob);
	    foreach my $file (glob $fileglob)
	    {
		# See if it is the first load, or if it has changed since the last time
		my $new_time = (stat($file))[9];
		$self->log($main::LOG_ERR, "StreamTLS Could not stat '$file': $!"), next unless $new_time;
		
		next if $new_time == $self->{LastModTime}{$file};
		$self->{LastModTime}{$file} = $new_time;
		
		$self->log($main::LOG_DEBUG, "(Re)loading CRL file '$file'");
		my $bio = &Net::SSLeay::BIO_new_file($file, 'r');
		$self->log($main::LOG_ERR, "StreamTLS BIO_new_file failed for CRL file $file: " . Net::SSLeay::print_errs()), next unless $bio;

		my $crl = &Net::SSLeay::PEM_read_bio_X509_CRL($bio);
		if ($crl)
		{
		    # Replaces any previous CRL from the same issuer
		    if (Net::SSLeay::X509_STORE_add_crl($cert_store, $crl) != 1)
		    {
			$self->log($main::LOG_ERR, "StreamTLS X509_STORE_add_crl failed for CRL file $file: " . Net::SSLeay::print_errs());
		    }
		}
		else
		{
		    $self->log($main::LOG_ERR, "StreamTLS PEM_read_bio_X509_CRL failed for CRL file '$file': " . Net::SSLeay::print_errs());
		}
		&Net::SSLeay::BIO_free($bio);
	    }
	}
    }
}

#####################################################################
sub serverInit
{
    my ($self, $object, $peername) = @_;

    return sessionInit($self, $object, $peername);
}

#####################################################################
# This is called for each certificate in the certificate chain. If it returns 0
# then further checking will be stopped.
# We call a local verification routin, which could be a closure etc.
sub verifyCallback
{
    my ($ok, $x509_store_ctx) = @_;

    my $err = 0;    # 0 means no verify error

    # Bail out if a previous callback failed already
    unless ($ok)
    {
	if ($Radius::StreamTLS::verifyFailedFn)
	{
	    # Call a protocol specific verify routine as a closure, if present
	    $err = &$Radius::StreamTLS::verifyFailedFn($x509_store_ctx);
	    return 0 if $err < 0;
	}
	else
	{
	    return 0;
	}
    }
    else
    {
	# Call a protocol specific verify routine as a closure, if present
	$err = &$Radius::StreamTLS::verifyFn($x509_store_ctx) if $Radius::StreamTLS::verifyFn;
    }

    unless (defined $err)
    {
	main::log($main::LOG_ERR, "TLS verifyCallback: undefined return value from verify function");
	Net::SSLeay::X509_STORE_CTX_set_error($x509_store_ctx, $Radius::StreamTLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION);
	return 0;
    }

    # Tell the caller what the problem was. This is available as Net::SSLeay::get_verify_result()
    &Net::SSLeay::X509_STORE_CTX_set_error($x509_store_ctx, $err) if $err;

    # Return 1 if no error from local callback
    return $err == 0;
}

#####################################################################
# This is called during TLS session setup and use to obtain and
# verify OCSP responses (aka. OCSP staples)
# Return values:
# When called without $ocsp_response: 0 (SSL_TLSEXT_ERR_OK), 3 (SSL_TLSEXT_ERR_NOACK), 1 (SSL_TLSEXT_ERR_ALERT_WARNING), 2 (SSL_TLSEXT_ERR_ALERT_FATAL)
# When called with    $ocsp_response: < 0 (ERROR), 0 (OCSP RESPONSE NOT ACCEPTED), > 0 (OCSP RESPONSE ACCEPTED)
sub ocspCallback
{
    my ($ssl, $ocsp_response, $parent) = @_;

    if ($ocsp_response)
    {
	# Callback called to verify/accept received OCSP response.
	# This should not happen as only a client can request the server
	# to send OCSP response/staple.

	# Get peer cert
	my $cert = Net::SSLeay::get_peer_certificate($ssl);

	if (!$cert)
	{
	    $parent->log($main::LOG_ERR, "TLS getting peer certificate to verify OCSP staple failed");
	    return 0; # OCSP RESPONSE NOT ACCEPTED
	}

	my $ret = run_ocsp($ssl, $parent, $cert, $ocsp_response);
	Net::SSLeay::X509_free($cert);

	if (!$ret)
	{
	    $parent->log($main::LOG_ERR, "TLS verifying received OCSP staple failed");
	    return 0; # OCSP RESPONSE NOT ACCEPTED
	}

	$parent->log($main::LOG_DEBUG, "TLS accepting received OCSP staple");

	return 1; # OCSP RESPONSE ACCEPTED
    }
    else
    {
	if ($parent->{do_ssl_tls})
	{
	    # I'm a client
	    $parent->log($main::LOG_DEBUG, "TLS server did not send OCSP staple");

	    # Callback called and a server did not provide OCSP response
	    if ($parent->{TLS_OCSPStrict})
	    {
		return 0; # OCSP RESPONSE NOT ACCEPTED
	    }

	    return 1; # OCSP RESPONSE ACCEPTED
	}
	else
	{
	    # I'm a server
	    unless (defined &Net::SSLeay::set_tlsext_status_ocsp_resp)
	    {
		$parent->log($main::LOG_INFO, "TLS OCSP stapling disabled because of Net::SSLeay version $Net::SSLeay::VERSION. See startup log messages for more information");
		return $Radius::TLS::NSL::TLSEXT_ERR_NOACK;
	    }

	    # Callback called to provide OCSP response
	    if (!$parent->{OCSP_response} || $parent->{OCSP_response}->[1] < time())
	    {
		if (!run_ocsp($ssl, $parent))
		{
		    $parent->log($main::LOG_ERR, "TLS acquiring OCSP response failed");
		    return $Radius::TLS::NSL::TLSEXT_ERR_NOACK;
		}
	    }

	    if ($parent->{OCSP_response})
	    {
		# Set OCSP staple
		Net::SSLeay::set_tlsext_status_ocsp_resp($ssl, $parent->{OCSP_response}->[0]);

		# SSL_TLSEXT_ERR_OK
		return $Radius::TLS::NSL::TLSEXT_ERR_OK;
	    }

	    # SSL_TLSEXT_ERR_NOACK
	    return $Radius::TLS::NSL::TLSEXT_ERR_NOACK;
	}
    }

    return -1;
}

#####################################################################
# Obtain and verify OCSP response
sub run_ocsp
{
    my ($ssl, $parent, $cert, $ocsp_resp) = @_;

    # Don't use a connection nor a host as $parent,
    # but a more persistent object.
    if ($parent->{Parent})
    {
	$parent = $parent->{Parent};
    }
    elsif ($parent->{parent})
    {
	$parent = $parent->{parent};
    }
    return unless $parent;

    my $now = time();
    my $set_ocsp_staple = 0;
    unless ($cert)
    {
	# Use my own cert
	$cert = Net::SSLeay::get_certificate($ssl);
	++$set_ocsp_staple;
	# Reset current OCSP staple
	$parent->{OCSP_response} = undef;
    }

    # Get id only for given $cert
    my $cert_id = eval { Net::SSLeay::OCSP_cert2ids($ssl, $cert) };

    if ($@ || !$cert_id)
    {
	$parent->log($main::LOG_ERR, "TLS could not get certificate identifiers for OCSP: $@");
	return;
    }

    my $cert_id_hex = unpack('H*', $cert_id);

    # Is there a valid cache entry?
    $parent->{OCSP_cache} = {} unless $parent->{OCSP_cache};
    if ($parent->{OCSP_cache}->{$cert_id})
    {
	if ($parent->{OCSP_cache}->{$cert_id}->[1] >= $now)
	{
	    if (!$parent->{OCSP_cache}->{$cert_id}->[0])
	    {
		# valid
		return 1;
	    }
	    else
	    {
		# invalid
		return;
	    }
	}
	else
	{
	    delete $parent->{OCSP_cache}->{$cert_id};
	    --$parent->{OCSP_cache_size};
	}
    }

    my ($ocsp_req, $ocsp_resp_data);
    unless ($ocsp_resp)
    {
	my $ocsp_uri;
	if ($parent->{TLS_OCSPURI})
	{
	    $ocsp_uri = $parent->{TLS_OCSPURI};
	}
	else
	{
	    $ocsp_uri = Net::SSLeay::P_X509_get_ocsp_uri($cert);
	}

	unless ($ocsp_uri)
	{
	    $parent->log($main::LOG_DEBUG, "TLS could not get OCSP URI for certificate: $cert_id_hex");
	    # Allow unless strict mode configured
	    unless ($parent->{TLS_OCSPStrict})
	    {
		return 1;
	    }
	    return;
	}

	if ($parent->{OCSP_backoff_until}->{$ocsp_uri} && $parent->{OCSP_backoff_until}->{$ocsp_uri} > $now)
	{
	    $parent->log($main::LOG_WARNING, "TLS still backing off from trying OCSP responder '$ocsp_uri'");
	    # Allow unless strict mode configured
	    unless ($parent->{TLS_OCSPStrict})
	    {
		return 1;
	    }
	    return;
	}
	delete $parent->{OCSP_backoff_until}->{$ocsp_uri};

	$ocsp_req = Net::SSLeay::OCSP_ids2req($cert_id);

	unless ($ocsp_req)
	{
	    $parent->log($main::LOG_ERR, "TLS creating OCSP request failed: $cert_id_hex");
	    return;
	}

	my $ocsp_req_data = Net::SSLeay::i2d_OCSP_REQUEST($ocsp_req);

	unless ($ocsp_req_data)
	{
	    $parent->log($main::LOG_ERR, "TLS invalid OCSP request for certificate: $cert_id_hex");
	    return;
	}

	$ocsp_resp_data = get_ocsp_response($parent, $cert_id, $ocsp_req_data, $ocsp_uri);

	unless ($ocsp_resp_data)
	{
	    $parent->log($main::LOG_ERR, "TLS getting OCSP response '$cert_id_hex' failed: $@");
	    $parent->{OCSP_backoff_until}->{$ocsp_uri} = $now + $parent->{TLS_OCSPFailureBackoffTime};
	    # Allow unless strict mode configured
	    unless ($parent->{TLS_OCSPStrict})
	    {
		return 1;
	    }
	    return;
	}

	$ocsp_resp = eval { Net::SSLeay::d2i_OCSP_RESPONSE($ocsp_resp_data) };

	if ($@)
	{
	    $parent->log($main::LOG_ERR, "TLS parsing OCSP response '$cert_id_hex' failed: $@");
	    return;
	}
    }

    my $ocsp_status = Net::SSLeay::OCSP_response_status($ocsp_resp);
    if ($ocsp_status != Net::SSLeay::OCSP_RESPONSE_STATUS_SUCCESSFUL())
    {
	$parent->log($main::LOG_DEBUG, "TLS OCSP response '$cert_id_hex' failed: " . Net::SSLeay::OCSP_response_status_str($ocsp_status));
	return;
    }

    my $ocsp_verify;
    if ($ocsp_req)
    {
	$ocsp_verify = eval { Net::SSLeay::OCSP_response_verify($ssl, $ocsp_resp, $ocsp_req) };
    }
    else
    {
	$ocsp_verify = eval { Net::SSLeay::OCSP_response_verify($ssl, $ocsp_resp) };
    }

    if ($@)
    {
	$parent->log($main::LOG_ERR, "TLS verifying OCSP response '$cert_id_hex' failed: $@");
	return;
    }

    if (!$ocsp_verify)
    {
	$parent->log($main::LOG_DEBUG, "TLS OCSP response verification '$cert_id_hex' failed: $ocsp_verify");
	return;
    }

    my @ocsp_results = Net::SSLeay::OCSP_response_results($ocsp_resp);
    foreach my $result (@ocsp_results)
    {
	# @results are in the same order as the @ids and contain:
	# $r->[0] - OCSP_CERTID
	# $r->[1] - undef if no error (certificate good) OR error message as string
	# $r->[2] - hash with details:
	#   thisUpdate - time_t of this single response
	#   nextUpdate - time_t when update is expected
	#   statusType - integer:
	#      V_OCSP_CERTSTATUS_GOOD(0)
	#      V_OCSP_CERTSTATUS_REVOKED(1)
	#      V_OCSP_CERTSTATUS_UNKNOWN(2)
	#   revocationTime - time_t (only if revoked)
	#   revocationReason - integer (only if revoked)
	#   revocationReason_str - reason as string (only if revoked)

	if ($result->[0] eq $cert_id)
	{
	    my $this_update = $result->[2]->{thisUpdate};
	    # Allow 5 minutes time difference
	    if (!$this_update || $this_update < ($now - 300))
	    {
		$this_update = $now;
	    }
	    my $next_update = $result->[2]->{nextUpdate};

	    my $cache_time = $parent->{TLS_OCSPCacheTime};
	    if (!$next_update || $next_update < $this_update)
	    {
		# Cache OCSP staple for 1h when not specified by nextUpdate.
		$cache_time = 3600 if $set_ocsp_staple;
		$next_update = $now + $cache_time;
	    }
	    elsif (($next_update - $now) > $parent->{TLS_OCSPCacheTime})
	    {
		# Cache OCSP staple for time specified by nextUpdate.
		$next_update = $now + $cache_time unless $set_ocsp_staple;
	    }

	    if ($set_ocsp_staple)
	    {
		# Set our OCSP staple
		$parent->{OCSP_response} = [];
		$parent->{OCSP_response}->[0] = $ocsp_resp_data;
		$parent->{OCSP_response}->[1] = $next_update;
		return 1;
	    }
	    else
	    {
		# Cache the result
		if ($parent->{OCSP_cache} && $parent->{OCSP_cache}->{$cert_id})
		{
		    # Update cache entry
		    $parent->{OCSP_cache}->{$cert_id}->[0] = $result->[2]->{statusType};
		    $parent->{OCSP_cache}->{$cert_id}->[1] = $next_update;
		}
		else
		{
		    $parent->{OCSP_cache_size} += 0;
		    if ($parent->{OCSP_cache_size} >= $parent->{TLS_OCSPCacheSize})
		    {
			# Flush an expired entry
			foreach my $cache_cert_id (keys %{$parent->{OCSP_cache}})
			{
			    if ($parent->{OCSP_cache}->{$cache_cert_id}->[1] < $now)
			    {
				delete $parent->{OCSP_cache}->{$cache_cert_id};
				--$parent->{OCSP_cache_size};
				last;
			    }
			}
		    }
		    if ($parent->{OCSP_cache_size} < $parent->{TLS_OCSPCacheSize})
		    {
			# Add a new cache entry
			++$parent->{OCSP_cache_size};
			$parent->{OCSP_cache}->{$cert_id}->[0] = $result->[2]->{statusType};
			$parent->{OCSP_cache}->{$cert_id}->[1] = $next_update;
		    }
		}

		if ($result->[2]->{statusType} == $Radius::TLS::NSL::V_OCSP_CERTSTATUS_GOOD)
		{
		    $parent->log($main::LOG_DEBUG, "TLS OCSP response states '$cert_id_hex' as good");
		    return 1;
		}
		else
		{
		    my $err = "invalid: err: ";
		    $err .= $result->[1] || '';
		    $err .= " status:$result->[2]->{statusType} reason:$result->[2]->{revocationReason_str}";
		    $parent->log($main::LOG_DEBUG, "TLS OCSP response states '$cert_id_hex' as $err");
		    return;
		}
	    }
	}
    }

    return;
}

#####################################################################
# Get OCSP response
sub get_ocsp_response
{
    my ($parent, $cert_id, $ocsp_request_data, $ocsp_uri) = @_;

    my $cert_id_hex = unpack('H*', $cert_id);
    my $resp;

    # TODO: FIXME: Get OCSP response data from external OCSP querier process
    $parent->log($main::LOG_DEBUG, "TLS sending OCSP request to URI '$ocsp_uri' for certificate: $cert_id_hex");

    my ($req, $res, $ok);
    unless ($parent->{ocsp})
    {
	eval {
	    require LWP::UserAgent;
	    require HTTP::Request;
	};

	if ($@)
	{
	    $parent->log($main::LOG_ERR, "TLS sending OCSP request to URI '$ocsp_uri' failed: $@");
	    return;
	}

	$parent->{ocsp} = LWP::UserAgent->new();
	$parent->{ocsp}->timeout(2);
	$parent->{ocsp}->ssl_opts(verify_hostname => 0);
	#$parent->{ocsp}->agent('ocsp-client/0.1');
    }

    $req = HTTP::Request->new(POST => $ocsp_uri);
    $req->content_type('application/ocsp-request');
    $req->content($ocsp_request_data);

    $res = $parent->{ocsp}->request($req);

    if ($res && $res->is_success() && $res->content_type() eq "application/ocsp-response")
    {
	++$ok;
	$resp = $res->content();
    }

    if ($ok)
    {
	$parent->log($main::LOG_DEBUG, "TLS OCSP response received for certificate: $cert_id_hex");
    }
    else
    {
	$parent->log($main::LOG_ERR, "TLS receiving OCSP response failed for certificate: $cert_id_hex");
    }

    return $resp;
}

#####################################################################
# Compare this host name or IP address against a certificate name or wildcard
sub matchHostName
{
    my ($hostname, $pattern) = @_;

    if ($pattern =~ /^\*(.*)$/)
    {
	# Wildcard starting with '*.'. Make a regexp
	# eg '*.open.com.au' -> 'open\.com\.au$'
	my $regexp = quotemeta($1) . '$';
	return 1 if $hostname =~ /$regexp/;
    }
    else
    {
	return 1 if lc($hostname) eq lc($pattern); # Exact match, case insens
    }
    return; # No match
}

#####################################################################
# This is called from within verifyCallback, having been set in receive()
# This is called to verify each certificate in the client certificate chain, 
# starting with the root. Return 0 if no error,
# else one X509_V_ERR_* from openssl/include/x509_vfy.h
# Returning 50 (X509_V_ERR_APPLICATION_VERIFICATION) triggers 
# TLS error 0x80090326 in Windows XP SP1 TLS client
sub verifyFn
{
    my ($object, $x509_store_ctx) = @_;

    my $depth = Net::SSLeay::X509_STORE_CTX_get_error_depth($x509_store_ctx);
    if ($depth == 0)
    {
	# This is the peer certificate we need to check
	my $cert = Net::SSLeay::X509_STORE_CTX_get_current_cert($x509_store_ctx);
	my $subject_name = &Net::SSLeay::X509_get_subject_name($cert);
	my $subject = &Net::SSLeay::X509_NAME_oneline($subject_name);
	my $hostname = $object->{Host};

	my $do_log = main::willLog($main::LOG_DEBUG);
	if ($do_log)
	{
	    $object->log($main::LOG_DEBUG, "Verifying certificate presented by peer $hostname");
	    Radius::TLS::log_certificate($object, undef, $cert, $subject);
	}

	# Sigh: need to canonicalise IPV6 IP addresses for compressed zeroes etc
	# else may not match an altname IPV6 IP address
	if ($hostname =~ /ipv6:(.*:.*)/i || $hostname =~ /(^[0-9a-fA-F:]+:[0-9a-fA-F:]+$)/i)
	{
	    $hostname = $1;
	    # IPV6 raw IP address, canonicalise
	    $hostname = Radius::Util::inet_ntop(Radius::Util::inet_pton($hostname));
	    $object->log($main::LOG_DEBUG, "verifyFn hostname after canonicalise $hostname");
	}
	elsif ($hostname =~ /^ipv6:(.*)/)
	{
	    $hostname = $1;
	}

	# TLS_CertificateVerifyHook
	if (defined $object->{parent}->{TLS_CertificateVerifyHook})
	{
	    my ($result) = $object->{parent}->runHook('TLS_CertificateVerifyHook', undef, $hostname, $x509_store_ctx, $cert, $subject_name, $subject, $object);
	    return $result if defined $result;
	}

	# Do OCSP verification when configured
	if ($object->{TLS_OCSPCheck})
	{
	    if (!run_ocsp($object->{ssl_streamtls}, $object, $cert))
	    {
		$object->log($main::LOG_WARNING, "Verifying OCSP response failed for Subject '$subject' presented by peer $object->{Host}");
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	}

	# If CertificateFingerprint is defined, the finger[rint of the certificate must match one of 
	# the fingerprints in the TLS_Fingerprint array
	# Requires X509_get_fingerprint which is not present in all versions of SSLeay
	if (defined $object->{TLS_CertificateFingerprint} 
	    && exists &Net::SSLeay::X509_get_fingerprint)
	{
	    my $found;

	    # At least one must match
	    foreach (@{$object->{TLS_CertificateFingerprint}})
	    {
		my ($fingerprint, $requiredfingerprint);

		if (/^sha-1:(.*)/)
		{
		    $requiredfingerprint = $1;
		    $fingerprint = &Net::SSLeay::X509_get_fingerprint($cert, 'sha1');
		}
		elsif (/^sha-256:(.*)/)
		{
		    $requiredfingerprint = $1;
		    $fingerprint = &Net::SSLeay::X509_get_fingerprint($cert, 'sha256');
		}
		elsif (/^md5:(.*)/)
		{
		    $requiredfingerprint = $1;
		    $fingerprint = &Net::SSLeay::X509_get_fingerprint($cert, 'md5');
		}
		else
		{
		    $object->log($main::LOG_ERR, "Invalid format in TLS_CertificateFingerprint: $_");
		    last;
		}
		$object->log($main::LOG_DEBUG, "Checking if TLS_CertificateFingerprint $_ matches $fingerprint");
		$found = $fingerprint eq $requiredfingerprint; # Found a match
		last if $found;
	    }
	    if (!$found)
	    {
		$object->log($main::LOG_WARNING, "No match for any TLS_CertificateFingerprint");
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	}

	# try to get subjectAltName extensions with type DNS
	# Support for X509_get_subjectAltNames was added in 1.30
	my $have_subject_alt_name_dns; # Have found a subjectAltName of type DNS
	my $have_subject_alt_name_srv; # Have found a subjectAltName of type SRV
	my $subject_alt_name_srv_matches; # Found a subjectAltName of type SRV that matches expected SRV name
	my $tls_srv_log_var; # For logging: what was used to match type SRV
	if (exists &Net::SSLeay::X509_get_subjectAltNames)
	{
	    # X509_get_subjectAltNames returns array of (type, string)
	    # type == 2 is dnsname. Type 7 is IPADD, type 6 is URI.
	    # For other types see openssl/x509v3.h GEN_*

	    # If TLS_SubjectAltNameURI is defined it must match at least one
	    # SubjectAltName:URI
	    if (defined $object->{TLS_SubjectAltNameURI})
	    {
		my $found = 0;
		my @altnames = &Net::SSLeay::X509_get_subjectAltNames($cert);
		while (@altnames)
		{
		    my ($type, $name) = splice(@altnames, 0, 2);
		    $name = Radius::Util::inet_ntop($name) if $type == 7;
		    $object->log($main::LOG_DEBUG, "Checking for subjectAltName:URI in type $type, value $name");
		    if ($type == 6
			&& $name =~ /$object->{TLS_SubjectAltNameURI}/)
		    {
			$object->log($main::LOG_DEBUG, "Matched TLS_SubjectAltNameURI $object->{TLS_SubjectAltNameURI} with $name");
			$found++;
			last;
		    }
		}
		if (!$found)
		{
		    $object->log($main::LOG_ERR, "Verification of TLS_SubjectAltNameURI $object->{TLS_SubjectAltNameURI} in certificate presented by $object->{Host}:$object->{Port} failed");
		    return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
		}
	    }

	    my @altnames = &Net::SSLeay::X509_get_subjectAltNames($cert);
	    while (@altnames)
	    {
		my ($type, $name) = splice(@altnames, 0, 2);
		if ($type == 7)
		{
		    $name = Radius::Util::inet_ntop($name);
		}
		$object->log($main::LOG_DEBUG, "Checking subjectAltName type $type, value $name from $hostname");
		$have_subject_alt_name_dns++ if $type == 2;

		# On client side can use Type 2 DNS name or type 7 IPADD
		if (!$object->{tls_is_server} && ($type == 2 || $type == 7))
		{
		    # Use TLS_SubjectAltNameDNS when configured
		    # allowing override for e.g., AuthBy DNSROAM
		    my $checked_hostname = $hostname;
		    if ($type == 2 && (defined $object->{TLS_SubjectAltNameDNS} || defined $object->{dynamic_TLS_SubjectAltNameDNS}))
		    {
			my $log_var = 'dynamically discovered name';
			unless (defined ($checked_hostname = $object->{dynamic_TLS_SubjectAltNameDNS}))
			{
			    $log_var = 'TLS_SubjectAltNameDNS';
			    $checked_hostname = $object->{TLS_SubjectAltNameDNS};
			}
			$object->log($main::LOG_DEBUG, "Using $log_var $checked_hostname instead of $hostname");
		    }

		    if (matchHostName($checked_hostname, $name))
		    {
			$object->log($main::LOG_DEBUG, "Certificate subjectAltName type $type, value $name matches $checked_hostname");
			return 0;
		    }
		}
		# On client side, subjectAltName:SRV extensions need to be checked against
		# possible DNS SRV name in order to confirm the certificate is associated
		# with the right SRV and server
		elsif (   (defined $object->{TLS_SRVName} || defined $object->{dynamic_TLS_SRVName})
		       && !$object->{tls_is_server} 
		       && $type == 0 
		       && $name =~ /_(.+?)\.(.+)/)
		{
		    my ($service, $srvname) = ($1, $2);
		    $have_subject_alt_name_srv++;

		    $tls_srv_log_var = 'dynamically discovered SRV name';
		    my $tls_srv_name = $object->{dynamic_TLS_SRVName};
		    unless (defined $tls_srv_name)
		    {
			$tls_srv_log_var = 'TLS_SRVName';
			$tls_srv_name = $object->{TLS_SRVName};
		    }
		    $tls_srv_log_var .= " '$tls_srv_name'";
		    $object->log($main::LOG_DEBUG, "Checking SubjectAltName type $type, against $tls_srv_log_var");

		    # Decompose TLS_SRVName, which should be in the format
		    # _service._transport.name
		    # eg:
		    # _radsec._tcp.example.com
		    if ($tls_srv_name =~ /^_(.+?)\._(.+?)\.(.+)/s)
		    {
			if ($1 eq $service && $3 eq $srvname)
			{
			    $subject_alt_name_srv_matches++;
			    $object->log($main::LOG_DEBUG, "Certificate subjectAltName type $type, value $name matches $tls_srv_name");
			}
		    }

		}
		# On server side can use type 7 IPADD
		elsif ($object->{tls_is_server} && $type == 7 && $hostname eq $name)
		{
		    $object->log($main::LOG_DEBUG, "Certificate IPAddress subjectAltName $name matches client address $object->{Host}");
		    return 0;
		}
		# Handled URI above
	    }
	}

	# If there was no subjectAltName type DNS seen,
	# check if the host name matches a CN, honouring wildcards
	# On the clinet side, Host is the configured Host name.
	# On the server side, Host is the IP address of the client.
	# Subject name could be in the form: /DC=com/DC=mtghouse/CN=Users/CN=vinny
	# Extract all the CNs and see if at least one of them matches
	# Array of names following each CN=
	# CN may be an exact hostname xyz.pqr.com or wildcard *.pqr.com
	if (!$have_subject_alt_name_dns)
	{
	    my @cn = map {/CN=([^\/]+)/ ? $1 : ()} split(/\//, $subject);
	    foreach my $cn (@cn)
	    {
		if (&matchHostName($hostname, $cn))
		{
		    $object->log($main::LOG_DEBUG, "Certificate CN $cn matches $object->{Host}");
		    return 0;
		}
	    }
	}

	# If a subjectAltName type SRV was seen, but none of them matched the defined TLS_SrvName
	# then the verify fails
	if ($have_subject_alt_name_srv && !$subject_alt_name_srv_matches)
	{
	    $object->log($main::LOG_WARNING, "No SubjectAltName:SRV certificate extension matches $tls_srv_log_var");
	    return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	}

	# OK if we match a configured pattern in TLS_ExpectedPeerName
	if (   defined $object->{TLS_ExpectedPeerName}
	    && $subject =~ /$object->{TLS_ExpectedPeerName}/)
	{
	    $object->log($main::LOG_DEBUG, "Certificate Subject matches TLS_ExpectedPeerName");
	    return 0;
	}

	# Nothing worked
	$object->log($main::LOG_ERR, "Verification of certificate presented by $object->{Host}:$object->{Port} failed");
	return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
    }

    return 0;
}

#####################################################################
# This is called to verify each certificate in the client certificate chain,
# starting with the root. Return 0 if no error,
# else one X509_V_ERR_* from openssl/include/x509_vfy.h
# or < 0 for a failure.
# Returning 50 (X509_V_ERR_APPLICATION_VERIFICATION) triggers
# TLS error 0x80090326 in Windows XP SP1 TLS client
sub verifyFailedFn
{
    my ($object, $x509_store_ctx) = @_;

    my $depth = Net::SSLeay::X509_STORE_CTX_get_error_depth($x509_store_ctx);

    if ($depth == 0)
    {
	# The peer certificate we need to check again is not always
	# present. One example is policy OID mismatch.
	my $verify_error = Net::SSLeay::X509_STORE_CTX_get_error($x509_store_ctx);
	my $cert = Net::SSLeay::X509_STORE_CTX_get_current_cert($x509_store_ctx);
	my ($subject_name, $subject);
	if ($cert)
	{
	    $subject_name = Net::SSLeay::X509_get_subject_name($cert);
	    $subject = Net::SSLeay::X509_NAME_oneline($subject_name);
	}

	my $do_log = main::willLog($main::LOG_DEBUG);
	if ($do_log)
	{
	    $object->log($main::LOG_DEBUG, "Certificate verification failure reason: " . Radius::TLS::verify_error_string($verify_error));
	    $cert ?
		Radius::TLS::log_certificate($object, undef, $cert, $subject) :
		$object->log($main::LOG_DEBUG, "Can not log certificate details, no certificate available");
	}

	if (defined $object->{parent}->{TLS_CertificateVerifyFailedHook})
	{
	    my ($result) = $object->{parent}->runHook('TLS_CertificateVerifyFailedHook', undef, $verify_error, $x509_store_ctx, $cert, $subject_name, $subject, $object);
	    if (!defined $result)
	    {
		$object->log($main::LOG_INFO, "TLS_CertificateVerifyFailedHook returned undefined");
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	    else
	    {
		return $result;
	    }
	}
    }

    # Return a failure
    return -1;
}

#####################################################################
# Create a new clean session context 
sub sessionInit
{
    my ($self, $object, $peername) = @_;

    $self->log($main::LOG_DEBUG, "StreamTLS sessionInit for $peername");
    &Net::SSLeay::free($object->{ssl_streamtls}) if $object->{ssl_streamtls};
    $object->{handshake_finished} = undef;
    $object->{ssl_streamtls} = &Net::SSLeay::new($self->{ssl_ctx_streamtls});

    if (!$object->{ssl_streamtls})
    {
	$object->log($main::LOG_ERR, 'StreamTLS could not create SSL: Net::SSLeay::new failed: ' . &Net::SSLeay::print_errs() . ",". $!);
	return;
    }

    # Certificate files names can depend on the identity of the other end
    my $certtype = defined $object->{TLS_CertificateType} && $object->{TLS_CertificateType} eq 'PEM' 
	? &Net::SSLeay::FILETYPE_PEM : &Net::SSLeay::FILETYPE_ASN1;

    if (defined $object->{TLS_CertificateFile} 
	&& &Net::SSLeay::use_certificate_file
	($object->{ssl_streamtls}, &Radius::Util::format_special($object->{TLS_CertificateFile}),
	 $certtype) != 1)
    {
	$self->log($main::LOG_ERR, "StreamTLS could not use_certificate_file $object->{TLS_CertificateFile}, $certtype: " . &Net::SSLeay::print_errs());
	$object->sessionClear();
	return;
    }

    # There is no SSL_use_certificate_chain_file

    if (defined $object->{TLS_PrivateKeyFile})
    {
	return unless session_load_private_key($self, $object, $peername, $certtype);
    }

    # Maybe reload CRLS that have changed
    &Radius::StreamTLS::reloadCrls($self);

    # Create 2 memory BIOs to do the IO with SSL
    $object->{rbio} = &Net::SSLeay::BIO_new(&Net::SSLeay::BIO_s_mem());
    $object->{wbio} = &Net::SSLeay::BIO_new(&Net::SSLeay::BIO_s_mem());
    &Net::SSLeay::set_bio($object->{ssl_streamtls}, $object->{rbio}, $object->{wbio});
    
    # This sets a unique binary context identifier to identify renegotiated sessions
    my $objectid = "$object->{ssl_streamtls}"; # stringify the address of the SSL context
    &Net::SSLeay::set_session_id_context($object->{ssl_streamtls}, $objectid, length($objectid));

    # Need this in set_verify
    $object->{TLS_VerifyMode} = $self->{TLS_VerifyMode};

    return 1;
}

# Load the private key. OpenSSL API change in 1.1.0f, Net::SSLeay
# method availability and unavailability of some of the functions in
# OpenSSL before 1.1.0 require us to check what we can use. See
# OpenSSL GitHub bug 2538 (originally RT 4694) for details.
#
# There is only one callback for CTX or SSL, but since the callback
# will only be called once during the subsequent *use_PrivateKey_file
# we dont care if it is overwritten later.
sub session_load_private_key
{
    my ($self, $object, $peername, $certtype) = @_;

    my $pw = $object->{TLS_PrivateKeyPassword}; # prevent references to $object
    Net::SSLeay::set_default_passwd_cb($object->{ssl_streamtls}, sub {return $pw;}) if $main::tls_have_ssl_passwd_cb;
    Net::SSLeay::CTX_set_default_passwd_cb($self->{ssl_ctx_streamtls}, sub {return $pw;});

    my $ret = 0;
    my $private_key_file = Radius::Util::format_special($object->{TLS_PrivateKeyFile}, undef, undef, $peername);
    $ret = Net::SSLeay::use_PrivateKey_file($object->{ssl_streamtls}, $private_key_file, $certtype) if $main::tls_have_ssl_passwd_cb;
    $ret = Net::SSLeay::CTX_use_PrivateKey_file($self->{ssl_ctx_streamtls}, $private_key_file, $certtype) if !$main::tls_have_ssl_passwd_cb;
    if ($ret != 1)
    {
	$self->log($main::LOG_ERR, "StreamTLS could not use_PrivateKey_file $private_key_file, $certtype: " . Net::SSLeay::print_errs());
	$object->sessionClear();
	return 0;
    }

    # Remove the callbacks
    Net::SSLeay::set_default_passwd_cb($object->{ssl_streamtls}, undef) if $main::tls_use_ssl_passwd_cb;
    Net::SSLeay::CTX_set_default_passwd_cb($self->{ssl_ctx_streamtls}, undef);

    return 1;
}

#####################################################################
# Remove a session entirely so it can never be reused or resumed
sub sessionClear
{
    my ($self) = @_;

    &Net::SSLeay::free($self->{ssl_streamtls}) if $self->{ssl_streamtls};
    $self->{ssl_streamtls} = undef;
}

#####################################################################
# This can initialise any object as a TLS server
# $self can be any type of object that can manage IO
sub start_server
{
    my ($self, $object, $peername) = @_;

    return unless $Radius::TLS::initialised;
    return unless &serverInit($self, $object, $peername);
    $object->{tls_enabled}++;
    $object->{tls_is_server}++;
    &receive($object); # Provoke output of any data to the peer
    $object->log($main::LOG_DEBUG, "StreamTLS Server Started for $object->{Host} ($object->{Peeraddress}:$object->{Port})");
    return 1;
}

#####################################################################
# This can initialise any object as a TLS client
# $self can be any type of object that can manage IO
sub start_client
{
    my ($self, $object, $peername) = @_;

    return unless $Radius::TLS::initialised;
    return unless &sessionInit($self, $object, $peername);
    $object->{tls_enabled}++;
    &receive($object); # Provoke output of any data to the peer
    $object->log($main::LOG_DEBUG, "StreamTLS Client Started for $object->{Host} ($object->{Peeraddress}:$object->{Port})");
    return 1;
}

#####################################################################
# Called to handle incoming data
sub receive
{
     my ($object, $data) = @_;

     no warnings "uninitialized";
     $object->log($main::LOG_EXTRA_DEBUG, 'StreamTLS receive: ' . unpack('H*', $data));
     &Net::SSLeay::BIO_write($object->{rbio}, $data);
     return unless $object->{ssl_streamtls};
     if (!$object->{handshake_finished})
     {
	 Radius::StreamTLS::set_verify($object, sub {&verifyFn($object, @_)}, sub {&verifyFailedFn($object, @_)});

	 if ($object->{TLS_OCSPStapling})
	 {
	     Radius::StreamTLS::set_ocsp_stapling_required($object);
	 }

	 # SSL handshake is not yet complete
	 if ($object->{tls_is_server})
	 {
	     # We are an SSL server
	     my $ret = &Net::SSLeay::accept($object->{ssl_streamtls});
	     my $reason = &Net::SSLeay::get_error($object->{ssl_streamtls}, $ret);
	     my $state = &Net::SSLeay::get_state($object->{ssl_streamtls});
	     &Radius::StreamTLS::reset_verify($object); # prevent SSLeay thread safety problems
	     $object->log($main::LOG_DEBUG, "StreamTLS SSL_accept result: $ret, $reason, $state");
	     if ($ret == 1)
	     {
		 # Success, the SSL accept has completed successfully,
		 # therefore the client has verified credentials.
		 # However, there may be some more data in the output
		 # BIO to send to the client, so we defer the ACCEPT
		 # until it is acked
		 $object->{handshake_finished}++;
	     }
	     elsif ($ret == 0)
	     {
		 # Handshake was not successful
		 $object->log($main::LOG_ERR, "StreamTLS server Handshake unsuccessful ($object->{Host}:$object->{Port}): " . &Net::SSLeay::print_errs());
		 $object->stream_disconnected();
		 return;
	     }
	     elsif (   $reason == Net::SSLeay::ERROR_WANT_READ
		    || $reason == Net::SSLeay::ERROR_WANT_WRITE)
	     {
		 # Looking for more read or write data, object will provide it when its available
	     }
	     else
	     {
		 my $errs = &Net::SSLeay::print_errs();
		 my $verify_result = &Net::SSLeay::get_verify_result($object->{ssl_streamtls});
		 if ($verify_result)
		 {
		     my $verify_error_string = &Radius::TLS::verify_error_string($verify_result);
		     $object->log($main::LOG_ERR, "StreamTLS Certificate verification error ($object->{Host}:$object->{Port}): $verify_error_string");
		 }
		 else
		 {
		     $object->log($main::LOG_ERR, "StreamTLS server error ($object->{Host}:$object->{Port}): $ret, $reason, $state, " .
			   &Net::SSLeay::print_errs());
		 }
		 # Error
		 $object->stream_disconnected();
		 return;
	     }
	 }
	 else
	 {
	     # We are an SSL client
	     my $ret = &Net::SSLeay::connect($object->{ssl_streamtls});
	     my $reason = &Net::SSLeay::get_error($object->{ssl_streamtls}, $ret);
	     my $state = &Net::SSLeay::get_state($object->{ssl_streamtls});
	     &Radius::StreamTLS::reset_verify($object); # prevent SSLeay thread safety problems
	     $object->log($main::LOG_DEBUG, "StreamTLS SSL_connect result: $ret, $reason, $state");
	     if ($ret == 1)
	     {
		 # Success, the SSL accept has completed successfully,
		 # therefore the client has verified credentials.
		 # However, there may be some more data in the output
		 # BIO to send to the client, so we defer the ACCEPT
		 # until it is acked
		 $object->{handshake_finished}++;
	     }
	     elsif ($ret == 0)
	     {
		 # Handshake was not successful
		 $object->log($main::LOG_ERR, "StreamTLS client Handshake unsuccessful ($object->{Host}:$object->{Port}): "
			      . &Net::SSLeay::print_errs());
		 $object->stream_disconnected();
		 return;
	     }
	     elsif (   $reason == Net::SSLeay::ERROR_WANT_READ
		    || $reason == Net::SSLeay::ERROR_WANT_WRITE)
	     {
		 # Looking for more read or write data, object will provide it when its available
	     }
	     else
	     {
		 # Error
		 $object->log($main::LOG_ERR, "StreamTLS client error ($object->{Host}:$object->{Port}): $ret, $reason, $state, "
			      . &Net::SSLeay::print_errs());
		 $object->stream_disconnected();
		 return;
	     }
	 }
	 $object->write();
     }

     # See if we have some translated data for the application
     if ($object->{handshake_finished})
     {
	 my $ret;
	 # Maybe multiple chunks waiting?
	 while (($data = &Net::SSLeay::read($object->{ssl_streamtls})) ne '')
	 {
	     if (!defined $data)
	     {
		 # Error
		 $object->log($main::LOG_ERR, "StreamTLS read failed ($object->{Host}:$object->{Port}): "
			      . &Net::SSLeay::print_errs());
		 $object->stream_disconnected();
		 return;
	     }
	     $ret .= $data;
	 }
	 return $ret;
     }
     return;
}

#####################################################################
# Called to get any data that must be sent to the other peer
# Also insert any plaintext data for possible encryption
sub get_pending
{
    my ($self, $data) = @_;

    no warnings "uninitialized";
    if ($self->{ssl_streamtls} && $self->{handshake_finished})
    {
	# Recover application data that was waiting for TLS
	$data .= $self->{wait_for_tls_data};
	$self->{wait_for_tls_data} = '';

	my $ret = &Net::SSLeay::write($self->{ssl_streamtls}, $data);
	if ($ret < 0)
	{
	    my $reason = &Net::SSLeay::get_error($self->{ssl_streamtls}, $ret);
	    $self->log($main::LOG_DEBUG, "SSLeay::write returned $ret, $reason");
	    
	    $self->log($main::LOG_ERR, "SSLeay::write failed: $ret, $reason, " . &Net::SSLeay::print_errs())
		if $reason != Net::SSLeay::ERROR_WANT_READ 
		   && $reason != Net::SSLeay::ERROR_WANT_WRITE;
	}
    }
    else
    {
	# Hold this application data until TLS is up.
	$self->{wait_for_tls_data} .= $data;
    }

    if ($self->{ssl_streamtls})
    {
	$data = &Net::SSLeay::BIO_read($self->{wbio}, $self->{MaxBufferSize});
	$self->log($main::LOG_EXTRA_DEBUG, 'StreamTLS send: ' . unpack('H*', $data));
	return $data;
    }
    return;
}

#####################################################################
# Net_SSLeay has only one callback handle. Sigh. Some other users of 
# Net_SSLeay may be operating within our code too, so to prevent collisions with their
# use of the verify callback, we have to explicitly set it every time we need it 
sub set_verify
{
    my ($object, $cb, $cb_failed) = @_;

    $Radius::StreamTLS::verifyFn = $cb;
    $Radius::StreamTLS::verifyFailedFn = $cb_failed;
    # Call a callback to verify the client certificate chain
    # SSLeay only supports on one calback, which we are forced to share
    # Reset it here in case someone else has been using it
    &Net::SSLeay::set_verify($object->{ssl_streamtls}, $object->{TLS_VerifyMode}, \&verifyCallback);
}

# Reset and remove the verify callback. This has the effect of removing the previously set
# verify callback. You must do this in the same thread as set_verify else Net::SSLeay may have 
# thread safety problems in a threaded environment.
sub reset_verify
{
    my ($object) = @_;

    &Net::SSLeay::set_verify($object->{ssl_streamtls}, $object->{TLS_VerifyMode}, undef);

}

#####################################################################
# Add TLS extension to require OCSP response from peer
sub set_ocsp_stapling_required
{
    my ($object) = @_;

    if (defined &Net::SSLeay::set_tlsext_status_type)
    {
	# Set TLS extension to require OCSP staple before doing SSL_accept
	Net::SSLeay::set_tlsext_status_type($object->{ssl_streamtls}, Net::SSLeay::TLSEXT_STATUSTYPE_ocsp());
    }
    else
    {
	$object->log($main::LOG_INFO, "OCSP stapling disabled because of Net::SSLeay version $Net::SSLeay::VERSION. See startup log messages for more information");
    }
}


1;

