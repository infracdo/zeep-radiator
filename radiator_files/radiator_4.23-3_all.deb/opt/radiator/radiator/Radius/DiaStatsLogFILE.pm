# DiaStatsLogFILE.pm
#
# Log DIAMETER statistics to FILE
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::DiaStatsLogFILE;
use strict;
use warnings;
our @ISA = qw(Radius::DiaStatsLogGeneric);
use Radius::DiaStatsLogGeneric;
use Radius::Util;

%Radius::DiaStatsLogFILE::ConfigKeywords =
(
 'Filename' =>
 ['string', 'This is the name of the file to log statistics to. Defaults to %L/statistics. The file name can include special formatting characters, although data from the current request or reply are never available (logging is never done in the context of a current request).', 0],
);

# RCS version number of this module
$Radius::DiaStatsLogFILE::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{Filename} = '%L/diastatistics';

    return;
}

#####################################################################
# Call the superclass to format filename and do the object traversal.
# Our sub log will be called for each object requiring logging
sub logAll
{
    my ($self) = @_;

    # Process filename and store it
    $self->{stats_filename} = Radius::Util::format_special($self->{Filename});

    $self->SUPER::logAll();
}

#####################################################################
# Log all the Statistics from one object
sub logObject
{
    my ($self, $diastats) = @_;

    my $time = time();

    # Try to find name for application code.
    $diastats->{ApplicationID_text} = $Radius::DiaMsg::appcode_to_name{$diastats->{ApplicationID}}
    if $diastats->{stats_type} eq $Radius::DiaStatsLogGeneric::STATS_TYPE{peer} &&
	exists $Radius::DiaMsg::appcode_to_name{$diastats->{ApplicationID}};

    my $peer_port = ($diastats->{DiaPeerPort}) ? "," . $diastats->{DiaPeerPort} : '';
    my $peer_name = ($diastats->{DiaPeerIP}) ? $diastats->{DiaPeerIP} . $peer_port : 'total';
    my $origin_realm = ($diastats->{OriginRealm}) ? $diastats->{OriginRealm} : 'total';
    my $origin_host = ($diastats->{OriginHost}) ? $diastats->{OriginHost} : 'total';
    my $application = ($diastats->{ApplicationID_text}) ? $diastats->{ApplicationID_text} : (defined $diastats->{ApplicationID}) ? $diastats->{ApplicationID} : 'total';
    my $statsname = $diastats->{stats_type} . "/" . $peer_name . "/" . $origin_realm . "/" . $origin_host . "/" . $application;

    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Logging DIAMETER statistic for '$statsname'");

    if (lc($self->{OutputFormat}) eq 'text')
    {
	# Create list containing enabled type(s).
	my @enabled_types = $self->{StatsType};
	@enabled_types = @Radius::StatsLog::Types if $self->{StatsType} eq $Radius::StatsLog::Type::All;

	# Loop through enabled types.
	foreach my $type (sort @enabled_types) {
	    my $category = $Radius::StatsLog::TypeToCounter{$type};
	    my @values = ();
	    Radius::Util::append($self->{stats_filename}, '#time_stamp:identifier:counter_type:' . join(':', sort keys %{$diastats->{$category}}) . "\n");
	    foreach my $key (sort keys %{$diastats->{$category}})
	    {
		push(@values, $diastats->{$category}->{$key});
	    }
	    Radius::Util::append($self->{stats_filename}, "$time;$statsname;$category;" . join(";", @values) . "\n") if @values;
	}

	return;
    }
    else
    {
	# Handle case when output format is something else than text.
	# Cumulative counters
	my $entry = {
	    log_type	       => "diastatslog",
	    timestamp	       => $time,
	    object_id	       => $statsname,
	    %{$diastats},
	};

	Radius::Util::append($self->{stats_filename}, $self->format_output($entry) . "\n");
	return;
    }
    return;
}

1;
