# AuthGOSSIP.pm
#
# Object for handling Authentication with Gossip API
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::AuthGOSSIP;
@ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use Radius::Gossip;
use Radius::Context;
use Radius::Util;
use Scalar::Util qw(refaddr);
use strict;
use warnings;

%Radius::AuthGOSSIP::ConfigKeywords =
(
'UsernameAttr' =>
 ['string',
  'The name of the attribute that is required to match the username in the authentication request (possibly after username rewriting by RewriteUsername). ',
  1],

 'PasswordAttr' =>
 ['string',
  'The name of the attribute that contains the correct password for the user. If you specify EncryptedPasswordAttr, it will be used instead of PasswordAttr, and PasswordAttr will not be fetched.',
  1],

 'EncryptedPasswordAttr' =>
 ['string',
  'Name of the attribute that contains a Unix crypt(3) encrypted password for the user. If you specify EncryptedPasswordAttr, it will be used instead of PasswordAttr, and PasswordAttr will not be fetched. You must specify either PasswordAttr or EncryptedPasswordAttr.',
  1],

 'ServerChecksPassword' =>
 ['flag',
  'Normally, Radiator fetches the user\'s password attribute from the server, and checks the password internally. This optional parameter causes the server to check the password instead. This is useful with servers that implement proprietary encryption algorithms in their passwords.',
  1],

 'UseFetch' =>
 ['flag',
  'This optional parameter causes Radiator to use Gossip fetch instead of Gossip publish to retrieve the user.',
  1],

 'UserKey' =>
 ['string', 'A path for users in Gossip backend.', 1],

 'AuthAttrDef' =>
 ['stringarray',
  'Allows you to specify attributes to use as general check and reply items during authentication. The general format is: <p><pre><code>AuthAttrDef gossipattributename,radiusattributename,type[,formatted]</code></pre>',
  1],

 'AcctAttrDef' =>
 ['stringarray',
  'AcctAttrDef is used to define which attributes in accounting requests are to be inserted into AccountingTable, and it also specifies which column they are to be inserted into, and optionally the data type of that column. The general format is: <p><pre><code>AcctAttrDef gossipattributename,attributename,type[,formatted]</code></pre>. Type can be either request or session',
  1],

 'AddIfNotExist' =>
 ['flag',
  'This optional parameter causes Radiator to add the user into Gossip backend if the user did not exist. AuthAttrDefs are used to populate the user entry.',
  1],

 'UserEntryTimeout' =>
 ['integer', 'When inserting a missing entry into Gossip backend, defines a time-to-live for the entry.', 1],

 'IgnoreReject' =>
 ['flag',
  'This optional parameter causes Radiator to ignore (i.e. not send back to the original NAS) any Access-Reject messages received from the remote server. This is sometimes useful for authenticating from multiple servers. However, you should note that if all the remote servers reject the request, then the NAS will receive no reply at all.',
  1],

 'Timeout' =>
 ['integer', 'Specifies the number of seconds to wait for a reply.', 1],

 'ContextTimeout' =>
 ['integer', 'Specifies the number of seconds to store reply attributes in context.', 1],

 'TimeoutReject' =>
 ['flag',
  'If a timeout occurs, REJECT instead of IGNORE. The RFCs say that IGNORE is the correct behaviour, but REJECT can work better in some load balancing situations',
  1],

 'ReplyHook' =>
 ['hook',
  'Perl function that will be called after a Gossip reply is received from the remote server.',
  1],

 'NoReplyHook' =>
 ['hook', 'Perl function that will be called if no reply is received from any remote server.', 1],

 'PostSearchHook' =>
 ['hook',
  'Perl function that will be called after a Gossip reply is received and possible AuthAttrDefs have been evaluated.',
  1],

 'NoForwardAuthentication' =>
 ['flag',
  'Stops AuthBy GOSSIP forwarding Authentication-Requests. They are ACCEPTED, but no further action is taken with them. This is different in meaning to IgnoreAuthentication, which IGNOREs them.',
  1],

 'NoForwardAccounting' =>
 ['flag',
  'Stops AuthBy GOSSIP forwarding Accounting-Requests. They are ACCEPTED, but no further action is taken with them. This is different in meaning to IgnoreAccounting, which IGNOREs them.',
  1],

 'Gossip' =>
 ['formatobjectlist', 'Gossip module to use for backend queries.', 0],

 'SessionDatabase' =>
 ['formatobjectlist', 'Specifies optional SessionDatabase which will be used to query session information. Special formatting characters are permitted.', 1],

 'AuthenticationMethod' =>
 ['string', 'This optional parameter defines a value for authentication which Gossip peer should use.', 1],
);

$Radius::AuthGOSSIP::VERSION = '$Revision$';

my %pending_requests;

# Make sure we get reinitialized on sighup
push(@main::reinitFns, \&reinitialize);

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;

    $self->{Timeout} = 2;
    $self->{ContextTimeout} = 5;

    $self->{UsernameAttr} = "username";
    $self->{UserKey} = $Radius::Gossip::Destination::ANY;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    $self->log($main::LOG_ERR, "No Gossip defined for AuthGOSSIP in '$main::config_file' line $.")
	unless defined $self->{Gossip};

    $self->log($main::LOG_WARNING, "No UsernameAttr defined for AuthGOSSIP in '$main::config_file' line $.")
	unless defined $self->{UsernameAttr};
    $self->log($main::LOG_WARNING, "No PasswordAttr or EncryptedPasswordAttr defined for AuthGOSSIP in '$main::config_file' line $.")
	if !defined $self->{PasswordAttr}
    && !defined $self->{EncryptedPasswordAttr}
    && !defined $self->{ServerChecksPassword}
    && !defined $self->{NoCheckPassword};

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    if (! $self->{Gossip})
    {
	$self->log($main::LOG_WARNING, "No Gossip method defined for AuthGOSSIP at '$main::config_file' line $.");
	return;
    }

    $self->{Gossip}[0]->register_message_handle("AuthGOSSIP-Access-Request-Reply", sub {
	my ($message) = @_;
	$self->handle_reply($message);
						}) unless $self->{NoForwardAuthentication};

    $self->{Gossip}[0]->register_message_handle("AuthGOSSIP-Accounting-Request-Reply", sub {
	my ($message) = @_;
	$self->handle_reply($message);
						}) unless $self->{NoForwardAccounting};
}

# Handle a request
sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    $self->log($main::LOG_DEBUG, "Handling with Radius::AuthGOSSIP: $self->{Identifier}", $p);

    unless ($self->{Gossip})
    {
	return ($main::IGNORE, 'Configuration error');
    }

    my $initial_user_name = $p->getUserName() || '';
    $initial_user_name =~ s/@[^@]*$//
	if $self->{UsernameMatchesWithoutRealm};
    $initial_user_name = $p->get_attr($self->{AuthenticateAttribute}) || ''
	if $self->{AuthenticateAttribute};

    if ($p->code eq 'Access-Request')
    {
	return ($main::ACCEPT, 'Accepted due to NoForwardAuthentication')
	    if $self->{NoForwardAuthentication};
	return ($main::IGNORE, "Ignored due to IgnoreAuthentication")
	    if $self->{IgnoreAuthentication};

	# Check the context cache
	my $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $initial_user_name : "authgossip:user:" . $initial_user_name;
	my $context = Radius::Context::find(refaddr($self) . $key);
	if ($context)
	{
	    $self->log($main::LOG_DEBUG, "AuthGOSSIP: Reusing context for user '$initial_user_name'", $p);
	    return $self->SUPER::handle_request($p, $dummy, $extra_checks);
	}
    }
    elsif ($p->code eq 'Accounting-Request')
    {
	return ($main::ACCEPT, 'Accepted due to NoForwardAccounting') if $self->{NoForwardAccounting};
	return ($main::IGNORE, "Ignored due to IgnoreAccounting")
	    if $self->{IgnoreAccounting};

	my $status_type = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE);
	return ($main::ACCEPT, 'Accepted due to HandleAcctStatusTypes')
	    if defined $self->{HandleAcctStatusTypes}
	&& !exists $self->{HandleAcctStatusTypes}{$status_type};

	return ($main::ACCEPT, 'Accepted due to AccountingStartsOnly')
	    if $self->{AccountingStartsOnly}
	&& $status_type ne 'Start';

	return ($main::ACCEPT, 'Accepted due to AccountingStopsOnly')
	    if $self->{AccountingStopsOnly}
	&& $status_type ne 'Stop';

	return ($main::ACCEPT, 'Accepted due to AccountingAlivesOnly')
	    if $self->{AccountingAlivesOnly}
	&& $status_type ne 'Alive';
    }

    # Tell callers the packet was proxied. Some callers need to know this.
    # Also causes Handler to increment the proxiedRequests stats
    $p->{proxied}++;

    # Whoever gets the request, logs with trace_id + 1
    my $trace_id = hex($p->{trace_id});
    $trace_id += 1;
    $trace_id = unpack('H*', pack('N', $trace_id));

    # Add attributes ...
    my $fp = {
	version => 1,
	type	=> "AuthGOSSIP-" . $p->code,
	msg_type => $Radius::Gossip::Message::REQUEST,
	msg_id => unpack('H*', Radius::Util::random_string(5)),
	msg_ttl => 1,
	from_id => "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self),
	timestamp => time(),
	trace_id => $trace_id,
	username => $initial_user_name,
	username_attr => $self->{UsernameAttr},
	password_attr => $self->{EncryptedPasswordAttr} || $self->{PasswordAttr} || '',
    };

    # Remember who this instance of AuthGOSSIP is
    #$fp->{ThisAuth} = $self;
    $fp->{auth_method} = $self->{AuthenticationMethod} if $self->{AuthenticationMethod};

    if ($p->code eq 'Accounting-Request')
    {
	$fp->{RAD_Acct_Status_Type} = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE) || '';
	my $origdelay = $p->getAttrByNum($Radius::Radius::ACCT_DELAY_TIME);
	$fp->{RAD_Acct_Delay_Time} = time - $p->{RecvTime} + $origdelay;

	my (%attrs, $session_attrs);
	foreach my $acctattrdef_set (@{$self->{AcctAttrDef}})
	{
	    my ($attribname,$attrib,$type,$formatting) = split (/\s*,\s*/, $acctattrdef_set);
	    $type = lc($type);
	    $formatting = lc($formatting);

	    my @vals;
	    if ($type eq 'request')
	    {
		@vals = $p->get_attr($attrib);
		@vals = map {Radius::Util::format_special($_, $p)} @vals
		    if ($formatting eq 'formatted');
	    }
	    elsif ($type eq 'session')
	    {
		if (! $session_attrs)
		{
		    if ($self->{SessionDatabase})
		    {
			# lookup session information
			my $nas_id = $p->getNasId();
			my $nas_port = $p->getAttrByNum($Radius::Radius::NAS_PORT);
			$session_attrs = $self->{SessionDatabase}[0]->getSessionData($initial_user_name, $nas_id, $nas_port, $p);
		    }
		}
		if ($session_attrs)
		{
		    @vals = ($session_attrs->{$attrib});
		    @vals = map {Radius::Util::format_special($_, $p)} @vals
			if ($formatting eq 'formatted');
		}
	    }
	    $attrs{$attribname} = \@vals if @vals;
	}

	$fp->{acct_attrs} = \%attrs if %attrs;
    }
    else
    {
	if ($self->{RejectEmptyPassword}
	    && $p->decodedPassword() eq ''
	    && !$p->getAttrByNum($Radius::Radius::CHAP_PASSWORD))
	{
	    $self->log($main::LOG_DEBUG, "AuthGOSSIP rejected because of an empty password", $p);
	    return ($main::REJECT, 'Empty password');
	}
	else
	{
	    if ($self->{ServerChecksPassword})
	    {
		$fp->{password} = $p->getAttrByNum($Radius::Radius::CHAP_PASSWORD) || $p->decodedPassword();
	    }
	}

	my @attrs;
	foreach my $authattrdef_set (@{$self->{AuthAttrDef}})
	{
	    my ($attribname,$attrib,$type,$formatting) = split (/\s*,\s*/, $authattrdef_set);
	    push(@attrs, $attribname) unless (lc($type) eq 'add');
	}

	$fp->{auth_attrs} = \@attrs if @attrs;
    }

    $p->{gossip_username} = $initial_user_name;

    if ($self->{UseFetch})
    {
	# TODO: FIXME: use ask() async with callback
	$self->log($main::LOG_DEBUG, "AuthGOSSIP: fetching username '$initial_user_name'", $p);
	my $user_hash = $self->{Gossip}[0]->ask($self->{UserKey} . ":" . $initial_user_name);
	if (!$user_hash)
	{
	    if ($self->{AddIfNotExist})
	    {
		# add missing entry
		$self->log($main::LOG_DEBUG, "AuthGOSSIP: username '$initial_user_name' was not found, adding it.", $p);
		my $user_password = "";
		my $user_attrs = {};
		my $group_attrs = [];

		# try to lookup init values
		my $key = ($self->{Blacklist}) ? "authgossip:user:" . $initial_user_name : "authgossip:blacklist:" . $initial_user_name;
		my $context = Radius::Context::find(refaddr($self) . $key);
		if ($context)
		{
		    $user_password = $context->{user_password};
		    $user_attrs = $context->{user_attrs};
		    $group_attrs = $context->{group_attrs};
		}
		else
		{
		    $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $initial_user_name : "authgossip:user:" . $initial_user_name;
		    $context = Radius::Context::find(refaddr($self) . $key);
		    if ($context)
		    {
			$user_password = $context->{user_password};
			$user_attrs = $context->{user_attrs};
			$group_attrs = $context->{group_attrs};
		    }
		}

		foreach my $authattrdef_set (@{$self->{AuthAttrDef}})
		{
		    my ($attribname,$val,$type,$formatting) = split (/\s*,\s*/, $authattrdef_set);
		    if (lc($type) eq 'add')
		    {
			$val = Radius::Util::format_special($val, $p)
			    if ($formatting && lc($formatting) eq 'formatted');
			$user_attrs->{$attribname} = [$val];
		    }
		}

		$user_hash = {
		    username => $initial_user_name,
		    user_password => $user_password || "",
		    user_attrs => $user_attrs || {},
		    group_attrs => $group_attrs || [],
		};

		if ($self->{UserEntryTimeout})
		{
		    $self->{Gossip}[0]->note($self->{UserKey} . ":" . $initial_user_name, $user_hash, $self->{UserEntryTimeout});
		}
		else
		{
		    $self->{Gossip}[0]->note($self->{UserKey} . ":" . $initial_user_name, $user_hash);
		}

		# When using as a blacklist, don't store entry in a context during the same authentication
		return $self->SUPER::handle_request($p, $dummy, $extra_checks) if $self->{Blacklist};
	    }
	}

	my $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $initial_user_name : "authgossip:user:" . $initial_user_name;
	$self->log($main::LOG_DEBUG, "AuthGOSSIP: Storing a context with key '$key'", $p);

	my $context = Radius::Context::get(refaddr($self) . $key, $self->{ContextTimeout});
	$context->{user_password} = $user_hash->{user_password} || "";
	$context->{user_attrs} = $user_hash->{user_attrs} || {};

	foreach my $authattrdef_set (@{$self->{AuthAttrDef}})
	{
	    my ($attribname,$val,$type,$formatting) = split (/\s*,\s*/, $authattrdef_set);
	    if (lc($type) eq 'add')
	    {
		$val = Radius::Util::format_special($val, $p)
		    if ($formatting && lc($formatting) eq 'formatted');
		$context->{user_attrs}->{$attribname} = [$val];
	    }
	}

	$context->{group_attrs} = $user_hash->{group_attrs} || [];

	return $self->SUPER::handle_request($p, $dummy, $extra_checks);
    }
    else
    {
	# ... and forward the request
	$pending_requests{refaddr($self) . $fp->{msg_id}} = [$p, $fp];
	$self->{Gossip}[0]->tell($self->{UserKey}, $fp);
	$fp->{TimeoutHandle} =
	    Radius::Select::add_timeout
	    (time + $self->{Timeout},
	     \&Radius::AuthGOSSIP::handle_timeout,
	     $self, $fp, $p);

	return ($main::ASYNC, 'Waiting for reply');
    }

    # Should not get this far
    return ($main::IGNORE, 'Unhandled message in AuthGOSSIP::handle_request');
}

# store data in context and call SUPER::handle_request(...)
sub handle_reply
{
    my ($self, $message_hash) = @_;

    unless ($message_hash->{msg_id})
    {
	$self->log($main::LOG_WARNING, "AuthGOSSIP $self->{Identifier}: Received a reply without a message id");
	return;
    }

    my $key = $message_hash->{msg_id};
    my $ref = delete $pending_requests{refaddr($self) . $key};
    unless ($ref)
    {
	# Do not log an error, another AuthGOSSIP could have sent the original request.
	#$self->log($main::LOG_DEBUG, "Auth $self->{Identifier}: Received an unexpected reply with a message id '$key'");
	return;
    }

    my ($op, $sp) = @{$ref};

    # set updated trace id
    $op->{trace_id} = $message_hash->{trace_id} if defined $message_hash->{trace_id};
    $op->{rp}->{trace_id} = $op->{trace_id};
    $self->log($main::LOG_DEBUG, "AuthGOSSIP $self->{Identifier}: Received a reply with a message id '$key'", $op);

    Radius::Select::remove_timeout($sp->{TimeoutHandle})
	|| $self->log($main::LOG_ERR, "AuthGOSSIP $self->{Identifier}: Timeout $sp->{TimeoutHandle} was not in the timeout list", $op);

    # Run the reply hook if there is one
    my $redirected;
    $self->runHook('ReplyHook', undef, \$message_hash, \$op->{rp}, \$op, \$sp, \$redirected) if $self->{ReplyHook};
    return if $redirected;

    my ($result, $reason);
    if (! defined $op->{RadiusResult} && defined $message_hash->{RAD_code})
    {
	if ($message_hash->{RAD_code} eq 'Access-Accept'
	    || $message_hash->{RAD_code} eq 'Accounting-Response'
	    || $message_hash->{RAD_code} eq 'Disconnect-Request-ACKed'
	    || $message_hash->{RAD_code} eq 'Change-Filter-Request-ACKed')
	{
	    $op->{RadiusResult} = $main::ACCEPT;
	}
	elsif ($message_hash->{RAD_code} eq 'Access-Challenge')
	{
	    $op->{RadiusResult} = $main::CHALLENGE;
	}
	else
	{
	    $op->{RadiusResult} = $main::REJECT;
	}
    }

    $reason = $message_hash->{RAD_Reply_Message} || 'Proxied';
    if (defined $op->{RadiusResult})
    {
	unless ($message_hash->{RAD_code}
		&& (($self->{IgnoreReject}
		     && $message_hash->{RAD_code} eq 'Access-Reject') ||
		    ($self->{IgnoreAccountingResponse}
		     && $message_hash->{RAD_code} eq 'Accounting-Response')))
	{
	    $op->{Handler}->handlerResult($op, $op->{RadiusResult}, $reason);
	    return;
	}
    }

    if (defined $message_hash->{username} && $message_hash->{username} ne '')
    {
	if ($message_hash->{username} ne $op->{gossip_username})
	{
	    $self->log($main::LOG_WARNING, "AuthGOSSIP: Username in reply ('$message_hash->{username}') does not match to original query ('$op->{gossip_username}')", $op);
	    $op->{Handler}->handlerResult($op, $main::REJECT, "Backend lookup mismatch");
	    return;
	}
	else
	{
	    my $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $op->{gossip_username} : "authgossip:user:" . $op->{gossip_username};

	    $self->log($main::LOG_DEBUG, "AuthGOSSIP: Storing a context with key '$key'", $op);

	    my $context = Radius::Context::get(refaddr($self) . $key, $self->{ContextTimeout});
	    if (exists $message_hash->{user_password})
	    {
		$context->{user_password} = $message_hash->{user_password};
	    }
	    if (exists $message_hash->{user_attrs})
	    {
		$context->{user_attrs} = $message_hash->{user_attrs};
		foreach my $authattrdef_set (@{$self->{AuthAttrDef}})
		{
		    my ($attribname,$val,$type,$formatting) = split (/\s*,\s*/, $authattrdef_set);
		    if (lc($type) eq 'add')
		    {
			$val = Radius::Util::format_special($val, $op) 
			    if ($formatting && lc($formatting) eq 'formatted');
			$context->{user_attrs}->{$attribname} = [$val];
		    }
		}
	    }
	    if (exists $message_hash->{group_attrs})
	    {
		$context->{group_attrs} = $message_hash->{group_attrs};
	    }
	}
    }
    else
    {
	$self->log($main::LOG_DEBUG, "AuthGOSSIP: No user found", $op);
	$result = ($self->{Blacklist}) ? $main::ACCEPT : $main::REJECT;
	$op->{Handler}->handlerResult($op, $result, "No such user");
	return;
    }

    ($result, $reason) = $self->SUPER::handle_request($op);
    $op->{Handler}->handlerResult($op, $result, $reason);
}

sub handle_timeout
{
    my ($handle, $self, $fp, $p) = @_;

    $self->log($main::LOG_DEBUG, "AuthGOSSIP: Request '$fp->{msg_id}' timed out");
    delete $pending_requests{refaddr($self) . $fp->{msg_id}};

    if ($self->{AcctFailedLogFileName} && $p->code eq 'Accounting-Request')
    {
	my $format_hook;
	$format_hook = sub { $self->runHook('AcctLogFileFormatHook', $p, $p); }
	if $self->{AcctLogFileFormatHook};

	Radius::Util::logAccounting($p, undef,
				    $self->{AcctFailedLogFileName},
				    $self->{AcctLogFileFormat},
				    $format_hook);
    }

    $self->runHook('NoReplyHook', undef, \$p, \$fp, \$p->{rp}) if $self->{NoReplyHook};
    $self->{Statistics}->{proxiedNoReply}++;

    $p->{RadiusResult} = ($self->{TimeoutReject}) ? $main::REJECT : $main::IGNORE;
    $p->{Handler}->handlerResult($p, $p->{RadiusResult}, 'Request Timeout');

    return;
}

sub findUser
{
    my ($self, $name, $p) = @_;

    return unless $name;

    my $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $name : "authgossip:user:" . $name;
    my $context = Radius::Context::find(refaddr($self) . $key);
    unless ($context)
    {
	$self->log($main::LOG_DEBUG, "AuthGOSSIP: Did not find context for user '$name' in findUser", $p);
	return;
    }

    my $user = Radius::User->new();
    my $got_password;

    if ($self->{EncryptedPasswordAttr})
    {
	my $password = $context->{user_password};
	if ($password)
	{
	    $got_password = 1;
	    $user->get_check->add_attr('Encrypted-Password', $password);
	}
    }
    elsif ($self->{PasswordAttr})
    {
	my $password = $context->{user_password};
	if ($password)
	{
	    $got_password = 1;
	    $user->get_check->add_attr('User-Password', $password);
	}
    }

    if (defined $context->{user_attrs})
    {
	foreach my $authattrdef_set (@{$self->{AuthAttrDef}})
	{
	    my ($attribname,$attrib,$type,$formatting) = split (/\s*,\s*/, $authattrdef_set);
	    $type = lc($type);
	    $formatting = lc($formatting) if $formatting;
	    if (exists $context->{user_attrs}->{$attribname})
	    {
		my @vals = @{$context->{user_attrs}->{$attribname}};
		@vals = map {Radius::Util::format_special($_, $p)} @vals
		    if ($formatting && $formatting eq 'formatted');

		if ($type eq 'check')
		{
		    if ($attrib eq 'GENERIC') {
			$user->get_check->parse(join ',', @vals);
		    }
		    else
		    {
			$user->get_check->add_attr($attrib, join('|', @vals));
		    }
		}
		elsif ($type eq 'reply')
		{
		    if ($attrib eq 'GENERIC')
		    {
			$user->get_reply->parse(join ',', @vals);
		    }
		    else
		    {
			map {$user->get_reply->add_attr($attrib, $_)} (@vals);
		    }
		}
		elsif ($type eq 'request')
		{
		    if ($attrib eq 'GENERIC')
		    {
			$p->parse(join ',', @vals);
		    }
		    else
		    {
			map {$p->add_attr($attrib, $_)} (@vals);
		    }
		}
	    }
	}
    }

    if ($user && !$got_password && !defined $self->{NoCheckPassword})
    {
	$self->log($main::LOG_ERR, "There was no password attribute found for $name. Check your authentication peer.", $p);
	$user->get_check->add_attr('Encrypted-Password', '**nevermatch-');

	# Encrypted-Password check attribute is not evaluated for EAP methods
	# such as EAP-GTC, EAP-MSCHAPv2, LEAP, EAP-MD5, etc.
	$user->get_check->add_attr('Auth-Type', 'Reject:There was no password attribute found. Check your authentication peer.');
    }

    $self->runHook('PostSearchHook', $p, $self, $name, \$p, \$user, \$p->{rp}) if $self->{PostSearchHook};

    return $user;
}

sub getUserGroups
{
    my ($self, $user, $p) = @_;

    return unless $user;

    my $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $user : "authgossip:user:" . $user;
    my $context = Radius::Context::find(refaddr($self) . $key);
    unless ($context)
    {
	$self->log($main::LOG_DEBUG, "AuthGOSSIP: Did not find context for user '$user' in getUserGroups", $p);
	return;
    }

    my @groups;

    if (defined $context->{group_attrs})
    {
	@groups = @{$context->{group_attrs}};
    }

    return @groups;
}

sub getLimitValue
{
    my ($self, $username, $check_name, $p) = @_;

    return unless ($username && $check_name);

    my $key = ($self->{Blacklist}) ? "authgossip:blacklist:" . $username : "authgossip:user:" . $username;
    my $context = Radius::Context::find(refaddr($self) . $key);
    unless ($context)
    {
	$self->log($main::LOG_DEBUG, "AuthGOSSIP: Did not find context for user '$username' in getLimitValue", $p);
	return;
    }

    my ($attribname,$attrib,$type);
    foreach my $authattrdef_set (@{$self->{AuthAttrDef}})
    {
	($attribname,$attrib,$type) = split (/\s*,\s*/, $authattrdef_set);
	last if $attrib eq $check_name;
    }

    # Expect value to be in an attribute without "Max-" prefix
    $attribname =~ s/^Max-//;

    # Prefer AuthGOSSIP reply context
    if (defined $context->{user_attrs} && $context->{user_attrs}->{$attribname})
    {
	my @vals = @{$context->{user_attrs}->{$attribname}};
	return $vals[0];
    }
    # Fall back to checking session database
    elsif ($self->{SessionDatabase})
    {
	# lookup session information
	my $nas_id = $p->getNasId();
	my $nas_port = $p->getAttrByNum($Radius::Radius::NAS_PORT);
	my $session_attrs = $self->{SessionDatabase}[0]->getSessionData($username, $nas_id, $nas_port, $p);
	if ($session_attrs)
	{
	    my @vals = ($session_attrs->{$attribname});
	    return $vals[0];
	}
    }

    return;
}

1;
