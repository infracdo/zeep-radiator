# AuthYUBIKEYVALIDATIONSERVER.pm
#
# Object for handling Authentication of Yubikey tokens (yubico.com)
# with Yubikey Validation Server.
#
# Author: Sami Keski-Kasari (samikk@open.com.au)
# Copyright (C) 2001-2014 Open System Consultants
# $Id$

package Radius::AuthYUBIKEYVALIDATIONSERVER;
use strict;
use warnings;
use Radius::AuthYUBIKEYBASE;
#use IO::Socket::SSL qw(debug3); # For verbose debugging
use LWP::UserAgent;
use MIME::Base64;
our @ISA = qw(Radius::AuthYUBIKEYBASE);

%Radius::AuthYUBIKEYVALIDATIONSERVER::ConfigKeywords =
(
'ValidationServerURL' =>
 ['string', 'The URL for Yubikey Validation server. Defaults to http://127.0.0.1:8003/yhsm/validate?', 0],

 'ClientID' =>
 ['string', 'Optional Yubico Client ID required by some validation servers.', 0],

 'APIKey' =>
 ['string', 'Optional Yubico API key used with Yubico Client ID required by some validation servers. Special formatting characters are supported.', 0],

 'OTPCharset' =>
 ['string', 'List of characters permitted in OTP. Request with OTP containing characters not in this set are rejected. Perl character set formats are permitted, such as "a-zA-Z0-9" which permits all alphanumeric characters. Defaults to: 0-9cbdefghijklnrtuv', 2],

 'OTPProtocol' =>
 ['counthash', 'Specifies which OTP protocols Radiator attempts to use with validation server. When multiple protocols are enabled, Radiator attempts to select the protocol based on the submitted value. Defaults to YubicoOTP.', 1],

 'APIVersion' =>
 ['enum', 'Validation Protocol version for YubicoOTP protocol. This must match API supported by server configured with ValidationServerURL.', 0, \@Radius::AuthYUBIKEYVALIDATIONSERVER::api_version_enum],

'Timeout' =>
 ['integer', 'Specifies a timeout interval in seconds that Radiator will wait for when talking to the Yubikey Validation server. Defaults to 3 seconds', 1],

'SSLVerify' =>
 ['string', 'May be used to control how the Yubikey Validation Server\'s certificate will be verified. May be one of "none" or "require".',
  1],

 'SSLCAPath' =>
 ['string', 'When verifying the XML Yubikey Validation Server\'s certificate, set this to the pathname of the directory containing CA certificates. These certificates must all be in PEM format. The directory in must contain certificates named using the hash value of the certificates\' subject names.',
  1],

 'SSLCAFile' =>
 ['string', 'When verifying the Yubikey Validation Server\'s certificate, set this to the filename containing the certificate of the CA who signed the server\'s certificate. The certificate must all be in PEM format.',
  1],
);

@Radius::AuthYUBIKEYVALIDATIONSERVER::api_version_enum = qw(yk-ksm 1.0 2.0);

# RCS version number of this module
$Radius::AuthYUBIKEYVALIDATIONSERVER::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initialize instance
# variables
# that might get overridden when the config file is parsed.
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{ValidationServerURL} = 'http://127.0.0.1:8003/yhsm/validate?';
    $self->{OTPCharset} = '0-9cbdefghijklnrtuv';
    $self->{Timeout} = 3; # In seconds

    return;
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    # Avoid creating OPTProtocol key
    if ($self->{OTPProtocol})
    {
	my ($use_hotp, $use_totp);
	foreach my $proto (sort keys(%{$self->{OTPProtocol}}))
	{
	    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Unknown OTPProtol: $proto")
		unless grep {$proto eq $_} (qw(YubicoOTP OATH-HOTP OATH-TOTP));
	    $use_hotp = 1 if $proto eq 'OATH-HOTP';
	    $use_totp = 1 if $proto eq 'OATH-TOTP';
	}

	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: OATH-HOTP and OATH-TOTP both enabled")
	    if $use_hotp && $use_totp;
    }

    if ($self->{APIKey})
    {
	require Digest::HMAC_SHA1;
    }

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Create run time versions of configuration parameters
    if ($self->{OTPProtocol})
    {
	%{$self->{run_OTPProtocol}} = %{$self->{OTPProtocol}};
    }
    else
    {
	$self->{run_OTPProtocol}->{YubicoOTP} = 1;
    }
    $self->{run_APIVersion} = $self->{APIVersion} ? $self->{APIVersion} : $Radius::AuthYUBIKEYVALIDATIONSERVER::api_version_enum[0];

    # Get the SSL options hash
    my %ssl_opts = $self->get_ssl_opts();

    $self->{ua} = LWP::UserAgent->new (
	ssl_opts => {%ssl_opts},
	);
    $self->{ua}->timeout($self->{Timeout});

    return;
}

#####################################################################
sub checkYubikey
{
    my ($self, $user, $submitted_pw, $p) = @_;

    my $reason = $self->check_otp_chars($submitted_pw);
    return ($main::REJECT, $reason) if $reason;

    my ($method, $params) = $self->format_otp_query($submitted_pw, $p);
    return ($main::REJECT, 'Submitted OTP not in supported format') unless $method;

    my $uri = "$self->{ValidationServerURL}".$params->{query};
    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: Request URI: $uri", $p);

    my $response = $self->{ua}->get($uri);
    unless ($response->code() eq '200') # HTTP::Status::HTTP_OK
    {
	my $status = $response->status_line();
	$reason = "Call to Validation Server returned with HTTP status $status";
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: $reason", $p);
	return ($main::REJECT, $reason);
    }

    # HTTP 200. Note: Response is multiline for some protocol versions.
    my $decoded_response = $response->decoded_content();
    unless (length ($decoded_response))
    {
	$reason = "Call to Validation Server returned with empty content";
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: $reason", $p);
	return ($main::REJECT, $reason);
    }

    # Got something from the server
    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: Response:\n$decoded_response", $p);
    if ($method eq 'YubicoOTP' && $self->{run_APIVersion} ne 'yk-ksm')
    {
	return $self->process_multiline($p, $params, $decoded_response);
    }
    else
    {
	return $self->process_pyhsm_oneline($p, $params, $decoded_response);
    }

    return ($main::REJECT, 'Unhandled OTP');
}

# Check length, allowed chars, etc.
sub check_otp_chars
{
    my ($self, $submitted_pw) = @_;

    return ('Undefined OTP')
	if !defined $submitted_pw;

    return ('Zero length OTP')
	if length($submitted_pw) == 0;

    return ('Invalid character in OTP')
        if (defined $self->{OTPCharset}
            && $submitted_pw =~ /[^$self->{OTPCharset}]/);

    return undef;
}

# For easy override during testing
sub make_nonce
{
    return unpack('H*', Radius::Util::random_string(16));
}

sub format_otp_query
{
    my ($self, $submitted_pw, $p) = @_;

    my $pw_len = length($submitted_pw);
    my $use_otp = $self->{run_OTPProtocol}->{YubicoOTP};
    my $use_hotp = $self->{run_OTPProtocol}->{'OATH-HOTP'};
    my $use_totp = $self->{run_OTPProtocol}->{'OATH-TOTP'};
    my ($method, %params);

    if ($use_otp &&
	$pw_len == 44)
    {
	# Yubico's own tokencode is 32 characters long. TokenId is
	# 1-16 characters where 12 is the default and typical length.
	my %url_params;
	$url_params{otp} = $submitted_pw;
	if ($self->{run_APIVersion} eq '2.0')
	{
	    $url_params{nonce} = $self->make_nonce();
	}
	$url_params{id} = $self->{ClientID} if $self->{ClientID}; # Empty and zero means don't use

	my $query = '';
	$query .= "$_=$url_params{$_}&" foreach (sort keys(%url_params));
	$query = substr($query, 0, -1); # Remove trailing &
	if ($self->{APIKey})
	{
	    my $key = decode_base64(Radius::Util::format_special($self->{APIKey}, $p, $self));
	    my $h = encode_base64(Digest::HMAC_SHA1::hmac_sha1($query, $key), '');
	    $url_params{h} = $h;
	    $h =~ s/\+/%2B/g; # URI escape +
	    $query .= "&h=$h";
	}

	$params{otp} = $url_params{otp};
	$params{nonce} = $url_params{nonce};
	$params{h} = $url_params{h};
	$params{query} = $query;
	$method = 'YubicoOTP';
    }
    elsif (($use_hotp || $use_totp) &&
	   ($pw_len == 18 || $pw_len == 20))
    {
	# Yubikeys support 12 character Class A - OATH Token
	# Identifiers and 6 or 8 character OATH-HOTP codes. Note:
	# Currently Yubico's PyHSM validation server yhsm-val does not
	# support 8 character codes.
	if ($use_hotp)
	{
	    $method = 'OATH-HOTP';
	    $params{query} = "hotp=$submitted_pw";
	}
	else
	{
	    $method = 'OATH-TOTP';
	    $params{query} = "totp=$submitted_pw";
	}
    }
    else
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Unknown OTP format, password length $pw_len");
    }

    return ($method, \%params);
}

# Handle PyHSM package's yhsm-val single line responses. With
# --short-otp mode the response looks like YubiKey Key Storage Module
# (YK-KSM) single line response. Modes --hotp, --totp and --pwhash
# also return a single line response.
sub process_pyhsm_oneline
{
    my ($self, $p, $params, $response) = @_;

    $response =~ s/\s+\z//; # Remove trailing whitespace, especially \r and \n
    if ($response =~ /^OK /)
    {
	$self->log($main::LOG_DEBUG, "YubiKey PyHSM validation result: $response");
	return ($main::ACCEPT, 'OTP accepted by PyHSM');
    }
    elsif ($response =~ /^ERR (.*)/)
    {
	return ($main::REJECT, "OTP rejected by PyHSM: $1");
    }

    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Bad response from PyHSM: $response", $p);
    return ($main::REJECT, 'Bad response from PyHSM');
}

# Handle YubiKey Validation Server (YK-VAL) protocol 1.0 or 2.0
# compatible response for YubikeyOTP protocol.
sub process_multiline
{
    my ($self, $p, $params, $response) = @_;

    # See that response parses correctly
    my ($res, $reject_reason);
    if (open(my $fh, '<', \$response))
    {
	($res, $reject_reason) = $self->parse_response($fh);
	close($fh);
    }
    else
    {
	$reject_reason = 'Could not read from response';
    }
    return $self->error_reject($p, $reject_reason) if $reject_reason;

    # Now see that the required parameters are present and correct
    if ($params->{h})
    {
	$reject_reason = $self->check_signature($res, $p);
	return $self->error_reject($p, $reject_reason) if $reject_reason;
    }

    # Used to check nonce and otp here. Later noticed that nonce is
    # returned for status=REPLAYED_OTP but not for status=BAD_OTP. Now
    # check that it's present for status=OK. The same was observed for
    # otp parameter too.

    unless (defined $res->{status})
    {
	return $self->error_reject($p, "Yubico OTP validation server did not return status");
    }

    # Response was well formatted. Check its status
    if ($res->{status} eq 'OK')
    {
	if ($params->{nonce} && (!$res->{nonce} || $params->{nonce} ne $res->{nonce}))
	{
	    return $self->error_reject($p, "Yubico OTP validation server did not return correct nonce");
	}

	if ($self->{run_APIVersion} eq '2.0' && (!$res->{otp} || $params->{otp} ne $res->{otp}))
	{
	    return $self->error_reject($p, "Yubico OTP validation server did not return correct otp");
	}

	my $status_reason = 'Yubico OTP accepted by validation server';
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: $status_reason", $p);
	return ($main::ACCEPT, $status_reason);
    }
    else
    {
	my $status_reason = "Yubico OTP rejected by validation server: $res->{status}";
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: $status_reason", $p);
	return ($main::REJECT, $status_reason);
    }

    # Should never get here
    return $self->error_reject($p, 'Unhandled response from validation server');
}

# Return (hashref, string) where hashref is only defined if response
# was parsed correctly. Otherwise string has the failure reason.
sub parse_response
{
    my ($self, $fh) = @_;

    my (%res, $reject_reason);
    while (my $line = <$fh>)
    {
	$line =~ s/\s+\z//; # Remove trailing whitespace, especially \r and \n
	next if $line eq ''; # Skip empty lines

	my ($param, $value) = ($line =~ m/^([a-z]+)=(.+)\z/); # Params must be lower case
	unless (defined $param && defined $value)
	{
	    $reject_reason = "Could not parse response line from validation server: $line";
	    last;
	}
	if (exists $res{$param})
	{
	    $reject_reason = "Parameter received multiple times: $param";
	    last;
	}
	$res{$param} = $value;
    }

    return (undef, $reject_reason) if $reject_reason;
    return (\%res, undef);
}

# Log a WARNING level message and return $main::REJECT
sub error_reject
{
    my ($self, $p, $reject_reason) = @_;

    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: $reject_reason", $p);
    return ($main::REJECT, $reject_reason);
}

# Check signature
sub check_signature
{
    my ($self, $res, $p) = @_;

    my $h = $res->{h};
    return 'No signature in response' unless defined $h;
    return 'Signature not Base64 encoded' unless $h =~ m{^[A-Za-z0-9+/=]+\z};

    my $input = '';
    $input .= ($_ eq 'h') ? '' : "$_=$res->{$_}&" foreach (sort keys(%$res));
    $input = substr($input, 0, -1); # Remove trailing &

    my $key = decode_base64(Radius::Util::format_special($self->{APIKey}, $p, $self));
    my $digest = Digest::HMAC_SHA1::hmac_sha1($input, $key);
    return 'Bad signature' if $digest ne decode_base64($h);

    # Signature is good
    return undef;
}

#####################################################################
# Collect the certificate verify options from the current
# configuration.
sub get_ssl_opts
{
    my ($self) = @_;

    my %ssl_verify = ( 'none' => 0, 'require' => 1 );
    my %ssl_opts;

    $ssl_opts{SSL_ca_file} = Radius::Util::format_special($self->{SSLCAFile})
        if defined $self->{SSLCAFile};
    $ssl_opts{SSL_ca_path} = Radius::Util::format_special($self->{SSLCAPath})
        if defined $self->{SSLCAPath};
    $ssl_opts{verify_hostname} = $ssl_verify{ lc($self->{SSLVerify}) }
        if defined $self->{SSLVerify};

    return %ssl_opts;
}

1;
