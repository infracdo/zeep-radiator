# DiaStatsLogGeneric.pm
#
# Generic DIAMETER logging module
#
# Author: Janne Redsven (janne@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::DiaStatsLogGeneric;
use strict;
use warnings;
our @ISA = qw(Radius::StatsLogGeneric);
use Radius::StatsLogGeneric;

%Radius::DiaStatsLogGeneric::ConfigKeywords =
(
 'PeerAliveDetectionInterval' =>
 ['integer', 'PeerAliveDetectionInterval specifies the time interval (in seconds) that counter updates must happen or peer is considered to be inactive. Statistics from inactive peers are not reported. Defaults to 60 seconds. PeerAliveDetectionInterval should be longer than two times watchdog trigger time (Twinit default 30 s, see RFC 6733) so that at least DWR/DWA counters are updated, thus minimum value is 60. Setting PeerAliveDetectionInterval to 0 disables peer alive checks.', 1],

 'PeerRemovalThreshold' =>
 ['integer', 'PeerRemovalThreshold is the amount of StatsLog intervals that inactive peer is kept in memory. After PeerRemovalThreshold * Interval seconds inactive peer is removed. Defaults to 1. Setting PeerRemovalThreshold to 0 disables inactive peer cleanup.', 1],

);

# Mapping for statistics describing traffic direction:
# IN  = incoming DIAMETER message
# OUT = outgoing DIAMETER message
# These are exported to Radius::DiaStatsLog for convenience
$Radius::DiaStatsLog::Direction::In  = 'In';
$Radius::DiaStatsLog::Direction::Out = 'Out';

# Statistic type mapping to make statistics output generation easier in other modules.
%Radius::DiaStatsLogGeneric::STATS_TYPE =
    (
     error => 'error',
     peer  => 'peer',
     total => 'total',
    );

# RCS version number of this module
$Radius::DiaStatsLogGeneric::VERSION = '$Revision$';

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{PeerStatsPrefix}      = 'dbpPerPeerStats';
    $self->{PeerErrorStatsPrefix} = 'dbpPerPeerErrorStats';
    $self->{TotalStatsPrefix}     = 'dbpLocalStatsTotalMessages';
    $self->{ErrorStatsPrefix}     = 'dbpLocalErrorStats';

    # If counter was updated within time interval, peer is considered to be alive.
    # PeerAliveDetectionInterval should be longer than two times watchdog trigger time
    # (Twinit default 30 s, see RFC 6733) so that at least DWR/DWA counters are updated.
    $self->{PeerAliveDetectionInterval} = 60;

    # If DIAMETER peer has not been active for defined amount of DiaStatsLog invocations,
    # remove it completely from DIAMETER counter data structure.
    $self->{PeerRemovalThreshold} = 1;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    if ($self->{PeerAliveDetectionInterval} < 60 && $self->{PeerAliveDetectionInterval} != 0)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: PeerAliveDetectionInterval ($self->{PeerAliveDetectionInterval}) is less than recommended minimum (60 s). Using default interval (60 s).");
	$self->{PeerAliveDetectionInterval} = 60;
    }

    return;
}

# Run same statistics as in StatsLogGeneric.pm but remove inactive peers.
sub process_statistics
{
    my ($self) = @_;

    # Run process_statistics from StatsLogGeneric.pm
    $self->SUPER::process_statistics();

    # Remove peers that have not been active.
    $self->removeInactivePeers() if $self->{PeerRemovalThreshold};
}

#####################################################################
# Override this to get control before and after loging starts
sub logAll
{
    my ($self) = @_;

    # First process total statistics, if there are any.
    # We are not returning from this function now since there might be only peer related errors.
    if (keys(%{$main::dia_statistics->{total}}))
    {
	my $diastats = {
	    stats_type => $Radius::DiaStatsLogGeneric::STATS_TYPE{total},
	};

	foreach my $direction (sort keys(%{$main::dia_statistics->{total}}))
	{
	    # Set a reference to statistics hash to make access easier.
	    my $direction_ref	 = $main::dia_statistics->{total}->{$direction};

	    # Set the value from previous round to be zero if this is the first run.
	    $direction_ref->{previous_count} = 0 unless $direction_ref->{previous_count};

	    # Calculate cumulative and derivative count
	    my $cumulative_count = $direction_ref->{count};
	    my $previous_count	 = $direction_ref->{previous_count};
	    my $derivative_count = $cumulative_count - $previous_count;

	    # Set statistical prefix + key
	    my $stats_key = $self->{TotalStatsPrefix};
	    $stats_key .= $direction;

	    # Add values to statistics hash.
	    $diastats->{cumulative_counters}->{$stats_key} = 0 + $cumulative_count;
	    $diastats->{derivative_counters}->{$stats_key} = 0 + $derivative_count;

	    # Calculate packet rate.
	    # $self->{statistics}->{rate_calculation_multiplier} is calculated in StatsLogGeneric.pm.
	    $diastats->{packet_rates}->{$stats_key} = $derivative_count * $self->{statistics}->{rate_calculation_multiplier};

	    # Save value from this round to be used in the next round.
	    $direction_ref->{previous_count} = 0 + $cumulative_count;
	}

	# Always log total statistics (total messages in/out)
	$self->logObject($diastats);
    }

    # Then process total error statistics, if there are any.
    if (keys(%{$main::dia_statistics->{errors}}))
    {
	my $diastats = {};
	foreach my $error (sort keys(%{$main::dia_statistics->{errors}}))
	{
	    # Set a reference to statistics hash to make access easier.
	    my $error_ref	 = $main::dia_statistics->{errors}->{$error};

	    # Set the value from previous round to be zero if this is the first run.
	    $error_ref->{previous_count} = 0 unless $error_ref->{previous_count};

	    # Calculate cumulative and derivative count
	    my $cumulative_count = $error_ref->{count};
	    my $previous_count	 = $error_ref->{previous_count};
	    my $derivative_count = $cumulative_count - $previous_count;

	    # Generate key for statistics (e.g. dbpLocalStatsTotalMessagesIn)
	    my $stats_key = $self->{ErrorStatsPrefix} . $error;

	    # Add values to statistics hash.
	    $diastats->{cumulative_counters}->{$stats_key} = 0 + $cumulative_count;
	    $diastats->{derivative_counters}->{$stats_key} = 0 + $derivative_count;

	    # Calculate packet rate.
	    # $self->{statistics}->{rate_calculation_multiplier} is calculated in StatsLogGeneric.pm.
	    $diastats->{packet_rates}->{$stats_key} = $derivative_count * $self->{statistics}->{rate_calculation_multiplier};

	    # Save value from this round to be used in the next round.
	    $error_ref->{previous_count} = 0 + $cumulative_count;
	}
	if (keys(%{$diastats}))
	{
	    $diastats->{stats_type} = $Radius::DiaStatsLogGeneric::STATS_TYPE{error};
	    $self->logObject($diastats);
	}
    }

    # Loop through diapeer ip addresses
    foreach my $diapeer_ip (sort keys(%{$main::dia_statistics->{peers}}))
    {
	my $diapeer_ip_ref = $main::dia_statistics->{peers}->{$diapeer_ip};
	# Loop through diapeer ports
	foreach my $diapeer_port (sort keys(%{$diapeer_ip_ref}))
	{
	    my $diapeer_port_ref = $diapeer_ip_ref->{$diapeer_port};

	    # Store counter-wise statistics. Purpose is to log all statistics
	    # related if any of the statistics is updated.
	    my @diastats_per_port;

	    # Set to true if counter is updated within $self->{PeerAliveDetectionInterval}.
	    my $is_updated = 0;

	    # Handle the special case when inactive_rounds is not initialized on the first run.
	    $diapeer_port_ref->{inactive_rounds} = 0 unless $diapeer_port_ref->{inactive_rounds};

	    # Diapeer IP and port stays the same for the rest of the loop.
	    my $peerstats_base = {
		DiaPeerIP     => $diapeer_ip,
		DiaPeerPort   => 0 + $diapeer_port,
	    };

	    # Process any peer related errors.
	    if (keys(%{$diapeer_port_ref->{errors}}))
	    {
		my $diastats = {
		    %{$peerstats_base},
		    stats_type	  => $Radius::DiaStatsLogGeneric::STATS_TYPE{error},
		};

		foreach my $error (sort keys(%{$diapeer_port_ref->{errors}}))
		{
		    my $error_ref = $diapeer_port_ref->{errors}->{$error};

		    # Handle the special case when the statistics are run for the first time.
		    $error_ref->{previous_count} = 0 unless $error_ref->{previous_count};

		    # Calculate cumulative and derivative count
		    my $cumulative_count = $error_ref->{count};
		    my $previous_count	 = $error_ref->{previous_count};
		    my $derivative_count = $cumulative_count - $previous_count;

		    # Set statistical prefix + key
		    my $stats_key = $self->{PeerErrorStatsPrefix} . $error;

		    # Check that we have fresh data. Always update if PeerAliveDetectionInterval is disabled.
		    $is_updated++ if ($self->{PeerAliveDetectionInterval} == 0) ||
				     (time() - $error_ref->{last_update}) <= $self->{PeerAliveDetectionInterval};

		    # Add to statistics hash.
		    $diastats->{cumulative_counters}->{$stats_key} += $cumulative_count;
		    $diastats->{derivative_counters}->{$stats_key} += $derivative_count;
		    $diastats->{packet_rates}->{$stats_key}	    = $derivative_count * $self->{statistics}->{rate_calculation_multiplier};

		    # Save counter for next round
		    $error_ref->{previous_count} = $cumulative_count;
		}
		# Save statistics to array. Array is logged only if there are updated counters.
		push @diastats_per_port, $diastats;
	    }

	    # After error processing it's time to process DiaPeerDef related statistics.
	    # Procedure is the following:
	    # - Loop through DiaPeerDefs
	    # - Loop Origin-Realms
	    # - Loop Origin-Hosts
	    # - Loop Application-Ids
	    # - Loop directions (In/Out)
	    # - Loop command codes (257, ...)
	    # - Loop message flags (request, error etc.)
	    # Finally collect statistics in the innermost loop for each Application-Id.
	    # This makes it possible to get statistics per DIAMETER application.

	    foreach my $diapeerdef (sort keys(%{$diapeer_port_ref->{diapeerdefs}}))
	    {
		my $diapeerdef_ref = $diapeer_port_ref->{diapeerdefs}->{$diapeerdef};
		# Loop through Origin-Realms
		foreach my $origin_realm (sort keys(%{$diapeerdef_ref}))
		{
		    my $origin_realm_ref = $diapeerdef_ref->{$origin_realm};
		    # Loop through Origin-Hosts
		    foreach my $origin_host (sort keys(%{$origin_realm_ref}))
		    {
			# At this point we have left direction (incoming/outgoing), Command code and message flag.
			my $origin_host_ref = $origin_realm_ref->{$origin_host};
			foreach my $application_id (sort keys(%{$origin_host_ref}))
			{
			    my $application_id_ref = $origin_host_ref->{$application_id};

			    # Generate a statistics hash to be filled in inner loops.
			    my $diastats = {
				%{$peerstats_base},
				DiaPeerDef    => $diapeerdef,
				OriginHost    => $origin_host,
				OriginRealm   => $origin_realm,
				stats_type    => $Radius::DiaStatsLogGeneric::STATS_TYPE{peer},
				ApplicationID => 0 + $application_id,
			    };

			    # Loop through message flow directions (In/Out)
			    foreach my $direction (sort keys(%{$application_id_ref}))
			    {
				my $direction_ref = $application_id_ref->{$direction};

				# Loop through DIAMETER command codes
				foreach my $code (sort keys(%{$direction_ref}))
				{
				    my $code_ref = $direction_ref->{$code};

				    # Loop through DIAMETER message flags
				    # FIXME: only request flag is used.
				    foreach my $flag (sort keys(%{$code_ref}))
				    {
					my $flag_ref = $code_ref->{$flag};
					# Handle the special case when the statistics are run for the first time.
					$flag_ref->{previous_count} = 0 unless $flag_ref->{previous_count};

					# Calculate cumulative and derivative count
					my $cumulative_count = $flag_ref->{count};
					my $previous_count   = $flag_ref->{previous_count};
					my $derivative_count = $cumulative_count - $previous_count;

					# Set statistical prefix + key
					my $abbr      = Radius::DiaMsg::code_to_abbr($code, $flag);
					my $stats_key = $self->{PeerStatsPrefix} . $abbr . 's';
					$stats_key   .= $direction;

					# Check that we have fresh data. Always update if PeerAliveDetectionInterval is disabled.
					$is_updated++ if ($self->{PeerAliveDetectionInterval} == 0) ||
							 (time() - $flag_ref->{last_update}) <= $self->{PeerAliveDetectionInterval};

					# Add counters to our to-be logged statistics hash
					$diastats->{cumulative_counters}->{$stats_key} += $cumulative_count;
					$diastats->{derivative_counters}->{$stats_key} += $derivative_count;
					$diastats->{packet_rates}->{$stats_key}		= $derivative_count * $self->{statistics}->{rate_calculation_multiplier};

					# Save counter for next round
					$flag_ref->{previous_count} = $cumulative_count;
				    }
				}
			    }
			    # Save statistics to array. Array is logged only if there are updated counters.
			    push @diastats_per_port, $diastats;
			}
		    }
		}
	    }

	    # log all counters if:
	    # - any of the statistics counters is updated,
	    # - peer is has been inactive for current statistics round (less or equal than PeerAliveDetectionInterval).
	    if ($is_updated || $diapeer_port_ref->{inactive_rounds} == 0)
	    {
		foreach my $diastat (@diastats_per_port)
		{
		    $self->logObject($diastat);
		}

		# Clear inactivation if there were updates.
		# Otherwise increase the number of inactive rounds to prevent further
		# statistic logging if PeerAliveDetectionInterval is not disabled.
		if ($is_updated)
		{
		    $diapeer_port_ref->{inactive_rounds} = 0;
		}
		elsif ($self->{PeerRemovalThreshold} > 0)
		{
		    $diapeer_port_ref->{inactive_rounds}++;
		    $self->log($main::LOG_DEBUG,  "$self->{log_class_identifier}: Peer $diapeer_ip:$diapeer_port has been marked as inactive.");
		}
	    }
	    elsif($self->{PeerRemovalThreshold} > 0)
	    {
		# Hint is for statistics cleanup.
		$diapeer_port_ref->{inactive_rounds}++;
		$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Peer $diapeer_ip:$diapeer_port has"
					   . " been inactive for $diapeer_port_ref->{inactive_rounds} StatsLog intervals.");
	    }
	}
    }
}

#####################################################################
# Log all the Statistics from one object
# Returns nothing
# Override this to do the work of logging stats from a single object
sub logObject
{
    my ($self, $object) = @_;

    $self->log($main::LOG_ERR, "You did not override logObject() in DiaStatsLogGeneric");
    return;
}

#####################################################################
# Purpose of removeInactivePeers is to remove peers that haven't been
# active for the amount defined by $self->{PeerRemovalThreshold} of
# DiaStatsLog invocations.
sub removeInactivePeers
{
    my ($self) = @_;

    # Loop through Diapeer IP addresses
    foreach my $diapeer_ip (keys(%{$main::dia_statistics->{peers}}))
    {
	my $diapeer_ip_ref = $main::dia_statistics->{peers}->{$diapeer_ip};
	# Loop through diapeer ports
	foreach my $diapeer_port (keys(%{$diapeer_ip_ref}))
	{
	    my $diapeer_port_ref = $diapeer_ip_ref->{$diapeer_port};
	    if ($diapeer_port_ref->{inactive_rounds} && ($diapeer_port_ref->{inactive_rounds} > $self->{PeerRemovalThreshold}))
	    {
		$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Peer $diapeer_ip:$diapeer_port has been inactive for $diapeer_port_ref->{inactive_rounds} StatsLog intervals. Cleaning up.");
		delete $main::dia_statistics->{peers}->{$diapeer_ip}->{$diapeer_port};
	    }
	}
	# If there are no ports left, remove peer IP from statistics.
	if (scalar keys %{$diapeer_ip_ref} == 0)
	{
	    delete $main::dia_statistics->{peers}->{$diapeer_ip};
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Peer $diapeer_ip does not contain any port definitions. Removing peer.");
	}
    }

    return;
}

1;
