# AcctLogSYSLOG.pm
#
# Specific class for logging accounting to SYSLOG
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AcctLogSYSLOG;
@ISA = qw(Radius::AcctLogGeneric);
use Radius::AcctLogGeneric;
use Radius::Configurable;
use Sys::Syslog qw(:DEFAULT setlogsock);
use strict;
use warnings;

%Radius::AcctLogSYSLOG::ConfigKeywords =
('Facility' =>
 ['string', 'The name of the syslog facility that will be logged to. The default is \'user\'.', 1],

 'Priority' =>
 ['string', 'The syslog priority level that will be used for each log message. Default is \'info\'.', 1],

 'LogFormat' =>
 ['string', 'The format for success messages. You can use any of the special characters. %0 is replaced by the result, %1 by the reason string (usually an empty string for success) and %2 by tracing identifier string. Defaults to \'%l:%n:%{Acct-Session-Id}:%{Framed-IP-Address}:%{Calling-Station-Id}\'.', 1],

 'LogSock' =>
 ['string', 'This optional parameter specifies what type of socket to use to connect to the syslog server. Allowable values are unix, inet, tcp, udp. Defaults to unix. The option inet means to try tcp first, then udp. The default is to use the Sys::Syslog default of tcp, udp, unix, stream, console.', 1],

 'LogPort' =>
 ['integer', 'This optional parameter specifies the destination port for the syslog server.', 1],

 'LogIdent' =>
 ['string', 'This optional parameter specifies an alternative ident name to be used for logging. Defaults to the executable name used to run radiusd. Special characters are suported.', 1],

 'LogOpt' =>
 ['string', 'This optional comma separated parameter specifies an alternative set of options for openlog(3). Defaults to \'pid\'. Special characters are suported.', 1],

 'LogHost' =>
 ['string', 'When LogSock is set to tcp or udp or inet, this optional parameter specifies the name or address of the syslog host. Defaults to the local host. Special characters are suported.', 0],

 'LogPath'  =>
 ['string', 'When LogSock is set to unix or stream or pipe, this optional parameter specifies the syslog path. Defaults to _PATH_LOG macro (if your system defines it).', 1],

 );

# RCS version number of this module
$Radius::AcctLogSYSLOG::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
    $self->{Facility} = 'user';
    $self->{Priority} = 'info';
    $self->{LogFormat} = '%l:%n:%{Acct-Session-Id}:%{Framed-IP-Address}:%{Calling-Station-Id}';
    $self->{LogIdent} = $0;
    $self->{LogOpt} = 'pid';
}

sub check_config
{
    my ($self) = @_;

    # Validate LogOpt. LogOpt can be empty.
    map
    {
	main::log($main::LOG_ERR, "Invalid LogOpt '$_' in AcctLog SYSLOG $self->{Identifier}")
	    unless ($_ =~ /^(cons|ndelay|nofatal|nowait|perror|pid)$/)
    } split /,/, $self->{LogOpt};

    # LogPort works with Sys::Syslog 0.28 or later
    if ($self->{LogPort})
    {
	my $type = ref($self);
	eval { require version; }; # Should be in Perl 5.10 and later
	if ($@)
	{
	    main::log($main::LOG_WARNING, "$type: LogPort only works with Sys::Syslog 0.28 or later. Your Sys::Syslog version is $Sys::Syslog::VERSION. Could not reliable compare versions, so make sure your Sys::Syslog is recent enough");
	    # Trust the user to now the feature is available
	    $self->{syslog_new_setlogsock} = 1;
	}
	else
	{
	    if (version->parse($Sys::Syslog::VERSION) < version->parse('0.28'))
	    {
		main::log($main::LOG_ERR, "$type: LogPort only works with Sys::Syslog 0.28 or later. Your Sys::Syslog version is $Sys::Syslog::VERSION. LogPort ignored");
	    }
	    else
	    {
		# We know the feature is available
		$self->{syslog_new_setlogsock} = 1;
	    }
	}
    }

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Log an accounting message
# $result is $main::ACCEPT, $main::IGNORE, $main::REJECT, etc.
# $reason is the reason, $p is the request packet
sub acctlog
{
    my ($self, $result, $reason, $p) = @_;

    my $message;
    my $trace_id = $p->{trace_id};
    if (defined $self->{LogFormatHook})
    {
	($message) = $self->runHook('LogFormatHook', $p, $result, $reason, $p, $trace_id);
    }
    else
    {
	$message = Radius::Util::format_special($self->{LogFormat}, $p, undef, $result, $reason, $trace_id);
    }

    # syslog can die:
    $message = substr($message, 0, $self->{MaxMessageLength}) if $self->{MaxMessageLength};
    $message =~ s/%/%%/g; # Make sure to escape any % signs that would be interpreted as printf
    my $ident = &Radius::Util::format_special($self->{LogIdent}, $p);
    my $logopt = &Radius::Util::format_special($self->{LogOpt}, $p);
    my $loghost = (length $self->{LogHost}) ? &Radius::Util::format_special($self->{LogHost}, $p) : undef;
    eval {
	my $res = 1; # Reset by setlogsock, if called

	# We reset these here in case there are multiple SYSLOG
	# callers with different configs.
	# Caution: there is no way to reset logsock back to the
	# default, so if you have multiple SYSLOG clauses, if any one
	# has LogSock defined, they must all have LogSock defined
	if ($self->{syslog_new_setlogsock})
	{
	    my $sock_opts = {};
	    $sock_opts->{port} = $self->{LogPort} if defined $self->{LogPort};
	    $sock_opts->{host} = $self->{LogHost} if $loghost;
	    $sock_opts->{type} = $self->{LogSock} if defined $self->{LogSock};
	    $sock_opts->{path} = $self->{LogPath} if defined $self->{LogPath};
	    $res = setlogsock($sock_opts) if %{$sock_opts};
	    # REVISIT: There is a bug in Sys::Syslog::setlogsock() which undefines $Sys::Syslog::host
	    # when $self->{LogPort} is not defined.
	    $Sys::Syslog::host = $loghost if $loghost;
	}
	else
	{
	    $res = setlogsock($self->{LogSock}) if defined $self->{LogSock};
	    $Sys::Syslog::host = $loghost if $loghost;
	}

	# setlogsock, if called, has set res to true on success and undef on failure
	if ($res)
	{
	    openlog($ident, $logopt, $self->{Facility});
	    syslog("$self->{Priority}", $message);

	    # closelog returns true on success
	    unless (closelog())
	    {
		my $warn_msg = "AcctLogSYSLOG: error in closing log";
		main::log($main::LOG_ERR, $warn_msg);
	    }
	}
	else
	{
	    my $warn_msg = "AcctLogSYSLOG: error in setting socket type and/or options. Check logging parameters";
	    main::log($main::LOG_ERR, $warn_msg);
	}
    };
    &main::log($main::LOG_ERR, "Error while doing AcctLog SYSLOG: $@")
	if $@;
}

1;
