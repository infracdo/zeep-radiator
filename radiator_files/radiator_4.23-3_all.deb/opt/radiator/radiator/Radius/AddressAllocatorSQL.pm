# AddressAllocatorSQL
#
# Implements IP address allocation from an SQL database.
# Called by AuthDYNADDRESS.pm
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2000 Open System Consultants
# $Id$

package Radius::AddressAllocatorSQL;
@ISA = qw(Radius::AddressAllocatorGeneric Radius::SqlDb);
use Radius::AddressAllocatorGeneric;
use Radius::SqlDb;
use Radius::Util;
use Radius::Select;
use strict;

%Radius::AddressAllocatorSQL::ConfigKeywords = 
('DefaultLeasePeriod'     => 
 ['integer', 'If SessionTimeout is set by a previous AuthBy then that is used as the expiry time. Otherwise DefaultLeasePeriod (in seconds) is used.', 1],
 'LeaseReclaimInterval'   => 
 ['integer', 'How often we check the database for expired leases leases can expire if an acounting stop is lost or if the session goes longer than the lease we originally asked for. ', 1],
 'FindQuery'              => 
 ['string', 'SQL query used to find available addresses', 1],
 'FindQueryBindVar'       => 
 ['stringarray', 'Optional list of bind variables to use for FindQuery', 1],
 'AllocateQuery'          => 
 ['string', 'SQL query used to allocate an address', 1],
 'AllocateQueryBindVar'   => 
 ['stringarray', 'Optional list of bind variables to use for AllocateQuery', 1],
 'UpdateQuery'          => 
 ['string', 'SQL query to run when Accounting-Request with Acct-Status-Type of Start or Alive is received', 1],
 'UpdateQueryBindVar'   => 
 ['stringarray', 'Optional list of bind variables to use for UpdateQuery', 1],
 'DeallocateQuery'        => 
 ['string', 'SQL query used to deallocate a previously allocated address', 1],
 'DeallocateQueryBindVar' => 
 ['stringarray', 'Optional list of bind variables to use for DeallocateQuery', 1],

 'DeallocateByNASQuery' =>
 ['string', 'SQL query used to deallocate all previously allocated addresses for a NAS', 1],

 'DeallocateByNASQueryBindVar' =>
 ['stringarray', 'Optional list of bind variables to use for DeallocateByNASQuery', 1],

 'CheckPoolQuery'         => 
 ['string', 'SQL query used to check the status of an address', 1],
 'CheckPoolQueryBindVar'  => ['stringarray', 'Optional list of bind variables to use for CheckPoolQuery', 1],
 'AddAddressQuery'        => 
 ['string', 'SQL query used to add a new address to a pool', 1],
 'AddAddressQueryBindVar' => 
 ['stringarray', 'Optional list of bind variables to use for AddAddressQuery', 1],
 'ReclaimQuery'           => 
 ['string', 'SQL query used to reclaim expired leases', 1],
 'ReclaimQueryBindVar'    => 
 ['stringarray', 'Optional list of bind variables to use for ReclaimQuery', 1],
 'AddressPool'            => 
 ['objectlist', 'List of AddressPool objects that define the available address pools', 1],
 'NoAddressHook'          => 
 ['hook', 'Perl function that will be called when address allocator could not find any free address.', 2],
 'DelayedPoolCheckTime'   => 
 ['integer', 'Time in seconds Radiator will delay checking address pools when AddressAllocatorSQL is activated.', 1],

 'NasId' =>
 ['string', 'Name of attribute in request or other value used by default for NAS_ID column. Available as SQL quoted special value for the queries. Defaults to %{NAS-Identifier}', 1],

 );

# RCS version number of this module
$Radius::AddressAllocatorSQL::VERSION = '$Revision$';

# This is a hash of pending asynchronous allocations
%Radius::AddressAllocatorSQL::pendingRequests = ();


#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::check_config();
    $self->Radius::SqlDb::check_config();
    return;
}

#####################################################################
# (Re)activate a Dynamic address allocator
sub activate
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::activate;
    $self->Radius::SqlDb::activate;

    # Delay pool creation when a delay is configured
    if ($self->{DelayedPoolCheckTime})
    {
	# Arrange to be called again in LeaseReclaimInterval seconds
	Radius::Select::add_timeout(time() + $self->{DelayedPoolCheckTime},
				    sub { $_[1]->activate_pools(); }, $self);
    }
    else
    {
	$self->activate_pools();
    }

    return $self;
}

#####################################################################
# Do per-instance default initialization
# This is called by Configurabel during Configurable::new before
# the config file is parsed. Its a good place initalze 
# instance variables
# that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->Radius::AddressAllocatorGeneric::initialize;
    $self->Radius::SqlDb::initialize;

    $self->{FindQuery} = "select TIME_STAMP, YIADDR, SUBNETMASK, DNSSERVER from RADPOOL 
where POOL='%0' and STATE=0 order by TIME_STAMP";
    $self->{AllocateQuery} = "update RADPOOL set STATE=1, 
TIME_STAMP=%0, 
EXPIRY=%1, USERNAME=%2 where YIADDR='%3' and STATE=0 and TIME_STAMP %4";

    $self->{CheckPoolQuery} = "select STATE from RADPOOL where YIADDR='%0'";

    $self->{AddAddressQuery} = "insert into RADPOOL (STATE, TIME_STAMP,
POOL, YIADDR, SUBNETMASK, DNSSERVER) values (0, %t, '%0', '%1',
'%2', '%3')";
    $self->{DeallocateQuery} = "update RADPOOL set STATE=0, 
TIME_STAMP=%t where YIADDR='%0'";

    # Might enable this later
    #$self->{DeallocateByNASQuery} = "update RADPOOL set STATE=0, TIME_STAMP=%t where NAS_ID=%0";

    $self->{ReclaimQuery} = "update RADPOOL set STATE=0 
where STATE!=0 and EXPIRY < %0";

    $self->{DefaultLeasePeriod}   = 86400; # 1 day
    $self->{LeaseReclaimInterval} = 86400; # 1 day

    $self->{NasId} = '%{NAS-Identifier}';
}

#####################################################################
# Override the object function in Configurable
sub object
{
    my ($self, $file, $keyword, @args) = @_;

    if ($keyword eq 'AddressPool')
    {
	my $pool = Radius::AddressPool->new($file, @args);
	$pool->check_config();
	$pool->activate() unless $pool->isCheckingConfiguration();
	return push(@{$self->{AddressPool}}, $pool);
    }
    return $self->SUPER::object($file, $keyword, @args);
}

#####################################################################
# Do any pool maintenance required during, or alternatively after,
# module activation
sub activate_pools
{
    my ($self) = @_;

    # Make sure all the addresses in all the pools are present in the
    # database.
    foreach (@{$self->{AddressPool}})
    {
	$self->createPool($_);
    }

    $self->reclaimExpired();
}

#####################################################################
# Allocate an address for username with the given pool hint
# return a hash of interesting values for AuthBy DYNADDRESS
# to do stuff with
sub allocate
{
    my ($self, $caller, $username, $hint, $p) = @_;

    my $nas_id = Radius::Util::format_special($self->{NasId}, $p, $self);

    my $now = time;
    # Use the Session-Timeout if its available, else
    # the DefaultLeasePeriod
    my $lease_period = $p->{rp}->getAttrByNum($Radius::Radius::SESSION_TIMEOUT);
    $lease_period = $self->{DefaultLeasePeriod}
        unless defined $lease_period;
    my $expiry = $now + $lease_period;

    my $iterations = 20; # Permit up to 20 collissions
    my ($result, $reason);

    ($result, $reason) = $self->try_to_allocate($caller, $username, $hint, $p, $iterations, $expiry, $nas_id);
    return ($result, $reason);
}

# Do the synchronous or asynchronous allocation.
sub try_to_allocate
{
    my ($self, $caller, $username, $hint, $p, $iterations, $expiry, $nas_id) = @_;
    my %details;

    my $now = time;
    # Find the oldest free address in this pool
    my $q = &Radius::Util::format_special
	($self->{FindQuery}, $p, $self, $hint, $self->quote($username), $expiry, $self->quote($nas_id));

    while ($iterations-- > 0)
    {
	if ($self->{AsynchronousSQL})
	{
	    my $key = $p->{RecvFromAddress}.$p->{RecvFromPort}.$p->code().$p->identifier();
	    my $sth = $self->prepareAndExecuteAsync
		($q, \&handle_reply_find, $key, map { &Radius::Util::format_special($_, $p, $self, $hint, $username, $expiry, $nas_id)}
		 @{$self->{FindQueryBindVar}});
	    unless ($sth)
	    {
		return ($main::IGNORE, 'Address pool database not available');
	    }

	    my $ref;
	    $ref->{self} = $self;
	    $ref->{p} = $p;
	    $ref->{caller} = $caller;
	    $ref->{username} = $username;
	    $ref->{hint} = $hint;
	    $ref->{iterations} = $iterations;
	    $ref->{expiry} = $expiry;
	    $ref->{nas_id} = $nas_id;
	    $ref->{sth} = $sth;
	    $ref->{dbname} = $self->{dbname};
	    $ref->{dbsource} = $self->{dbsource};
	    $ref->{timeouthandle} =
		Radius::Select::add_timeout(time + $self->{Timeout},
					    \&handle_timeout,
					    $self, $key);

	    $Radius::AddressAllocatorSQL::pendingRequests{$key} = $ref;
	    return ($main::ASYNC, 'Waiting for FindQuery to complete');
	}
	else
	{
	    my $sth = $self->prepareAndExecute
		($q, map { &Radius::Util::format_special($_, $p, $self, $hint, $username, $expiry, $nas_id)}
		 @{$self->{FindQueryBindVar}});

	    return ($main::IGNORE, 'Address pool database not available')
		unless $sth;
	    my $last_time_stamp;
	    if (($last_time_stamp, $details{yiaddr}, $details{subnetmask}, $details{dnsserver})
		= $self->getOneRow($sth))
	    {
		# Got a new address, update the state and timestamp
		# and expiry time

		my $timestamp_compare = $last_time_stamp eq '' ?
		    'is NULL' : "=$last_time_stamp";

		if ($self->{AllocateQuery} ne '')
		{
		    my $allocquery = &Radius::Util::format_special
			($self->{AllocateQuery},
			 $p, $self,
			 $now, $expiry, $self->quote($username), $details{yiaddr},
			 $timestamp_compare, $self->quote($nas_id));

		    # If this fails, then its prob because someone else
		    # got the same address before us. Try again
		    next unless $self->do($allocquery,
					  map { &Radius::Util::format_special
						    ($_, $p, $self, $now, $expiry, $username, $details{yiaddr},
						     $last_time_stamp, $nas_id)}
					  @{$self->{AllocateQueryBindVar}}) == 1;
		}
		# Call the callers allocateDone() function to process
		# the results
		$caller->allocateDone($p, \%details);
		# And tell the caller to accept immediately
		return ($main::ACCEPT, 'allocate succeeded');
	    }
	    else
	    {
		# Hmmm, no spare addresses
		my ($result, $reason) = ($main::REJECT, "No available addresses");
		$self->runHook('NoAddressHook', $p, \$p, \$p->{rp}, \$result, \$reason, $hint);
		return ($result, $reason);
	    }
	}
    }

    # Hmmmm, should not happen: too many other people trying
    # to get addresses at the same time
    my ($result, $reason) = ($main::REJECT, "Too many simultaneous address requests");
    $self->runHook('NoAddressHook', $p, \$p, \$p->{rp}, \$result, \$reason, $hint);

    # If SQL operation is asynchronous, we should call handlerResult since
    # allocate() has already returned $main::ASYNC to its caller.
    $p->{Handler}->handlerResult($p, $result, $reason) if $self->{AsynchronousSQL};

    return ($result, $reason);
}

#####################################################################
# Confirm a previously allocated address is in use
sub confirm
{    
    my ($self, $caller, $address, $p) = @_;

    my $nas_id = Radius::Util::format_special($self->{NasId}, $p, $self);

    if ($self->{UpdateQuery})
    {
	my $expiry = time() + $self->{DefaultLeasePeriod};

	my $q = Radius::Util::format_special
	    ($self->{UpdateQuery}, $p, $self, $expiry, $address, $self->quote($nas_id));

	if ($self->{AsynchronousSQL})
	{
	    my $key = $p->{RecvFromAddress}.$p->{RecvFromPort}.$p->code().$p->identifier();
	    my $rc = $self->doAsync($q, \&handle_reply_confirm, $key,
				    map { Radius::Util::format_special($_, $p, $self, $expiry, $address, $nas_id)}
				    @{$self->{UpdateQueryBindVar}});
	    unless (defined $rc)
	    {
		return ($main::IGNORE, 'No address pool database connections available');
	    }

	    my $ref;
	    $ref->{self} = $self;
	    $ref->{p} = $p;
	    $ref->{caller} = $caller;
	    $ref->{dbname} = $self->{dbname};
	    $ref->{dbsource} = $self->{dbsource};
	    $ref->{timeouthandle} =
		Radius::Select::add_timeout(time + $self->{Timeout},
					    \&handle_timeout,
					    $self, $key);

	    $Radius::AddressAllocatorSQL::pendingRequests{$key} = $ref;
	    return ($main::ASYNC, 'Waiting for UpdateQuery to complete');
	}
	else
	{
	    my $rc = $self->do($q,
			       map { Radius::Util::format_special($_, $p, $self, $expiry, $address, $nas_id)}
			       @{$self->{UpdateQueryBindVar}});
	    unless (defined $rc)
	    {
		my $user = $p->get_attr('User-Name');
		my $nas_ip = $p->get_attr('NAS-IP-Address');
		return ($main::REJECT, "AddressAllocatorSQL: UpdateQuery failed for user $user, NAS: $nas_id ($nas_ip)");
	    }
	}
    }

    return ($main::ACCEPT, 'confirm succeeded');
}

#####################################################################
# Free a previously allocated address
sub deallocate
{    
    my ($self, $caller, $address, $p) = @_;

    my $nas_id = Radius::Util::format_special($self->{NasId}, $p, $self);

    if ($self->{DeallocateQuery})
    {

	my $q = &Radius::Util::format_special
	    ($self->{DeallocateQuery}, $p, $self, $address, $self->quote($nas_id));

	if ($self->{AsynchronousSQL})
	{
	    my $key = $p->{RecvFromAddress}.$p->{RecvFromPort}.$p->code().$p->identifier();
	    my $rc = $self->doAsync($q, \&handle_reply_deallocate, $key,
				    map { &Radius::Util::format_special($_, $p, $self, $address, $nas_id)}
				    @{$self->{DeallocateQueryBindVar}});
	    unless (defined $rc)
	    {
		return ($main::IGNORE, 'No address pool database connections available');
	    }

	    my $ref;
	    $ref->{self} = $self;
	    $ref->{p} = $p;
	    $ref->{caller} = $caller;
	    $ref->{dbname} = $self->{dbname};
	    $ref->{dbsource} = $self->{dbsource};
	    $ref->{timeouthandle} =
		Radius::Select::add_timeout(time + $self->{Timeout},
					     \&handle_timeout,
					     $self, $key);

	    $Radius::AddressAllocatorSQL::pendingRequests{$key} = $ref;
	    return ($main::ASYNC, 'Waiting for DeallocateQuery to complete');
	}
	else
	{
	    my $rc = $self->do($q,
			       map { &Radius::Util::format_special($_, $p, $self, $address, $nas_id)}
			       @{$self->{DeallocateQueryBindVar}});
	    unless (defined $rc)
	    {
		my $user = $p->get_attr('User-Name');
		my $nas_ip = $p->get_attr('NAS-IP-Address');
		return ($main::REJECT, "AddressAllocatorSQL: DeallocateQuery failed for user $user, NAS: $nas_id ($nas_ip)");
	    }
	}
    }

    return ($main::ACCEPT, 'deallocate succeeded');
}

#####################################################################
# Free all previously allocated address for the NAS
sub deallocate_by_nas
{
    my ($self, $caller, $p) = @_;

    my $nas_id = Radius::Util::format_special($self->{NasId}, $p, $self);

    if ($self->{DeallocateByNASQuery})
    {
	my $q = &Radius::Util::format_special
	    ($self->{DeallocateByNASQuery}, $p, $self, $self->quote($nas_id));
	my $rc = $self->do($q,
			   map { &Radius::Util::format_special($_, $p, $self, $nas_id)}
			   @{$self->{DeallocateByNASQueryBindVar}});
	unless (defined $rc)
	{
	    my $user = $p->get_attr('User-Name');
	    my $nas_ip = $p->get_attr('NAS-IP-Address');
	    return ($main::REJECT, "AddressAllocatorSQL: DeallocateByNASQuery failed for user $user, NAS: $nas_id ($nas_ip)");
	}
    }
    return ($main::ACCEPT, 'deallocated_by_nas succeeded');
}

#####################################################################
# Glue between the timeout callback and the reclaimExpired function
sub reclaimExpiredTimeout
{
    my ($handle, $self) = @_;

    $self->reclaimExpired();
}

#####################################################################
# Arrange for reclamation of expired leases every
# LeaseReclaimInterval seconds
sub reclaimExpired
{
    my ($self) = @_;

    my $now = time;
    if ($self->{ReclaimQuery})
    {
	&main::log($main::LOG_DEBUG, "Reclaiming expired leases");
	my $q = &Radius::Util::format_special
	    ($self->{ReclaimQuery}, undef, $self, $now);
	$self->do($q,
		  map { &Radius::Util::format_special($_, undef, $self, $now)} 
		  @{$self->{ReclaimQueryBindVar}});
    }
    # Arrange to be called again in LeaseReclaimInterval seconds
    &Radius::Select::add_timeout($now + $self->{LeaseReclaimInterval},
				 \&reclaimExpiredTimeout, $self);
}   

#####################################################################
# Ensure all the addresses in an address pool are present
# in the database
sub createPool
{
    my ($self, $pool) = @_;

    # For each range, and for each address in the range
    # make sure it exists in the database
    my ($i4, $address, $state);
    foreach my $range (@{$pool->{Range}})
    {
	if ($range =~ /(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\s+(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/)
	{
	    # 2 addresses a.b.c.d e.f.g.h
	    my ($l1, $l2, $l3, $l4) = ($1, $2, $3, $4);
	    my ($u1, $u2, $u3, $u4) = ($5, $6, $7, $8);
	    
	    # Some error checking. We only permit the 
	    # last octet to vary
	    if (   $l1 != $u1 || $l1 > 255
		|| $l2 != $u2 || $l2 > 255
		|| $l3 != $u3 || $l3 > 255
		|| ($l4 + $pool->{Step} - 1) > $u4)
	    {
		&main::log($main::LOG_ERR, "Invalid Range $range. Ignored");
		next;
	    }
	    
	    my $lower = ($l1 << 24) + ($l2 << 16) + ($l3 << 8) + $l4;
	    my $upper = ($u1 << 24) + ($u2 << 16) + ($u3 << 8) + $u4;
	    main::log($main::LOG_DEBUG, "Checking address range $range");
	    $self->checkAddressRange($pool, $lower, $upper);
	}
	elsif ($range =~ /(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\/(\d{1,2})/)
	{
	    # CIDR block a.b.c.d/x  
	    
	    my ($l1, $l2, $l3, $l4, $bs) = ($1, $2, $3, $4, $5);
	    # Some error checking. We only permit the 
	    # last octet to vary
	    if ($l1 > 255 || $l2 > 255 || $l3 > 255 || $l4 > 255
		|| $bs > 32)
	    {
		&main::log($main::LOG_ERR, "Invalid CIDR block $range. Ignored");
		next;
	    }
	    my $lower = ($l1 << 24) + ($l2 << 16) + ($l3 << 8) + $l4;
	    my $mask = (1 << (32 - $bs)) - 1;
	    $lower &= ~$mask;
	    my $upper = $lower | $mask;
	    main::log($main::LOG_DEBUG, "Checking address range $range");
	    $self->checkAddressRange($pool, $lower, $upper);
	}
	elsif ($range =~ /(([a-z0-9]{1,4}:){1,7}:)\/(\d{2,3})/)
	{
	    # IPv6 prefix
	    my ($base_address, $prefix_length) = ($1, $3);

	    my $subnetmask = $pool->{Subnetmask};
	    $subnetmask =~ s/\///g;
	    $subnetmask = int($subnetmask);
	    $pool->{Subnetmask} = $subnetmask;

	    if (($prefix_length < 16 || $prefix_length > 128) || ($prefix_length > $pool->{Subnetmask}))
	    {
		main::log($main::LOG_ERR, "Invalid IPv6 prefix $range in pool '$pool->{Name}'. Ignored");
		next;
	    }

	    my @nibbles = split(':', $base_address);
	    my $client_addr;
	    foreach my $n (@nibbles)
	    {
		my $l = length($n);
		$n = "0" x (4 - $l) . $n;
		$client_addr .= $n;
	    }
	    $client_addr = "0x" . $client_addr . "0" x (32 - length($client_addr));
	    require Math::BigInt;
	    my $base = Math::BigInt->new($client_addr);
	    my $mask = Math::BigInt->new('0b' . '1' x 128);
	    $mask->brsft($pool->{Subnetmask});

	    my $prefixes = (2 ** ($pool->{Subnetmask} - $prefix_length)) / $pool->{Step};
	    if ($prefixes < 1)
	    {
		main::log($main::LOG_ERR, "Less than one /$pool->{Subnetmask} IPv6 prefixes from $range (every $pool->{Step}) in pool '$pool->{Name}'. Ignored");
		next;
	    }
	    elsif ($prefixes > 1048576)
	    {
		main::log($main::LOG_ERR, "Too many ($prefixes) /$pool->{Subnetmask} IPv6 prefixes from $range in pool '$pool->{Name}'. Ignored");
		next;
	    }

	    main::log($main::LOG_DEBUG, "$prefixes /$pool->{Subnetmask} IPv6 prefixes from $range in pool '$pool->{Name}'");
	    for (my $i = 0; $i < $prefixes; $i++)
	    {
		my $prefix = $base->as_hex();
		$prefix =~ s/^0x//;
		@nibbles = ($prefix =~ m/..../g);
		$prefix = join(':', @nibbles);
		# abbrev zeros
		$prefix =~ s/(:0000)+$/::/;
		$prefix =~ s/:0{1,3}/:/g;
		main::log($main::LOG_DEBUG, "Checking prefix $prefix/$pool->{Subnetmask} [" . ($i + 1) . "]");
		$self->checkAddressPrefix($pool, "$prefix");
		for (my $j = 0; $j < $pool->{Step}; $j++)
		{
		    $base->badd($mask + 1);
		}
	    }
	}
	else
	{
	    &main::log($main::LOG_WARNING, 
		       "Range $range, unknown Range format. Ignored");
	}
    }
}

#####################################################################
# Ensure that a single address exists, else create it
# Return 0 if it was created, else 0
# Address is in the form of an integer
sub checkAddress
{
    my ($self, $pool, $address) = @_;

    if ($self->{CheckPoolQuery} ne '')
    {
	# Convert integer address to a dotted quad
	my $dquad = sprintf("%d.%d.%d.%d", 
			    $address >> 24 & 0xff,
			    $address >> 16 & 0xff,
			    $address >> 8  & 0xff,
			    $address       & 0xff);
	
	# Check whether it already exists
	&main::log($main::LOG_DEBUG, "Checking address $dquad");
	my $q = &Radius::Util::format_special
	    ($self->{CheckPoolQuery}, undef, $self, $dquad);
	my $sth = $self->prepareAndExecute($q, map { &Radius::Util::format_special($_, undef, $self, $dquad)} 
					   @{$self->{CheckPoolQueryBindVar}});
	last unless $sth;
	if (!$self->getOneRow($sth))
	{
	    if ($self->{AddAddressQuery} ne '')
	    {
		# Not there, add it
		$q = &Radius::Util::format_special
		    ($self->{AddAddressQuery},
		     undef, $self,
		     $pool->{Name}, $dquad, $pool->{Subnetmask},
		     $pool->{DNSServer}, $pool->{PoolGroup}, $pool->{Priority}, $pool->{NasIdentifier});
		return $self->do($q,
				 map { &Radius::Util::format_special
					   ($_, undef, $self, $pool->{Name}, $dquad, $pool->{Subnetmask},
					    $pool->{DNSServer}, $pool->{PoolGroup}, $pool->{Priority}, $pool->{NasIdentifier})}
				 @{$self->{AddAddressQueryBindVar}});
	    }
	    else
	    {
		&main::log($main::LOG_WARNING, "Address $dquad not present in pool '$pool->{Name}'. Unable to add because AddAddressQuery is not defined");
		
	    }
	}
    }
    return;
}
    
#####################################################################
# Check that all the addresses in the range $lower to $upper
# inclusive exist in the pool, else create them
sub checkAddressRange
{
    my ($self, $pool, $lower, $upper) = @_;

    my $i;
    for ($i = $lower; $i <= $upper; $i += $pool->{Step})
    {
	$self->checkAddress($pool, $i);
    }
}

#####################################################################
# Check that the prefix exist in the pool, else create it
sub checkAddressPrefix
{
    my ($self, $pool, $prefix) = @_;

    if ($self->{CheckPoolQuery} ne '')
    {
	main::log($main::LOG_DEBUG, "Checking prefix $prefix");
	my $q = Radius::Util::format_special
	    ($self->{CheckPoolQuery}, undef, $self, $prefix);
	my $sth = $self->prepareAndExecute($q, map { Radius::Util::format_special($_, undef, $self, $prefix)}
					   @{$self->{CheckPoolQueryBindVar}});
	last unless $sth;
	if (!$self->getOneRow($sth))
	{
	    if ($self->{AddAddressQuery} ne '')
	    {
		$q = Radius::Util::format_special
		    ($self->{AddAddressQuery},
		     undef, $self,
		     $pool->{Name}, $prefix, $pool->{Subnetmask},
		     $pool->{DNSServer}, $pool->{PoolGroup}, $pool->{Priority}, $pool->{NasIdentifier});
		return $self->do($q,
				 map { Radius::Util::format_special
					   ($_, undef, $self, $pool->{Name}, $prefix, $pool->{Subnetmask},
					    $pool->{DNSServer}, $pool->{PoolGroup}, $pool->{Priority}, $pool->{NasIdentifier})}
				 @{$self->{AddAddressQueryBindVar}});
	    }
	    else
	    {
		main::log($main::LOG_WARNING, "Prefix $prefix not present in pool '$pool->{Name}'. Unable to add because AddAddressQuery is not defined");
	    }
	}
    }
    return;
}

sub handle_reply_find
{
    my ($key) = @_;

    # Do *not* cross it off from pending list yet
    my $ref = $Radius::AddressAllocatorSQL::pendingRequests{$key};

    # Couldn't find a reference
    if (!defined $ref)
    {
	main::log($main::LOG_WARNING, "Unknown reply to find received in AddressAllocatorSQL");
	return;
    }

    # Cross it off our timeout list
    Radius::Select::remove_timeout($ref->{timeouthandle})
	|| main::log($main::LOG_ERR, "Timeout $ref->{timeouthandle} was not in the timeout list");

    my $self = $ref->{self};
    my $p = $ref->{p};
    my $caller = $ref->{caller};
    my $username = $ref->{username};
    my $hint = $ref->{hint};
    my $sth = $ref->{sth};
    my $expiry = $ref->{expiry};
    my $nas_id = $ref->{nas_id};

    my $now = time;
    my %details;
    my $last_time_stamp;

    if (($last_time_stamp, $details{yiaddr}, $details{subnetmask}, $details{dnsserver})
	= $self->getOneRow($sth))
    {
	# Got a new address, update the state and timestamp
	# and expiry time

	my $timestamp_compare = $last_time_stamp eq '' ?
	    'is NULL' : "=$last_time_stamp";

	if ($self->{AllocateQuery} ne '')
	{
	    my $allocquery = Radius::Util::format_special
		($self->{AllocateQuery},
		 $p, $self,
		 $now, $expiry, $self->quote($username), $details{yiaddr},
		 $timestamp_compare, $self->quote($nas_id));

	    $ref->{timeouthandle} =
		Radius::Select::add_timeout(time + $self->{Timeout},
					    \&handle_timeout,
					    $self, $key);

	    $ref->{details} = \%details;

	    # If this fails, then its prob because someone else
	    # got the same address before us. Try again
	    my $rc = $self->doAsync($allocquery, \&handle_reply_allocate, $key,
				    map { Radius::Util::format_special
					      ($_, $p, $self, $now, $expiry, $username, $details{yiaddr},
					       $last_time_stamp, $nas_id)}
				    @{$self->{AllocateQueryBindVar}});

	    unless (defined $rc)
	    {
		Radius::Select::remove_timeout($ref->{timeouthandle});
		delete $Radius::AddressAllocatorSQL::pendingRequests{$key};
		$p->{Handler}->handlerResult($p, $main::IGNORE, 'No address pool database connections available');
	    }

	    $ref->{dbname} = $self->{dbname};
	    $ref->{dbsource} = $self->{dbsource};

	    # Note: pending request was updated and remains on the list
	    return;
	}
	# Call the callers allocateDone() function to process
	# the results

	# Cross it off our pending list
	delete $Radius::AddressAllocatorSQL::pendingRequests{$key};

	$caller->allocateDone($p, \%details, $main::ACCEPT);
	return;
    }
    else
    {
	# Cross it off our pending list
	delete $Radius::AddressAllocatorSQL::pendingRequests{$key};

	# Hmmm, no spare addresses
	my ($result, $reason) = ($main::REJECT, "No available addresses");
	$self->runHook('NoAddressHook', $p, \$p, \$p->{rp}, \$result, \$reason, $hint);
	$p->{Handler}->handlerResult($p, $result, $reason);
    }

    return;
}

sub handle_reply_allocate
{
    my ($key) = @_;

    # Cross it off our pending list
    my $ref = delete $Radius::AddressAllocatorSQL::pendingRequests{$key};

    # Couldn't find a reference
    if (!defined $ref)
    {
	main::log($main::LOG_WARNING, "Unknown reply to allocate received in AddressAllocatorSQL");
	return;
    }

    # Cross it off our timeout list
    Radius::Select::remove_timeout($ref->{timeouthandle})
	|| main::log($main::LOG_ERR, "Timeout $ref->{timeouthandle} was not in the timeout list");

    my $self = $ref->{self};
    my $p = $ref->{p};
    my $caller = $ref->{caller};
    my $username = $ref->{username};
    my $hint = $ref->{hint};
    my $iterations = $ref->{iterations};
    my $expiry = $ref->{expiry};
    my $sth = $ref->{sth};
    my $details = $ref->{details};
    my $nas_id = $ref->{nas_id};

    my $res = $self->getAsyncResult();
    if ($res && $res > 0)
    {
	# success
	$caller->allocateDone($p, $details, $main::ACCEPT);
    }
    else
    {
	# fail, try again
	$self->log($main::LOG_INFO, "Address $details->{yiaddr} was already taken in the meanwhile..");
	$self->try_to_allocate($caller, $username, $hint, $p, $iterations, $expiry, $nas_id);
    }

    return;
}

sub handle_reply_confirm
{
    my ($key) = @_;

    # Cross it off our pending list
    my $ref = delete $Radius::AddressAllocatorSQL::pendingRequests{$key};

    # Couldn't find a reference
    if (!defined $ref)
    {
	main::log($main::LOG_WARNING, "Unknown reply to confirm received in AddressAllocatorSQL");
	return;
    }

    # Cross it off our timeout list
    Radius::Select::remove_timeout($ref->{timeouthandle})
	|| main::log($main::LOG_ERR, "Timeout $ref->{timeouthandle} was not in the timeout list");

    my $self = $ref->{self};
    my $p = $ref->{p};
    my $caller = $ref->{caller};

    my $res = $self->getAsyncResult();
    if ($res && $res > 0)
    {
	# success
	$caller->confirmDone($p, $main::ACCEPT);
    }
    else
    {
	# fail
	my $user = $p->get_attr('User-Name');
	my $nas_ip = $p->get_attr('NAS-IP-Address');
	my $nas_id = $p->get_attr('NAS-Identifier');
	$self->log($main::LOG_WARNING, "AddressAllocatorSQL: UpdateQuery failed for user $user, NAS: $nas_id ($nas_ip)");
	$p->{Handler}->handlerResult($p, $main::REJECT, "UpdateQuery failed for user $user, NAS: $nas_id ($nas_ip)");
    }

    return;
}

sub handle_reply_deallocate
{
    my ($key) = @_;

    # Cross it off our pending list
    my $ref = delete $Radius::AddressAllocatorSQL::pendingRequests{$key};

    # Couldn't find a reference
    if (!defined $ref)
    {
	main::log($main::LOG_WARNING, "Unknown reply to deallocate received in AddressAllocatorSQL");
	return 1;
    }

    # Cross it off our timeout list
    Radius::Select::remove_timeout($ref->{timeouthandle})
	|| main::log($main::LOG_ERR, "Timeout $ref->{timeouthandle} was not in the timeout list");

    my $self = $ref->{self};
    my $p = $ref->{p};
    my $caller = $ref->{caller};

    my $res = $self->getAsyncResult();
    if ($res && $res > 0)
    {
	# success
	$caller->deallocateDone($p, $main::ACCEPT);
    }
    else
    {
	# fail
	my $user = $p->get_attr('User-Name');
	my $nas_ip = $p->get_attr('NAS-IP-Address');
	my $nas_id = $p->get_attr('NAS-Identifier');
	$self->log($main::LOG_WARNING, "AddressAllocatorSQL: DeallocateQuery failed for user $user, NAS: $nas_id ($nas_ip)");
	$p->{Handler}->handlerResult($p, $main::REJECT, "DeallocateQuery failed for user $user, NAS: $nas_id ($nas_ip)");
    }

    return;
}

sub handle_timeout
{
    my ($handle, $self, $key) = @_;

    # Cross it off our pending list
    my $ref = delete $Radius::AddressAllocatorSQL::pendingRequests{$key};

    my $p = $ref->{p};
    my $dbsource = $ref->{dbsource};

    $self->log($main::LOG_INFO, "AddressAllocatorSQL: No reply from SQL server '$dbsource'", $p);

    # No reply after all the retries, so reject the request
    $p->{Handler}->handlerResult($p, $main::REJECT, 'No reply from SQL server');

    $self->{sqldb_async_query} = 1;
    $self->{dbname} = $ref->{dbname};
    $self->{dbsource} = $dbsource;
    $self->disconnect();
    $self->{sqldb_async_query} = 0;

    return;
}

#####################################################################
#####################################################################
#####################################################################
# This is where we define the companion class AddressPool
# which allows us to tell the database what our pools are
# each AddressPool will be checked out at startup time, to ensure
# it is in the database
package Radius::AddressPool;
@Radius::AddressPool::ISA = qw(Radius::Configurable);

%Radius::AddressPool::ConfigKeywords = 
('Range'      => 
 ['stringarray', 'List of address ranges. Each address range is either a starting and ending address (such as 192.1.1.1 192.1.1.50), or a CIDR address specification (such as 192.1.2.0/31) or IPv6 address prefix (such as 2001:db8:100::/48)', 0],
 'Subnetmask' => 
 ['string', 'The subnet mask in dot-decimal format for IPv4 or /masklen format for IPv6 to use for each address or address prefix', 1],
 'DNSServer'  => 
 ['string', 'The DNS server to send', 1],
 'Step'       => 
 ['integer', 'The step size to use when creating new addresses', 1],
 'PoolGroup'  => 
 ['string', 'A name which can be used to group multiple pools with different priorities', 1],
 'Priority'   => 
 ['integer', 'A priority of pool inside a pool group', 1],
 'NasIdentifier'   => 
 ['string', 'NAS Identifier such as NAS-IP-Address or NAS-IPv6-Address', 1],
 );

#####################################################################
# Do per-instance configuration check
sub check_config
{
    my ($self) = @_;

    main::log($main::LOG_ERR, "No Ranges defined for AddressPool $self->{Name} in '$main::config_file'")
	unless defined $self->{Range};
    $self->SUPER::check_config();

    return;
}

#####################################################################
# (Re)activate a new AddressPool
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();
}

#####################################################################
# Do per-instance default initialization
# This is called by Configurabel during Configurable::new before
# the config file is parsed. Its a good place initalze 
# instance variables
# that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Subnetmask} = '255.255.255.255';
    $self->{Step} = 1; # Range address step size
}

1;
