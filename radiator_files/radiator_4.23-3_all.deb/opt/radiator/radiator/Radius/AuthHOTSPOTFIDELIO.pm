# AuthHOTSPOTFIDELIO.pm
#
# Object for handling hotspot Authentication and prepaid billing by
# Micros Fidelio Opera Hotel Property Management System (PMS)
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2011 Open System Consultants
# $Id$

package Radius::AuthHOTSPOTFIDELIO;
use strict;
our @ISA = qw(Radius::AuthHOTSPOT Radius::AuthFIDELIO Radius::SqlDb);
use Radius::AuthHOTSPOT;
use Radius::AuthFIDELIO;
use Radius::SqlDb;

%Radius::AuthHOTSPOTFIDELIO::ConfigKeywords =
(
 'BlockDuration' =>
 ['integer', 'Specifies a number of seconds a prepaid block of time will last for, from the time it is first purchased. Defaults to 86400 (1 day).', 1],

 'BlockPrice' =>
 ['integer', 'Specifies a number without decimal indicator a prepaid block of time costs. Defaults to 900 (for example, USD 9.00).', 1],

 'PostSendQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the insert query used to insert Posting record data.', 1],

 'PostSendQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with PostSendQuery.', 1],

 'PostAnswerQuery' =>
 ['string', 'This optional parameter allows you to customise the exact form of the insert query used to insert Posting Answer (PA) data.', 1],

 'PostAnswerQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with PostAnswerQuery.', 1],

);

# RCS version number of this module
$Radius::AuthHOTSPOTFIDELIO::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->Radius::AuthHOTSPOT::initialize();
    $self->Radius::AuthFIDELIO::initialize();
    $self->Radius::SqlDb::initialize();

    $self->{BlockDuration} = 86400; # One day
    $self->{BlockPrice} = 900; # Cents
    $self->{ConfirmUpgradeOrRenew} = 0;

    $self->{PostSendQuery} = "INSERT INTO posts (roomNumber, guestNumber, macAddress, postNumber, posted, cost) VALUES (%0, %1, %2, %3, %4, %5)";
    $self->{PostAnswerQuery} = "INSERT INTO postacks (roomNumber, postNumber, transactionNumber, received) VALUES (%0, %1, %2, %3)";

    # Default service to use
    $self->{DefaultService} = '';
    $self->{DefaultServiceDefinition} = "";

    return;
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->Radius::AuthHOTSPOT::check_config();
    $self->Radius::AuthFIDELIO::check_config();
    $self->Radius::SqlDb::check_config();

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->Radius::AuthHOTSPOT::activate();
    $self->Radius::AuthFIDELIO::activate();
    $self->Radius::SqlDb::activate();

    # Default service to use
    $self->{DefaultService} = 'default' unless $self->{DefaultService};
    unless ($self->{DefaultServiceDefinition})
    {
	$self->{DefaultServiceDefinition} = "name:$self->{DefaultService} price:$self->{BlockPrice} prepaidTime:$self->{BlockDuration} allowQuotaToExceed:0";
    }

    return;
}

#####################################################################
sub findUser
{
    my ($self, $look_for, $p, $rp, $orig_user_name, $defaultNumber) = @_;

    my ($user, $error) = $self->Radius::AuthFIDELIO::findUser($look_for, $p, $rp, $orig_user_name, $defaultNumber);

    if ($p)
    {
	$p->{internal_vars}->{hotspot_username} = $look_for;
	unless (defined $p->{internal_vars}->{hotspot_id})
	{
	    $p->{internal_vars}->{hotspot_id} = $user->{fidelio_gn};
	}
    }

    return $self->Radius::AuthHOTSPOT::findUser($look_for, $p, $rp, $orig_user_name, $defaultNumber, $user, $error);
}

#####################################################################
# Overrides handle_message in AuthFIDELIO
sub handle_message
{
    my ($self, $type, $record) = @_;

    $self->Radius::AuthFIDELIO::handle_message($type, $record);

    # Special local handling for PA, record to SQL database
    if ($type eq 'PA' && $record->{AS} eq 'OK')
    {
	# Posting was accepted, log it
	my $postNumber = $record->{'P#'};
	my ($transactionNumber) = $record->{CT} =~ /Interface transaction number\/s - (\d+)/;
	$transactionNumber = 0 unless defined $transactionNumber;
	my $timestamp_now = Radius::Util::strftime('%Y-%m-%d %T', time());

	if ($self->{PostAnswerQueryParam})
	{
	    my @bind_values;
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, undef, $self,
			  $record->{RN},
			  $postNumber,
			  $transactionNumber,
			  $timestamp_now)),
		 @{$self->{PostAnswerQueryParam}});
	    $self->prepareAndExecute($self->{PostAnswerQuery}, @bind_values);
	}
	else
	{
	    $self->do(Radius::Util::format_special(
			  $self->{PostAnswerQuery}, undef, $self,
			  $self->quote($record->{RN}),
			  $postNumber,
			  $transactionNumber,
			  $self->quote($timestamp_now)));
	}
    }

    return;
}

#####################################################################
sub charge_subscription
{
    my ($name, $id, $price, $subscription, $self, $p) = @_;

    $price = $self->{BlockPrice} unless defined $price;

    my ($user_ref, $charge_ref);
    ($user_ref, $charge_ref, $price) = Radius::AuthHOTSPOT::charge_subscription($name, $id, $price, $subscription, $self, $p);
    $charge_ref = $id unless defined $charge_ref;

    my $duration = $subscription->{quota_time_pre_left} || $subscription->{quota_time_post_left} || $self->{BlockDuration} || 0;

    # Send post to Fidelio
    my $rc = $self->Radius::AuthFIDELIO::post($name, $id, $price, $duration, $p);
    unless ($rc)
    {
	$self->log($main::LOG_WARNING, 'AuthHOTSPOTFIDELIO: Post to Fidelio failed');
	$user_ref = undef;
    }

    my $mac = $p->getAttrByNum($Radius::Radius::CALLING_STATION_ID);
    my $timenow = time();
    my $timestamp_now = Radius::Util::strftime('%Y-%m-%d %T', $timenow);

    # Insert into posts table
    $rc = $self->do_post_send_query($p, $name, $id, $mac, $self->{posting_sequence}, $timestamp_now, $price);
    unless ($rc)
    {
	$self->log($main::LOG_WARNING, 'AuthHOTSPOTFIDELIO: PostSendQuery failed');
	$user_ref = undef;
    }

    return ($user_ref, $charge_ref, $price);
}

# Store information about the Posting message we are sending
sub do_post_send_query
{
    my ($self, $p, $room, $gn, $mac, $posting_sequence, $timestamp_now, $cost) = @_;

    my ($q, @bind_values);
    if ($self->{PostSendQueryParam})
    {
	$q = $self->{PostSendQuery};
	map (push(@bind_values, Radius::Util::format_special(
		      $_, $p, $self,
		      $room, $gn, $mac, $posting_sequence, $timestamp_now, $cost)),
	     @{$self->{PostSendQueryParam}});
    }
    else
    {
	$q = Radius::Util::format_special($self->{PostSendQuery}, $p, $self, $self->quote($room), $self->quote($gn), $self->quote($mac), $posting_sequence, "'$timestamp_now'", $cost);
    }

    return $self->do($q, @bind_values);
}

1;
