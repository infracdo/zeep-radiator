# TotalControl.pm
#
# Implement Radiator routines for communicating with a given type of NAS
#
# Copyright (C) Open System Consultants
# $Id$

package Radius::Nas::TotalControl;
use strict;

# RCS version number of this module
$Radius::Nas::TotalControl::VERSION = '$Revision$';

#####################################################################
# Check Total Control by using pmwho
sub isOnline
{
    my ($name, $nas_id, $nas_port, $session_id, $client) = @_;

    if (!-x $main::config->{PmwhoProg})
    {
	&main::log($main::LOG_ERR, "$main::config->{PmwhoProg} is not executable. Check and configure Nas.pm");
	return 1; # Assume the worst
	
    }

    open (my $pmwho, '-|', "$main::config->{PmwhoProg} $nas_id");
    while (<$pmwho>)
    {
	next if (/Port/);
	next if (/---/);
	my ($port, $user) = split;
	$port =~ s/^S//;
	$user =~ s/^[PSC]//;
	$user =~ s/\.(ppp|slip|cslip)$//;
	
	if ($port == $nas_port) 
	{ 
	    close ($pmwho);
	    return ($user eq $name);
	}
    }
    close ($pmwho);
    return 0; # Not there
}


1;
