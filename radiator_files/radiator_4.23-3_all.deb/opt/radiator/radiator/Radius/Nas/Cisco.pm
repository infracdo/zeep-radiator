# Cisco.pm
#
# Updated by Utku Er <utkuer@utkuer.com>
# The old version could not verify ISDN users.
# Cisco cannot use SNMP to get the username of the ISDN users. (asked to TAC ;-))
# So if this is an ISDN user then we'll have to finger NAS
#
# Implement Radiator routines for communicating with a given type of NAS
#
# Supported attribute translations:
#   macaddr
#     cisco-avpair = "client-mac-address=1122.33aa.bbcc"
#
# Copyright (C) Open System Consultants
# $Id$

package Radius::Nas::Cisco;
@ISA = qw(Radius::Nas::NasGeneric);
use Radius::Nas::NasGeneric;
use Radius::SNMP;
use strict;
use warnings;

# RCS version number of this module
$Radius::Nas::Cisco::VERSION = '$Revision$';

# The Cisco SNMP MIB
# As at 2012, some SNMP tools dont ship with MIBs
#$Radius::Nas::CiscoMIB = '.iso.org.dod.internet.private.enterprises.9';
$Radius::Nas::CiscoMIB = '.1.3.6.1.4.1.9';


#####################################################################
#Format of finger in cisco is like:
#    Line       User       Host(s)              Idle       Location
#   2 tty 2     stas@guven Async interface          -
#   7 tty 7     merkoto@ne Async interface      00:01:21   PPP: 10.1.1.1
#  10 tty 10    asd        Async interface      00:00:00   PPP: 10.1.1.2
#  .....
#  Interface      User        Mode                     Idle     Peer Address
#  Vi8          briuser     Virtual PPP (Bundle) 00:00:00 10.3.3.3
#  Se6:6        briuser     Sync PPP                    -   Bundle: Vi8
#  Se6:28       briuser     Sync PPP                    -   Bundle: Vi8
#  Se7:23       otherbrius  Sync PPP             00:00:03   PPP: 10.4.4.4
#####################################################################
sub isOnline
{
    my ($name, $nas_id, $nas_port, $session_id, $client) = @_;

    return 1 unless &Radius::SNMP::snmpgetprogExists();

    #Checking if this is an ISDN connection
    if ($nas_port > 20000 ) 
    {
        &main::log($main::LOG_DEBUG, "Cisco: Checking ISDN $nas_id:$nas_port:$name" );
	
        my ($result, @lines) = &Radius::Nas::finger("\@$nas_id");
        return 1 if !$result; # Could not finger. Assume still there
	
        # We are getting the "SerialXX:YY" port number for this connection
        # Nas port is structured like 2XXYY. This means SerialXX:YY
        my $part1 = substr($nas_port, 1, 2);
        my $part2 = substr($nas_port, 3, 2);
        my $port = sprintf("Se%d:%d",$part1,$part2); #Sprintf works even XX is zero
        #&main::log($main::LOG_DEBUG, "Cisco:ISDN Part1:$part1 Part2:$part2");
        &main::log($main::LOG_DEBUG, "Cisco:ISDN User is in this port:$port");
        # Finger only shows the first 10 characters of username@domain
        my $nameshort = substr($name, 0, 10);

        foreach my $line (@lines)
        {
            if ($line =~ /$port.*$nameshort/) 
	    {
                &main::log($main::LOG_DEBUG, "Cisco: ISDN User online: $line");
                return 1;
            }
        }
        return 0; # not there
    }
    else 
    {
        my $result = &Radius::SNMP::snmpget
	    ($nas_id,
	     $client->{SNMPCommunity},
	     "$Radius::Nas::CiscoMIB.2.9.2.1.18.$nas_port");

	&main::log($main::LOG_DEBUG, "Cisco: snmpget result: $result");
	return uc($1) eq uc($name)
	    if ($result =~ /^.*\"([^"]+)".*$/);
    }

    return 0;
}

#####################################################################
# Does a NAS specific translation for a received attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_in
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $strip, @extra) = @_;

    # Get the cisco A we are configured to be interested in. The
    # format in the configuration file must be: cisco-avpair=A
    my ($cisco_a) = ($source =~ /^cisco-avpair=(.*)$/);
    unless ($cisco_a)
    {
	main::log($main::LOG_WARNING, "Cisco.pm can currently do VsaTranslateIn only for cisco-avpair attributes", $p);
	return;
    }

    my @avpairs = grep { $_ =~ /^$cisco_a/ } $p->get_attr('cisco-avpair');
    return unless @avpairs;

    my $val = $avpairs[0];
    if ($translation eq 'macaddr')
    {
	# Strip the cisco A= and dots
	$val =~ s/^client-mac-address=(.*)$/$1/ if $cisco_a eq 'client-mac-address';
	$val =~ s/\.//g;
    }
    elsif ($translation eq 'copyvalue')
    {
	$val =~ s/^[^=]+=(.*)$/$1/;
    }
    elsif ($translation eq 'copyavp')
    {
	# Do nothing. We have cisco_a=cisco_v in $val
    }

    # Not implemented for a possibly multivalue attribute
    #$p->delete_attr('cisco-avpair') if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $p->add_attr($target, $val);

    return;
}

#####################################################################
# Does a NAS specific translation for a sent attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_out
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $op, $strip, @extra) = @_;

    # Our destination object, prefer $op over $p
    my $dp = $op ? $op : $p;

    # Get the cisco A we are configured to be interested in from the
    # AVP that looks like: cisco-avpair="A=V".
    my ($cisco_a) = ($target =~ /^cisco-avpair=(.*)$/);
    unless ($cisco_a)
    {
	main::log($main::LOG_WARNING, "Cisco.pm can currently do VsaTranslateOut only for cisco-avpair attributes", $p);
	return;
    }

    my $val;
    if ($translation eq 'copy')
    {
	$val = $dp->get_attr($source);
    }
    elsif ($translation eq 'macaddr')
    {
	$val = $dp->get_attr($source);
	return unless $val;

	if ($cisco_a eq 'client-mac-address')
	{
	    $val = join('.', ($val =~ m/.{4}/g)); # Insert dots to separate 16 bits groups
	}
    }

    $dp->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $dp->add_attr("cisco-avpair", "$cisco_a=$val");

    return;
}

1;
