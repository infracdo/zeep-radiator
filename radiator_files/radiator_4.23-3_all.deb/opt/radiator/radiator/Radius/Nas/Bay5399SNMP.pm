# Bay5399SNMP.pm
#
# Implement Radiator routines for communicating with a given type of NAS
#
# Copyright (C) Open System Consultants
# $Id$

package Radius::Nas::Bay5399SNMP;
use Radius::Nas::Bay;
use strict;

# RCS version number of this module
$Radius::Nas::Bay5399SNMP::VERSION = '$Revision$';

sub isOnline
{
    return &Radius::Nas::Bay::isOnline(@_);
}

1;
