# Juniper.pm
#
# Implement Radiator routines for communicating with Juniper
#
# Supported attribute translations:
#   macaddr
#     Unisphere-Pppoe-Description = "pppoe 11:22:33:aa:bb:cc"
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::Nas::Juniper;
@ISA = qw(Radius::Nas::NasGeneric);
use Radius::Nas::NasGeneric;
use strict;
use warnings;

# RCS version number of this module
$Radius::Nas::Juniper::VERSION = '$Revision$';

#####################################################################
# Does a NAS specific translation for a received attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_in
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $strip, @extra) = @_;

    my $val;
    if ($translation eq 'copy')
    {
	$val = $p->get_attr($source);
    }
    elsif ($translation eq 'macaddr')
    {
	$val = $p->get_attr($source);
	return unless $val;

	# Strip 'pppoe ' and colons
	$val =~ s/^pppoe (.*)$/$1/ if $source eq 'Unisphere-Pppoe-Description';
	$val =~ s/://g;
    }

    $p->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $p->add_attr($target, $val);

    return;
}

#####################################################################
# Does a NAS specific translation for a sent attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_out
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $op, $strip, @extra) = @_;

    # Our destination object, prefer $op over $p
    my $dp = $op ? $op : $p;

    my $val;
    if ($translation eq 'copy')
    {
	$val = $dp->get_attr($source);
    }
    elsif ($translation eq 'macaddr')
    {
	$val = $dp->get_attr($source);
	return unless $val;

	if ($target eq 'Unisphere-Pppoe-Description')
	{
	    $val = join(':', ($val =~ m/.{2}/g)); # Insert colons to separate octets
	    $val = "pppoe $val";
	}
    }

    $dp->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $dp->add_attr($target, $val);

    return;
}

1;
