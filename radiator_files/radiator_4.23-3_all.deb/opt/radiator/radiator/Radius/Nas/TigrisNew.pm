# TigrisNew.pm
#
# Implement Radiator routines for communicating with a given type of NAS
#
# Copyright (C) Open System Consultants
# $Id$

package Radius::Nas::TigrisNew;
use Radius::Nas::Tigris;
use strict;

# RCS version number of this module
$Radius::Nas::TigrisNew::VERSION = '$Revision$';

sub isOnline
{
    return &Radius::Nas::Tigris::isOnline(@_);
}

1;
