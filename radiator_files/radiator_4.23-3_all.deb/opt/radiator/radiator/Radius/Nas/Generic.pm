# Generic.pm
#
# Implement Radiator routines for communicating with a Generic NAS
#
# Supported attribute translations:
#   macaddr
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2017 Open System Consultants
# $Id$

package Radius::Nas::Generic;
@ISA = qw(Radius::Nas::NasGeneric);
use Radius::Nas::NasGeneric;
use strict;
use warnings;

# RCS version number of this module
$Radius::Nas::Generic::VERSION = '$Revision$';

#####################################################################
# Does a NAS specific translation for a received attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_in
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $strip, @extra) = @_;

    my $val;
    if ($translation eq 'copy')
    {
	$val = $p->get_attr($source);
    }
    elsif ($translation eq 'macaddr')
    {
	$val = $p->get_attr($source);
	return unless $val;

	my $ssid;
	($val, $ssid) = canonicalize_mac_addr($val, $source eq 'Called-Station-Id');
	if ($ssid)
	{
	    $p->add_attr($target . '-SSID', $ssid);
	}
    }
    elsif ($translation eq 'realm')
    {
	$val = $p->get_attr($source);
	return unless $val;

	$val = get_realm_from_username($val);
    }

    $p->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $p->add_attr($target, $val);

    return;
}

#####################################################################
# Does a NAS specific translation for a sent attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_out
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $op, $strip, @extra) = @_;

    # Our destination object, prefer $op over $p
    my $dp = $op ? $op : $p;

    my $val;
    if ($translation eq 'copy')
    {
	$val = $dp->get_attr($source);
    }

    $dp->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $dp->add_attr($target, $val);

    return;
}

#####################################################################
# Get a canolicalized mac address and possible SSID
# Unify MAC address formats:
#
# 001122AABBCC
# 001122.AABBCC
# 001122:AABBCC
# 001122-AABBCC
# 0011.22AA.BBCC
# 0011:22AA:BBCC
# 0011-22AA-BBCC
# 00.11.22.AA.BB.CC
# 00:11:22:AA:BB:CC
# 00-11-22-AA-BB-CC
#
# to
#
# 00-11-22-aa-bb-cc
sub canonicalize_mac_addr
{
    my ($mac_addr, $get_ssid) = @_;

    my $mac_addr_copy = $get_ssid ? $mac_addr : undef;
    $mac_addr =~ s/[-:.]//g;
    my $canonicalized_mac_addr = substr($mac_addr, 0, 12, '');

    my $ssid = $mac_addr;
    if ($get_ssid && $ssid)
    {
        ($ssid) = $mac_addr_copy =~ m/([^:]+)$/i;
    }
    else
    {
        $ssid = '';
    }

    $mac_addr = lc join('-', ($canonicalized_mac_addr =~ m/..?/g));
    return ($mac_addr, $ssid);
}

#####################################################################
# Get a realm from different username formats
# Supported formats:
#
# "" to realm ""
# "user" to realm ""
# "user@org.tld" to realm "org.tld"
# "user@sub.org.tld" to realm "sub.org.tld"
# "user@host.sub.org.tld" to realm "sub.org.tld"
# "host/host.sub.org.tld" to realm "sub.org.tld"
# "DOMAIN\user" to realm ""
# "DOMAIN\user@org.tld" to realm "org.tld"
# "DOMAIN\host/host.sub.org.tld" to realm "sub.org.tld"
# "org.tld\user" to realm "org.tld"
# "sub.org.tld\user", # realm "sub.org.tld"
# "host.sub.org.tld\user", # realm "sub.org.tld"
# "org.tld\user@org.tld", # realm "org.tld"
# "sub.org.tld\user@org.tld", # realm "org.tld"
# "host.sub.org.tld\user@org.tld", # realm "org.tld"
#
sub get_realm_from_username
{
    my ($name) = @_;

    my ($r, @t);

    # get suffix
    (@t) = $name =~ /([^@\\\/]+)$/i;

    my (@u, $l, $s, $e);
    if (@t)
    {
	@u = split('\.', $t[0]);
	$l = scalar @u;
	$s = ($l >= 3) ? $l - 3 : 0;
	$e = ($l >= 3) ? 2 : 1;
	$r = join('.', @u[$s .. $s + $e]) if ($l > 1);
    }

    unless (defined $r)
    {
	# get prefix
	(@t) = $name =~ /^([^@\\\/]+)/i;
	if (@t)
	{
	    @u = split('\.', $t[0]);
	    $l = scalar @u;
	    $s = ($l >= 3) ? $l - 3 : 0;
	    $e = ($l >= 3) ? 2 : 1;
	    $r = join('.', @u[$s .. $s + $e]) if ($l > 1);
	}
    }

    $r = '' unless defined $r;
    return lc $r;
}

1;
