# unknown.pm
#
# Implement Radiator routines for communicating with a given type of NAS
#
# Copyright (C) 1997-2002 Open System Consultants
# Author: Mike McCauley (mike@open.com.au)
# $Id$

package Radius::Nas::unknown;
use strict;

# RCS version number of this module
$Radius::Nas::unknown::VERSION = '$Revision$';

#####################################################################
# Unknown NAS type, assume they are online
sub isOnline
{
    return 1;
}

#####################################################################
# Unknown NAS type, assume they are online
sub activeSessions
{
    return;
}

1;
