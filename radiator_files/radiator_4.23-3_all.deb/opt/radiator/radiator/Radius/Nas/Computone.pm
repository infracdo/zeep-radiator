# Computone.pm
#
# Implement Radiator routines for communicating with a given type of NAS
#
# Copyright (C) Open System Consultants
# $Id$

package Radius::Nas::Computone;
use strict;

# RCS version number of this module
$Radius::Nas::Computone::VERSION = '$Revision$';

#####################################################################
# Check whether an Computone Powerrack or similar is online with finger
sub isOnline
{
    my ($name, $nas_id, $nas_port, $session_id, $client) = @_;

    my ($result, @lines) = &Radius::Nas::finger("\@$nas_id");
    return 1 if !$result; # Could not finger. Assume still there

    foreach my $line (@lines)
    {  
	return 1 if index($line, $name) > -1;
    }
    return 0; # Not there
}

1;
