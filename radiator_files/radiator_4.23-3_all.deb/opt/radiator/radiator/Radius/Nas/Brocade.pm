# Brocade.pm
#
# Implement Radiator routines for communicating with Broacde
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::Nas::Brocade;
@ISA = qw(Radius::Nas::NasGeneric);
use Radius::Nas::NasGeneric;
use strict;
use warnings;

# RCS version number of this module
$Radius::Nas::Brocade::VERSION = '$Revision$';

#####################################################################
# Does a NAS specific translation for a received attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_in
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $strip, @extra) = @_;

    my $val;
    if ($translation eq 'copy')
    {
	$val = $p->get_attr($source);
    }

    $p->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $p->add_attr($target, $val);

    return;
}

#####################################################################
# Does a NAS specific translation for a sent attribute
# See NasGeneric.pm for the parameters
sub translate_vsa_out
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $op, $strip, @extra) = @_;

    # Our destination object, prefer $op over $p
    my $dp = $op ? $op : $p;

    my $val;
    if ($translation eq 'copy')
    {
	$val = $dp->get_attr($source);
    }

    $dp->delete_attr($source) if $strip;

    # Nothing got successfully converted
    return unless defined $val;

    $dp->add_attr($target, $val);

    return;
}

1;
