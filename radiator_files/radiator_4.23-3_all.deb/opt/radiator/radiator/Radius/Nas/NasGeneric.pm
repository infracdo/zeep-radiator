# NasGeneric.pm
#
# Generic classs for implementing Radiator routines for communicating
# with a given type of NAS
#
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::Nas::NasGeneric;
use strict;
use warnings;

# RCS version number of this module
$Radius::Nas::NasGeneric::VERSION = '$Revision$';

#####################################################################
sub new
{
    my ($class, @args) = @_;

    my $self = {@args};
    bless $self, $class;
    return $self;
}

####################################################################
# Returns 1 if they are still online, according to the NAS
sub isOnline
{
    my ($name, $nas_id, $nas_port, $session_id, $client, $framed_ip_address) = @_;

    # This module does not define an isOnline method. Assume the
    # worst: they are still online
    return 1;
}

####################################################################
# Returns 1 and a list of session IDs if successful, else undef
sub activeSessions
{
    my ($nas_id, $client) = @_;

    # This module does not define an activeSessions method. Assume the
    # worst: failed to get active sessions
    return;
}

####################################################################
# Returns true if we think it worked, else undef
sub disconnectUser
{
    my ($name, $nas_id, $nas_port, $session_id, $client) = @_;

    # This module does not define a disconnectUser method. Assume the
    # worst: failed to disconnect the sessions
    return;
}


####################################################################
# VSA translation methods

#####################################################################
# Does a NAS specific translation for received attributes
sub translateVSAsIn
{
    my ($self, $vsa_type, $vsa_translate_in, $p) = @_;

    foreach my $source (keys %$vsa_translate_in)
    {
	# Make a copy, do not alter the original.
	my @args = @{$vsa_translate_in->{$source}};
	my ($target, $operation) = splice(@args, 0, 2);
	$operation = 'copy' unless $operation;

	# By default we do not strip the translation source attribute
	# from the incoming request
	my $strip = 0;
	$strip = 1 if grep {$_ eq 'strip'} @args;

	$self->translate_vsa_in($vsa_type, $source, $target, $operation, $p, $strip, @args);
    }

    return;
}

#####################################################################
# Does a NAS specific translation for sent attributes
# $op is the target of translation, if defined
sub translateVSAsOut
{
    my ($self, $vsa_type, $vsa_translate_out, $p, $op) = @_;

    foreach my $source (keys %$vsa_translate_out)
    {
	# Make a copy, do not alter the original.
	my @args = @{$vsa_translate_out->{$source}};
	my ($target, $translation) = splice(@args, 0, 2);
	$translation = 'copy' unless $translation;

	# By default we strip the translation source attribute from
	# the outgoing request
	my $strip = 1;
	$strip = 0 if grep {$_ eq 'nostrip'} @args;

	$self->translate_vsa_out($vsa_type, $source, $target, $translation, $p, $op, $strip, @args);
    }

    return;
}


# The following translation methods need to be defined by subclasses

#####################################################################
# Does a NAS specific translation for a received attribute
#
# $vsa_type is the value from VsaType configuration parameter
# $source, $target and $translation are the values from the configuration
# parameter
#   VsaTranslateIn source, target, translation[, extra1, extra2]
# $p is the current request object
# $strip is true when the translation source attribute should be
#   stripped from the incoming request
# @extra contains any values within [] above
sub translate_vsa_in
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $strip, @extra) = @_;

    return;
}

#####################################################################
# Does a NAS specific translation for a sent attribute
#
# $vsa_type is the value from VsaType configuration parameter
# $source, $target and $translation are the values from the configuration
# parameter
#   VsaTranslateOut source, target, translation[, extra1, extra2]
# $p is the current request object
# $op, if defined, is the destination object for the translated attribute
# $strip is true when the translation source attribute should be
#   stripped from the outgoig request
# @extra contains any values within [] above
sub translate_vsa_out
{
    my ($self, $vsa_type, $source, $target, $translation, $p, $op, $strip, @extra) = @_;

    return;
}

1;
