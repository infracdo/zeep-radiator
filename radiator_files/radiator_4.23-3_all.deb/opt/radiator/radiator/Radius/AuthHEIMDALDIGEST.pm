# AuthHEIMDALDIGEST.pm
#
# Object for handling Authentication with a Heimdal Kerberos KDC
# This module uses the program kdigest shipped with Heimdal to do digest
# authentication without the radius server ever seeing the password.
#
# This file will be 'require'd only one time when the first Realm 
# with an AuthType of HEIMDALDIGEST is found in the config file
#
# Author: Klas Lindfors (klas.lindfors@it.su.se)
# Modified and modernized, fixed some bugs, integrated into Radiator 4.10 by Mike McCauley 2012
# Copyright (C) Open System Consultants Pty Ltd.
# assigned to OSC by Stockholm University 2012-11-02
# $Id$

package Radius::AuthHEIMDALDIGEST;
@ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use IPC::Open2;
use POSIX ":sys_wait_h";
use strict;
use warnings;

$Radius::AuthHEIMDALDIGEST::VERSION = '$Revision$';

%Radius::AuthHEIMDALDIGEST::ConfigKeywords =
(
 'KdigestPath'              => 
 ['string', 
  'The path to the executable Heimdal kdigest program. This program will be run externally by AuthBy HEIMDALDIGEST to authenticate each password. Defaults to /usr/libexec/kdigest',
  1],

 'KdigestSuffix'              => 
 ['string', 
  'String that will be added to the end of each username before authenticating with kdigest. Defaults to empty string. See also default_realm in krb5.conf, which will be used if username does not contain a Kerberos realm.',
  1],

 'KdigestRealm'              => 
 ['string', 
  'String specifying the Kerberos realm that will be used to authenticate each user. Used to specify --kerberos-realm= to kdigest. Defaults to undefined',
  1],
);

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->log($main::LOG_ERR, "KdigestPath binary $self->{KdigestPath} is not executable") 
	unless -e $self->{KdigestPath};

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;

    $self->{KdigestPath} = '/usr/libexec/kdigest';
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate;
}

#####################################################################
# Create a user object with no check or reply items. This AuthBy can
# only authenticate the user from an external source.
sub findUser
{
    my ($self, $name, $p) = @_;

    return Radius::User->new($name);
}

#####################################################################
sub checkUserAttributes
{
    my ($self, $user, $p) = @_;

    my $userName = $p->getUserName();

    # Names with NUL octets can not be fully passed to kdigest
    return ($main::REJECT_IMMEDIATE, 'NUL octet in username') if defined $userName && $userName =~ /\0/;

    # Short circuit authentication in EAP requests ?
    return ($main::ACCEPT, '') if $p->getAttrByNum($Radius::Radius::EAP_MESSAGE);

    return ($main::ACCEPT, '') if $self->check_password($p, undef, $userName);
    return ($main::REJECT, 'AuthBy HEIMDALDIGEST Password check failed');
}

#####################################################################
# Check a plaintext PAP password
# Generate kdigest challenge and do the MD5 challenge test
# $submitted_pw is the submitted password
sub check_plain_password
{
    my ($self, $user, $submitted_pw, $pw, $p, $encrypted) = @_;

    my $chapid = chr(1);
    my $context = {}; # Fake context for kdigest_digest

    # The challenge is also stored in context
    my $challenge = $self->kdigest_challenge($p, $context, "CHAP");
    return 0 unless $challenge;

    my $response = Digest::MD5::md5($chapid . $submitted_pw . $challenge);

    return $self->kdigest_digest($p, $user, $context, $chapid, $response, undef, 'CHAP');
}

#####################################################################
# Check an MD5 repsonse digest
sub check_md5
{
    my ($self, $context, $p, $username, $pw, $chapid, $challenge, $response) = @_;

    return $self->kdigest_digest($p, $username, $context, $chapid, $response, undef, 'CHAP');
}

#####################################################################
# Check a CHAP password response
sub check_chap
{
    my ($self, $p, $username, $pw, $chapid, $challenge, $response) = @_;

    $self->log($main::LOG_WARNING, 'AuthBy HEIMDALDIGEST cannot authenticate with CHAP. Rejecting', $p);
    return 0;
}

#####################################################################
# Check an MSCHAP response digest
sub check_mschap
{
    my ($self, $p, $username, $nthash, $challenge, $response,
	$usersessionkeydest, $lanmansessionkeydest, $context) = @_;

    $self->log($main::LOG_WARNING, 'AuthBy HEIMDALDIGEST cannot authenticate with MSCHAP. Rejecting', $p);
    return 0;
}

#####################################################################
# Check an MSCHAPv2 response digest
sub check_mschapv2
{
    my ($self, $p, $username, $nthash, $challenge, $peerchallenge, $response,
	$mppekeys_dest, $authenticator_responsedest, $lanmansessionkeydest, $context) = @_;

    # Warn about non-EAP-MSCHAP-V2 authentication attempts. EAP-MSCHAP-V2 calls us with context
    unless ($context)
    {
	$self->log($main::LOG_WARNING, "AuthBy HEIMDALDIGEST does not support plain MS-CHAP-V2", $p);
	return 0;
    }

    my $status = $self->kdigest_digest($p, $username, $context, undef, $response, $peerchallenge, 'MS-CHAP-V2');
    return 0 unless $status;
    unless ($context->{kdigest_rsp} && $context->{kdigest_session_key})
    {
	$self->log($main::LOG_WARNING, "AuthBy HEIMDALDIGEST did not get both rsp and session-key from kdigest for MS-CHAP-V2", $p);
	return 0;
    }

    $$authenticator_responsedest = "S=" . $context->{kdigest_rsp};

    # Maybe generate MPPE keys.
    # session_key from kdigest is in fact the MSCHAP master key
    $$mppekeys_dest = Radius::MSCHAP::mppeGetKeyFromMasterKey($context->{kdigest_session_key}, 16)
	if defined $mppekeys_dest;
    
    return ($status);
}

#####################################################################
# Check a digest against using Heimdal kdigest. Returns 1 if kdigest
# status is 'ok', 0 otherwise. Note: the caller must check that all
# required information for the authentication method was received
# from kdigest.
sub kdigest_digest
{
    my ($self, $p, $username, $context, $chapid, $client_response, $client_challenge, $type) = @_;

    # Names with NUL octets can not be fully passed to kdigest
    if ($username =~ /\0/)
    {
	$self->log($main::LOG_INFO, 'AuthHEIMDALDIGEST rejects NUL octet in username', $p);
	return 0;
    }

    my $status;
    my $realm;
    my $client_nonce;
    $username .= $self->{KdigestSuffix} 
        if defined $self->{KdigestSuffix};
    $realm = '--kerberos-realm=' . $self->{KdigestRealm}
	if defined $self->{KdigestRealm};
    $client_nonce = '--client-nonce=' . $self->kdigest_unpackstring($client_challenge)
	if defined $client_challenge;

    my @command = ($self->{KdigestPath}, 'digest-server-request');
    push (@command, '--type=' . $type);
    push (@command, '--username=' . $username);
    push (@command, '--opaque=' . $context->{kdigest_opaque});
    push (@command, '--server-identifier=' . $self->kdigest_unpackstring($chapid)) if defined $chapid;
    push (@command, '--server-nonce=' . $self->kdigest_unpackstring($context->{kdigest_challenge}));
    push (@command, '--client-response=' . $self->kdigest_unpackstring($client_response));
    push (@command, $client_nonce) if defined $client_nonce;
    push (@command, $realm) if defined $realm;
    $self->log($main::LOG_DEBUG, "AuthHEIMDALDIGEST digest command: @command", $p);

    delete $context->{kdigest_rsp};
    delete $context->{kdigest_session_key};

    my ($read, $write);
    my $child_pid = open2($read, $write, @command);
    while(<$read>)
    {
	chomp;
	my $output = $_;
	$self->log($main::LOG_DEBUG, "AuthHEIMDALDIGEST digest command output: $output", $p);

	m/([\w\-]+)\=([\w\-]+)/;
	next if $1 eq 'tickets';
	$status = $2 and next if $1 eq 'status';
	$context->{kdigest_rsp} = $2 and next if $1 eq 'rsp';
	$context->{kdigest_session_key} = $self->kdigest_packstring($2) and next if $1 eq 'session-key';
	$self->log($main::LOG_ERR, "AuthHEIMDALDIGEST Unexpected output from kdigest: $output.", $p);
    }
    close($read); close($write);
    waitpid($child_pid, 0); # Reap it

    return 1 if ($status && $status eq "ok");
    return 0;
}

#####################################################################
# Use Heimdal to generate an MD5 challenge
sub md5_challenge
{
    my ($self, $context, $p) = @_;

    return $context->{md5_challenge} = $self->kdigest_challenge($p, $context, 'CHAP');
}

#####################################################################
# Use Heimdal to generate an MSCHAPv2 challenge
sub mschapv2_challenge
{
    my ($self, $context, $p) = @_;

    return $context->{mschapv2_challenge} = $self->kdigest_challenge($p, $context, 'MS-CHAP-V2');
}

#####################################################################
# Generate a challenge for the user with Heimdal kdigest
# Returns challenge or undef for failure.
sub kdigest_challenge
{
    my ($self, $p, $context, $type) = @_;

    my $realm;
    $realm = '--kerberos-realm=' . $self->{KdigestRealm} if defined $self->{KdigestRealm};

    my @command = ($self->{KdigestPath}, 'digest-server-init', "--type=$type");
    push (@command, $realm) if $realm;
    $self->log($main::LOG_DEBUG, "AuthHEIMDALDIGEST challenge command: @command", $p);

    my ($read, $write);
    my $child_pid = open2($read, $write, @command);
    while(<$read>)
    {
	chomp;
	my $output = $_;
	$self->log($main::LOG_DEBUG, "AuthHEIMDALDIGEST challenge command output: $output", $p);

	m/([\w\-]+)\=([\w\-]+)/;
	next if $2 eq "$type";

	$context->{kdigest_challenge} = $self->kdigest_packstring($2) and next if $1 eq 'server-nonce';
	$context->{kdigest_identifier} = $2 and next if $1 eq 'identifier';
	$context->{kdigest_opaque} = $2 and next if $1 eq 'opaque';
	$self->log($main::LOG_ERR, "AuthHEIMDALDIGEST Unexpected output from kdigest: $output.", $p);
    }
    close($read); close($write);
    waitpid($child_pid, 0); # Reap it

    unless ($context->{kdigest_challenge} && $context->{kdigest_opaque})
    {
	$self->log($main::LOG_ERR, "AuthHEIMDALDIGEST did not get both server-nonce and opaque from challenge command", $p);
	return undef;
    }

    return $context->{kdigest_challenge};
}

#####################################################################
sub kdigest_packstring
{
    my ($self, $string) = @_;

    return pack('H*', $string);
}

#####################################################################
sub kdigest_unpackstring
{
    my ($self, $string) = @_;

    return uc(unpack('H*', $string));
}

1;

