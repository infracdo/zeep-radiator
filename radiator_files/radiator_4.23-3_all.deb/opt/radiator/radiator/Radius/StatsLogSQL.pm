# StatsLogSQL.pm
#
# Log statistics to an SQL database
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002 Open System Consultants
# $Id$

package Radius::StatsLogSQL;
@ISA = qw(Radius::StatsLogGeneric Radius::SqlDb);
use Radius::StatsLogGeneric;
use Radius::SqlDb;
use strict;
use warnings;

%Radius::StatsLogSQL::ConfigKeywords = 
('InsertQuery' => 
 ['string', 'This optional parameter specifies the SQL query to be used for each log. It can include special formatting characters as described in Section 5.2 on page 16. %0 to %23 are replaced by statistics data as described in the Radiator Reference manual. If InsertQuery is not defined then a standard set of statistics wil be logged', 1],

 'TableName' => 
 ['string', 'Name of the SQL table to insert into. Defaults to RADSTATSLOG', 1],

 );

# RCS version number of this module
$Radius::StatsLogSQL::VERSION = '$Revision$';

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->Radius::StatsLogGeneric::check_config();
    $self->Radius::SqlDb::check_config();

    # StatsType All is currently not supported in StatsLogSQL. Default to Cumulative.
    if ($self->{StatsType} eq $Radius::StatsLog::Type::All)
    {
	$self->log($main::LOG_ERR, "StatsType All is currently not supported in StatsLogSQL. Defaulting to cumulative.");
	$self->{StatsType} = $Radius::StatsLog::Type::Cumulative;
    }

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->Radius::StatsLogGeneric::activate();
    $self->Radius::SqlDb::activate();
}

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->Radius::StatsLogGeneric::initialize();
    $self->Radius::SqlDb::initialize();
    $self->{TableName} = 'RADSTATSLOG';
}

#####################################################################
# Log all the Statistics from one object
sub logObject
{
    my ($self, $object) = @_;

    return unless $self->reconnect;
    my $time = time;
    my $type = $object->{ObjType} || (split(/:/, ref($object)))[2];
    my $id = $object->{Identifier} || $object->{Name} || 'unknown';
    my $q;

    # Type All is currently not supported in StatsLogSQL.
    if ($self->{StatsType} eq $Radius::StatsLog::Type::All)
    {
	my $stats_href = $self->get_all_statistics($object);
	foreach my $stat_type (@Radius::StatsLog::Types)
	{
	    if (defined $self->{InsertQuery})
	    {
		# FIXME: insert statistics type.
		$q = &Radius::Util::format_special
		    ($self->{InsertQuery}, undef, undef,
		     $time, $type, $id, @{$stats_href->{$stat_type}});
	    }
	    else
	    {
		my $cols = join(',', 'TIME_STAMP', 'TYPE', 'IDENTIFIER',
				map { uc $_ } sort keys %Radius::StatsLogGeneric::statistic_names);
		my $vals = join(',', $time, $self->quote($type), $self->quote($id),
				@{$stats_href->{$stat_type}});
		$q = "insert into $self->{TableName} ($cols) values ($vals)";
	    }
	    $self->do($q);
	}
    }
    else
    {
	my @values = map { $self->get_statistics($object, $_) } sort keys %Radius::StatsLogGeneric::statistic_names;
	if (defined $self->{InsertQuery})
	{
	    $q = Radius::Util::format_special($self->{InsertQuery}, undef, undef, $time, $type, $id, @values);
	}
	else
	{
	    my $cols = join(',', 'TIME_STAMP', 'TYPE', 'IDENTIFIER',
			    map { uc $_ } sort keys %Radius::StatsLogGeneric::statistic_names);
	    my $vals = join(',', $time, $self->quote($type), $self->quote($id), @values);
	    $q = "insert into $self->{TableName} ($cols) values ($vals)";
	}
	$self->do($q);
    }
}

1;
