# Nas.pm
# 
# Routines for communicating directly with NASs
#
# Looks for a NAS-specific module in Radius/Nas/type.pm, and then tries
# to run the isOnline (or whatever) funtion in that module.
#
# This makes it easier to add support for new NAS types.
# If you add support for your type of NAS, please consider sending
# it to Open System Consultants for inclusion in future releases.
#
# Policy statement: in general, software failures or configuration
# problems act to accept logins, rather than reject them. This is 
# thought to be better for end-users.
#
# One day, this file will be split into a separate file for each NAS
# type
#
# Copyright (C) 1997-2002 Open System Consultants
# Author: Mike McCauley (mike@open.com.au)
# $Id$

package Radius::Nas;
use strict;
use Radius::Log;

# RCS version number of this module
$Radius::Nas::VERSION = '$Revision$';

# Hash of loaded module names to short circuit slow eval
my %module_loaded;

# Hash of loaded module class instances. Eventually this should replace %module_loaded use
%Radius::Nas::NasClasses = ();

# Make sure we get reinitialized on sighup
push(@main::reinitFns, \&reinitialize);

# Make sure the NAS class instances will be re-created
sub reinitialize
{
    %Radius::Nas::NasClasses = ();
}

#####################################################################
# Wrapper that can handle any NAS type
# Returns 1 if they are still online, according to the NAS
# I really dont like carrying the $client pointer down here just to
# get the SNMP Community for some Nas types.
sub isOnline
{
    my ($nas_type, $name, $nas_id, $nas_port, $session_id, $client, $framed_ip_address) = @_;

    &main::log($main::LOG_DEBUG, 
	       "Checking if user is still online: $nas_type, $name, $nas_id, $nas_port, $session_id $framed_ip_address");

    if  ($nas_type =~ /^Exec-Program\s+(.*)/)
    {
	system(&Radius::Util::format_special
	       ($1, undef, undef, 'isonline', 
		$name, $nas_id, $nas_port, $session_id, $framed_ip_address));
	return $? >> 8;
    }
    else
    {
	my $nas_module = "Radius::Nas::$nas_type";
	my $path = Radius::Util::classname_to_path($nas_module);
	if (!$module_loaded{$nas_module} && !eval{require $path;})
	{
	    # Anything else, unknown type, assume the worst
	    &main::log($main::LOG_ERR, "Could not load NAS-specific module $nas_module: $@");
	    return 1;
	}
	$module_loaded{$nas_module} = 1;
	my $fn = "${nas_module}::isOnline";
	if (defined(&$fn))
	{
	    # So we can use symbolic references
	    no strict 'refs'; ## no critic (Perl::Critic::Policy::TestingAndDebugging::ProhibitNoStrict)
	    return &$fn($name, $nas_id, $nas_port, $session_id, $client, $framed_ip_address);
	    use strict 'refs';
	}
	else
	{
	    # module does not define an isOnline fn. Assume the worst: they are still online
	    return 1;
	}
    }
}

#####################################################################
# Wrapper that can handle any NAS type
# Returns 1 and a list of session IDs if successful, else undef
sub activeSessions
{
    my ($nas_type, $nas_id, $client) = @_;

    &main::log($main::LOG_DEBUG, "Getting active sessions from $nas_id");

    if  ($nas_type =~ /^Exec-Program\s+(.*)/)
    {
	system(&Radius::Util::format_special
	       ($1, undef, undef, 'active', $nas_id));
	return $? >> 8;
    }
    else
    {
	my $nas_module = "Radius::Nas::$nas_type";
	my $path = Radius::Util::classname_to_path($nas_module);
	if (!eval{require $path;})
	{
	    # Anything else, unknown type, assume the worst
	    &main::log($main::LOG_ERR, 
		       "Could not load NAS-specific module $nas_module: $@");
	    return 1;
	}
	else
	{
	    my $fn = "${nas_module}::activeSessions";
	    if (defined(&$fn))
	    {
		# So we can use symbolic references
		no strict 'refs'; ## no critic (Perl::Critic::Policy::TestingAndDebugging::ProhibitNoStrict)
		return &$fn($nas_id, $client);
		use strict 'refs';
	    }
	    else
	    {
		# module does not define an activeSessions fn. Assume the worst
		return;
	    }
	}
    }
}

#####################################################################
# Wrapper that can handle any NAS type
# returns true if we think it worked, else undef
sub disconnectUser
{
    my ($nas_type, $name, $nas_id, $nas_port, $session_id, $client) = @_;

    &main::log($main::LOG_DEBUG, 
	       "Checking if user is still online: $nas_type, $name, $nas_id, $nas_port, $session_id");

    if  ($nas_type =~ /^Exec-Program\s+(.*)/)
    {
	system(&Radius::Util::format_special
	       ($1, undef, undef, 'disconnect', $name, $nas_id, $nas_port, 
		$session_id));
	return $? >> 8;
    }
    else
    {
	my $nas_module = "Radius::Nas::$nas_type";
	my $path = Radius::Util::classname_to_path($nas_module);
	if (!eval{require $path;})
	{
	    # Anything else, unknown type, assume the worst
	    &main::log($main::LOG_ERR, 
		       "Could not load NAS-specific module $nas_module: $@");
	    return 1;
	}
	else
	{
	    my $fn = "${nas_module}::disconnectUser";
	    if (defined(&$fn))
	    {
		# So we can use symbolic references
		no strict 'refs'; ## no critic (Perl::Critic::Policy::TestingAndDebugging::ProhibitNoStrict)
		return &$fn($name, $nas_id, $nas_port, $session_id, $client);
		use strict 'refs';
	    }
	    else
	    {
		# module does not define an disconnectUser fn. Assume the worst
		return;
	    }
	}
    }
}


#####################################################################
# Call the internal or external finger, depending on the setting
# of fingerprog. Returns 1, and an array of lines read from finger
# or undef if an error occurred (which we logged)
# REVISIT: should move this somewhere else
sub finger
{
    my ($addr) = @_;

    my @lines;

    if ($main::config->{FingerProg})
    {
	&main::log($main::LOG_DEBUG, "Using external program $main::config->{FingerProg} to finger $addr");

	# use the external finger program
	if (!-x $main::config->{FingerProg})
	{
	    main::log($main::LOG_ERR, "$main::config->{FingerProg} is not executable. Please check the value of FingerProg in your configuration file");
	    return;
	}

	my $fingerh;
	if (!open($fingerh, '-|', "$main::config->{FingerProg} $addr"))
	{
	    &main::log($main::LOG_ERR, "Could not open $main::config->{FingerProg}: $!");
	    return;
	}

	while (<$fingerh>)
	{  
	    push(@lines, $_);
	}
	close($fingerh);
	
	my $result = $?; # so we dont lose it due sigchld hadlers
	if ($result)
	{
	    &main::log($main::LOG_ERR, "The command '$main::config->{FingerProg} $addr' failed with error $result. Please check the value of FingerProg in your configuration file");
	    return;
	}
    }
    else
    {
	if (!eval{require Net::Finger;})
	{
	    main::log($main::LOG_ERR, "Need Net::Finger to finger $addr, but it is not installed.");
	    return;
	}

	# use the internal finger client
	&main::log($main::LOG_DEBUG, "Using Net::Finger to finger $addr");

	@lines = Net::Finger::finger($addr);
	if ($Net::Finger::error)
	{
	    &main::log($main::LOG_ERR, "The Net::Finger failed with: $Net::Finger::error");
	    return;
	}
    }
    return (1, @lines);
}

#####################################################################
# Translate incoming RADIUS attributes to the common internal presentations
sub translateVSAsIn
{
    my ($vsa_vendor, $vsa_type, $translate_vsa_in, $p) = @_;

    main::log($main::LOG_DEBUG, "Translating RADIUS attributes from $vsa_vendor" . (($vsa_type) ? "/$vsa_type" : '') . " to OSC", $p);

    my $nas = getNasClass($vsa_vendor) || return;
    $nas->translateVSAsIn($vsa_type, $translate_vsa_in, $p);

    return;
}

####################################################################
# Translate outgoing RADIUS attributes from the common internal presentations
# $op, if defined, is the destination object for the translated attribute
sub translateVSAsOut
{
    my ($vsa_vendor, $vsa_type, $translate_vsa_out, $p, $op) = @_;

    main::log($main::LOG_DEBUG, "Translating RADIUS attributes from OSC to $vsa_vendor" . (($vsa_type) ? "/$vsa_type" : ''), $p);

    my $nas = getNasClass($vsa_vendor) || return;
    $nas->translateVSAsOut($vsa_type, $translate_vsa_out, $p, $op);

    return;
}

####################################################################
# Load the NAS/NasType.pm
sub getNasClass
{
    my ($nas_type) = @_;

    # Strip all atypical characters
    $nas_type =~ s/[^a-z0-9_-]//ig;

    return $Radius::Nas::NasClasses{$nas_type} if exists $Radius::Nas::NasClasses{$nas_type};
    my $class = "Radius::Nas::${nas_type}";
    my $path = Radius::Util::classname_to_path($class);
    main::log($main::LOG_DEBUG, "Radius::Nas loads $class");
    if (eval{require $path;})
    {
        $Radius::Nas::NasClasses{$nas_type} = $class->new();
    }
    else
    {
        main::log($main::LOG_ERR, "Radius::Nas could not load NAS module $class: $@");
    }

    return $Radius::Nas::NasClasses{$nas_type};
}

1;
