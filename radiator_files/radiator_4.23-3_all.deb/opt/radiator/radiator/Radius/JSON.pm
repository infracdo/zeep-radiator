# JSON.pm
#
# JSON wrapper module. This module tries to load various JSON modules and
# exports encode_json and decode_json from those modules.
#
# In this way module author can 'use Radiator::JSON' and check if any JSON
# module was found by querying Radiator::JSON::is_enabled().
#
# Original idea was adopted from JSON::MaybeXS.
#
# Author: Janne Redsven (janne@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$
package Radius::JSON;
use strict;
use warnings;
use base qw(Exporter);
use Radius::Log;

our @EXPORT_OK = qw(encode_json decode_json);

# RCS version number of this module
$Radius::JSON::VERSION = '$Revision$';

sub _choose_json_module {
    # Check if JSON module is already in INC
    return 'Cpanel::JSON::XS' if $INC{'Cpanel/JSON/XS.pm'};
    return 'JSON'             if $INC{'JSON.pm'};
    return 'JSON::XS'         if $INC{'JSON/XS.pm'};
    return 'JSON::PP'         if $INC{'JSON/PP.pm'};

    # Try to load different JSON modules
    return 'Cpanel::JSON::XS' if eval { require Cpanel::JSON::XS; 1; };

    return 'JSON' if eval { require JSON; 1; }; ## no critic (Freenode::DiscouragedModules)

    return 'JSON::XS' if eval { require JSON::XS; 1; }; ## no critic (Freenode::DiscouragedModules)

    return 'JSON::PP' if eval { require JSON::PP; 1; };

    main::log_buffered($main::LOG_ERR, "JSON: Could not load any JSON module: Cpanel::JSON::XS, " .
		                               "JSON, JSON::XS, JSON:PP");

    return;
}

BEGIN {
    our $JSON_Class = _choose_json_module();
    $JSON_Class->import(qw(encode_json decode_json)) if defined $JSON_Class;
}

# Provide OO interface
sub new {
    my (undef, @args) = @_;
    my %params = scalar @args == 1 ? %{$args[0]} : @args;
    my $new = (our $JSON_Class)->new;
    $new->$_($params{$_}) for keys %params;
    return $new;
}

# Return the name of JSON backend
sub json_backend
{
    return (our $JSON_Class);
}

# Add possibility to query whether JSON backend was found
sub is_enabled
{
    return (defined our $JSON_Class) ? 1 : 0;
}

1;
