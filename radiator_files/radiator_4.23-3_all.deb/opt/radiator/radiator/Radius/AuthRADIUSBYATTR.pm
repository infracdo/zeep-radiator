# AuthRADIUSBYATTR.pm
#
# Object for sending a RADIUS packet to a remote RADIUS server
# based on attributes defined in a packet.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AuthRADIUSBYATTR;
use strict;
use warnings;
our @ISA = qw(Radius::AuthRADIUS);
use Radius::AuthRADIUS;
use Radius::Util;

%Radius::AuthRADIUSBYATTR::ConfigKeywords =
(
 'HostsInfoAttribute' =>
 ['string', 'Name of an attribute in a request which contains Host information. Format for a value is: host1,secret,authport,acctport,dynauthport,dynauthsecret;host2,secret,authport,acctport,dynauthport,dynauthsecret', 1],

 'HostParamDef' =>
 ['stringhash', 'List of parameter definitions for Radius Hosts. Format is: HostParamDef  hostkeyword,radiusattributename[,defaultvalue]', 1],
);

# RCS version number of this module
$Radius::AuthRADIUSBYATTR::VERSION = '$Revision$';

sub initialize {
    my ($self) = @_;

    $self->SUPER::initialize();

    # Formatted Attribute containing multiple hosts;
    # overrides Host, Secret, AuthPort, AcctPort and DynAuthPort definitions
    $self->{HostsInfoAttribute} = 'RadiusHosts';
    $self->{ParamSeparator} = ',';
    $self->{HostSeparator} = ';';

    return;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();
    return;
}

sub chooseHost
{
    my ($self, $fp, $p) = @_;

    # Initialize or increment hostCounter
    $fp->{hostCounter} = defined($fp->{hostCounter}) ? ++$fp->{hostCounter} : 0;

    # Initialize hosts list from Radius Attributes
    # Check for HostsInfoAttribute data or else use HostParamDef
    my $hosts_info = $self->{HostsInfoAttribute} ? $p->get_attr($self->{HostsInfoAttribute}) : undef;

    my ($hostname, $secret, $authport, $acctport, $dynauthport, $dynauthsecret);
    if ($hosts_info && $hosts_info ne '')
    {
	my @hosts = split($self->{HostSeparator}, $hosts_info);
	my $hostcount = scalar @hosts;

	# If hostCounter > number of hosts then return, indicating
	# no more available hosts to send to
	return if $fp->{hostCounter} >= $hostcount;

	# Parse hostinfo and return next target host
	($hostname, $secret, $authport, $acctport, $dynauthport, $dynauthsecret) = split($self->{ParamSeparator}, @hosts[$fp->{hostCounter}]);
    }

    # Parse HostParamDef
    my %args;
    if (defined $self->{HostParamDef})
    {
	foreach my $keyword (keys %{$self->{HostParamDef}})
	{
	    my $attribute = $self->{HostParamDef}{$keyword};

	    # assign Host, Secret, AuthPort, AcctPort, DynAuthPort, DynAuthSecret if not defined by HostsInfoAttribute
	    if (($attribute eq 'Host') && (!defined $hostname || $hostname eq ''))
	    {
		my @hosts = split($self->{HostSeparator}, $p->get_attr($attribute));
		my $hostcount = scalar @hosts;

		# if hostCounter > number of hosts then return, indicating
		# no more available hosts to send to
		return if $fp->{hostCounter} >= $hostcount;

		$hostname = @hosts[$fp->{hostCounter}] if $hostcount;
	    }
	    elsif (($attribute eq 'Secret') && (!defined $secret || $secret eq ''))
	    {
		$secret = $p->get_attr($attribute);
	    }
	    elsif (($attribute eq 'AuthPort') && (!defined $authport || $authport eq ''))
	    {
		$authport = $p->get_attr($attribute);
	    }
	    elsif (($attribute eq 'AcctPort') && (!defined $acctport || $acctport eq ''))
	    {
		$acctport = $p->get_attr($attribute);
	    }
	    elsif (($attribute eq 'DynAuthPort') && (!defined $dynauthport || $dynauthport eq ''))
	    {
		$dynauthport = $p->get_attr($attribute);
	    }
	    elsif (($attribute eq 'DynAuthSecret') && (!defined $dynauthsecret || $dynauthsecret eq ''))
	    {
		$dynauthsecret = $p->get_attr($attribute);
	    }
	    else
	    {
		# Assign additional Host attributes.
		# Format: attributename[,defaultvalue]
		# Prefer value of attributename in request and default
		# to HostParamDef configured value. If neither is
		# available, use nothing. Any default set by parent is
		# then used.
		my @param_def = split(m/,/s, $attribute, 2);
		my $val; $val = $p->get_attr($param_def[0]) if @param_def;
		$val = $param_def[1] if (! defined $val) && defined $param_def[1];
		$args{$keyword} = $val if defined $val;
	    }
	}
    }

    # Set identifier for current host
    if ($hostname && $hostname ne '')
    {
	$args{Identifier} = $hostname . '_' . $authport . '_' . $acctport;
    }
    else
    {
	# return if no host information found
	return $self->SUPER::chooseHost($fp, $p);
    }

    my $host = Radius::Host->new
	(undef, $hostname,
	 'Secret'                     => $secret,
	 'AuthPort'                   => $authport,
	 'AcctPort'                   => $acctport,
	 'DynAuthPort'                => $dynauthport,
	 'DynAuthSecret'              => $dynauthsecret,
	 'Parent'                     => $self,
	 %args
	);
    return unless $host;
    $host->activate();

    if (defined $host->{Address})
    {
        return $host;
    }

    return;
}

# Override so that we can rewrite the username
# and handle request attribute changes
sub sendHost
{
    my ($self, $host, $fp, $p) = @_;

    # Rewrite the user name if required
    my $name = $fp->getUserName;
    if (length $host->{RewriteFunction})
    {
	($name) = $self->runHook('RewriteFunction', $fp, $name);
	$fp->changeUserName($name);
	$self->log($main::LOG_DEBUG, "RewriteFunction rewrote user name to $name", $fp);
    }
    elsif (length $host->{RewriteUsername})
    {
	$name = $fp->rewriteUsername($host->{RewriteUsername});
    }

    # Strip HostsInfoAttribute
    $fp->delete_attr($self->{HostsInfoAttribute}) if $self->{HostsInfoAttribute};

    # Add and strip attributes before forwarding.
    map {$fp->delete_attr($_)} (split(m/\s*,\s*/s, $host->{StripFromRequest}))
	if defined $host->{StripFromRequest};

    $fp->delete_attr_fn
	(sub {return $_[0] =~ m/^Unknown/s; })    # Possibly strip attributes that were not known in dictionary
	if (!$main::config->{ProxyUnknownAttributes} && $p->{UnknownAttributeCount});

    $fp->delete_attr_fn
	(sub {
	    !grep{ $_[0] eq $_ } split(m/\s*,\s*/s, $host->{AllowInRequest});
	 }) if defined $host->{AllowInRequest};

    $fp->parse(Radius::Util::format_special($host->{AddToRequest}, $p))
	if (defined $host->{AddToRequest});

    $fp->parse_ifnotexist(Radius::Util::format_special($host->{AddToRequestIfNotExist}, $p))
	if defined $host->{AddToRequestIfNotExist};

    return $self->SUPER::sendHost($host, $fp, $p);
}

1;
