# StatsLogGeneric.pm
#
# Generic module for logging statistics
# Traverses the object hierarchy from ServerConfig on down, 
# loging the contents of the
# Statistics hash for each type of object that has one
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002 Open System Consultants
# $Id$

package Radius::StatsLogGeneric;
use strict;
use warnings;
our @ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Select;

%Radius::StatsLogGeneric::ConfigKeywords =
('Interval' => 
 ['integer', 'This is the time interval (in seconds) between each set of statistics. Defaults to 600 seconds (10 minutes).', 1],

 'RateCalculationInterval' =>
 ['integer', 'Sometimes you may want to calculate packet rates that are different from the value of Interval. RateCalculationInterval is an optional parameter that defines the time interval (in seconds) in which the packet rate is calculated. For example, if Interval is set to 600 seconds and RateCalculationInterval is set to 60, statistics is dumped in every 600 seconds but packet rate shows the average amount of packets in 60 second interval. Calculated example: Amount of packets in Interval (600 s) is 1000 pkts and RateCalculationInterval is one minute (60 s). (1000 pkts/10 min) * (60 s/min) / (600 s/10 min) = 100 pkts/min. RateCalculationInterval defaults to 1 (packets per second).', 1],

 'StatsType' =>
 ['enum', 'By default statistics produces counter (e.g. cumulative) values. You can specify the output type between cumulative, derivative, packet_rate and all. Cumulative counter shows the number of  processed packets. Derivative is the difference (delta) between two counter values in time interval. PPS is the amount of packets transferred within time interval (packets per second). Type all produces output from all available statistic types (cumulative, derivative and packet_rate). By default output type is cumulative.', 1, \@Radius::StatsLog::TypeEnum],

 'OutputFormat' =>
 ['enum', 'Format for the stats entries. Currently supported values are text and json. Default value is text.', 1, \@Radius::StatsLog::OutputTypeEnum],
);

# These are the official names and descriptions of various statistics
# we keep in each object listed in $p->StatsTrail
%Radius::StatsLogGeneric::statistic_names = (
    requests => 'Total requests',
    droppedRequests => 'Total dropped requests',
    duplicateRequests => 'Total duplicate requests',
    proxiedRequests => 'Total proxied requests',
    proxiedNoReply => 'Total proxied requests with no reply',
    badAuthRequests => 'Total Bad authenticators in requests',
    responseTime => 'Average response time',

    accessRequests => 'Access requests',
    dupAccessRequests => 'Duplicate access requests',
    accessAccepts => 'Access accepts',
    accessRejects => 'Access rejects',
    accessChallenges => 'Access challenges',
    malformedAccessRequests => 'Malformed access requests',
    badAuthAccessRequests => 'Bad authenticators in authentication requests',
    droppedAccessRequests => 'Dropped access requests',

    accountingRequests => 'Accounting requests',
    dupAccountingRequests => 'Duplicate accounting requests',
    accountingResponses => 'Accounting responses',
    malformedAccountingRequests => 'Malformed accounting requests',
    badAuthAccountingRequests => 'Bad authenticators in accounting requests',
    droppedAccountingRequests => 'Dropped accounting requests',
    );

$Radius::StatsLog::Type::Cumulative = "cumulative";
$Radius::StatsLog::Type::Derivative = "derivative";
$Radius::StatsLog::Type::PacketRate = "packet_rate";
$Radius::StatsLog::Type::All        = "all";

%Radius::StatsLog::TypeToCounter = (
    $Radius::StatsLog::Type::Cumulative => "cumulative_counters",
    $Radius::StatsLog::Type::Derivative => "derivative_counters",
    $Radius::StatsLog::Type::PacketRate => "packet_rates",
);

# Different StatsTypes we know.
@Radius::StatsLog::Types = ($Radius::StatsLog::Type::Cumulative, $Radius::StatsLog::Type::Derivative, $Radius::StatsLog::Type::PacketRate);

# StatsTypes enumeration including type "All" (not a type itself but a collection of all available types).
@Radius::StatsLog::TypeEnum = (@Radius::StatsLog::Types, $Radius::StatsLog::Type::All);

# RCS version number of this module
$Radius::StatsLogGeneric::VERSION = '$Revision$';

# Output type enumeration
@Radius::StatsLog::OutputTypeEnum = qw(text json);

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    # Default interval is 600 s.
    $self->{Interval} = 600;
    # Default rate calculation interval is 1 s, which results packets per second.
    $self->{RateCalculationInterval} = 1;

    # Default stats type is cumulative.
    $self->{StatsType} = $Radius::StatsLog::Type::Cumulative;

    # Initialize timestamp of "previous run" to be our start time.
    # Then we already have elapsed time on the first round of statistics.
    $self->{statistics}->{time_previous_run} = $main::statistics{start_time};

    # Initialize packet counter
    $self->{statistics}->{total_packets_previous} = 0;
    # Initialize packet rate
    $self->{statistics}->{packet_rate} = 0;

    # Set default OutputFormat
    $self->{OutputFormat} = 'text';

    # This allows registering new formatters later
    $self->{output_formatters} =
    {
	json => \&encode_to_json,
	text => sub { my ($self, $entry) = @_; return $entry; },
    };
}

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    # Check that calculation interval is on valid range.
    if ($self->{Interval} <= 0)
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Interval ($self->{Interval}) is invalid. Using default interval (600 s).");
	$self->{Interval} = 600;
    }

    # Check that rate calculation interval is on sensible range.
    if (($self->{RateCalculationInterval} > $self->{Interval}) ||
	($self->{RateCalculationInterval} <= 0))
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: RateCalculationInterval ($self->{RateCalculationInterval}) is invalid. Using default RateCalculationInterval (1 s).");
	$self->{RateCalculationInterval} = $self->{Interval};
    }

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Check that output formatter can be found
    # TODO: should module activation fail if output formatter can
    # not be initialized?
    $self->initialize_output_formatter();

    # Set the first timeout ready to go
    $self->{_timeouthandle} = &Radius::Select::add_timeout
	(time + $self->{Interval},
	 \&handle_timeout, $self);
}

#####################################################################
sub destroy
{
    my ($self) = @_;

    print "StatsLogGeneric destroy\n";
    &Radius::Select::remove_timeout($self->{_timeouthandle});
}

#####################################################################
# handle_timeout callback function
# This is called from within Select::process_timeouts
# Each time the time interval expires
sub handle_timeout
{
    my ($handle, $self) = @_;

    # Process statistics.
    $self->process_statistics();
    # Schedule the timeout again
    &Radius::Select::add_timeout
	(time + $self->{Interval}, \&handle_timeout, $self);
}

#####################################################################
# Package function to create an empty statistics store for an $object
sub make_object_statistics
{
    my ($object) = @_;

    my $s;
    $s->{$_} = 0 foreach keys (%Radius::StatsLogGeneric::statistic_names);

    return $s;
}

#####################################################################
# Perform the actual statistics processing. This function can be overloaded in modules
# which inherit StatsLogGeneric (e.g. DiaStatsLogGeneric).
sub process_statistics
{
    my ($self) = @_;
    # Calculate main packet rate in this StatsLog instance. $self is used to store values to allow
    # multiple StatsLog clauses in radiator config. Each clause can have different time interval.
    # Packet rates are calculated based on elapsed time and counter value from previous invocation
    # so in this way all StatsLog instances can perform calculations based on configured time interval.

    my $time_now = Radius::Util::getTimeHires();

    # The time elapsed between two rounds is saved so that it can be used in log* functions.
    $self->{statistics}->{time_elapsed} = $time_now - $self->{statistics}->{time_previous_run};

    # Prevent division by zero.
    return unless ($self->{statistics}->{time_elapsed} > 0);

    # Calculate rate calculation multiplier. In default case (see initialize()) multiplier is roughly 1/600 s
    # resulting packets per second.
    $self->{statistics}->{rate_calculation_multiplier} = $self->{RateCalculationInterval} / $self->{statistics}->{time_elapsed};
    $self->{statistics}->{packet_rate} = ($main::statistics{total_packets} - $self->{statistics}->{total_packets_previous}) / $self->{statistics}->{time_elapsed};

    $self->logAll();

    # Save packet counter and timestamp from this round so that difference can be calculated on next round.
    $self->{statistics}->{total_packets_previous} = $main::statistics{total_packets};
    $self->{statistics}->{time_previous_run} = $time_now;

    return;
}

#####################################################################
# Override this to get control before and after loging starts
sub logAll
{
    my ($self) = @_;

    # Log the ServerConfig stats and the stats of any objects within it
    # recursively
    $self->logObject($main::config);
    map $self->logObject($_), (@{$main::config->{Client}});
    map $self->logHandler($_), (@{$main::config->{Realm}}, @{$main::config->{Handler}});
}

#####################################################################
# Log all the Statistics from one object
# Override this to do the work of logging stats from a single
# object
sub logObject
{
    my ($self, $object) = @_;

    $self->log($main::LOG_ERR, "You did not override logObject() in StatsLogGeneric");
}

#####################################################################
sub logAuth
{
    my ($self, $object) = @_;

    $self->logObject($object);

    # Recurse inside AuthBy GROUP
    if ($object->isa('Radius::AuthGROUP'))
    {
	map $self->logAuth($_), (@{$object->{AuthBy}});
    }
    # Do the Hosts inside AuthBy RADIUS
    if ($object->isa('Radius::AuthRADIUS'))
    {
	map $self->logAuth($_), (@{$object->{Hosts}});
    }
}

#####################################################################
sub logHandler
{
    my ($self, $object) = @_;

    $self->logObject($object);

    # Do any AuthBys contained in here
    map $self->logAuth($_), (@{$object->{AuthBy}});
}

#####################################################################
# This function uses get_statistics to get all statistics attributes.
# if caller gives hash reference as a parameter, then values will
# be inserted to that.
sub get_all_statistics {
    my ($self, $object, $stats_href) = @_;
    my $stats = {};

    foreach (sort keys %Radius::StatsLogGeneric::statistic_names)
    {
	# First get statistics to particular key, then check whether we use
	# reference (mainly StatsLogREDIS) or not.
	my @val = $self->get_statistics($object, $_);
	if (defined $stats_href)
	{
	    $stats_href->{$Radius::StatsLog::TypeToCounter{$Radius::StatsLog::Type::Cumulative}}->{$_} = $val[0];
	    $stats_href->{$Radius::StatsLog::TypeToCounter{$Radius::StatsLog::Type::Derivative}}->{$_} = $val[1];
	    $stats_href->{$Radius::StatsLog::TypeToCounter{$Radius::StatsLog::Type::PacketRate}}->{$_} = $val[2];
	}
	else
	{
	    push @{$stats->{$Radius::StatsLog::Type::Cumulative}}, $val[0];
	    push @{$stats->{$Radius::StatsLog::Type::Derivative}}, $val[1];
	    push @{$stats->{$Radius::StatsLog::Type::PacketRate}}, $val[2];
	}
    }
    return $stats;
}

#####################################################################
# This function calculates statistics (packets per second, number of packets within time interval)
# for RADIUS objects (i.e. droppedAccessRequests) based on information from the previous run.
sub get_statistics
{
    my ($self, $object, $key, $return_hashref) = @_;

    my $current = my $delta = my $packet_rate = 0;

    # Proceed further if source data is available.
    if (exists $object->{Statistics}{$key} && $key ne 'responseTime')
    {
	# Get current counter value.
	$current = $object->{Statistics}{$key};

	# Initialize previous round counter on the first run. $object will be converted to string which is used as object identifier.
	$self->{statistics}->{statistics_previous}->{$object}->{$key} = 0 unless exists
	    $self->{statistics}->{statistics_previous}->{$object}->{$key};

	# Calculate difference between rounds to be used in counters and calculate packet rate.
	$delta = $current - $self->{statistics}->{statistics_previous}->{$object}->{$key};

	# Save counter value for this round to be used in the next round.
	$self->{statistics}->{statistics_previous}->{$object}->{$key} = $current;

	# Calculate packet rate. Rate calculation multiplier is calculated in handle_timeout().
	$packet_rate = $delta * $self->{statistics}->{rate_calculation_multiplier};
    }

    # responseTime (Average response time (seconds) is not counter so give the same value for each counter type.
    $delta = $packet_rate = $current = $object->{Statistics}{$key}
    if $key eq 'responseTime' && exists $object->{Statistics}{$key};

    # 1) check that caller did not give hashref.
    # 2) If we have hashref, check which StatsType is enabled and act based on that.
    if (defined $return_hashref)
    {
	if ($self->{StatsType} eq $Radius::StatsLog::Type::All)
	{
	    $return_hashref->{$Radius::StatsLog::TypeToCounter{$Radius::StatsLog::Type::Cumulative}}->{$key} = $current;
	    $return_hashref->{$Radius::StatsLog::TypeToCounter{$Radius::StatsLog::Type::Derivative}}->{$key} = $delta;
	    $return_hashref->{$Radius::StatsLog::TypeToCounter{$Radius::StatsLog::Type::PacketRate}}->{$key} = $packet_rate;
	}
	else
	{
	    $return_hashref->{$key} = $current	   if $self->{StatsType} eq $Radius::StatsLog::Type::Cumulative;
	    $return_hashref->{$key} = $delta	   if $self->{StatsType} eq $Radius::StatsLog::Type::Derivative;
	    $return_hashref->{$key} = $packet_rate if $self->{StatsType} eq $Radius::StatsLog::Type::PacketRate;
	}
	return;
    }

    # Return if cumulative was requested.
    return $current if $self->{StatsType} eq $Radius::StatsLog::Type::Cumulative;

    # Return if derivative was requested.
    return $delta if $self->{StatsType} eq $Radius::StatsLog::Type::Derivative;

    # Return if derivative was requested.
    return $packet_rate if $self->{StatsType} eq $Radius::StatsLog::Type::PacketRate;

    # Return list of counter values if type is "all".
    return ($current, $delta, $packet_rate) if ($self->{StatsType} eq $Radius::StatsLog::Type::All) && wantarray;
}

#####################################################################
# Checks that output format can be handled correctly.
sub initialize_output_formatter
{
    my ($self) = @_;
    if (lc($self->{OutputFormat}) eq 'json')
    {
	eval { require JSON };
	if ($@)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Could not find JSON library: $!");
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Defaulting to text output.");
	    $self->{OutputFormat} = 'text';
	}
    }
}

#####################################################################
# This function formats the output to the format specified in 
# $self->{OutputFormat}
# It allows classes to define their own formatter functions for i.e.
# JSON
sub format_output
{
    my ($self, $entry) = @_;
    my $output_format = lc($self->{OutputFormat});
    my $formatter = $self->{output_formatters}->{$output_format};
    return &{$formatter}($self, $entry);
}

#####################################################################
# Encode input to JSON format
sub encode_to_json
{
    my ($self, $entry) = @_;

    my $encoded;
    # Check if entry type is either reference or scalar value. By
    # default, references other than array or hash are not allowed for JSON
    # encoding.
    if (ref($entry) eq 'HASH' || ref($entry) eq 'ARRAY')
    {
	eval { $encoded = JSON::encode_json($entry) };
    }
    elsif (ref($entry) eq '')
    {
	eval { $encoded = JSON->new->utf8->allow_nonref->encode($entry) };
    }
    else
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Incorrect entry type for JSON encoder: " . ref($entry));
    }
    if ($@)
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: JSON encoding failed: $@");
	return;
    }

    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: JSON encoded entry is: " . $encoded)
	if (main::willLog($main::LOG_EXTRA_DEBUG));

    return $encoded;
}

1;
