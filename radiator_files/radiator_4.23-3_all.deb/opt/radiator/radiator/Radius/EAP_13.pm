# EAP_13.pm
#
# Radiator module for  handling Authentication via EAP type 13 (TLS)
# which uses certificates for the server to authenticate the client
# and possibly vice-versa.
#
# See RFCs 2869 2284 1994 2246 2716
#
# Requires Net_SSLeay.pm-1.20 or later
# Requires openssl 0.9.7 or later
# See example in goodies/eap_tls.cfg
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002 Open System Consultants
# $Id$

package Radius::EAP_13;
use Radius::TLS;
use strict;

# RCS version number of this module
$Radius::EAP_13::VERSION = '$Revision$';


#####################################################################
# Called by EAP.pm when the caller wants to know the EAP type name this class supports
sub type_name
{
    my ($classname) = @_;

    return 'TLS';
}

#####################################################################
# request
# Called by EAP.pm when a request is received for this protocol type
sub request
{
    my ($classname, $self, $context, $p, $data) = @_;

    Radius::TLS::contextSessionClear($context);
    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'Unexpected EAP request');
}

#####################################################################
# Called by EAP.pm when an EAP Response/Identity is received
sub response_identity
{
    my ($classname, $self, $context, $p) = @_;

    # Initialise our EAP context for use with TLS
    return ($main::REJECT, 'EAP TLS Could not initialise context') 
	unless &Radius::TLS::contextInit($context, $self, $p);

    # Forget the user structure for a previous auth
    $context->{tls_authenticated_user} = undef;

    # If verification had failed for a previous auth, allow sending alerts again
    $context->{verification_already_failed} = 0;

    # Require a valid client certificate
    $context->{ssl_verify_mode} |= (&Net::SSLeay::VERIFY_PEER | &Net::SSLeay::VERIFY_FAIL_IF_NO_PEER_CERT);

    # Ready to go: acknowledge with a TLS Start
    my $message = pack('C', $Radius::TLS::FLAG_START);
    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_TLS, $message);
    return ($main::CHALLENGE, 'EAP TLS Challenge');
}

#####################################################################
# Called by EAP.pm when an EAP Response (other than Identity)
# is received. Handles defragmenting packets. All the fragments
# are concatenated into $context->{data}, which will end up 
# a number of messages, each precended by a 4 byte length
sub response
{
    my ($classname, $self, $context, $p, $type, $typedata) = @_;

    if (!$context->{ssl})
    {
	# The client should start again with EAP Response/Identity
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP TLS Response for a closed session. Retransmitted?', $p);
    }

    if (defined $context->{ocsp_response_data})
    {
	return finish_handshake($self, $context, $p);
    }

    # Decode the typedata to get the TLS flags, 
    # the TLS message length (if present) and TLS data (in TLS record format)
    my ($flags) = unpack('C', $typedata);
    my ($tlsdata, $length);
    if ($flags & $Radius::TLS::FLAG_LENGTH_INCLUDED)
    {
	($flags, $length, $tlsdata) = unpack('C N a*', $typedata);
    }
    else
    {
	($flags, $tlsdata) = unpack('C a*', $typedata);
    }

    # Just finished with this request?
    my $handshake_just_finished; 

    # If we actually received anything
    if (length($tlsdata))
    {
	# TLS data is appended to SSL engine read BIO for processing:
	&Net::SSLeay::BIO_write($context->{rbio}, $tlsdata);
	
	if (!($flags & $Radius::TLS::FLAG_MORE_FRAGMENTS))
	{
	    # We have discovered that the user database _must_ be checked during
	    # certificate validation instead of after the TLS handshake is complete
	    # else Windows XP SP1 PEAP-TLS behaves strangely.
	    &Radius::TLS::set_verify($self, $context, sub {&verifyCallback($self, $context, $p, @_)}, sub {&verifyFailedCallback($self, $context, $p, @_)});

	    if ($self->{EAPTLS_OCSPStapling})
	    {
		Radius::TLS::set_ocsp_stapling_required($self, $context);
	    }

	    # We must have all of this message set,
	    # so continue with the accept. It will go as far as it can
	    # and maybe prompt us for more data
	    my $ret = &Net::SSLeay::accept($context->{ssl});
	    my $reason = &Net::SSLeay::get_error($context->{ssl}, $ret);
	    # Remove the callback to prevent thread problems that can cause crashes at exit.
	    &Radius::TLS::reset_verify($self, $context);
	    
	    if ($ret == 1)
	    {
		# Success, the SSL accept has completed successfully,
		# therefore the client has verified credentials.
		# However, there may be some more data in the output
		# BIO to send to the client, so we defer the ACCEPT
		# until it is acked
		Radius::TLS::get_session_info($context);
		$self->log($main::LOG_DEBUG, "EAP TLS Session accepted: $context->{EAPTLS_Session}->{Protocol} $context->{EAPTLS_Session}->{Cipher}", $p);
		my ($reuse_result, $reuse_reason) = Radius::TLS::contextSessionCheckReuse($self, $context, $p);
		unless ($reuse_result == $main::ACCEPT)
		{
		    Radius::TLS::contextSessionClear($context);
		    $self->eap_failure($p->{rp}, $context);
		    return ($reuse_result, $reuse_reason);
		}
		$handshake_just_finished++;
		$context->{handshake_finished}++;
	    }
	    elsif ($ret == 0)
	    {
		# Handshake was not successful
		my $errs_reason = Radius::TLS::get_errs_reason(&Net::SSLeay::print_errs());
		Radius::TLS::contextSessionClear($context);
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "EAP TLS Handshake unsuccessful: $errs_reason");
	    }
	    elsif ($reason == Net::SSLeay::ERROR_WANT_READ)
	    {
		# Looking for more data, just ack this
	    }
	    elsif ($reason == Net::SSLeay::ERROR_WANT_WRITE)
	    {
		# Looking for more data, just ack this
	    }
	    else
	    {
		# Error
		my $errs = &Net::SSLeay::print_errs();
		my $errs_reason = Radius::TLS::get_errs_reason($errs);
		my $state = &Net::SSLeay::get_state($context->{ssl});
		my $verify_result = &Net::SSLeay::get_verify_result($context->{ssl});
		if ($verify_result)
		{
                    if ($context->{verification_already_failed})
                    {
                        # Some EAP-TLS clients may continue resending
                        # TLS messages, possibly trying to restart TLS
                        # with client_hello after an TLS alert.
                        # Windows 7 is known to do this when it
                        # receives certain TLS alerts such as alert
                        # 48, 'Unknown CA'. We do not support
                        # restarting.
                        Radius::TLS::contextSessionClear($context);
                        $self->eap_failure($p->{rp}, $context);
                        $context->{verification_already_failed} = 0;
                        return ($main::REJECT, "EAP TLS Handshake unsuccessful, rejecting possible restart: $errs_reason", $p);
                    }

		    # Certificate verification failed, keep going
		    # so we tell the client what the problem was
		    my $verify_error_string = &Radius::TLS::verify_error_string($verify_result);
		    $self->log($main::LOG_INFO, "EAP TLS certificate verification failed: $verify_error_string, $errs", $p);

                    # Remember the error in case the client does not
                    # give up.
                    $context->{verification_already_failed}++;
                    my $sep = ($context->{reject_reason}) ? ', ' : '';
                    $context->{reject_reason} .= "$sep$verify_error_string, $errs_reason";
		}
		else
		{
		    # Serious TLS error, bail out
		    $self->log($main::LOG_ERR, "EAP TLS error: $ret, $reason, $state, $verify_result, $errs", $p);
		    &Radius::TLS::contextSessionClear($context);
		    $self->eap_failure($p->{rp}, $context);
		    return ($main::REJECT, "EAP TLS error: $errs_reason");
		}
	    }
	}
    }

    # If there are any bytes to send to the peer, get them and
    # package them, else just acknowledge this packet
    my $message;
    my $pending = &Net::SSLeay::BIO_pending($context->{wbio});
    if ($pending)
    {
	# In case we run e.g., inside PEAP, we must check outer frag size too.
	my $framedmtu = $p->get_attr('Framed-MTU'); 
	my $innerfragsize;
	$innerfragsize = $p->{outerRequest}->{EAPOuterFragSize} - 40
	    if defined $p->{outerRequest} && defined $p->{outerRequest}->{EAPOuterFragSize};
	my $maxfrag = $self->{EAPTLS_MaxFragmentSize};
	$maxfrag = $framedmtu if defined $framedmtu && $framedmtu < $maxfrag;	
	$maxfrag = $innerfragsize if defined $innerfragsize && $innerfragsize < $maxfrag;

	my $towrite = &Net::SSLeay::BIO_read($context->{wbio}, $maxfrag);
	my $flags;
	my $more_pending = &Net::SSLeay::BIO_pending($context->{wbio});
	$flags |= $Radius::TLS::FLAG_MORE_FRAGMENTS
	    if $more_pending;
	if ($context->{first_frag})
	{
	    $flags |= $Radius::TLS::FLAG_LENGTH_INCLUDED;
	    
	    $message = pack('C N a*', $flags, $pending, $towrite);
	}
	else
	{
	    $message = pack('C a*', $flags, $towrite);
	}

	# This tells us if the next fragment will be the first
	# of a new message set:
	$context->{first_frag} = $more_pending ? 0 : 1;
    }
    elsif ($handshake_just_finished || ($context->{handshake_finished} && (length($tlsdata) == 0)))
    {
	return finish_handshake($self, $context, $p);
    }
    elsif (length($tlsdata))
    {
	# Reply with an ACK
	$message = pack('C', 0); # ACK
    }
    else
    {
	# An ack, probably acknowledge an alert, now fail
	&Radius::TLS::contextSessionClear($context);
	$self->eap_failure($p->{rp}, $context);
	my $reason = $context->{reject_reason} || "";
	return ($main::REJECT, "TLS Alert acknowledged: $reason");
    }
    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_TLS, $message);
    return ($main::CHALLENGE, 'EAP TLS Challenge');

}

#####################################################################
# Finish handshake by authenticating the client
sub finish_handshake
{
    my ($self, $context, $p) = @_;

    # The handshake has successfully completed recently, so the client
    # certificate is correctly signed by a root with a short enough
    # certificate chain, and verifyCallback was happy with each one,
    # or maybe we are doing a session resumption
    my $peer = Net::SSLeay::get_peer_certificate($context->{ssl});
    if (!$peer)
    {
	Radius::TLS::contextSessionClear($context);
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP TLS No peer certificate');
    }

    if ($self->{EAPTLS_OCSPAsyncCheck})
    {
	my $ret;
	if (!defined $context->{ocsp_response_data})
	{
	    $ret = Radius::TLS::run_ocsp($context->{ssl}, $self, $peer, undef, $context, 1);
	    if (defined $ret)
	    {
		if ($ret == 2)
		{
		    Net::SSLeay::X509_free($peer);
		    return ($main::ASYNC, "EAP TLS asynchronous OCSP check started");
		}
	    }
	}
	# Allow unless strict mode configured
	elsif (defined $context->{ocsp_response_ret})
	{
	    unless ($self->{EAPTLS_OCSPStrict})
	    {
		$ret = 1;
	    }
	}
	else
	{
	    $ret = Radius::TLS::run_ocsp($context->{ssl}, $self, $peer, undef, $context);
	}

	if (!$ret)
	{
	    Net::SSLeay::X509_free($peer);
	    Radius::TLS::contextSessionClear($context);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, "EAP TLS certificate $context->{tls_authenticated_cn} OCSP status not good");
	}
    }

    Net::SSLeay::X509_free($peer); # get_peer_certificate increments the count

    my $authuser = $context->{tls_authenticated_user};
    $context->{tls_authenticated_user} = undef;
    if (!$authuser && !$self->{EAPTLS_NoCheckId})
    {
	# This is a session resumption, not a new session
	# Make sure the user we authenticated in the initial session
	# is still in our user database
	my ($user, $result, $reason) = $self->get_user($context->{tls_authenticated_cn}, $p);
	if (!$user || $result != $main::ACCEPT)
	{
	    Radius::TLS::contextSessionClear($context);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, "EAP TLS session resumed by user $context->{tls_authenticated_cn} is not authenticated: $reason");
	}
	$authuser = $user;
    }

    # Send the EAP success
    $p->{rp}->{inner_identity} = $context->{tls_authenticated_cn};
    $self->authoriseUser($authuser, $p) unless $self->{EAPTLS_NoCheckId};
    $self->adjustReply($p);
    $self->setTLSMppeKeys($context, $p, 'client EAP encryption');
    $self->eap_success($p->{rp}, $context);
    Radius::TLS::contextSessionAllowReuse($context);
    return ($main::ACCEPT, 'EAP TLS Success'); # Success, all done
}


#####################################################################
# This is called to verify each clertificate in the client certificate chain, 
# starting with the root. Return 0 if no error,
# else one X509_V_ERR_* from openssl/include/x509_vfy.h
# Returning 50 (X509_V_ERR_APPLICATION_VERIFICATION) triggers 
# TLS error 0x80090326 in Windows XP SP1 TLS client
sub verifyCallback
{
    my ($self, $context, $p, $x509_store_ctx) = @_;

    my $depth = Net::SSLeay::X509_STORE_CTX_get_error_depth($x509_store_ctx);
    if ($depth == 0)
    {
	# This is the peer certificate we need to check
	my $cert = Net::SSLeay::X509_STORE_CTX_get_current_cert($x509_store_ctx);
	my $subject_name = &Net::SSLeay::X509_get_subject_name($cert);
	my $subject = &Net::SSLeay::X509_NAME_oneline($subject_name);
	my $matchedcn;

	my $do_log = main::willLog($main::LOG_DEBUG, $p);
	Radius::TLS::log_certificate($self, $p, $cert, $subject) if $do_log;

	# Do OCSP verification when configured
	if ($self->{EAPTLS_OCSPCheck})
	{
	    if (!Radius::TLS::run_ocsp($context->{ssl}, $self, $cert))
	    {
		$context->{reject_reason} = "OCSP verification failed";
		$self->log($main::LOG_INFO, "EAP TLS client certificate subject $subject OCSP verification failed", $p);
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	}

	if (!$self->{EAPTLS_NoCheckId})
	{
	    my $username = $p->getUserName();
	    # Build a success request packet

	    # Strip off any DOMAIN or host/ , else the username may not match the cert
	    my $username_nodomain =  $username;
	    $username_nodomain =~ s/^(.*)\\//;
	    $username_nodomain =~ s/^host\///;
	    my $identity_nodomain = $context->{identity};
	    $identity_nodomain =~ s/^(.*)\\//;
	    $identity_nodomain =~ s/^host\///;


	    # Subject name could be in the form: /DC=com/DC=mtghouse/CN=Users/CN=vinny
	    # Extract all the CNs and make sure at least one of them matches
	    # Array of names following each CN=
	    my @cn = map {/CN=([^\/]+)/ ? $1 : ()} split(/\//, $subject);
	    foreach my $cn (@cn)
	    {
		# Maybe rewrite the certificate common name
		foreach my $rule (@{$self->{EAPTLSRewriteCertificateCommonName}})
		{
		    # We use an eval so an error in the pattern wont kill us.
		    eval("\$cn =~ $rule"); ## no critic (Perl::Critic::Policy::BuiltinFunctions::ProhibitStringyEval)
		    &main::log($main::LOG_ERR, "Error while rewriting certificate common name $cn: $@", $p) 
			if $@;
		    
		    &main::log($main::LOG_DEBUG, "Rewrote certificate common name to $cn", $p);
		}
		# The subject conversion can leave literal '\x00' where there were NUL chars in 
		# a Unicode CN string. Here we remove them to give the ASCII equivalent. 
		# Some CAs use Unicode iff there is an @ in the CN.
		$cn =~ s/\\x00//g;

		# If there is a hook, run it to see if the CN matches the 
		# username or whatever
		if (defined $self->{EAPTLS_CommonNameHook})
		{
		    ($matchedcn) = $self->runHook('EAPTLS_CommonNameHook', $p, $cn, $username, $context->{identity}, $p);
		    if (defined $matchedcn)
		    {
			&main::log($main::LOG_DEBUG, "Matched certificate CN $cn using EAPTLS_CommonNameHook", $p);
			last;
		    }
		}
		if (   $username eq $cn || $username_nodomain eq $cn 
		    || $context->{identity} eq $cn || $identity_nodomain eq $cn)
		{
		    &main::log($main::LOG_DEBUG, "Matched certificate CN $cn with User-Name $username or identity $context->{identity}", $p);
		    $matchedcn = $cn;
		    last;
		}
	    }

	    if (!defined $matchedcn)
	    {
		# Look for a SubjectAltName that might match
		# X509_get_subjectAltNames returns array of (type, string)
		# type == 0 is OTHERNAME, which might be a Windows UPN, as
		# per http://support.microsoft.com/kb/281245
		# For other types see openssl/x509v3.h GEN_*
		my @altnames = &Net::SSLeay::X509_get_subjectAltNames($cert);
		while (@altnames)
		{
		    my ($type, $name) = splice(@altnames, 0, 2);
		    
		    $self->log($main::LOG_DEBUG, "Checking subjectAltName type $type, value $name", $p);
		    if ($type == $Radius::TLS::NSL::GEN_OTHERNAME || $type == $Radius::TLS::NSL::GEN_EMAIL)
		    {
			if (   $username eq $name || $username_nodomain eq $name 
			       || $context->{identity} eq $name || $identity_nodomain eq $name)
			{
			    main::log($main::LOG_DEBUG, "Matched certificate subjectAltName type $type, value $name with User-Name $username or identity $context->{identity}", $p);
			    $matchedcn = $name;
			    last;
			}
		    }
		}
	    }

	    if (!defined $matchedcn)
	    {
		# Still no match
		$self->log($main::LOG_INFO, "EAP TLS client certificate subject $subject does not match user name $username or identity $context->{identity}", $p);
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }

	    # Make sure the user we authenticated is in our database too
	    my ($user, $result, $reason) = $self->get_user($matchedcn, $p);
	    if (!$user || $result != $main::ACCEPT)
	    {
		$context->{reject_reason} = $reason;
		$self->log($main::LOG_INFO, "EAP TLS Could not authenticate user $matchedcn: $reason", $p);
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	    $context->{tls_authenticated_user} = $user;
	    $context->{tls_authenticated_cn} = $matchedcn;
	    
	}

	if (defined $self->{EAPTLS_CertificateVerifyHook})
	{
	    ($matchedcn) = $self->runHook('EAPTLS_CertificateVerifyHook', $p, $matchedcn, $x509_store_ctx, $cert, $subject_name, $subject, $p);
	    if (!defined $matchedcn)
	    {
		$self->log($main::LOG_INFO, "EAPTLS_CertificateVerifyHook returned undefined", $p);
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	}
    }
    return 0;
}

#####################################################################
# This is called to verify each clertificate in the client certificate chain,
# starting with the root. Return 0 if no error,
# else one X509_V_ERR_* from openssl/include/x509_vfy.h
# or < 0 for a failure.
# Returning 50 (X509_V_ERR_APPLICATION_VERIFICATION) triggers
# TLS error 0x80090326 in Windows XP SP1 TLS client
sub verifyFailedCallback
{
    my ($self, $context, $p, $x509_store_ctx) = @_;

    my $depth = Net::SSLeay::X509_STORE_CTX_get_error_depth($x509_store_ctx);
    if ($depth == 0)
    {
	# The peer certificate we need to check again is not always
	# present. One example is policy OID mismatch.
	my $verify_error = Net::SSLeay::X509_STORE_CTX_get_error($x509_store_ctx);
	my $cert = Net::SSLeay::X509_STORE_CTX_get_current_cert($x509_store_ctx);
	my ($subject_name, $subject);
	if ($cert)
	{
	    $subject_name = Net::SSLeay::X509_get_subject_name($cert);
	    $subject = Net::SSLeay::X509_NAME_oneline($subject_name);
	}

	my $do_log = main::willLog($main::LOG_DEBUG, $p);
	if ($do_log)
	{
	    $self->log($main::LOG_DEBUG, "Certificate verification failure reason: " . Radius::TLS::verify_error_string($verify_error), $p);
	    $cert ?
		Radius::TLS::log_certificate($self, $p, $cert, $subject) :
		$self->log($main::LOG_DEBUG, "Can not log certificate details, no certificate available", $p);
	}

	if (defined $self->{EAPTLS_CertificateVerifyFailedHook})
	{
	    my ($result) = $self->runHook('EAPTLS_CertificateVerifyFailedHook', $p, $verify_error, $x509_store_ctx, $cert, $subject_name, $subject, $p);
	    if (!defined $result)
	    {
		$self->log($main::LOG_INFO, "EAPTLS_CertificateVerifyFailedHook returned undefined", $p);
		return $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION;
	    }
	    else
	    {
		return $result;
	    }
	}
    }

    # Return a failure
    return -1;
}

1;
