# SqlDb.pm
#
# Object for handling an SQL database. 
# Routines are provided to connect to a server (and fall back
# to alternates if not available.
# Also routines to do generic prepare/execute
#
# This module also implements database handle sharing: all instances
# that connect to the same database with the same username and password
# will share the same database connection
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::SqlDb;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Select;
use DBI;
use strict;

%Radius::SqlDb::ConfigKeywords = 
('DBSource'           => 
 ['stringarray', 
  'The data source name to use for each databse. This parameter is used by Perl DBI to specify the database driver and database system to connect to. It will usually begin with dbi:driver_name:. There is no standard for the text following the driver name. Consult the details for your DBD driver. Examples are dbi:mysql:radius, dbi:ODBC:Rodopi etc.', 
  0],

 'DBUsername'         => 
 ['stringarray', 
  'The SQL username to use to log in to each database, in the same order as the DBSource list', 0],

 'DBAuth'             => 
 ['stringarray', 
  'The password to use for each DBUsername to log in to each database, in the same order as the DBUsername list', 
  0],

 'Timeout'            =>
 ['integer', 
  'Specifies a timeout interval in seconds that Radiator will wait for when trying to contact the SQL server specified by DBAuth. If the server does not respond within the Timeout period, Radiator will consider the SQL server to be failed, and will stop trying to contact the SQL server until the FailureBackoffTime is expired
', 
  1],

 'FailureBackoffTime' => 
 ['integer', 'If Radiator detects an SQL server failure, it will wait for this number of seconds before trying to contact the SQL server again. ', 1],

 'SQLRetries' => 
 ['integer', 'When executing a query, Radiator will try up to SQLRetries attempts to execute the query, retrying if certain types of SQL error are seen. Defaults to 2.', 2],

 'DateFormat'         => 
 ['string', 
  'Specifies the format to be used to format dates for insertion into the AccountingTable. Any of the special % characters are permitted. Defaults to \'%b %e, %Y %H:%M\' (e.g. \'Sep 3, 1995 13:37\').', 1],

 'DisconnectAfterQuery' => ['flag', 'Forces this module to disconnect from SQL after each query.', 2],

 'SQLRecoveryFile'    => 
 ['string', '<b>This feature is known not to work as expected with some types of database. Its use is deprecated: you are strongly discouraged from using this feature. Support for it may be removed in future versions.</b><p>
This optional parameter specifies the name of a file where any failed SQL do queries will be logged, perhaps for later recovery. The default is no logging. The SQLRecoveryFile file is always opened written and closed for each failed SQL do query, so you can safely rotate it at any time. ', 3],

 'ConnectionHook'     => 
 ['hook', 
  'Specifies a Perl hook that will be run every time this clause (re)connects to the SQL database. This is most useful for executing func() to configure the database connection in customised ways.', 
  2],

 'ConnectionAttemptFailedHook' => 
 ['hook', 
  'Specifies a Perl hook that will be run whenever the module attempts to conent to an SQL database and fails to connect. The default just logs the failure.', 
  2],

 'NoConnectionsHook'           => 
 ['hook', 
  'Specifies a Perl hook that will be run whenever the module fails to connet to any SQL server. The default just logs the failure.', 
  2],
 'RoundRobinOnFailure'           => 
 ['flag', 
  'This flag specifies that in the event of a database failure or timeout, it will attempt to connect to the next database in the list, instead of going back to the first database in the list', 
  1],

 'AsynchronousSQL' =>
 ['flag', 'Query SQL asynchronously. Supported only by some database drivers.', 1],

 'AsynchronousSQLConnections' =>
 ['integer', 'When using AsynchronousSQL, defines a size of connection pool. Defaults to a single connection.', 1],

 'RoundRobinQueries' =>
 ['flag', 'Load balance SQL queries to all defined DBSources when AsynchronousSQL is enabled. By default, only one of defined DBSources is used at the time.', 1],

 'ConnectSQLAtStartup' =>
 ['flag', 'Connect to SQL immediately when Radiator starts. By default, first connection to SQL is made when SQL is first time queried.', 1],
 );

# RCS version number of this module
$Radius::SqlDb::VERSION = '$Revision$';

# This is a hash of "$dbsource;$dbusername;$dbauth-rr-nxxxx" to database handle
# that allows multiple instances to share handles
%Radius::SqlDb::handles = ();

# This is a hash of "$dbsource;$dbusername;$dbauth" to DBSource ordinal numbers.
%Radius::SqlDb::handle_ids = ();

# This is a hash of "$dbsource;$dbusername;$dbauth-rr-nxxxx" to prepared statements
# that allows multiple instances to share prepared statements
%Radius::SqlDb::statements = ();

# This is an array of strings representing SQL connections for a
# DBSource, indexed by the DBSource's ordinal number. One string
# exists for each DBSource.
# Each string position designates a connection number. The value for a
# position is '0' for a free connection and '1' for an occupied one.
@Radius::SqlDb::async_conns = ();

# This is an array for caching that is indexed similarly to
# async_conns above. If a value is defined, it's the most recently
# used free async connection number for the DBSource.
@Radius::SqlDb::free_async_conn = ();

# Callbacks waiting for a database replies.
@Radius::SqlDb::callbacks = ();

#
# Define the maximum number of cached prepared statements
#
$Radius::SqlDb::MAX_CACHED_PREPARED_STATEMENTS = 32;


#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    # For logging
    my $type = ref($self);
    my $identifier = (defined $self->{Identifier}) ? $self->{Identifier} : '';

    $self->log($main::LOG_WARNING, "No DBSource defined for $type '$identifier' in '$main::config_file'")
	unless @{$self->{DBSource}};

    if ($self->{AsynchronousSQLConnections} > 9999)
    {
	$self->log($main::LOG_WARNING, "$type '$identifier' has too many AsynchronousSQLConnections $self->{AsynchronousSQLConnections} > 9999 configured, reducing number of connections to 9999.");
	$self->{AsynchronousSQLConnections} = 9999;
    }

    if ($self->{AsynchronousSQL})
    {
	if ($self->{Timeout} < 2)
	{
	    $self->log($main::LOG_WARNING, "$type '$identifier' has too low Timeout value $self->{Timeout} < 2 configured, increasing timeout value for connections to 2 seconds.");
	    $self->{Timeout} = 2;
	}
    }

    $self->SUPER::check_config();
    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    for (my $i = 0; $i < scalar @{$self->{DBSource}}; $i++)
    {
	# Check whether DBSource has been already been defined
	my $dbname = $self->getDbName($i);
	my $id = $#Radius::SqlDb::async_conns + 1;
	if (exists $Radius::SqlDb::handle_ids{$dbname})
	{
	    # For logging
	    my $type = ref($self);
	    my $identifier = (defined $self->{Identifier}) ? $self->{Identifier} : '';

	    $id = $Radius::SqlDb::handle_ids{$dbname};

	    my $conns = length($Radius::SqlDb::async_conns[$id]);
	    if ($self->{AsynchronousSQLConnections} > $conns)
	    {
		$self->log($main::LOG_WARNING, "$type '$identifier' has greater AsynchronousSQLConnections defined for '$self->{DBSource}[$i]', increasing size of a connection pool.");
		$Radius::SqlDb::async_conns[$id] = $Radius::SqlDb::async_conns[$id] . ("0" x ($self->{AsynchronousSQLConnections} - $conns));
	    }
	    elsif ($self->{AsynchronousSQLConnections} < $conns)
	    {
		$self->log($main::LOG_WARNING, "$type '$identifier' has DBSource '$self->{DBSource}[$i]' defined which already has a connection pool greater than $self->{AsynchronousSQLConnections} connections defined, increasing AsynchronousSQLConnections to $conns connections.");
		$self->{AsynchronousSQLConnections} = $conns;
	    }
	}
	else
	{
	    $Radius::SqlDb::handle_ids{$dbname} = $id;
	    $Radius::SqlDb::async_conns[$id] = "0" x $self->{AsynchronousSQLConnections};
	}
    }

    if ($self->{ConnectSQLAtStartup})
    {
	# For logging
	my $type = ref($self);
	my $identifier = (defined $self->{Identifier}) ? $self->{Identifier} : '';

	# Create one connection for synchronous use and the required
	# number of connections for asynchronous use.
	my $async_connections = ($self->{AsynchronousSQL}) ? $self->{AsynchronousSQLConnections} : 0;
	for (my $i = 0; $i < scalar @{$self->{DBSource}}; $i++)
	{
	    my $dbname = $self->getDbName($i);
	    my $id = $Radius::SqlDb::handle_ids{$dbname};

	    # We start from -1 to reserve connection 00000 for synchronous queries.
	    my $conn_id_str = '00000';
	    for (my $j = -1; $j < $async_connections; $j++)
	    {
		if ($j >= 0)
		{
		    $conn_id_str = 10000 + $j;
		    $self->{sqldb_async_query} = 1;
		    $self->{sqldb_async_conn_id} = $j;
		}
		$self->{dbname} = undef;
		if ($self->reconnect($i))
		{
		    $self->log($main::LOG_DEBUG, "$type '$identifier' Connected to SQL DB '$self->{dbsource}'");
		}
		else
		{
		    $self->log($main::LOG_ERR, "$type '$identifier' Connection to SQL DB failed '$self->{dbsource}'");
		}
		$self->{sqldb_async_query} = 0;
	    }
	    $Radius::SqlDb::free_async_conn[$id] = 0;
	}
    }

    # Make sure we start from the first configured DBSource
    $self->{roundrobin_counter} = 0;
    $self->{dbname} = undef;
}

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initalze 
# instance variables
# that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    # Empty arrays for database details
    $self->{DBSource}   = [];
    $self->{DBUsername} = [];
    $self->{DBAuth}     = [];
    $self->{Timeout}    = 60; # Seconds
    $self->{SQLRetries} = 2;
    $self->{FailureBackoffTime} = 600; # Seconds
    $self->{DateFormat} = '%b %e, %Y %H:%M'; # eg 'Sep 3, 1995 13:37'

    ## no critic (ValuesAndExpressions::RequireInterpolationOfMetachars)
    $self->set("ConnectionAttemptFailedHook",
               'sub {
                      my $self = shift;
                      my $dbsource = shift;
                      my $dbusername = shift;
                      my $dbauth = shift;

	              # If the connect failed, we get an exception, with
	              # the message in $@
 	              $self->log($main::LOG_ERR, "Could not connect to SQL database with DBI->connect $dbsource, $dbusername, **obscured**: $@ $DBI::errstr");
                     }');

    $self->set("NoConnectionsHook",
               'sub { 
                      my $self = shift;

	              $self->log($main::LOG_ERR, "Could not connect to any SQL database. Request is ignored. Backing off for $self->{FailureBackoffTime} seconds");
                     }');
    ## use critic

    $self->{AsynchronousSQL} = 0;
    $self->{AsynchronousSQLConnections} = 1;

    $self->{sqldb_async_query} = 0;

    $self->{backoff_until} = 0;
    $self->{roundrobin_counter} = 0;
}

#####################################################################
# reconnect
# Connect or reconnect to a database
# Returns true if there is a viable database connection available
sub reconnect
{
    my ($self, $dbsource_index) = @_;

    # Implement backoff strategy in case of database failure
    return 0 if time < $self->{backoff_until};

    # Maybe restart at the first one or use the one we're told
    $self->{roundrobin_counter} = 0 unless ($self->{RoundRobinOnFailure} || ($self->{RoundRobinQueries} && $self->{AsynchronousSQL}));
    $self->{roundrobin_counter} = $dbsource_index if defined $dbsource_index;

    # async dbnames have postfix "-1xxxx" and
    # sync  dbnames have postfix "-00000"
    my $postfix = '00000';
    if ($self->{sqldb_async_query})
    {
	$postfix = 10000 + $self->{sqldb_async_conn_id};
    }
    if ($self->{dbname})
    {
	substr($self->{dbname}, -5, 5, $postfix);
	substr($self->{dbsource}, -5, 5, $postfix);
    }

    if (!$self->{dbname} || !$Radius::SqlDb::handles{$self->{dbname}})
    {
	#print "Reconnecting to $self->{dbname}\n";
	# A new connection is required, try all the 
	# ones in the $self->{DBSource} in order til we 
	# find either an existing shared one, or a can create
	# a new connection
	my $i;
	my $database_count = @{$self->{DBSource}};
	for ($i = 0; $i < $database_count; $i++)
	{
	    my ($dbsource, $dbusername, $dbauth) 
		= ($self->{DBSource}[$self->{roundrobin_counter}], 
		   $self->{DBUsername}[$self->{roundrobin_counter}],
		   $self->{DBAuth}[$self->{roundrobin_counter}]);
	    $dbsource = &Radius::Util::format_special($dbsource, undef, $self);
	    $dbusername = &Radius::Util::format_special($dbusername, undef, $self);
	    $dbauth = &Radius::Util::format_special($dbauth, undef, $self);

	    my $dbname = "$dbsource;$dbusername;$dbauth";
	    my $dbsource_id = $Radius::SqlDb::handle_ids{$dbname};
	    $self->{dbsource} = "$dbsource Connection id: $dbsource_id-$postfix";
	    $self->{dbname} = "$dbname-" . $postfix;

	    unless ($self->{RoundRobinQueries} && $self->{AsynchronousSQL} && $self->{sqldb_async_query})
	    {
		$self->{roundrobin_counter} = ($self->{roundrobin_counter} + 1) % $database_count;
	    }
	    return 1
		if $Radius::SqlDb::handles{$self->{dbname}};

	    $self->log($main::LOG_DEBUG, "Connecting to '$self->{dbsource}'");
	    # We evaluate the connection 
	    # with an alarm for the timeout period
	    # pending. If the alarm goes off, the eval will die
	    &Radius::Util::exec_timeout($self->{Timeout},
		    sub {
			eval {
			    $Radius::SqlDb::handles{$self->{dbname}}
			    = DBI->connect($dbsource,
					   $dbusername,
					   $dbauth,
					   { PrintError => 0 });
			};
			if ($@)
			{
			    $self->log($main::LOG_ERR, ref($self) . " $self->{Identifier}: SQL connection to '$dbsource' failed: $@");
			}
		    });

	    if ($Radius::SqlDb::handles{$self->{dbname}})
	    {
		$Radius::SqlDb::handles{$self->{dbname}}->{AutoCommit} = 1;
		# This one stops DBD-Sybase finish causing hangs
		# in MS-SQL, see Sybase.pm in DBD-Sybase.
		$Radius::SqlDb::handles{$self->{dbname}}->{syb_flush_finish} = 1;

		# A work around for missing timeouts on Windows
		$Radius::SqlDb::handles{$self->{dbname}}->{odbc_query_timeout} = $self->{Timeout} if $^O eq 'MSWin32';

		# Call the ConnectionHook, if there is one
		$self->runHook('ConnectionHook', undef, $self, $Radius::SqlDb::handles{$self->{dbname}});

#		$Radius::SqlDb::handles{$self->{dbname}}->trace(15);

                delete $Radius::SqlDb::statements{$self->{dbname}};

		if ($self->{AsynchronousSQL} && $self->{sqldb_async_query})
		{
		    my $fd =  $self->getAsyncFd();
		    return 0 unless defined $fd;

		    Radius::Select::add_file($fd, 1, undef, undef, \&handle_socket_read, $self, $self->{dbsource}, $self->{dbname}, $dbsource_id, $self->{roundrobin_counter}, $self->{sqldb_async_conn_id});
		}

		return 1; # Database is available
	    }
	    $self->runHook('ConnectionAttemptFailedHook', undef, $self, $dbsource, $dbusername, $dbauth);
	}
	$self->runHook('NoConnectionsHook', undef, $self);

	unless ($self->{AsynchronousSQL} && $self->{sqldb_async_query})
	{
	    $self->{backoff_until} = time + $self->{FailureBackoffTime};
	}

	return 0;  # Database is not available
    }
    return 1; # Database is still up

}

#####################################################################
# Turn a Unix epoch seconds count into an SQL format date
# of the format Sep 3, 1995 13:37
# Uses local time
# This is deprecated and will be removed one day soon
# use $self->formatDate() or
# Radius::Util::strftime($self->{DateFormat}) instead
sub formatSQLDate
{
    return Radius::Util::strftime('%b %e, %Y %H:%M', $_[0]);
}

# Format a date according to DateFormat
sub formatDate
{
    my ($self, $time) = @_;
    return Radius::Util::strftime($self->{DateFormat}, $time);
}

#####################################################################
# Convenience function to prepare and execute a query.
# If it fails to execute, complain, and try to reconnect and reexecute.
# If it still fails to execute, return undef, else a statement handle
# We keep a cache of the first MAX_CACHED_PREPARED_STATEMENTS statments
# that have bind variables, for the sake of the efficiency of the SQL server.
sub prepareAndExecute
{
    my ($self, $q, @bind_values) = @_;
    my ($attempts, $cached_sth, $sth, $rc);

    # Try to execute the query. If we fail due to database failure
    # try to reconnect and try again. If that also fails, give up
    while (!$sth && $attempts++ < $self->{SQLRetries})
    {
	if ($self->reconnect())
	{
	    $self->log($main::LOG_DEBUG, "Query to '$self->{dbsource}': '$q': @bind_values");
            $cached_sth = $sth = $Radius::SqlDb::statements{$self->{dbname}}{$q}
	        if @bind_values > 0;

	    # We evaluate the execution
	    # with an alarm for the timeout period
	    # pending. If the alarm goes off, the eval will die
	    my $prepare_options;
	    if ($self->{AsynchronousSQL} && $self->{sqldb_async_query})
	    {
		if ($self->{dbname} =~ /^dbi:mysql/i)
		{
		    $prepare_options->{async} = 1;
		}
		elsif ($self->{dbname} =~ /^dbi:pg/i)
		{
		    $prepare_options->{pg_async} = 1;
		}
	    }

	    &Radius::Util::exec_timeout($self->{Timeout},
		sub {
		$sth = $Radius::SqlDb::handles{$self->{dbname}}->prepare($q, $prepare_options)
		    if !$sth;
		$rc = $sth->execute(@bind_values) if $sth;
	    });


	    # Preparing a statement is a relatively expensive operation.
	    # Keep the statement around for future use.
	    #
	    if ((@bind_values > 0) && $sth && ($sth ne $cached_sth))
	    {
		my @tmp = keys %{$Radius::SqlDb::statements{$self->{dbname}}};
		
		# Cache the prepared statement only as long as we still have room
		$Radius::SqlDb::statements{$self->{dbname}}{$q} = $sth
		    if @tmp <= $Radius::SqlDb::MAX_CACHED_PREPARED_STATEMENTS;
	    }

	    # Some DBD drivers dont undef rc on DB failure
	    return $sth if $sth && $rc && !$DBI::err;
	    # If we got here, something went wrong
	    my $reason = $DBI::errstr;

	    # Primary key violation is not a cause for disconnection
	    return $sth if $reason =~ /violation/i
		          || $reason =~ /duplicate key/im
		          || $reason =~ /Duplicate entry/im
			  || $reason =~ /^ORA-00001/;
	    
	    $reason = "SQL Timeout" if $@ && $@ =~ /timeout/;
	    $reason = $@ unless defined $reason;
	    $self->log($main::LOG_ERR, "Execute failed for '$q': $reason");
	}
	# Hmm, failed prob due to database failure, try to reconnect
	# to an alternate
	$self->disconnect();
	$sth = undef;
    }
    return;
}

# Ready and call asynchronous prepareAndExecute query
sub prepareAndExecuteAsync
{
    my ($self, $q, $callback, $key, @bind_values) = @_;

    my ($dbsource_id, $conn_id) = $self->setAsyncConn();
    unless (defined $dbsource_id)
    {
	$self->log($main::LOG_ERR, "Asynchronous prepare and execute query failed: '$q': @bind_values");
	return;
    }

    my $sth = $self->prepareAndExecute($q, @bind_values);
    $self->{sqldb_async_query} = 0;
    if ($sth)
    {
	$Radius::SqlDb::callbacks[$dbsource_id]->{$conn_id} = [$callback, $key];
    }

    return $sth;
}

#####################################################################
# Convenience function to do a query.
# If it fails to execute, complain, and try to reconnect and reexecute up to MaxRetries times.
sub do
{
    my ($self, $q, @bind_values) = @_;
    my ($attempts, $rc, $reason);

    no warnings qw(uninitialized);

    while (!defined($rc) && $attempts++ < $self->{SQLRetries})
    {
	if ($self->reconnect())
	{
	    $self->log($main::LOG_DEBUG, "do query to '$self->{dbsource}': '$q': @bind_values");
	    # We evaluate the execution
	    # with an alarm for the timeout period
	    # pending. If the alarm goes off, the eval will die
	    my $do_options;
	    if ($self->{AsynchronousSQL} && $self->{sqldb_async_query})
	    {
		if ($self->{dbname} =~ /^dbi:mysql/i)
		{
		    $do_options->{async} = 1;
		}
		elsif ($self->{dbname} =~ /^dbi:pg/i)
		{
		    $do_options->{pg_async} = 1;
		}
	    }

	    &Radius::Util::exec_timeout($self->{Timeout},
                     sub {
			 $rc = $Radius::SqlDb::handles{$self->{dbname}}->do
			     ($q, $do_options, @bind_values);
		     });
	    $self->disconnect() if ($self->{DisconnectAfterQuery} && !$self->{sqldb_async_query});
	    if (!$rc)
	    {
		$reason = $DBI::errstr;
		$reason = "SQL Timeout" if $@ && $@ =~ /timeout/;
		$self->log($main::LOG_ERR, 
			   "do failed for '$q': $reason");
	    }
	    # Primary key violation is not a cause for disconnection
	    return $rc if defined $rc 
		          || $reason =~ /violation/i
		          || $reason =~ /duplicate key/im
		          || $reason =~ /Duplicate entry/im
			  || $reason =~ /^ORA-00001/;
	}
	# there was an error (as opposed to no rows affected)
	$self->disconnect();
    }

    # Failure, maybe log the query to a file
    $self->saveQueryToFile($q, $self->{SQLRecoveryFile})
	if defined $self->{SQLRecoveryFile};
    return;
}

# Ready and call asynchronous do query
sub doAsync
{
    my ($self, $q, $callback, $key, @bind_values) = @_;

    my ($dbsource_id, $conn_id) = $self->setAsyncConn();
    unless (defined $dbsource_id)
    {
	$self->log($main::LOG_ERR, "Asynchronous do query failed: '$q': @bind_values");
	return;
    }

    my $rc = $self->do($q, @bind_values);
    $self->{sqldb_async_query} = 0;
    if (defined $rc)
    {
	$Radius::SqlDb::callbacks[$dbsource_id]->{$conn_id} = [$callback, $key];
    }

    return $rc;
}

# Get our dbname
sub getDbName
{
    my ($self, $i) = @_;

    return unless defined $i;

    my ($dbsource, $dbusername, $dbauth) =
	($self->{DBSource}[$i],
	 $self->{DBUsername}[$i],
	 $self->{DBAuth}[$i]);

    $dbsource = Radius::Util::format_special($dbsource, undef, $self);
    $dbusername = Radius::Util::format_special($dbusername, undef, $self);
    $dbauth = Radius::Util::format_special($dbauth, undef, $self);

    return "$dbsource;$dbusername;$dbauth";
}

# Set our dbname and other variables for next asynchronous
# query. Returns nothing for failure or the selected index to DBSource
# array and connection identifier for the DBSource.
sub setAsyncConn
{
    my ($self) = @_;

    my ($database_count, $dbsource_id, $conn_id, $set_dbname);
    if ($self->{RoundRobinQueries})
    {
	$database_count = scalar @{$self->{DBSource}};
	unless (defined $self->{roundrobin_counter_prev})
	{
	    # init round robin counter with a random at the first time
	    $self->{roundrobin_counter} = int(rand($database_count));
	}
	else
	{
	    # then just increment it
	    $self->{roundrobin_counter} = ($self->{roundrobin_counter_prev} + 1) % $database_count;
	}

	$set_dbname++;
	$self->{roundrobin_counter_prev} = $self->{roundrobin_counter};
    }

    my $dbname = $self->getDbName($self->{roundrobin_counter});
    $dbsource_id = $Radius::SqlDb::handle_ids{$dbname};

    $conn_id = $Radius::SqlDb::free_async_conn[$dbsource_id];
    unless (defined $conn_id)
    {
	$conn_id = index($Radius::SqlDb::async_conns[$dbsource_id], '0');
	unless ($conn_id >= 0)
	{
	    if ($self->{RoundRobinQueries})
	    {
		$set_dbname++;
		for (my $i = 0; $i < $database_count; $i++)
		{
		    $dbsource_id = ($dbsource_id + 1) % $database_count;
		    $conn_id = index($Radius::SqlDb::async_conns[$dbsource_id], '0');
		    last if $conn_id >= 0;
		}
	    }
	    else
	    {
		$self->log($main::LOG_ERR, "No available SQL connections for asynchronous query");
		return;
	    }
	}

	$self->{roundrobin_counter} = $dbsource_id;
	$self->{roundrobin_counter_prev} = $dbsource_id;
    }

    $self->{sqldb_async_query} = 1;

    substr($Radius::SqlDb::async_conns[$dbsource_id], $conn_id, 1, '1');
    $Radius::SqlDb::free_async_conn[$dbsource_id] = undef;

    if ($set_dbname)
    {
	$dbname = $self->getDbName($self->{roundrobin_counter});

	# init dbname to match dbsource to be used
	$self->{dbname} = $dbname . $self->{roundrobin_counter} . "-1xxxx";
    }

    $self->{sqldb_async_conn_id} = $conn_id;

    return ($dbsource_id, $conn_id);
}

#####################################################################
# Save the text of an SQL query to a file, for later recovery
sub saveQueryToFile
{
    my ($self, $query, $file) = @_;

    &Radius::Util::append(&Radius::Util::format_special($file, undef, $self), $query . "\n");
}

#####################################################################
# Get a single row from a previously prepared handle, 
# with appropriate timeouts
sub getOneRow
{
    my ($self, $sth) = @_;

    my @row;
    &Radius::Util::exec_timeout($self->{Timeout},
       sub {
	   @row = $sth->fetchrow();
           $sth->finish;
       });
    
    $self->disconnect() if $self->{DisconnectAfterQuery};
    if ($@ && $@ =~ /timeout/)
    {
	# there was an error (as opposed to no rows affected)
	$self->disconnect();
	$self->log($main::LOG_ERR, "getOneRow timed out");
    }
    return @row;
}

#####################################################################
# Get a result of async query
sub getAsyncResult
{
    my ($self) = @_;

    my $res = 0;

    if ($self->{dbname} =~ /^dbi:mysql/i)
    {
	$res = $Radius::SqlDb::handles{$self->{dbname}}->mysql_async_result();
    }
    elsif ($self->{dbname} =~ /^dbi:pg/i)
    {
	$res = $Radius::SqlDb::handles{$self->{dbname}}->pg_result();
    }

    return $res;
}

# Get the fd that can be used for async query
sub getAsyncFd
{
    my ($self) = @_;

    my $fd;
    if ($self->{dbname} =~ /^dbi:mysql/i)
    {
	$fd = $Radius::SqlDb::handles{$self->{dbname}}->mysql_fd();
    }
    elsif ($self->{dbname} =~ /^dbi:pg/i)
    {
	$fd = $Radius::SqlDb::handles{$self->{dbname}}->{pg_socket};
    }

    return $fd if defined $fd;

    $self->log($main::LOG_ERR, ref($self) . " $self->{Identifier}: DBSource $self->{dbsource} does not support asynchronous operations.");
    return undef;
}

#####################################################################
# Returns true if the database server is currently connected.
sub connected
{
    my ($self) = @_;

    return exists($Radius::SqlDb::handles{$self->{dbname}})
        && defined $Radius::SqlDb::handles{$self->{dbname}};
}

#####################################################################
# Force disconnection from the current database
# Protect against timeouts
sub disconnect
{
    my ($self) = @_;

    if (exists($Radius::SqlDb::handles{$self->{dbname}})
        && defined $Radius::SqlDb::handles{$self->{dbname}})
    {
	if ($self->{sqldb_async_query})
	{
	    my $fd = $self->getAsyncFd();
	    if (defined $fd)
	    {
		Radius::Select::remove_file($fd, 1, undef, undef);
	    }
	    my $dbname = $self->getDbName($self->{roundrobin_counter});
	    my $dbsource_id = $Radius::SqlDb::handle_ids{$dbname};
	    substr($Radius::SqlDb::async_conns[$dbsource_id], $self->{sqldb_async_conn_id}, 1, '0') if (defined $self->{roundrobin_counter} && defined $self->{sqldb_async_conn_id});
	}
        &Radius::Util::exec_timeout($self->{Timeout},
				    sub { $Radius::SqlDb::handles{$self->{dbname}}->disconnect });
    }
    delete $Radius::SqlDb::handles{$self->{dbname}};
    delete $Radius::SqlDb::statements{$self->{dbname}};
}

#####################################################################
# Quote a string in a DB dependent way, but hide the dbh
# Ensures the database is connected first.
# Protect against timeouts
sub quote
{
    my ($self, $s) = @_;

    return unless $self->reconnect();

    my $ret;
    &Radius::Util::exec_timeout
	($self->{Timeout},
	 sub { $ret = $Radius::SqlDb::handles{$self->{dbname}}->quote($s) });

    if ($@ && $@ =~ /timeout/)
    {
        $self->disconnect();
        $self->log($main::LOG_ERR, "dbh->quote timed out");
    }
    return $ret;
}

#####################################################################
sub queryOneRow
{
    my ($self, $q, @bind_values) = @_;

    my $sth = $self->prepareAndExecute($q, @bind_values);
    return unless $sth;
    return $self->getOneRow($sth);
}

#####################################################################
sub handle_socket_read
{
    my ($fileno, $self, $dbsource_log, $dbname, $dbsource_id, $rr_counter, $conn_id) = @_;

    my $e = delete $Radius::SqlDb::callbacks[$dbsource_id]->{$conn_id};
    unless (defined $e)
    {
	main::log($main::LOG_ERR, "SQL reply received $dbsource_log, but no callback set!");
	die;
	return;
    }

    substr($Radius::SqlDb::async_conns[$dbsource_id], $conn_id, 1, '0');
    $Radius::SqlDb::free_async_conn[$dbsource_id] = $conn_id;

    my ($cb, $key) = @{$e};
    $self->{dbname} = $dbname;
    $self->{dbsource} = $dbsource_log;
    $self->{roundrobin_counter} = $rr_counter;
    $self->{sqldb_async_conn_id} = $conn_id;
    $self->{sqldb_async_query} = 1;
    &$cb($key) if defined $cb;
    $self->{sqldb_async_query} = 0;

    return;
}

1;
