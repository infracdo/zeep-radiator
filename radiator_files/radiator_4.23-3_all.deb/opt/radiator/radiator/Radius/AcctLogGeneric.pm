# AcctLogGeneric.pm
#
# Generic superclass for handling accounting logging
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AcctLogGeneric;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::LogFormat;
use strict;
use warnings;

%Radius::AcctLogGeneric::ConfigKeywords =
(
 'MaxMessageLength' =>
 ['integer',
  'Sets the maximum length of log messages. All messages longer than MaxMessageLength characters are truncated to MaxMessageLength.',
 1],

 'LogFormatHook' =>
 ['hook',
  'Specifies an optional Perl hook that will be run for each log message when defined. By default no hook is defined.',
  1],

 );

# RCS version number of this module
$Radius::AcctLogGeneric::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
    $self->{ObjType} = 'AcctLog';
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Log an accounting message
# $result is $main::ACCEPT, $main::IGNORE, $main::REJECT, etc.
# $reason is the reason, $p is the request packet
sub acctlog
{
    my ($self, $result, $reason, $p) = @_;

    $self->log($main::LOG_ERR, "You did not override acctlog() in AcctLogGeneric", $p);
}

#####################################################################
# Find the AcctLog module with a given identifier

sub find
{
    my ($id) = @_;

    return Radius::Configurable::find('AcctLog', $id);
}

1;
