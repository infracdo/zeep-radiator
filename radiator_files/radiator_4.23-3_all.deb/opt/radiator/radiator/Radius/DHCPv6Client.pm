# DHCPv6Client.pm
#
# Acts as a DHCPv6 client
# Opens an IPv6 socket to talk to a DHCPv6 server per RFC 3315
#
# Author: Mike McCauley (mikem@open.com au)
# Copyright (C) 2011 Open System Consultants
# $Id$

package Radius::DHCPv6Client;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Util;
use Radius::DHCPv6;
use Radius::Select;
use Radius::Log;
use Socket;
use Fcntl;
use strict;
use warnings;

%Radius::DHCPv6Client::ConfigKeywords =
('Host' =>
 ['string', 'Hostname of the DHCP server to use. Defaults to All_DHCP_Relay_Agents_and_Servers (ff02::1:2)', 0],
 'Port' =>
 ['string', 'DHCP Server Port number that this client will send DHCPv6 requests to. Defaults to 567.', 1],
 'ClientPort' =>
 ['string', 'DHCP Client Port number that this client will bind to. Defaults so 546.', 1],
 'LocalAddress' =>
 ['string', 'The bind address to use for the DHCP request port. Defaults to the IPv6 wildcard address ::', 1],
 'InterfaceName' =>
 ['string', 'If LocalAddress is a link-local address, InterfaceName is the name of the interface that it applies to', 1],
 'InterfaceIndex' =>
 ['integer', 'If InterfaceIndex is set, InterfaceName is not required', 1],
 'Synchronous' =>
 ['flag', 'All requests operate synchronously with the DHCP server and block until a reply is received or fails. Defaults to 0', 1],
);

# RCS version number of this module
$Radius::DHCPv6Client::VERSION = '$Revision$';

#####################################################################
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initalize instance
# variables that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;

    $self->{Host} = 'ff02::1:2';
    $self->{Port} = $Radius::DHCPv6::UDP_PORT_SERVER;
    $self->{ClientPort} = $Radius::DHCPv6::UDP_PORT_CLIENT;
    $self->{LocalAddress} = '::';
}

#####################################################################
# (Re)activate a new client
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Do class level initialization
    $self->socketInit();
}

#####################################################################
# Returns ($interface_index) currently. May return a more information
# in the future, for example interface link local address. Returns
# empty list on failure.
sub getInterfaceDetails
{
    my ($self, $interface) = @_;

    my $interface_index;
    if ($^O eq 'linux')
    {
	# REVISIT: consider netlink for fetching IP addresses and
	# other interface information

	my $s; # Will autoclose
	socket($s, Socket::PF_INET, Socket::SOCK_DGRAM, getprotobyname('ip'));
	return unless $s;

	my $ifreqpack = 'a16a16';
	my $buf = pack($ifreqpack, $interface, '');
	my $ifconf = pack('iP', length($buf), $buf);

	my $path = "sys/ioctl.ph"; # For SIOCGIFINDEX()
	require $path;
	my $ret = ioctl($s, SIOCGIFINDEX(), $buf);
	return unless $ret == 0;

	$interface_index = unpack('x16 C', $buf);
    }
    elsif (0 && $^O eq 'darwin')
    {
	# OS X (and other OSes too, including Linux) supports
	# if_nametoindex(3) for mapping between interface names and
	# indexes.
    }
    else
    {
	$self->log($main::LOG_ERR, "DHCPv6Client: Do not know how to get interface details for $^O. Consider using InterfaceIndex configuration parameter directly");
	return;
    }

    return ($interface_index);
}

#####################################################################
# Do class level initialization
#
# RFC 3493 says the following about scop_id in sockaddr_in6: The
#   mapping of sin6_scope_id to an interface or set of interfaces is
#   left to implementation and future specifications on the subject of
#   scoped addresses.
#
# Linux ipv6(7) man page says: sin6_scope_id is an ID depending on the
#   scope of the address. Linux supports it only for link-local
#   addresses, in that case sin6_scope_id contains the interface index
#   (see netdevice(7))
#
# For this reason we use pack_sockaddr_in6_all to set scope_id to the
# if_index of the desired interface
#
sub socketInit
{
    my ($self) = @_;

    # May be reinitializing
    Radius::Select::remove_file(fileno($self->{Socket}), 1, undef, undef)
	if $self->{Socket};

    # Create a socket for us to send through. DHCPv6 requires an IPv6
    # socket
    # We could have used FileHandle here, but this is much
    # more lightweight. It makes a reference to a TYPEGLOB
    # and Perl can use a typeglob ref as an IO handle

    $self->{Socket} = do { local *FH };
    my $pfamily = Radius::Util::PF_INET6();
    socket($self->{Socket}, $pfamily, Socket::SOCK_DGRAM, scalar getprotobyname('udp'))
	|| warn "Could not create DHCPv6 socket in DHCPv6Client: $!";
    binmode($self->{Socket}); # Make safe in UTF environments
    setsockopt($self->{Socket}, Socket::SOL_SOCKET, Socket::SO_REUSEADDR, 1);

    my $interface_index = $self->{InterfaceIndex};
    ($interface_index) = $self->getInterfaceDetails($self->{InterfaceName})
	unless $interface_index;

    my $thisaddr = Radius::Util::pack_sockaddr_in6
    	(Radius::Util::get_port($self->{ClientPort}),
    	 Radius::Util::inet_pton($self->{LocalAddress}),
    	 $interface_index, # scope_id
    	 0); # flow_id

    # Need to bind to the port server sends replies to. By default
    # replies are not send back to the originating port but to a fixed
    # port which defaults to 546.
    bind($self->{Socket}, $thisaddr)
         || warn "Could not bind to LocalAddress $self->{LocalAddress} InterfaceName $self->{InterfaceName} interface index $interface_index ClientPort $self->{ClientPort} in DHCPv6Client: $!";

    # On some hosts, select sometimes incorrectly says that there is a
    # reply waiting, even when there isnt.  Set the socket
    # non-blocking to prevent waiting forever
    if ($^O ne 'MSWin32')
    {
	fcntl($self->{Socket}, F_SETFL,
	      fcntl($self->{Socket}, F_GETFL, 0) | O_NONBLOCK)
	    || warn "Could not fcntl DHCPv6 socket in DHCPv6Client: $!";
    }
    elsif ($^O eq 'MSWin32' && $] >= 5.008)
    {
	# Uses ioctl FIONBIO for setting socket to nonblock. Works with Perl 5.8 and later.
	# http://www.nntp.perl.org/group/perl.perl5.porters/2008/10/msg140537.html
	# 0x80000000  IOC_IN
	# 0x00040000  sizeof(u_long)<<16
	# 0x00006600  'f'<<8
	# 0x0000007e  126
	# ==========
	# 0x8004667e

	my $nonblock=pack("I", 1);
	$self->log($main::LOG_ERR, "DHCPv6Client could not ioctl NONBLOCK socket on Windows")
	    if (!ioctl ($self->{Socket}, 0x8004667e, \$nonblock));
    }
    else
    {
	# Windows with old Perl.
	$self->log($main::LOG_DEBUG, "DHCPv6Client could not ioctl NONBLOCK socket on Windows with Perl version lower than 5.8");
    }

    # Get the destination address for the server
    $self->{serveraddress} = Radius::Util::pack_sockaddr_in6
   	(Radius::Util::get_port($self->{Port}),
   	 Radius::Util::inet_pton($self->{Host}),
   	 $interface_index, # scope_id
   	 0); # flow_id

    # Add this socket to the list in Radius::Select.
    Radius::Select::add_file
	(fileno($self->{Socket}), 1, undef, undef,
	 \&Radius::DHCPv6Client::handle_dhcpv6_socket_read,
	 $self);
}

#####################################################################
# This is called by Select::select whenever our DHCP socket
# becomes readable. Read at most one packet from the socket and
# process it.
# The packets received here will be replies to requests we have
# forwarded to a DHCP server.
# We have to reply to AuthDYNADDRESS and cross the original request
# off our timeout list.
# We must also save some context for later deallocation.
sub handle_dhcpv6_socket_read
{
    my ($fileno, $self) = @_;

    my $whence;
    my $rec;

    if ($whence = recv($self->{Socket}, $rec, 8192, 0))
    {
	my $dump = unpack('H*', $rec);
	$self->log($main::LOG_EXTRA_DEBUG, "DHCPv6Client handle_dhcpv6_socket_read: received $dump");
	my $message = Radius::DHCPv6::Message->new();
	if (!$message->decode($rec))
	{
	    self->log($main::LOG_ERR, "handle_dhcpv6_socket_read: could not decode message");
	    return;
	}
	$self->log($main::LOG_DEBUG, "DHCPv6Client handle_dhcpv6_socket_read: received " . $message->dump())
	    if (main::willLog($main::LOG_DEBUG));

	my $transaction_id = $message->{transaction_id};

	my $original_message = $self->{pendingRequests}{$transaction_id};
	if ($original_message)
	{
	    $self->handleReplyTo($original_message, $message);
	    delete $self->{pendingRequests}{$transaction_id};
	}
	# Else discard as a request or an unexpected reply
    }
}

#####################################################################
sub checkServerIdPresent
{
    my ($self, $message) = @_;

    my ($dummy1, $server_duid) = $message->option($Radius::DHCPv6::OPTION_SERVERID);
    return 1 if $server_duid;

    $self->log($main::LOG_WARNING, "DHCPv6Client no SERVERID. Discarding");
    return;
}

#####################################################################
sub checkStatusCodeSuccess
{
    my ($self, $message) = @_;

    my ($dummy, $status_code) = $message->option($Radius::DHCPv6::OPTION_STATUS_CODE);
    return 1 if defined $status_code && $status_code == $Radius::DHCPv6::STATUS_CODE_SUCCESS;
    $self->log($main::LOG_WARNING, "DHCPv6Client status code $Radius::DHCPv6::status_code_to_name{$status_code}. Discarding");
    return; # Discard
}

#####################################################################
sub maybeShowStatusCode
{
    my ($self, $message) = @_;

    my ($dummy, $status_code) = $message->option($Radius::DHCPv6::OPTION_STATUS_CODE);
    $self->log($main::LOG_WARNING, "DHCPv6Client status code $Radius::DHCPv6::status_code_to_name{$status_code}")
	if defined $status_code && $status_code != $Radius::DHCPv6::STATUS_CODE_SUCCESS;
}

#####################################################################
sub getIAsToRequest
{
    my ($self, $message, $reply) = @_;

    # What was solicited
    my (undef, @sol_ia_na_options) = $message->option($Radius::DHCPv6::OPTION_IA_NA);
    my (undef, @sol_ia_pd_options) = $message->option($Radius::DHCPv6::OPTION_IA_PD);

    # What was advertised
    my (undef, @ia_na_options) = $reply->option($Radius::DHCPv6::OPTION_IA_NA);
    my (undef, @ia_pd_options) = $reply->option($Radius::DHCPv6::OPTION_IA_PD);

    # See if we got any IA options in the ADVERTISE
    unless (@ia_na_options || @ia_pd_options)
    {
	$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo no OPTION_IA_NA or OPTION_IA_PD in ADVERTISE");
	return;
    }

    # See if we got offered address, prefix or both
    my ($got_addr, $got_prefix);
    $got_addr = Radius::DHCPv6::Message::get_option($Radius::DHCPv6::OPTION_IAADDR, $ia_na_options[3])
	if (@ia_na_options && $ia_na_options[3]);
    $got_prefix = Radius::DHCPv6::Message::get_option($Radius::DHCPv6::OPTION_IAPREFIX, $ia_pd_options[3])
	if (@ia_pd_options && $ia_pd_options[3]);

    if (@sol_ia_na_options)
    {
	if (!@ia_na_options)
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo no OPTION_IA_NA in ADVERTISE");
	}
	elsif (!$got_addr)
	{
	    my (undef, $status_code, $status_message) = Radius::DHCPv6::Message::get_option($Radius::DHCPv6::OPTION_STATUS_CODE, $ia_na_options[3]);
	    if (defined $status_code)
	    {
		my $status_name =  $Radius::DHCPv6::status_code_to_name{$status_code};
		$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo OPTION_IA_NA in ADVERTISE status: $status_name ($status_code) $status_message");
	    }
	    else
	    {
		$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo OPTION_IA_NA in ADVERTISE had no OPTION_IAADDR nor OPTION_STATUS");
	    }
	    @ia_na_options = (); # Don't request address
	}
    }

    if (@sol_ia_pd_options)
    {
	if (!@ia_pd_options)
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo no OPTION_IA_PD in ADVERTISE");
	}
	elsif (!$got_prefix)
	{
	    my (undef, $status_code, $status_message) = Radius::DHCPv6::Message::get_option($Radius::DHCPv6::OPTION_STATUS_CODE, $ia_pd_options[3]);
	    if (defined $status_code)
	    {
		my $status_name =  $Radius::DHCPv6::status_code_to_name{$status_code};
		$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo OPTION_IA_PD in ADVERTISE status: $status_name ($status_code) $status_message");
	    }
	    else
	    {
		$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo OPTION_IA_PD in ADVERTISE had no OPTION_IAPREFIX nor OPTION_STATUS");
	    }
	    @ia_pd_options = (); # Don't request prefix
	}
    }

    # Are there any addresses or prefixes we can request?
    unless ($got_addr || $got_prefix)
    {
	$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo no OPTION_IAADDR nor OPTION_IAPREFIX to request in ADVERTISE");
	return;
    }

    return (@ia_na_options ? \@ia_na_options : undef, @ia_pd_options ? \@ia_pd_options : undef);
}

#####################################################################
# Called to indicate that processing a message is complete or failed
# If a reply was received, it will be in $reply
# If the reply was in fact due to an earlier message, notify that instead
sub messageComplete
{
    my ($self, $message, $reply) = @_;

    return $self->messageComplete($message->{originalmessage}, $reply)
	if $message->{originalmessage};
    $message->{reply} = $reply;

    # Maybe call a callback
    &{$message->{reply_fn}}($self, $message, $reply)
    	if $message->{reply_fn};

    $message->{completed}++;
}

#####################################################################
sub handleReplyTo
{
    my ($self, $message, $reply) = @_;

    # REVISIT: cancel any retransmission timeouts
    Radius::Select::remove_timeout($message->{timeouthandle});

    # For all replies, check that the clint duid is correct
    my (undef, $message_client_duid) = $message->option($Radius::DHCPv6::OPTION_CLIENTID);
    my (undef, $reply_client_duid) = $reply->option($Radius::DHCPv6::OPTION_CLIENTID);
    if ($message_client_duid ne $reply_client_duid)
    {
	$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo CLIENTID does not match. Discarding.");
	return;
    }
    $self->maybeShowStatusCode($reply);

    my $message_type = $Radius::DHCPv6::message_type_to_name{$message->{message_type}};
    my $reply_type = $Radius::DHCPv6::message_type_to_name{$reply->{message_type}};

    # Check whether its an appropriate reply type
    if ($message->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_INFORMATION_REQUEST)
    {
	if ($reply->{message_type} != $Radius::DHCPv6::MESSAGE_TYPE_REPLY)
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo unexpected reply $reply_type to $message_type. Discarding");
	    return;
	}
	# Use whatever was in the reply
    }
    elsif ($message->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_SOLICIT)
    {
	if ($reply->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_ADVERTISE)
	{
	    # Sigh, have to do the full dance
	    return unless $self->checkServerIdPresent($reply);

	    # IA_NA, IP_PD or both were present. See if they contain
	    # addresses or prefixes we an ask for
	    my ($ia_na_options, $ia_pd_options) = $self->getIAsToRequest($message, $reply);
	    unless ($ia_na_options || $ia_pd_options)
	    {
		$self->messageComplete($message, $reply);
		return;
	    }

	    # There is at least one address or prefix we can ask for
	    # Send a Request to the same server with the same ORO
	    my (undef, $server_duid) = $reply->option($Radius::DHCPv6::OPTION_SERVERID);
	    my (undef, @oro_options) = $message->option($Radius::DHCPv6::OPTION_ORO);
	    my $new_message = Radius::DHCPv6::Message
		->new($Radius::DHCPv6::MESSAGE_TYPE_REQUEST,
		      [$Radius::DHCPv6::OPTION_CLIENTID, $message_client_duid],
		      [$Radius::DHCPv6::OPTION_SERVERID, $server_duid],
		);
	    $new_message->add_option($Radius::DHCPv6::OPTION_IA_NA, @$ia_na_options) if $ia_na_options;
	    $new_message->add_option($Radius::DHCPv6::OPTION_IA_PD, @$ia_pd_options) if $ia_pd_options;
	    $new_message->add_option($Radius::DHCPv6::OPTION_ORO, @oro_options) if @oro_options;
	    $new_message->{originalmessage} = $message;
	    $self->sendRequest($new_message, $message->{reply_fn});
	    return; # Come back later, maybe
	}
	elsif ($reply->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_REPLY)
	{
	    # Hmmm, maybe we asked for and got a RAPID_COMMIT
	    return unless $self->checkServerIdPresent($reply);
	    if ($reply->option($Radius::DHCPv6::OPTION_RAPID_COMMIT) &&
		!$message->option($Radius::DHCPv6::OPTION_RAPID_COMMIT))
	    {
		$self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo received unexpected OPTION_RAPID_COMMIT in REPLY. Discarding");
		return;
	    }
	    # Use whatever was in the reply
	}
	else
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo unexpected reply $reply_type to $message_type. Discarding");
	    return; # Discard
	}
    }
    elsif ($message->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_REQUEST)
    {
	if ($reply->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_REPLY)
	{
	    return unless $self->checkServerIdPresent($reply);
	}
	else
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo unexpected reply $reply_type to $message_type. Discarding");
	    return; # Discard
	}
	# Use whatever was in the reply
    }
    elsif ($message->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_RENEW)
    {
	if ($reply->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_REPLY)
	{
	    return unless $self->checkServerIdPresent($reply);
	    # No status code!
	}
	else
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo unexpected reply $reply_type to $message_type. Discarding");
	    return; # Discard
	}
    }
    elsif ($message->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_RELEASE)
    {
	if ($reply->{message_type} == $Radius::DHCPv6::MESSAGE_TYPE_REPLY)
	{
	    return unless $self->checkServerIdPresent($reply);
	    return unless $self->checkStatusCodeSuccess($reply);
	}
	else
	{
	    $self->log($main::LOG_WARNING, "DHCPv6Client handleReplyTo unexpected reply $reply_type to $message_type. Discarding");
	    return; # Discard
	}
    }
    # OTHERS?

    # The reply type is appropriate to the request type
    # Pass it back up to higher layers and original callers
    $self->messageComplete($message, $reply);
}

#####################################################################
# Never got a response to this message
sub noReplyTo
{
    my ($self, $message) = @_;

    $self->messageComplete($message); # No reply because it failed
}

#####################################################################
# Called when a retransmission timeout RT expires for $message
# Maybe retransmit
sub handle_retransmission_timeout
{
    my ($handle, $self, $message) = @_;

    # Maybe resend the message
    $self->log($main::LOG_INFO, "DHCPv6Client retransmission timeout");
    $self->sendMessage($message);
}

#####################################################################
# Send or resend a message, adjusting retransmission timeouts etc
sub sendMessage
{
    my ($self, $message, $reply_fn) = @_;

    # Calculate retransmission parameters
    if ($message->{MRC} && ($message->{transmission_count} > $message->{MRC}))
    {
	# Too many retrans, fail
	$self->log($main::LOG_ERR, "sendMessage: retransmissions exceeds $message->{MRC}. Failing");
	$self->noReplyTo($message);
	return;
    }

    if ($message->{transmission_count}
	&& $message->{MRD}
	&& (time >= ($message->{initial_transmit_time} + $message->{MRD})))
    {
	# Too long a delay, fail
	$self->log($main::LOG_ERR, "sendMessage: delay exceeds $message->{MRD}. Failing");
	$self->noReplyTo($message);
	return;
    }

    my $random_jitter = rand(0.2) - 0.1; # -0.1 to 0.1
    if ($message->{transmission_count} == 0)
    {
	$message->{RT} = $message->{IRT} + ($message->{IRT} * $random_jitter);
	$message->{initial_transmit_time} = time;
    }
    else
    {
	$message->{RT} = (2 * $message->{RT}) + ($message->{RT}  * $random_jitter);
    }
    $message->{RT} = $message->{MRT} if $message->{RT} > $message->{MRT}; # Upper bound
    $message->{RT} = 1 if $message->{RT} == 0; # 0 length timeout is silly
    $message->{transmission_count}++;

    my $encoded = $message->encode(); # Maybe could cache it?
    my $hex = unpack('H*', $encoded);
    $self->log($main::LOG_EXTRA_DEBUG, "DHCPv6Client sendMessage: sending $hex");

    # and send it
    # Some platforms (eg Linux) will produce "Connection refused"
    # if the desination does not have a port open,
    # so ignore those kinds of errors
    if (!send($self->{Socket}, $encoded, 0, $self->{serveraddress}))
    {
	$self->log($main::LOG_ERR, "DHCPv6Client sendMessage: send failed: $!")
	    unless $! =~ /^Connection refused/;
    }

    # Set up retransmission timeout
    $message->{timeouthandle} =  Radius::Select::add_timeout(time + $message->{RT},
				 \&Radius::DHCPv6Client::handle_retransmission_timeout,
				 $self, $message);
}

#####################################################################
sub setRetransmissionParameters
{
    my ($self, $message) = @_;

    # Set up retransmission parameters:
    # Type     IRT         MRT        MRC        MRD
    # Solicit  SOL_TIMEOUT SOL_MAX_RT 0          0
    # Request  REQ_TIMEOUT REQ_MAX_RT REQ_MAX_RC 0
    # Confirm  CNF_TIMEOUT CNF_MAX_RT 0          CNF_MAX_RD
    # Renew    REN_TIMEOUT REN_MAX_RT 0          Remaining time until T2
    # Rebind   REB_TIMEOUT REB_MAX_RT 0          Remaining time until valid lifetimes of all addresses have expired
    # Inform   INF_TIMEOUT INF_MAX_RT 0          0
    # Release  REL_TIMEOUT 0          REL_MAX_RC 0
    # Decline  DEC_TIMEOUT 0          DEC_MAX_RC 0

    # HINT: you can change the defaults if you need
    my $mt = $message->{message_type};
    my ($IRT, $MRT, $MRC, $MRD);
    if ($mt == $Radius::DHCPv6::MESSAGE_TYPE_SOLICIT)
    {
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_SOL_TIMEOUT, $Radius::DHCPv6::DEFAULT_SOL_MAX_RT, $Radius::DHCPv6::DEFAULT_SOL_MAX_RC, $Radius::DHCPv6::DEFAULT_SOL_MAX_RD);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_REQUEST)
    {
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_REQ_TIMEOUT, $Radius::DHCPv6::DEFAULT_REQ_MAX_RT, $Radius::DHCPv6::DEFAULT_REQ_MAX_RC, $Radius::DHCPv6::DEFAULT_REQ_MAX_RD);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_CONFIRM)
    {
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_CNF_TIMEOUT, $Radius::DHCPv6::DEFAULT_CNF_MAX_RT, $Radius::DHCPv6::DEFAULT_CNF_MAX_RC, $Radius::DHCPv6::DEFAULT_CNF_MAX_RD);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_RENEW)
    {
	my $time_until_t2 = 10; # REVISIT
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_REN_TIMEOUT, $Radius::DHCPv6::DEFAULT_REN_MAX_RT, $Radius::DHCPv6::DEFAULT_REN_MAX_RC, $time_until_t2);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_REBIND)
    {
	my $time_until_expiry = 10; # REVISIT
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_REB_TIMEOUT, $Radius::DHCPv6::DEFAULT_REB_MAX_RT, $Radius::DHCPv6::DEFAULT_REB_MAX_RC, $time_until_expiry);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_INFORMATION_REQUEST)
    {
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_INF_TIMEOUT, $Radius::DHCPv6::DEFAULT_INF_MAX_RT, $Radius::DHCPv6::DEFAULT_INF_MAX_RC, $Radius::DHCPv6::DEFAULT_INF_MAX_RD);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_RELEASE)
    {
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_REL_TIMEOUT, $Radius::DHCPv6::DEFAULT_REL_MAX_RT, $Radius::DHCPv6::DEFAULT_REL_MAX_RC, $Radius::DHCPv6::DEFAULT_REL_MAX_RD);
    }
    elsif ($mt == $Radius::DHCPv6::MESSAGE_TYPE_DECLINE)
    {
	($IRT, $MRT, $MRC, $MRD) = ($Radius::DHCPv6::DEFAULT_DEC_TIMEOUT, $Radius::DHCPv6::DEFAULT_DEC_MAX_RT, $Radius::DHCPv6::DEFAULT_DEC_MAX_RC, $Radius::DHCPv6::DEFAULT_DEC_MAX_RD);
    }
    # ELSE WHAT. Can this even happen?
    ($message->{IRT}, $message->{MRT}, $message->{MRC}, $message->{MRD}) = ($IRT, $MRT, $MRC, $MRD);
}

#####################################################################
# See that the ID will be unique
sub makeTransactionID
{
    my ($self) = @_;

    my $transaction_id;
    do
    {
	$transaction_id = Radius::Util::random_string(3);

    } while (exists $self->{pendingRequests}{$transaction_id});

    return $transaction_id;
}

#####################################################################
sub sendRequest
{
    my ($self, $message, $reply_fn) = @_;

    $self->setRetransmissionParameters($message);
    $message->{reply_fn} = $reply_fn;

    my $transaction_id = $self->makeTransactionID();
    $message->{transaction_id} = $transaction_id;
    $self->{pendingRequests}{$transaction_id} = $message;
    $message->{transmission_count} = 0;
    $self->log($main::LOG_DEBUG, "DHCPv6Client sendRequest: sending " . $message->dump())
	if (main::willLog($main::LOG_DEBUG));
    $self->sendMessage($message);
}

#####################################################################
# Blocks until a reply is received or the message fails
# Processes timeouts in the meantime
# Returns the received reply if any
sub waitForReplyTo
{
    my ($self, $message) = @_;

    # Here we process replies until the request we are doing
    # has either been replied to or timed out
    # CAUTION: while this is happening, no other incoming requests
    # will be handled: If the remote server is down
    # you may get a serious performance hit
    # Wait for activity on the reply socket or timeouts
    my $waitfor = 0;
    my $found;
    vec($waitfor, fileno($self->{Socket}), 1) = 1;
    while (!$message->{completed})
    {
	# Wait up to a second for activity on the socket
	select($found=$waitfor, undef, undef, 1)
	    && &handle_dhcpv6_socket_read
	    (fileno($self->{Socket}), $self);
	Radius::Select::process_timeouts();
    }
    return $message->{reply};
}

#####################################################################
sub sendRequestWaitReply
{
    my ($self, $message, $reply_fn) = @_;

    $self->sendRequest($message, $reply_fn);
    return $self->waitForReplyTo($message);
}

#####################################################################
sub informationRequest
{
    my ($self, $client_duid, $reply_fn) = @_;

    my $message = Radius::DHCPv6::Message
	->new($Radius::DHCPv6::MESSAGE_TYPE_INFORMATION_REQUEST,
	      [$Radius::DHCPv6::OPTION_CLIENTID, $client_duid],
	      [$Radius::DHCPv6::OPTION_ELAPSED_TIME, 0]	);

    return $self->sendRequestWaitReply($message, $reply_fn)
	if $self->{Synchronous};
    $self->sendRequest($message, $reply_fn);
    return;
}

#####################################################################
# $options is an arrayref of DHCPv6 options we need to ask from the
# DHCPv6 server
sub allocateRequest
{
    my ($self, $client_duid, $preferred_lifetime, $options, $pool_hint, $reply_fn) = @_;

    $preferred_lifetime += 0;

    my $iaid = 0; # Fake IAID for one address per $client_duid

    # See if we need to do stateful allocation, or stateless
    # information request
    my $req_iaaddr   = grep {$_ == $Radius::DHCPv6::OPTION_IAADDR}   @$options;
    my $req_iaprefix = grep {$_ == $Radius::DHCPv6::OPTION_IAPREFIX} @$options;

    my $message_type = ($req_iaaddr || $req_iaprefix) ?
	$Radius::DHCPv6::MESSAGE_TYPE_SOLICIT :
	$Radius::DHCPv6::MESSAGE_TYPE_INFORMATION_REQUEST;

    my $message = Radius::DHCPv6::Message
	->new($message_type,
	      [$Radius::DHCPv6::OPTION_CLIENTID, $client_duid],
	);

    # Rapid Commit is only allowed in solicit messages
    $message->add_option($Radius::DHCPv6::OPTION_RAPID_COMMIT)
	if ($message_type == $Radius::DHCPv6::MESSAGE_TYPE_SOLICIT && $self->{RapidCommit});

    # Here we ask for both IA_NA and IA_PD, so the serve will send whatever it can for this
    # client
    # REVISIT: request a specific lease period?
    $message->add_option($Radius::DHCPv6::OPTION_IA_NA, $iaid, $preferred_lifetime, $preferred_lifetime*2)
	if $req_iaaddr;
    $message->add_option($Radius::DHCPv6::OPTION_IA_PD, $iaid, $preferred_lifetime, $preferred_lifetime*2)
	if $req_iaprefix;

    # If we have a pool_hint, add it to the request in a USER_CLASS option
    # REVISIT: the ISC DHCP server (version 4.3.3) does not support USER_CLASS
    $message->add_option($Radius::DHCPv6::OPTION_USER_CLASS, $pool_hint)
        if defined $pool_hint;

    # draft-ietf-dhc-rfc3315bis: There is no need request IAADDR or IAPREFIX
    my @oro_options = grep { $_ != $Radius::DHCPv6::OPTION_IAPREFIX && $_ != $Radius::DHCPv6::OPTION_IAADDR } @$options;
    $message->add_option($Radius::DHCPv6::OPTION_ORO, @oro_options) if @oro_options;

    return $self->sendRequestWaitReply($message, $reply_fn)
	if $self->{Synchronous};
    $self->sendRequest($message, $reply_fn);
    return;
}

#####################################################################
sub renewRequest
{
    my ($self, $client_duid, $server_duid, $iaaddr, $iaprefix, $reply_fn) = @_;

    my $iaid = 0; # Fake IAID for one address per $client_duid
    my $message = Radius::DHCPv6::Message
	->new($Radius::DHCPv6::MESSAGE_TYPE_RENEW,
	      [$Radius::DHCPv6::OPTION_CLIENTID, $client_duid],
	      [$Radius::DHCPv6::OPTION_SERVERID, $server_duid],
	);

    $message->add_option($Radius::DHCPv6::OPTION_IA_NA, $iaid, 0, 0, [$Radius::DHCPv6::OPTION_IAADDR, $iaaddr, 0, 0])
	if $iaaddr;
    $message->add_option($Radius::DHCPv6::OPTION_IA_PD, $iaid, 0, 0, [$Radius::DHCPv6::OPTION_IAPREFIX, 0, 0, $iaprefix->[0], $iaprefix->[1]])
	if $iaprefix;

    return $self->sendRequestWaitReply($message, $reply_fn)
	if $self->{Synchronous};
    $self->sendRequest($message, $reply_fn);
    return;
}

#####################################################################
sub releaseRequest
{
    my ($self, $client_duid, $server_duid, $iaaddr, $iaprefix, $reply_fn) = @_;

    my $iaid = 0; # Fake IAID for one address per $client_duid
    my $message = Radius::DHCPv6::Message
	->new($Radius::DHCPv6::MESSAGE_TYPE_RELEASE,
	      [$Radius::DHCPv6::OPTION_CLIENTID, $client_duid],
	      [$Radius::DHCPv6::OPTION_SERVERID, $server_duid],
	);

    $message->add_option($Radius::DHCPv6::OPTION_IA_NA, $iaid, 0, 0, [$Radius::DHCPv6::OPTION_IAADDR, $iaaddr, 0, 0])
	if $iaaddr;
    $message->add_option($Radius::DHCPv6::OPTION_IA_PD, $iaid, 0, 0, [$Radius::DHCPv6::OPTION_IAPREFIX, 0, 0, $iaprefix->[0], $iaprefix->[1]])
	if $iaprefix;

    return $self->sendRequestWaitReply($message, $reply_fn)
	if $self->{Synchronous};
    $self->sendRequest($message, $reply_fn);
    return;
}

1;

