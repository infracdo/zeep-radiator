# RuntimeChecks.pm
#
# A package for runtime checks to run during radiusd startup and
# optionally from Hooks and other code.
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2014 Open System Consultants
# $Id$

package Radius::RuntimeChecks;

use strict;
use warnings;

# RCS version number of this module
$Radius::RuntimeChecks::VERSION = '$Revision$';

# Note: this function is called from ServerConfig initialize() when
# loggers are not yet available. If possible, the checks should be
# done in do_startup_checks() which gets called during ServerConfig
# activate().
sub do_initialize_checks
{
    check_sctp_capability();

    return;
}

sub do_startup_checks
{

    check_inc();
    check_net_ssleay_capability();
    check_ipv6_capability();
    check_digest_sha();
    check_digest_md4() unless is_disabled('Digest::MD4');
    check_heartbleed() unless is_disabled('CVE-2014-0160');

    return;
}

# If radiusd can not open each existing directory in @INC, it may fail
# loading the required Perl modules. The exact behaviour (exit, be
# silent) depends on the Perl version.
sub check_inc()
{

    # The first two directories may have been added to @INC by radiusd
    # and its command line options. Some installations have paths in
    # @INC that are not present, so we do not check all @INC
    # components.
    foreach my $dir (@INC[0 .. 1])
    {
	main::log($main::LOG_WARNING, "Directory '$dir' in \@INC is not readable. If module loading fails, check that all \@INC directories are readable by the radiusd process")
	    if (-e $dir && ! -r $dir);
    }

    return;
}

# Returns 1 when the named runtime check is disabled. This lets any
# new, misspelled and unknown checks to remain active until they are
# disabled.
sub is_disabled
{
    my ($check) = @_;

    my @disabled_checks = split(/\s*,\s*/, Radius::Util::format_special($main::config->{DisabledRuntimeChecks}));

    return 1 if grep { $_ eq $check } @disabled_checks;
    return 0;
}

# See what OpenSSL, LibreSSL or whatever library we have supports with
# the version of Net::SSLeay we are using.
sub check_net_ssleay_capability
{
    return if $Radius::RuntimeChecks::done_net_ssleay_capability++;

    eval {require Net::SSLeay;};
    if ($@)
    {
	main::log($main::LOG_INFO, "Could not load Net::SSLeay module. TLS based EAP methods and other SSL/TLS based protocols are not available");
	return;
    }

    my $ssleay_version = $Net::SSLeay::VERSION;
    my ($ver_string, $ver_number, $hex_ver_number);
    eval
    {
	# Not available in Net-SSLeay-1.42 and before
	$ver_string = Net::SSLeay::SSLeay_version();
	$ver_number = Net::SSLeay::SSLeay();
	$hex_ver_number = sprintf("0x%x", $ver_number);
    };

    check_tls_capability($ssleay_version, $ver_string, $ver_number, $hex_ver_number);
    check_passwd_cb_funcs($ssleay_version, $ver_string, $ver_number, $hex_ver_number);

    return;
}

# TLSv1.1 and TLSv1.2 are supported by OpenSSL 1.0.1 or
# later.
#
# Net::SSLeay 1.53 or later is required for correct calculation of
# MPPE keys for TLS based EAP methods that use TLSv1.2.
#
# Net::SSLeay 1.46 is the first version that supports
# Net::SSLeay::OP_NO_TLSv1_1 and Net::SSLeay::OP_NO_TLSv1_2.
#
# Net::SSLeay 1.43 is the first version that supports querying OpenSSL
# version number and version string
sub check_tls_capability
{
    my ($ssleay_version, $ver_string, $ver_number, $hex_ver_number) = @_;

    if ($ver_string)
    {
	main::log($main::LOG_INFO, "Using Net::SSLeay $ssleay_version with SSL/TLS library version $hex_ver_number ($ver_string)");
    }
    else
    {
	main::log($main::LOG_INFO, "Using Net::SSLeay $ssleay_version but could not determine SSL/TLS library version. Net::SSLeay version 1.53 or later is recommended for querying SSL/TLS library version and TLSv1.1 and TLSv1.2 support status");
    }

    if (!defined $ver_number)
    {
	$main::eaptls_upto_v10 = 1;
	main::log($main::LOG_INFO, "SSL/TLS library version not known. EAP based TLS methods limited to TLSv1.0. Other TLS versions for other protocols may be available, depending on the SSL/TLS library version");
    }
    elsif ($ver_number < 0x1000100f)
    {
	$main::eaptls_upto_v10 = 1;
	main::log($main::LOG_INFO, "SSL/TLS library version $hex_ver_number ($ver_string) does not support TLSv1.1 or TLSv1.2");
    }
    else
    {
	# We have TLSv1.1 and TLSv1.2 capable library. See if
	# Net::SSLeay is older than 1.53 which means MPPE keys will be
	# miscalculated for TLSv1.2.
	unless (exists &Net::SSLeay::export_keying_material)
	{
	    # Net::SSLeay is older than 1.53
	    unless(eval { Net::SSLeay::OP_NO_TLSv1_2() })
	    {
		# Net::SSLeay version is older than 1.46
		$main::eaptls_upto_v10 = 1;
		main::log($main::LOG_INFO, "Net::SSLeay version $ssleay_version does not work with TLSv1.2 based EAP methods and can only downgrade to TLSv1.0. Version 1.53 or later is required for full support.");
	    }
	    else
	    {
		# Net::SSLeay knows about TLSv1.1 and TLSv1.2 but will
		# miscalculate MPPE keys for TLSv1.2
		$main::eaptls_upto_v11 = 1;
		main::log($main::LOG_INFO, "Net::SSLeay version $ssleay_version does not work with TLSv1.2 based EAP methods. Highest supported version is TLSv1.1. Version 1.53 or later is required for full support.");
	    }
	}
    }

}

# See if we must use OpenSSL's SSL_set_default_passwd_cb() when
# loading pass phrase protected keys for a ssl object.
sub check_passwd_cb_funcs
{
    my ($ssleay_version, $ver_string, $ver_number, $hex_ver_number) = @_;

    # Net::SSLeay must be 1.83 or later for this function
    if (exists &Net::SSLeay::set_default_passwd_cb)
    {
	$main::tls_have_ssl_passwd_cb = 1;
	main::log($main::LOG_DEBUG, "SSL/TLS library and Net::SSLeay support set_default_passwd_cb and related functions");
    }
}

# Digest::SHA is always needed and part of core Perl but packaged
# separately by some distributions such as Red Hat and CentOS.
sub check_digest_sha
{
    return if eval {require Digest::SHA;};

    main::log($main::LOG_ERR, 'Startup check could not load Digest::SHA. This module is required for Radiator to work');
    return;
}

# Digest::MD4 is needed so often that it is a good idea to always to
# have it installed.
sub check_digest_md4
{
    return if eval {require Digest::MD4;};

    main::log($main::LOG_WARNING, 'Startup check could not load Digest::MD4. See Radiator reference manual for DisabledRuntimeChecks parameter');
    return;
}

# Check for CVE-2014-0160, the OpenSSL Heartbleed vulnerability.
sub check_heartbleed
{
    # We check for Heartbleed only when Net::SSLeay is present
    return unless eval {require Net::SSLeay;};

    my ($ver_number, $ver_string);
    eval
    {
	$ver_number = Net::SSLeay::SSLeay();
	$ver_string = Net::SSLeay::SSLeay_version();
    };

    unless ($ver_number)
    {
	main::log($main::LOG_WARNING, 'Startup check could not determine OpenSSL version while checking for the Heartbleed (CVE-2014-0160) vulnerability. See Radiator reference manual for DisabledRuntimeChecks parameter');

	return; # Can not tell if affected
    }

    if ($ver_number >= 0x1000100f && $ver_number <= 0x1000106f)
    {
	my $hex_ver_number = sprintf("0x%x", $ver_number);
	main::log($main::LOG_WARNING, "Startup check found OpenSSL version $hex_ver_number ($ver_string) while checking for the Heartbleed (CVE-2014-0160) vulnerability. This version may be vulnerable. See Radiator reference manual for DisabledRuntimeChecks parameter");

	return; # Can not tell if affected
    }

    # The OpenSSL version seems not to be affected.
    return;
}

#####################################################################
# IPv6 support is fully available with recent Perls only.

# See if we can fully or just partially support IPv6
sub check_ipv6_capability
{
    my $capability = Radius::RuntimeChecks::get_ipv6_capability();
    if ($capability eq 'none')
    {
	main::log($main::LOG_INFO, "This Perl installation can handle IPv6 attributes in binary format only. IPv6 sockets are not supported. Consider installing Socket6.pm for full IPv6 support.");
    }
    else
    {
	main::log($main::LOG_DEBUG, "This system is IPv6 capable. IPv6 capability provided by: $capability");
    }

    return;
}

# Probe runtime environment's IPv6 capabilities. Return one of (core,
# socket6 or none).
sub get_ipv6_capability
{
    # See if we already know the capability.
    my $value = $main::ipv6_capability;
    return $value if defined $value;

    # If something dies, value remains undefined
    eval
    {
	# Prepare some test data
	my $port = 1812;
	my $addr = '2001:db8:148:100::31';
	my $prepared_addr = pack('H*', '20010db8014801000000000000000031');

	# First create a sockaddr_in6
	my ($err, @res) = Socket::getaddrinfo($addr, $port,
					      {family => Socket::AF_INET6(),
					       socktype => Socket::SOCK_STREAM()});
	die if $err;
	my $sa = $res[0]->{addr};

	# Try to unpack it back to port and address
	my ($err2, $addr2, $port2) = Socket::getnameinfo($sa,
							 Socket::NI_NUMERICHOST() |
							 Socket::NI_NUMERICSERV());
	die if $err2;

	# We should get back the original port and address.
	# Note: this depends on textual address presentation.
	die unless ($port == $port2 && $addr eq lc $addr2);

	# Then see if we can unpack a sockaddr_in6
	my (undef, $packed_sa_addr) = Socket::unpack_sockaddr_in6($sa);
	die unless $packed_sa_addr eq $prepared_addr;

	# Create another sockaddr_in6 from a prepared address
	my $sa2 = Socket::pack_sockaddr_in6($port, $prepared_addr);

	# Both sockaddr_in6 structures should be equal
	die unless ($sa eq $sa2);

	$value = 'core';
    };

    # Core did not provide everything required. Try Socket6.
    eval
    {
	require Socket6;
	$value = 'socket6';
    } unless $value;

    $value = 'none' unless $value;
    $main::ipv6_capability = $value;
    return $main::ipv6_capability;
}

#####################################################################
# SCTP specific socket API calls require Radius::SCTP
#
sub check_sctp_capability
{

    $main::sctp_sockets_api_available = 0;

    # We avoid probing on systems that we know we don't
    # support. Support depends on capabilities of Radius::SCTP.
    if ($^O ne 'MSWin32')
    {
	my $ret = eval { require Radius::SCTP; return 1;};
	if ($ret)
	{
	    $main::sctp_sockets_api_available = 1;
	    main::log_buffered($main::LOG_INFO, "SCTP sockets API supported by Radius::SCTP");
	}
	else
	{
	    main::log_buffered($main::LOG_DEBUG, "SCTP socket API extensions not available");
	}
    }

    return  $main::sctp_sockets_api_available;
}

1;
