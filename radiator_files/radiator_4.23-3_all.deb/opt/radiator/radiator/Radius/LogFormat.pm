# LogFormat.pm
#
# Perl module for formatting authentication, accounting and other log
# messages to different formats.
#
# Currently supported formats are:
#  o ArcSight Common Event Format (CEF)
#    https://protect724.hp.com/docs/DOC-1072
# o JSON
#
# Consider installing JSON::XS for faster encoding. JSON::XS is
# automatically used when it's available. See JSON::XS documentation
# in CPAN for more information.
#
# Author: Sami Keski-Kasari <samikk@open.com.au>
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::LogFormat;
use Radius::Util;
use Scalar::Util;
use strict;
use warnings;

# RCS version number of this module
$Radius::LogFormat::VERSION = '$Revision$';

# Log in JSON format. This is similar to the default log format
sub format_log_json
{
    my ($priority, $s, $p, $trace_id) = @_;
    require JSON;

    # Convert numeric value to textual
    $priority = $Radius::Log::priorityToString[$priority];

    my $time = $main::config->{LogMicroseconds} ? Radius::Util::getTimeHires() :
						  time();
    my %message = (
	trace_id	   => $trace_id,
	time		   => $time,
	timestamp	   => scalar localtime($time),
	priority	   => $priority,
	message		   => $s,
	);

    return JSON::encode_json(\%message);
}

# AuthLog in CEF compliant format
sub format_authlog_cef
{
    my ($s, $reason, $p, $trace_id) = @_;

    my $cef_message = "CEF:0|Open System Consultants|Radiator|$main::VERSION|AuthLog|";
    # Event Name
    $cef_message .= ($s == $main::ACCEPT ? 'Access accepted|' : 'Access rejected|');
    # Event Severity
    $cef_message .= "0|";

    # Extensions
    my $timestamp = time();
    $cef_message .= "rt=$timestamp";

    my $hostname = $main::hostname;
    $cef_message .= " deviceExternalId=$hostname";

    my $nas_ip = $p->get_attr('NAS-IP-Address');
    $cef_message .= " dst=$nas_ip" if $nas_ip;

    my $called = $p->get_attr('Called-Station-Id');
    $cef_message .= " dmac=$called" if $called;

    my $calling = $p->get_attr('Calling-Station-Id');
    $cef_message .= " smac=$calling" if $calling;

    my $framed_ip = $p->get_attr('Framed-IP-Address');
    $cef_message .= " src=$framed_ip" if $framed_ip;

    my $user = Radius::Util::format_special('%u');
    $cef_message .= " suser=$user" if $user;

    $cef_message .= " reason=$reason" if $reason;

    my $authby = Radius::Util::format_special('%{AuthBy:Identifier}', $p);
    $cef_message .= " cs3=$authby cs3_label=AuthBy_Identifier" if $authby;

    return $cef_message;
}

# AcctLog in CEF compliant format
sub format_acctlog_cef
{
    my ($result, $reason, $p, $trace_id) = @_;

    if (@_ == 1 && Scalar::Util::blessed($_[0]))
    {
	# We may also be called with just $p as the first parameter
	($result, $reason, $p) = (undef, undef, $_[0]);
	$trace_id = $p->{trace_id};
    }

    my $event_name = (defined $result)
	? (($result == $main::ACCEPT) ? 'Accounting accepted|' : 'Accounting rejected|')
	: 'Accounting received|';

    my $cef_message = "CEF:0|Open System Consultants|Radiator|$main::VERSION|AcctLog|";
    # Event Name
    $cef_message .= $event_name;
    # Event Severity
    $cef_message .= "0|";

    # Extensions
    my $timestamp = time();
    $cef_message .= "rt=$timestamp";

    my $hostname = $main::hostname;
    $cef_message .= " deviceExternalId=$hostname";

    my $nas_ip = $p->get_attr('NAS-IP-Address');
    $cef_message .= " dst=$nas_ip" if $nas_ip;

    my $called = $p->get_attr('Called-Station-Id');
    $cef_message .= " dmac=$called" if $called;

    my $calling = $p->get_attr('Calling-Station-Id');
    $cef_message .= " smac=$calling" if $calling;

    my $framed_ip = $p->get_attr('Framed-IP-Address');
    $cef_message .= " src=$framed_ip" if $framed_ip;

    my $user = Radius::Util::format_special('%u');
    $cef_message .= " suser=$user" if $user;

    $cef_message .= " reason=$reason" if $reason;

    my $handler = Radius::Util::format_special('%{Handler:Identifier}', $p);
    $cef_message .= " cs3=$handler cs3_label=Handler_Identifier" if $handler;

    return $cef_message;
}

# AuthLog in JSON format
sub format_authlog_json
{
    my ($s, $reason, $p, $trace_id) = @_;
    require JSON;

    my $time = $main::config->{LogMicroseconds} ? Radius::Util::getTimeHires() :
						  time();
    my %message = (
	trace_id	   => $trace_id,
	time		   => $time,
	timestamp	   => scalar localtime($time),
	source_host	   => $main::hostname,
	type		   => 'authentication',
	result		   => ($s == $main::ACCEPT ? 'accept' : 'reject'),
	username	   => '%u',
	nas_ip_address	   => '%{NAS-IP-Address}',
	nas_identifier	   => '%{NAS-Identifier}',
	nas_port	   => '%{NAS-Port}',
	called_station_id  => '%{Called-Station-Id}',
	calling_station_id => '%{Calling-Station-Id}',
    );

    # Format only values that have special characters
    $message{$_} = Radius::Util::format_special($message{$_}, $p)
	for (qw(
	     username nas_ip_address nas_identifier nas_port
	     called_station_id calling_station_id));

    # Add reject reason
    $message{reason} = $reason if $s == $main::REJECT;

    return JSON::encode_json(\%message);
}


# Accounting log in JSON format
sub format_acctlog_json
{
    my ($result, $reason, $p, $trace_id) = @_;

    if (@_ == 1 && Scalar::Util::blessed($_[0]))
    {
	# We may also be called with just $p as the first parameter
	($result, $reason, $p) = (undef, undef, $_[0]);
	$trace_id = $p->{trace_id};
    }

    require JSON;

    my $time = $main::config->{LogMicroseconds} ? Radius::Util::getTimeHires() :
						  time();
    my %message = (
	trace_id	   => $trace_id,
	time		   => $time,
	timestamp	   => scalar localtime($time),
	source_host	   => $main::hostname,
	type		   => 'accounting',
	username	   => "%u",
	nas_ip_address     => "%{NAS-IP-Address}",
	nas_identifier     => "%{NAS-Identifier}",
	nas_port	   => "%{NAS-Port}",
	called_station_id  => "%{Called-Station-Id}",
	calling_station_id => "%{Calling-Station-Id}",
	framed_ip_address  => "%{Framed-IP-Address}",
	acct_session_id    => "%{Acct-Session-Id}",
	acct_status_type   => "%{Acct-Status-Type}",
	);

    # Format only values that have special characters
    $message{$_} = Radius::Util::format_special($message{$_}, $p)
	for (qw(
	     username nas_ip_address nas_identifier nas_port
	     called_station_id calling_station_id
	     framed_ip_address acct_session_id acct_status_type));

    # Possibly add result and reject reason
    if (defined $result)
    {
	$message{result} = ($result == $main::ACCEPT ? 'accept' : 'reject');
	$message{reason} = $reason if $result == $main::REJECT;
    }

    return JSON::encode_json(\%message);
}

1;
