# AcctLogSQL.pm
#
# Specific class for logging accounting to SQL
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AcctLogSQL;
@ISA = qw(Radius::AcctLogGeneric Radius::SqlDb);
use Radius::AcctLogGeneric;
use Radius::SqlDb;
use strict;
use warnings;

%Radius::AcctLogSQL::ConfigKeywords =
 (
  'LogQuery' =>
  ['string', 'This optional parameter specifies the SQL query that will be used to log authentication successes. There is no default. If LogQuery is not defined (which is the default), no logging of accounting will occur. In the query, special formatting characters are permitted. %0 is replaced by the result. %1 is replaced with the quoted reason message (which is usually empty for successes). %2 is replaced with the SQL quoted User-Name. %3 is replaced with the SQL quoted original user name from the incoming request (before any RewriteUsername rules were applied). %4 is replaced with tracing identifier string', 1],

 'LogQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables (where supported by the SQL server) and query caching. If you specify one or more LogQueryParam parameters, they will be used in order to replace parameters named with a question mark (\`?\') in LogQuery, and the query will be cached for future reuse by the SQL server. Only the first QueryCacheSize queries will be cached.', 1],

  );

# RCS version number of this module
$Radius::AcctLogSQL::VERSION = '$Revision$';

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->Radius::AcctLogGeneric::initialize();
    $self->Radius::SqlDb::initialize();
    return;
}

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    # Multiple inheritance:
    $self->Radius::AcctLogGeneric::check_config();
    $self->Radius::SqlDb::check_config();
    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->Radius::AcctLogGeneric::activate();
    $self->Radius::SqlDb::activate();
    return;
}

#####################################################################
# Log an accounting message
# $result is $main::ACCEPT, $main::IGNORE, $main::REJECT, etc.
# $reason is the reason, $p is the request packet
sub acctlog
{
    my ($self, $result, $reason, $p) = @_;

    my @bind_values = ();
    my $trace_id = $p->{trace_id};

    if ($self->{LogQuery})
    {
	return unless $self->reconnect();
	if (!$self->{LogQueryParam})
	{
	    $self->do(&Radius::Util::format_special
		      ($self->{LogQuery}, $p, $self,
		       $result,
		       $self->quote($reason),
		       $self->quote($p->getUserName()),
		       $self->quote($p->getOriginalUserName()),
		       $trace_id,
		      ));
	}
	else
	{
	    map (push(@bind_values, Radius::Util::format_special(
			  $_, $p, $self,
			  $result, $reason, $p->getUserName(), $p->getOriginalUserName(), $trace_id)),
		 @{$self->{LogQueryParam}});

	    $self->prepareAndExecute($self->{LogQuery}, @bind_values);
	}
    }
}

1;
