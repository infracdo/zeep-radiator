# StatsLogREDIS.pm
#
# Log statistics to Redis. The statistics are stored in JSON format.
#
# Author: Tuure Vartiainen (vartiait@archred.com)
# Copyright (C) 2015 Arch Red Oy
# $Id$

package Radius::StatsLogREDIS;
use strict;
use warnings;
our @ISA = qw(Radius::StatsLogGeneric);
use Radius::StatsLogGeneric;
use Radius::Gossip;

%Radius::StatsLogREDIS::ConfigKeywords =
(
 'StatsKey' =>
 ['string', "Redis key to store stats. Defaults to 'Radiator::StatsLogREDIS'", 1],
);

# RCS version number of this module
$Radius::StatsLogREDIS::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{OutputFormat} = 'JSON';
    $self->{StatsKey} = 'Radiator:StatsLogREDIS';
    $self->{redis} = undef;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    unless (defined $Radius::Gossip::handle &&
	    ref($Radius::Gossip::handle) eq 'Radius::GossipRedis')
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: GossipRedis is required, but no GossipRedis defined in '$main::config_file'");
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: No Redis handle, StatsLogREDIS disabled");
    }
    else
    {
	$self->{redis} = \$Radius::Gossip::handle;
    }
}

#####################################################################
# Log all the Statistics from one object
sub logObject
{
    my ($self, $object) = @_;

    # Config is missing GossipRedis?
    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Cannot log stats, ref. handle for REDIS is undefined");
	return;
    }

    my $type = $object->{ObjType} || (split(/:/, ref($object)))[2];
    my $id = $object->{Identifier} || $object->{Name} || 'unknown';
    my $object_id = $main::config->{Identifier} . "/$type:$id";
    my $values = { };

    # Check StatsTypes and act accordingly.
    # Cumulative, derivative and packet_rate produces output in similar manner as
    # in StatsLogFILE and SQL. Type all produces leaf structure (cumulative_counters,
    # derivative_counters and packet_rates) which contain statistics attributes (e.g.
    # requests, droppedRequests, ...).
    if ($self->{StatsType} eq $Radius::StatsLog::Type::All)
    {
	$self->get_all_statistics($object, $values);
    }
    else
    {
	map { $values->{$_} = $self->get_statistics($object, $_) } keys %Radius::StatsLogGeneric::statistic_names;
    }

    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Logging statistic for '$object_id'");

    # Log some extra attributes such as time elapsed between StatsLogREDIS invocations and statistics type.
    my $entry = {
	log_type => "radiator",
	stats_type => $self->{StatsType},
	time_elapsed => $self->{statistics}->{time_elapsed},
	timestamp => time,
	object => $object_id,
	main_pps => $self->{statistics}->{packet_rate},
	%{$values},
    };

    # Encode in to configured output format and store values in Redis
    my $enc = $self->format_output($entry);

    my $key = Radius::Util::format_special($self->{StatsKey});
    ${$self->{redis}}->exec_call(
	sub { $_[0]->{redis}->rpush($key, $enc, $_[0]->get_redis_callback(sub {})); }
	);
}

1;

