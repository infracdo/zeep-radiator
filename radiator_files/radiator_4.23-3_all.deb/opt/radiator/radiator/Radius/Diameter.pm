# Diameter.pm
#
# Low level routines for sending and receiving Diameter requests
# over a TCP stream.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2005 Open System Consultants
# $Id$

package Radius::Diameter;
@ISA = qw(Radius::Stream);
use Radius::Stream;
use Radius::DiaStatsLogGeneric;
use strict;

# RCS version number of this module
$Radius::Diameter::VERSION = '$Revision$';

# A hash for storing statistics for this Radiator instance
$main::dia_statistics = {};

#####################################################################
# Called by Stream.pm when there is some pending data in inbuffer
# Process as many complete messages as possible, calling the superclass recv()
# for each one
sub read_data
{
    my ($self) = @_;

    while (length $self->{inbuffer} >= 4)
    {
	# Have a DIAMETER header at least
	my  ($verslen) = unpack('N', $self->{inbuffer}); # 1 octet of version, 3 of length
	my $length = $verslen & 0xffffff;
	my $version = $verslen >> 24;

	# Make some trivial checks on the request
	if ($length > $self->{MaxBufferSize})
	{
	    $self->log($main::LOG_ERR, "Diameter received a request with excessive length $length. Disconnecting");
	    dia_peer_errors_increment($self->{Peeraddress}, $self->{Port}, 'Error-Length');
	    $self->stream_disconnected();
	}
	if ($version != 1)
	{
	    $self->log($main::LOG_ERR, "Diameter received a request with unsupported version $version. Disconnecting");
	    dia_peer_errors_increment($self->{Peeraddress}, $self->{Port}, 'Error-Diameter-Version');
	    $self->stream_disconnected();
	}

	# Have at least one complete message yet?
	last unless length($self->{inbuffer}) >= $length;

	# Have the entire request
	# Update incoming messages count
	Radius::Diameter::dia_total_stats_increment($Radius::DiaStatsLog::Direction::In);

	# Get, clear and handle this request.
	# Superclass is expected to implement recv_diameter()
	$self->recv_diameter(substr($self->{inbuffer}, 0, $length, ''));
    }
}

#####################################################################
# Incrementing DIAMETER statistics. This function should not be called directly.
# The idea is to take list as parameter and construct a hash of hashes from it.
sub dia_stats_increment
{
    my $ref = $main::dia_statistics;

    foreach (@_)
    {
        $ref->{$_} = {} if !$ref->{$_};
        $ref = $ref->{$_};
    }
    $ref->{count}++;
    $ref->{last_update} = time();
}

#####################################################################
# Increment error counters.
sub dia_errors_increment
{
    main::log($main::LOG_DEBUG, "Incrementing error counters: " . join(", ", @_));

    dia_stats_increment("errors", @_);
}

#####################################################################
# Increment peer-related error counters.
sub dia_peer_errors_increment
{
    my ($peer_address, $peer_port, @event) = @_;

    main::log($main::LOG_DEBUG, "Incrementing errors counters (peer $peer_address:$peer_port): " . join(", ", @event));

    dia_stats_increment("peers", $peer_address, $peer_port, "errors", @event);
}

#####################################################################
# Increment per peer counters.
sub dia_peer_stats_increment
{
    dia_stats_increment("peers", @_);
}

#####################################################################
# Increment total message statistics.
sub dia_total_stats_increment
{
    dia_stats_increment("total", @_);
}

1;
