# Win32Service.pm
#
# Utility routines For running Radiator as a Windows service
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2003 Open System Consultants Pty Ltd
#
# $Id$

package Radius::Win32Service;
use Win32;
use Win32::Daemon;
use strict;
use warnings;

# RCS version number of this module
$Radius::Win32Service::VERSION = '$Revision$';

#####################################################################
# Start and run as a service, monitor for changes in state
sub service
{
    # Required by 2016 server for stopping, etc this service
    Win32::Daemon::AcceptedControls(SERVICE_ACCEPT_STOP |
				     SERVICE_ACCEPT_SHUTDOWN |
				     SERVICE_ACCEPT_PAUSE_CONTINUE);

    Win32::Daemon::StartService();

    my $state;
    my $prev_state = SERVICE_START_PENDING;
    while (($state = Win32::Daemon::State()) != SERVICE_STOPPED)
    {
	if ($state == SERVICE_START_PENDING
	    || $main::restart)
	{
	    main::initialize();
	    Win32::Daemon::State(SERVICE_RUNNING);
	    $prev_state = SERVICE_RUNNING;
	}
	elsif ($state == SERVICE_RUNNING)
	{
	    # This will handle a few events and then return
	    main::handleEvents();
	}
	elsif ($state == SERVICE_STOP_PENDING)
	{
	    Win32::Daemon::State(SERVICE_STOPPED);
	    $prev_state = SERVICE_STOPPED;
	}
	elsif ($state == SERVICE_PAUSE_PENDING)
	{
	    Win32::Daemon::State(SERVICE_PAUSED);
	    $prev_state = SERVICE_PAUSED;
	}
	elsif ($state == SERVICE_CONTINUE_PENDING)
	{
	    Win32::Daemon::State(SERVICE_RUNNING);
	    $prev_state = SERVICE_RUNNING;
	}
	else
	{
	    Win32::Daemon::State($prev_state);
	    sleep(1);
	}
    }

    main::log($main::LOG_NOTICE, "Windows service stopped: $main::ident");
    Win32::Daemon::StopService();
    return;
}

#####################################################################
# Permanently install this executable as a service
# Returns true on success, false otherwise.
sub install
{
    return 0 unless Radius::Win32Service::uninstall();

    # Do some sanity checks:
    if ($0 !~ /^\D:/)
    {
	print STDERR "ERROR: You have specified '$0'
as your Radiator program name.
To run Radiator as a service, the Radiator program name
must be given as a FULL path name including the drive letter,
typically something like
  C:\\Perl\\bin\\radiusd
Radiator was not installed\n";
    }
    elsif ($main::config_file !~ /^\D:/)
    {
	print STDERR "ERROR: You have specified '$main::config_file'
as your Radiator configuration file name.
To run Radiator as a service, the configuration file name
must be given as a FULL path name including the drive letter,
typically something like
  -config_file \"C:\\Program Files\\Radiator\\radius.cfg\"
Radiator was not installed\n";
    }
    elsif (!-f $main::config_file)  ## no critic (ValuesAndExpressions::ProhibitFiletest_f)
    {
	print STDERR "ERROR: You have specified '$main::config_file'
as your Radiator configuration file name, but that name does
not seem to exist as a readable file on this system.
To run Radiator as a service, the configuration file name
must be given as a FULL path name including the drive letter,
typically something like
  -config_file \"C:\\Program Files\\Radiator\\radius.cfg\"
Radiator was not installed\n";
    }
    else
    {
	# OK to install
	# Build a command line for the service
	my $servicename = $main::servicename || 'Radiator';
	my $parameters = make_service_parameters();

	# These options install on the local machine to run under the System Account
	my %options =
	    (
	     machine     => '',
	     name        => $servicename,
	     display     => "$servicename AAA Server",
	     path        => $^X,
	     user        => '',
	     pwd         => '',
	     description => 'Provides RADIUS, TACACS+ and other authentication, authorization and accounting services',
	     parameters  => $parameters,
	     );

	if (!Win32::Daemon::CreateService(\%options))
	{
	    my $error = Win32::Daemon::GetLastError();
	    $error = "$error: " . Win32::FormatMessage($error);
	    print STDERR "Failed to install Radiator as a Windows service named $servicename: $error\n";
	    return 0;
	}
	return 1;
    }

    return 0; # Failed
}

# Create service parameters based on radiusd command line parameters
sub make_service_parameters
{
    my @command = ($0, '-service', @main::original_argv);

    # Remove command line options that are not needed when running
    # as a service

    # -installservice is needed only for service creation
    @command = grep { $_ ne '-installservice' } @command;

    # These parameters are for service creation or perl.exe, not
    # radiusd as a service
    for my $index (reverse 0..$#command)
    {
	if ($command[$index] eq '-serviceperlargs' ||
	    $command[$index] eq '-servicename')
	{
	    splice(@command, $index, 2);
	}
    }

    # Quote any options in the command line that may have spaces
    foreach (@command)
    {
	$_ = "\"$_\"" if /\s/;
    }

    my $parameters = join(' ', @command);

    # Prepend for perl.exe. Note: we can't quote whitespace for
    # -serviceperlargs because we don't know if whitespace is
    # parameter separator or part of parameter value.
    $parameters = $main::serviceperlargs . ' ' . $parameters
	if $main::serviceperlargs;

    return $parameters;
}

#####################################################################
# Permanently uninstall this executable as a service.
# Returns true on success, false otherwise.
sub uninstall
{
    my $servicename = $main::servicename || 'Radiator';
    my $ret = 1; # Default to success
    if (!Win32::Daemon::DeleteService('', $servicename))
    {
	my $error = Win32::Daemon::GetLastError();
	unless ($error == 1060 || $error == 1072)
	{
	    $error = "$error: " . Win32::FormatMessage($error);
	    print STDERR "Failed to uninstall Radiator as a Windows service named $servicename: $error\n";
	    $ret = 0;
	}
    }

    return $ret;
}

1;



