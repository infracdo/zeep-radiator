# MessageLogGeneric.pm
#
# Generic module for logging incoming and outgoing RADIUS, Diameter
# and TACACS+ messages.
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::MessageLogGeneric;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use strict;
use warnings;

%Radius::MessageLogGeneric::ConfigKeywords =
(
 'LogSelectHook' =>
 ['hook',
  'Specifies an optional Perl hook that will be run for each log message when defined. If it returns true the message is logged, otherwise logging is skipped. By default no Hook is defined and all messages are logged. Hooks arguments are direction, protocol, from_ip, from_port, to_ip, to_port, request_object.', 1],

);

# RCS version number of this module
$Radius::MessageLogGeneric::VERSION = '$Revision$';

# MessageLog direction
$Radius::MessageLogGeneric::Direction::IN  = 'in';
$Radius::MessageLogGeneric::Direction::OUT = 'out';

# MessageLog protocols
$Radius::MessageLogGeneric::Protocol::NONE       = 'none';
$Radius::MessageLogGeneric::Protocol::INTERNAL   = 'internal';
$Radius::MessageLogGeneric::Protocol::RADIUS     = 'radius';
$Radius::MessageLogGeneric::Protocol::RADSEC     = 'radsec';
$Radius::MessageLogGeneric::Protocol::DIAMETER   = 'diameter';
$Radius::MessageLogGeneric::Protocol::TACACSPLUS = 'tacacsplus';
$Radius::MessageLogGeneric::Protocol::DHCP       = 'dhcp';
$Radius::MessageLogGeneric::Protocol::DHCPV6     = 'dhcpv6';

# Create a one to one map from protocol name to the same name. We'll
# use it later to check for valid protocol names, etc.
%Radius::MessageLogGeneric::protocol_to_name = ();
foreach my $proto (keys %Radius::MessageLogGeneric::Protocol::)
{
    my $value = ${$Radius::MessageLogGeneric::Protocol::{$proto}};
    $Radius::MessageLogGeneric::protocol_to_name{$value} = $value;
}

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
    $self->{ObjType} = 'MessageLog'; # Maintain an Identifier directory
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();
}

#####################################################################
# Find the allocator module with the identifier name given
sub find
{
    return Radius::Configurable::find('MessageLog', $_[0]);
}

#####################################################################
# RADIUS logging

# Log an incoming RADIUS message
# $p is the incoming message
sub log_radius_in
{
    my ($self, $p) = @_;

    my ($from_ip, $from_port, $to_ip, $to_port, $data, $message_log_proto);

    ($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in($p->{RecvSockname});
    $from_ip = $p->{RecvFromAddress};
    $from_port = $p->{RecvFromPort};
    $data = $p->{RecData};
    $message_log_proto = $p->{internal_vars}->{MessageLogProtocol};

    if ($self->{LogSelectHook})
    {
	my $from_ip_p = Radius::Util::inet_ntop($from_ip);
	my $to_ip_p   = Radius::Util::inet_ntop($to_ip);
	my ($log) = $self->runHook('LogSelectHook', $p, $Radius::MessageLogGeneric::Direction::IN,
				   $message_log_proto, $from_ip_p, $from_port, $to_ip_p, $to_port, $p);
	return unless $log;
    }

    $self->log_radius_msg($p, $from_ip, $from_port, $to_ip, $to_port, $data, $message_log_proto);
}

# Log an outgoing RADIUS message
# $rp is the outgoing message
# $p is the message that caused this $rp
sub log_radius_out
{
    my ($self, $rp, $p) = @_;

    my ($from_ip, $from_port, $to_ip, $to_port, $data, $message_log_proto);

    if ($rp->{SendSocket})
    {
	# $rp is e.g., a proxied message
	($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in($rp->{SendTo});
	($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in(getsockname($rp->{SendSocket}));
    }
    elsif ($rp->{ThisHost})
    {
	# $rp is e.g., a RadSec proxied message
	($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in($rp->{ThisHost}->{PeerName});
	($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in(getsockname($rp->{ThisHost}->{socket}));
    }
    else
    {
	# Typically a reply back to the client
	$to_port = $p->{RecvFromPort};
	$to_ip = $p->{RecvFromAddress};
	($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in($p->{RecvSockname});
    }
    $data = $rp->{Packet};
    $message_log_proto = $rp->{internal_vars}->{MessageLogProtocol};

    if ($self->{LogSelectHook})
    {
	my $from_ip_p = Radius::Util::inet_ntop($from_ip);
	my $to_ip_p   = Radius::Util::inet_ntop($to_ip);
	my ($log) = $self->runHook('LogSelectHook', $p, $Radius::MessageLogGeneric::Direction::OUT,
				   $message_log_proto, $from_ip_p, $from_port, $to_ip_p, $to_port, $p, $rp);
	return unless $log;
    }

    $self->log_radius_msg($rp, $from_ip, $from_port, $to_ip, $to_port, $data, $message_log_proto);
}

# RADIUS message logging function the subclasses must implement
sub log_radius_msg
{
    my ($self, $p, $from_ip, $from_port, $to_ip, $to_port, $data, $message_log_proto) = @_;

    $self->log($main::LOG_WARNING, "You forgot to override log_radius_msg()", $p);
}

#####################################################################
# Diameter logging

# Log an incoming Diameter message
# $data is the message in binary format
# $conn is the Stream object for the incoming message
# $m, if defined, is the incoming message object DiaMsg
sub log_diameter_in
{
    my ($self, $data, $conn, $m) = @_;

    my ($from_ip, $from_port, $to_ip, $to_port);
    ($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in(getsockname($conn->{socket}));
    ($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in($conn->{PeerName});

    if ($self->{LogSelectHook})
    {
	my $from_ip_p = Radius::Util::inet_ntop($from_ip);
	my $to_ip_p   = Radius::Util::inet_ntop($to_ip);
	my ($log) = $self->runHook('LogSelectHook', undef, $Radius::MessageLogGeneric::Direction::IN,
				   $Radius::MessageLogGeneric::Protocol::DIAMETER, $from_ip_p, $from_port, $to_ip_p, $to_port, $m);
	return unless $log;
    }

    $self->log_diameter_msg($m, $from_ip, $from_port, $to_ip, $to_port, $data);
}

# Log an outgoing Diameter message
# $m, if defined, is the outgoing message object DiaMsg
# $data is the message in binary format
# $conn is the Stream object for the outgoing message
# $m, if defined, is the outgoing message object DiaMsg
sub log_diameter_out
{
    my ($self, $data, $conn, $m) = @_;

    my ($from_ip, $from_port, $to_ip, $to_port);
    if ($conn->{socket})
    {
	($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in(getpeername($conn->{socket}));
	return unless defined $to_ip; # Can happen if the socket was just disconnected
	($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in(getsockname($conn->{socket}));
    }
    else
    {
	# We may be waiting for the connection to come up
	($to_port, $to_ip) = (0, Radius::Util::inet_pton('0.0.0.0'));
	($from_port, $from_ip) = ($to_port, $to_ip);
    }

    if ($self->{LogSelectHook})
    {
	my $from_ip_p = Radius::Util::inet_ntop($from_ip);
	my $to_ip_p   = Radius::Util::inet_ntop($to_ip);
	my ($log) = $self->runHook('LogSelectHook', undef, $Radius::MessageLogGeneric::Direction::OUT,
				   $Radius::MessageLogGeneric::Protocol::DIAMETER, $from_ip_p, $from_port, $to_ip_p, $to_port, $m);
	return unless $log;
    }

    $self->log_diameter_msg($m, $from_ip, $from_port, $to_ip, $to_port, $data);
}

# Diameter message logging function the subclasses must implement
# $m, if defined, is the diameter message
# $data is always defined and is the message in binary format
sub log_diameter_msg
{
    my ($self, $m, $from_ip, $from_port, $to_ip, $to_port, $data) = @_;

    $self->log($main::LOG_WARNING, "You forgot to override log_diameter_msg()");
}

#####################################################################
# TACACS+ logging

# Log an incoming TACACS+ message
# $data is TACACS+ message octets
# $conn is Radius::TacacsplusConnection for the message
sub log_tacacsplus_in
{
    my ($self, $data, $conn) = @_;

    my ($from_ip, $from_port, $to_ip, $to_port);
    ($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in(getsockname($conn->{socket}));
    ($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in($conn->{peer});

    $self->log_tacacsplus_msg($conn, $from_ip, $from_port, $to_ip, $to_port, $data);
}

# Log an outgoing TACACS+ message
# $data is TACACS+ message octets
# $conn is Radius::TacacsplusConnection for the message
sub log_tacacsplus_out
{
    my ($self, $data, $conn) = @_;

    my ($from_ip, $from_port, $to_ip, $to_port);
    if ($conn->{socket})
    {
	($to_port, $to_ip) = Radius::Util::unpack_sockaddr_in($conn->{peer});
	return unless defined $to_ip; # Can happen if the socket was just disconnected
	($from_port, $from_ip) = Radius::Util::unpack_sockaddr_in(getsockname($conn->{socket}));
    }
    else
    {
	# We may be waiting for the connection to come up
	($to_port, $to_ip) = (0, Radius::Util::inet_pton('0.0.0.0'));
	($from_port, $from_ip) = ($to_port, $to_ip);
    }

    $self->log_tacacsplus_msg($conn, $from_ip, $from_port, $to_ip, $to_port, $data);
}

# TACACS+ message logging function the subclasses must implement
sub log_tacacsplus_msg
{
    my ($self, $conn, $from_ip, $from_port, $to_ip, $to_port, $data) = @_;

    $self->log($main::LOG_WARNING, "You forgot to override log_tacacsplus_msg()");
}

1;
