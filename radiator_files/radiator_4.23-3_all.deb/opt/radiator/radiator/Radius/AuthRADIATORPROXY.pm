# AuthRADIATORPROXY.pm
#
# Object for sending a specially labeled RADIUS packet to a Radiator
# load balancer for forwarding to the actual destination NAS.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AuthRADIATORPROXY;
@ISA = qw(Radius::AuthRADIUSBYATTR);
use Radius::AuthRADIUSBYATTR;
use Radius::Gossip;
use Radius::Util;
use Scalar::Util qw(refaddr);
use strict;
use warnings;

# Reusable keyword definitions
@Radius::AuthRADIATORPROXY::hostkeywords =
(
 'Address' =>
 ['string', 'A Destination address to which forward RADIUS requests.', 1],

 'Port' =>
 ['integer', 'Defines a destination port to which forward RADIUS requests.', 0],
);

%Radius::AuthRADIATORPROXY::ConfigKeywords =
(
 'RadiatorProxies' =>
 ['objectlist', 'List of hardwired peers in order of transmission attempts.', 0],

 'ProxyRequest' =>
 ['flag', 'Use OSC Proxy instead of generating DYNAUTH request.', 1],

 @Radius::AuthRADIATORPROXY::hostkeywords,
);

# RCS version number of this module
$Radius::AuthRADIATORPROXY::VERSION = '$Revision$';

sub initialize {
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{radiator_proxies} = {};
    $self->{ProxyRequest}     = 0;

    main::addChildInitFn(\&childInit, $self);
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Discover OSC Radius proxy when running on single process mode
    $self->discover_proxy() if $self->{Gossip} && ! $main::config->{FarmSize};
}

sub childInit
{
    my ($self) = @_;

    # Discover OSC Radius proxy when running with FarmSize
    $self->discover_proxy() if $self->{Gossip};
}

sub object
{
    my ($self, $file, $keyword, $name, @args) = @_;

    if ($keyword eq 'RadiatorProxy')
    {
	$self->add_proxy($name, $file, @args);
	return 1;
    }

    return $self->SUPER::object($file, $keyword, $name, @args);
}

sub add_proxy
{
    my ($self, $name, $file, @args) = @_;

    # Don't add a same host twice, compare Name or Address & Port
    my $add_host = 1;
    foreach my $host (@{$self->{RadiatorProxies}})
    {
	# Compare Name, Port and Addresses
	if ($host->{Name} eq $name)
	{
	    $add_host = 0;
	}

	unless ($add_host)
	{
	    if ($host->{is_failed})
	    {
		# If Host was marked failed, mark it active again
		$host->{is_failed} = 0;
		$self->log($main::LOG_INFO, "Marking RadiatorProxy '$name' as active again.");
	    }
	    last;
	}
    }
    unless ($add_host)
    {
	$self->log($main::LOG_WARNING, "Not adding RadiatorProxy '$name' as it already existed.");
	return;
    }

    my $object = Radius::RadiatorProxy->new
	($file, $name,
	 'Identifier'		      => $name || "Unknown",
	 'Address'		      => $self->{Address},
	 'Port'			      => $self->{Port},
	 'Parent'		      => $self,
	 @args
	);
    return unless $object;

    $object->activate();

    # Add all addresses
    foreach my $address (@{$object->{Addresses}})
    {
	$self->add_radiator_proxy($name, $address, $object->{Port}, 1);
    }

    push(@{$self->{RadiatorProxies}}, $object);

    return $object;
}

sub discover_proxy
{
    my ($self) = @_;

    if ($self->{Gossip} && ! $Radius::Gossip::handle)
    {
	$self->log($main::LOG_WARNING, "No Gossip method defined for AuthRADIATORPROXY at '$main::config_file' line $.");
	return;
    }

    # Register to learn OSC RADIUS proxy IPs and ports
    $Radius::Gossip::handle->register_message_handle("NFV-RadiusProxy-Peer-JOIN",   sub { my ($message) = @_; $self->process_proxy_report($message); });
    $Radius::Gossip::handle->register_message_handle("NFV-RadiusProxy-Peer-UNJOIN", sub { my ($message) = @_; $self->process_proxy_report($message); });

    # Send discover request from the last farm instance
    if (! defined $main::config->{FarmSize} || $main::farmInstance == $main::config->{FarmSize})
    {
	# Send NFV-Proxy-Report gossip message
	my $gossip_message = {
	    version   => 1,
	    type      => "NFV-RadiusProxy-Report",
	    from      => $main::hostname . "." . $main::farmInstance,
	    from_id   => "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self),
	    timestamp => time(),
	};

	$self->log($main::LOG_DEBUG, "AuthRADIATORPROXY $self->{Identifier}: Discovering Radius proxies through Gossip");
	$Radius::Gossip::handle->tell_others($gossip_message);
    }
}

sub add_radiator_proxy
{
    my ($self, $name, $address, $port, $address_binary) = @_;

    # All requests are forwarded to same port of the proxy so addresses can be
    # translated and packed beforehand.
    my $addr_n;
    if ($address_binary)
    {
	$addr_n = $address;
	$address = Radius::Util::inet_ntop($address);
    }
    else
    {
	$addr_n = Radius::Util::inet_pton($address);
    }
    my $packed_addr = Radius::Util::pack_sockaddr_in($port, $addr_n);
    $self->log($main::LOG_DEBUG, "AuthRADIATORPROXY $self->{Identifier}: Adding a new proxy '$name' $address $port");
    $self->{radiator_proxies}->{$name} = {
	from        => $name,
	address     => $address,
	port        => $port,
	address_n   => $addr_n,
	packed_addr => $packed_addr,
	is_failed   => 0,
    };

    return;
}

sub delete_radiator_proxy
{
    my ($self, $name, $address, $port) = @_;

    my $peer = delete $self->{radiator_proxies}->{$name};
    unless($peer)
    {
	$self->log($main::LOG_DEBUG, "AuthRADIATORPROXY: Trying to delete nonexistent RadiusProxy Peer: $name (address = $address, port = $port)");
    }

    return;
}

sub process_proxy_report
{
    my ($self, $message) = @_;

    # Process proxy join messages
    if ($message->{type} eq "NFV-RadiusProxy-Peer-JOIN")
    {
	unless($message->{from} || $message->{address} || $message->{port})
	{
	    $self->log($main::LOG_ERROR, "AuthRADIATORPROXY: Incomplete $message->{type} received.");
	    return;
	}

	$self->add_radiator_proxy($message->{from}, $message->{address}, $message->{port});
    }
    # Process proxy unjoin messages
    elsif ($message->{type} eq "NFV-RadiusProxy-Peer-UNJOIN")
    {
	$self->delete_radiator_proxy($message->{from}, $message->{address}, $message->{port});
    }
    else
    {
	$self->log($main::LOG_DEBUG, "AuthRADIATORPROXY: Unknown message type $message->{type} $message->{from} (address = $message->{address})");
	return;
    }

    $self->log($main::LOG_DEBUG, "AuthRADIATORPROXY: Processed $message->{type} from $message->{from} (address = $message->{address}, port = $message->{port})");

    return;
}

# We override chooseHost so that we can make and add the label
# Radiator proxy requires.
sub chooseHost
{
    my ($self, $fp, $p) = @_;
    my $host;

    unless (%{$self->{radiator_proxies}})
    {
	$self->log($main::LOG_WARNING, "AuthRADIATORPROXY: No Radiator proxies available, can not forward", $p);
	return;
    }

    if ($self->{ProxyRequest})
    {
	$host = $self->Radius::AuthRADIUS::chooseHost($fp, $p);
    }
    else
    {
	$host = $self->SUPER::chooseHost($fp, $p);
    }

    if ($host)
    {
	my $dst_port;
	$dst_port = $host->{AuthPort} if $fp->code eq 'Access-Request';
	$dst_port = $host->{AcctPort} if $fp->code eq 'Accounting-Request';
	if ($fp->code eq 'Disconnect-Request' || $fp->code eq 'Change-Filter-Request')
	{
	    if ($host->{DynAuthPort})
	    {
		$dst_port = $host->{DynAuthPort};
	    }
	    else
	    {
		$dst_port = $host->{AuthPort};
	    }
	}
	if (! $dst_port)
	{
	    $self->log($main::LOG_WARNING, "AuthRADIATORPROXY: Don't know how to proxy request type '" . $fp->code . "'", $p);
	    return;
	}
	$self->add_proxy_info($fp, $p, @{$host->{Address}}[0], $dst_port);
    }

    return $host;
}

# Add the Radiator load balancer label and packed address information
# in $fp. These allow forwarding the RADIUS request to the proxy which
# will then extract the label and forward to the destination NAS.
#
# $fp is the RADIUS request
# $p is the original request from the NAS or the pseudo request to
#    help handling $fp
sub add_proxy_info
{
    my ($self, $fp, $p, $dest_nas_addr, $dest_nas_port) = @_;

    # Append OSC's label in the data. Proxy packs the label like this:
    # VSA OSC (9048), OSC-Forwarded-For (22) and OSC-Trace-Id (23)
    # my $label = pack('C C N C C a16 n a16 n C C N', 26, 50, 9048, 22, 38, $src_addr, $src_port, $dst_addr, $dst_port, 23, 6, $trace_id);

    # Destination NAS address expanded for the label
    my $dest_nas = "\x00" x 16;
    $dest_nas |= "\x00" x (16 - length($dest_nas_addr)) . $dest_nas_addr;

    # We tell proxy to use wildcard source address and port. Might
    # use a specific address in the future.
    my $proxy_ip = "\x00" x 16;
    my $proxy_port = 0;

    # Update trace id
    my $trace_id = hex($p->{trace_id});
    $trace_id += 1;
    $trace_id = unpack('H*', pack('N', $trace_id));

    my $vsa = pack('C C N C C a16 n a16 n C C H*', 26, 50, 9048, 22, 38, $dest_nas, $dest_nas_port, $proxy_ip, $proxy_port, 23, 6, $trace_id);
    $fp->{RecvFromLabel} = $vsa;

    # Pick the proxy to use to send to the NAS.
    my ($proxy, $i);
    my $max_proxies = scalar keys %{$self->{radiator_proxies}};
    do
    {
	$proxy = (keys %{$self->{radiator_proxies}})[int(rand($max_proxies))]; # Pick a random proxy
	++$i;
    }
    while ($self->{radiator_proxies}->{$proxy}->{is_failed} && $i < $max_proxies);

    if ($proxy)
    {
	$fp->{SendToDestAddr} = $self->{radiator_proxies}->{$proxy}->{address_n};
	$fp->{SendToDestPort} = $self->{radiator_proxies}->{$proxy}->{packed_addr};

	$self->log($main::LOG_DEBUG, "AuthRADIATORPROXY: Using proxy $proxy (address = $self->{radiator_proxies}->{$proxy}->{address}, port = $self->{radiator_proxies}->{$proxy}->{port}) for NAS " . Radius::Util::inet_ntop($dest_nas_addr) . " $dest_nas_port", $p);
    }
    else
    {
	$self->log($main::LOG_ERR, "AuthRADIATORPROXY: All proxies marked failed, could not proxy a request to NAS " . Radius::Util::inet_ntop($dest_nas_addr) . " $dest_nas_port", $p);
    }
}

package Radius::RadiatorProxy;
@Radius::RadiatorProxy::ISA = qw(Radius::Configurable);

%Radius::RadiatorProxy::ConfigKeywords =
(
 @Radius::AuthRADIATORPROXY::hostkeywords
);

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;

    $self->{AuthPort} = 1645;
    $self->{AcctPort} = 1646;

    $self->{is_failed} = 0;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Permit formatting chars in the host name
    my $name = Radius::Util::format_special($self->{Name});

    # If there are multiple addresses, remember them for round-robin
    my ($cname, $aliases, $addrtype, $length, @addrs) = Radius::Util::gethostbyname($name);

    if (!@addrs)
    {
	# Nothing in the DNS, try to convert from presentation to network
	$addrs[0] = Radius::Util::inet_pton($name);
	unless (defined $addrs[0] && $addrs[0] ne '')
	{
	    ($cname, $aliases, $addrtype, $length, @addrs) = Radius::Util::gethostbyname($self->{Address});
	    if (!@addrs)
	    {
		$addrs[0] = Radius::Util::inet_pton($self->{Address});
		unless (defined $addrs[0] && $addrs[0] ne '')
		{
		    @addrs = ();
		}
	    }
	}
    }

    if (!@addrs)
    {
	# still nothing!
	$self->log($main::LOG_WARNING, "GossipUDPPeer '$name' has no IP address at '$main::config_file' line $.");
	return;
    }

    @{$self->{Addresses}} = @addrs;
    $self->{Port} = Radius::Util::get_port($self->{Port});
}

1;
