# RDict.pm
#
# Object for handling radius dictionaries.
#
# Supports:
# - mapping attributes by name and number to detailed attribute
#   information
# - mapping attribute values by name and number to detailed value
#   information
# - mapping vendor name and number to vendor details
# - SubTLVs use by, for example, WiMAX
#
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::RDict;
use Radius::Util;
use File::Basename;
use English qw(-no_match_vars);
use strict;
use warnings;

# RCS version number of this module
$Radius::RDict::VERSION = '$Revision$';

my @known_types = qw(text string binary tagged-string hexadecimal
    integer signed-integer tagged-integer integer8 integer16 integer64
    boolean ipaddr ipaddrv4v6 ipaddrv6 date abinary ipv4prefix ipv6prefix
    ifid tlv custom);

#####################################################################
# Create a new dictionary object. If one or more files names are supplied,
# parse them. If any parsing fails, returns undef.
sub new
{
    my ($class, @files) = @_;

    my $self = {};
    bless $self, $class;
    $self->{AttrNum} = {}; # Hash of
    $self->{AttrName} = {}; # Hash of
    $self->{ValNum} = {};
    $self->{ValName} = {};
    $self->{VendorNum} = {}; # Vendor codes by number
    $self->{VendorName} = {}; # Vendor codes by name
    $self->{TLV} = {}; # Sub-Dictionary for each TLV
    foreach (@files)
    {
	$self->parse($_);
    }
    return $self;
}

#####################################################################
# Parse a dictionary file
sub parse
{
    my ($self, $filename) = @_;

    main::log($main::LOG_DEBUG, "Reading dictionary file '$filename'");

    my $ret = open(my $handle, '<', $filename);
    unless ($ret)
    {
	main::log($main::LOG_ERR, "Could not open dictionary file '$filename': $ERRNO");
	return 0;
    }
    $self->parse_handle($handle, $filename);
    close($handle);
    return 1;
}

#####################################################################
# parse_handle
# Parse a dictionary file
sub parse_handle
{
    my ($self, $handle, $handledesc) = @_;

    my $current_vendor = undef;
    my $current_tlv = undef;
    my @tlvs = (); # TLVs and therefore TLV dictionaries can be nested :-(
    while (my $line = <$handle>)
    {
	# Trim comments, leading and trailing whitespace, blank lines
	$line =~ s/#.*\z//s;
        $line =~ s/^\s*//s;
        $line =~ s/\s*\z//s;
	next unless length($line);

	# ATTRIBUTE name number type [flags]
	if ($line =~ m/^ATTRIBUTE\s+(\S+)\s+(\S+)\s+(\S+)(\s+(\S+))?/s)
	{
	    my $dict = $current_tlv || $self;
	    my $vendor = $current_tlv ? 0 : $current_vendor; # TLVs dont have vendor numbers
	    main::log($main::LOG_WARNING, "Failed to add attribute $1 in dictionary '$handledesc' line $NR Ignored")
		unless $dict->defineAttr($1, $2, $3, $vendor, $5);
	}
	# VENDORATTR|VSA|VENDOR_ATTRIBUTE vendornum name number type [flags]
	elsif ($line =~ m/^(VENDORATTR|VSA|VENDOR_ATTRIBUTE)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)(\s+(\S+))?/s)
	{
	    my ($vendor, $name, $attrnum, $type, $flags) = ($2, $3, $4, $5, $7);
	    # Convert vendor name to number if needed
	    $vendor = $self->{VendorName}{$vendor}[1]
		if $vendor !~ m/^\d+\z/s
		    && defined $self->{VendorName}{$vendor};
	    # Handle oct and hex
	    $attrnum = oct $attrnum if $attrnum =~ m/^0/s;
	    main::log($main::LOG_WARNING, "Failed to add attribute $name in dictionary '$handledesc' line $NR Ignored")
		unless $self->defineAttr($name, $attrnum, $type, $vendor, $flags);
	}
	# VALUE attrname valname valnum
	elsif ($line =~ m/^VALUE\s+(\S+)\s+(\S+)\s+((0x[0-9a-fA-F]{1,8})|([0-9]+))\z/s)
	{
	    my ($attrname, $valname, $valnum) = ($1, $2, $3);
	    $valnum = hex($valnum) if $valnum =~ m/^0x/s; # Handle hex

	    my $dict = $current_tlv || $self;
	    if (defined $dict->{AttrName}->{$attrname})
	    {
		$dict->defineVal($attrname, $valname, $valnum);
	    }
	    else
	    {
		# Dont complain too loud about these: some dictionaries are
		# guilty of it
		main::log($main::LOG_WARNING, "There is no attribute named $attrname in dictionary '$handledesc' before line $NR Ignored");
	    }
	}
	# Compatibility with Merit.
	# VENDOR_CODE  name number extra-info
	elsif ($line =~ m/^VENDOR(_CODE)?\s+(\S+)\s+(\S+)\s*(.*)/s)
	{
	    $self->defineVendor($2, $3, $4);
	}
	elsif ($line =~ m/^NAS_TYPE\s+(\d+)\s+(\S+)\s+(.*)/s)
	{
	    # $1 = value-as-int, $2 = Vendor-Code, $3 = Description
	}
	elsif ($line =~ m/^TACACS_VALUE\s+(\S+)\s+(\S+)\s+(\d+)/s)
	{
	    # $1 = Tac-Attrib, $2 = field name, $3 = function
	}
	elsif ($line =~ m/^ATTRIB_TACACS\s+(\S+)\s+(\S+)\s+(\S+)/s)
	{
	    # $1 = Tac-Attrib, $2 = value, $3 = type
	}
	elsif ($line =~ m/^BEGIN-VENDOR\s+(\S+)/si)
	{
	    # FreeRadius
	    my @vdetails = $self->vendorByName($1);
	    $current_vendor = $vdetails[1];
	}
	elsif ($line =~ m/^END-VENDOR/si)
	{
	    # FreeRadius
	    $current_vendor = undef;
	}
	elsif ($line =~ m/^BEGIN-TLV\s+(\S+)/si)
	{
	    push(@tlvs, $current_tlv); # Save the current TLV dictionary
	    my $dict = $current_tlv || $self;
	    $current_tlv = Radius::RDict->new();
	    $dict->{TLV}{$1} = $current_tlv;
	}
	elsif ($line =~ m/^END-TLV/si)
	{
	    # FreeRadius
	    $current_tlv = pop(@tlvs);
	}
	elsif ($line =~ m/^include\s+(.*)/s)
	{
	    # Radiator style include
	    # May be a glob
	    foreach my $inc_file (glob(Radius::Util::format_special($1)))
	    {
		$self->parse($inc_file);
	    }
	}
	elsif ($line =~ m/^\$INCLUDE\s+(.*)/s)
	{
	    # Freeradius style include, relative to this file
	    my $path = $1;
	    # RElative path
	    $path = dirname($handledesc) . '/' . $path
		unless $path =~ m/^\//s;
	    $self->parse($path);
	}
	else
	{
	    main::log($main::LOG_ERR, "Bad format in dictionary '$handledesc' at line $NR: $line");
	}

    }
    return 1;
}


#####################################################################
# defineAttr
# Define a new attribute
sub defineAttr
{
    my ($self, $name, $number, $type, $vendor, $flags) = @_;

    if ($name =~ m/^Unknown/s)
    {
	main::log($main::LOG_WARNING, "Attribute $name starts with reserved prefix 'Unknown', ignoring");
	return undef;
    }

    unless (grep {$type eq $_} @known_types)
    {
	main::log($main::LOG_WARNING, "Attribute $name uses unknown type '$type' on line $NR");
    }

    if ($vendor && !$self->{VendorNum}->{$vendor})
    {
	main::log($main::LOG_WARNING, "Vendor $vendor not defined for attribute '$name' on line $NR");
    }

    $vendor = 'IANA' unless defined $vendor;
    my $new_attr = [$name, $number, $type, $vendor, $flags];
    my $key = "$number,$vendor";
    # Clobber any previously existing defs
    $self->{AttrNum}->{$key} = $new_attr;
    $self->{AttrName}->{$name} = $new_attr;

    return $new_attr;
}

#####################################################################
# defineVal
# Define a new named value
sub defineVal
{
    my ($self, $attribute, $name, $number) = @_;

    my $v = [ $name, $number, $attribute ];
    # Clobber any previously existing defs
    $self->{ValName}->{$attribute}->{$name} = $v;
    $self->{ValNum}->{$attribute}->{$number} = $v;

    return $v;
}

#####################################################################
# defineVendor
# Define a new vendor
sub defineVendor
{
    my ($self, $name, $number, $extras) = @_;

    my $new_vendor = [$name, $number, $extras];

    # Clobber any previously existing defs
    $self->{VendorNum}->{$number} = $new_vendor;
    $self->{VendorName}->{$name} = $new_vendor;

    return $new_vendor;
}

sub vendorByName
{
    my ($self, $name) = @_;
    return @{$self->{VendorName}->{$name}};
}

sub vendorByNum
{
    my ($self, $num) = @_;
    return @{$self->{VendorNum}->{$num}};
}

#####################################################################
# Return all the details of an attribute given its name
# The array is (name, number, type, vendorid)
sub attrByName
{
    my ($self, $name) = @_;

    return exists $self->{AttrName}->{$name}
           ? @{$self->{AttrName}->{$name}} : undef;
}

#####################################################################
# Return all the attribute details for an attribute
# given the attribute number and vendor
# The returned array is (name, number, type, vendorid, flags)
sub attrByNum
{
    my ($self, $number, $vendor) = @_;

    $vendor = 'IANA' unless defined $vendor;
    my $key = "$number,$vendor";

    return @{$self->{AttrNum}->{$key}}
        if (exists $self->{AttrNum}->{$key});

    my $msg = '';
    $msg = " (vendor $vendor)" if $vendor ne 'IANA';
    main::log($main::LOG_ERR, "Attribute number $number$msg is not defined in your dictionary");
    return ('Unknown', $number, undef, undef, undef);
}

#####################################################################
# Return all the attribute details for an attribute given the
# attribute number and vendor. For unknown attributes return special
# name Unknown-vendor-number where vendor is 'IANA' for IANA type space.
# The returned array is (name, number, type, vendorid, flags, is_unknown)
sub attrOrUnknownByNum
{
    my ($self, $number, $vendor) = @_;

    $vendor = 'IANA' unless defined $vendor;
    my $key = "$number,$vendor";

    return (@{$self->{AttrNum}->{$key}}, 0)
        if (exists $self->{AttrNum}->{$key});

    # Unknown attribute from IANA type space or unknown vendor attribute
    return ("Unknown-$vendor-$number", $number, 'binary', $vendor, undef, 1);
}

#####################################################################
# Return the value name given the attritbue name and the value number
sub valNumToName
{
    my ($self, $attrname, $valnum) = @_;

    return $self->{ValNum}->{$attrname}->{$valnum}->[0]
	if (defined $valnum && exists $self->{ValNum}->{$attrname}->{$valnum});

    return undef;
}

#####################################################################
# Return the value number given the atribute name and value name
# IF its already an integer, dont to anything
sub valNameToNum
{
    my ($self, $attrname, $val) = @_;

    if (!defined $val)
    {
	main::log($main::LOG_ERR, "Undefined value for attribute $attrname. Using 0.");
	$val = 0;
    }
    elsif ($val =~ m/^0x([0-9a-fA-F]+)\z/si)
    {
	# Hex
	$val = hex($1);
    }
    else
    {
	# It might be a decimal integer, or it might be a VALUE with an integer name,
	# such as Tunnel-Medium-Type=802
	if (exists $self->{ValName}->{$attrname}->{$val})
	{
	    $val = $self->{ValName}->{$attrname}->{$val}->[1];
	}
	else
	{
	    # Is there a (possibly negative) decimal integer?
	    if ($val !~ m/^-?\d+\z/s)
	    {
		main::log($main::LOG_ERR, "There is no value named '$val' for attribute $attrname. Using 0.");
		$val = 0;
	    }
	}
    }
    return $val;
}

#####################################################################
# Return a list of all the valid value names for a given attribute name
sub valuesForAttribute
{
    my ($self, $attrname) = @_;

    my @sorted = sort keys %{$self->{ValName}->{$attrname}};
    return @sorted;
}

#####################################################################
# Returns the subdictionary for a TLV
sub dictForTLV
{
    my ($self, $tlvname) = @_;

    return $self->{TLV}{$tlvname};
}

1;
