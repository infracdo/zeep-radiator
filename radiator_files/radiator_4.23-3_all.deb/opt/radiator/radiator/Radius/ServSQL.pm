# ServSQL.pm
#
# SQL service and subscription databases
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::ServSQL;
use strict;
use warnings;
our @ISA = qw(Radius::ServGeneric Radius::SqlDb);
use Radius::ServGeneric;
use Radius::SqlDb;

%Radius::ServSQL::ConfigKeywords =
(
 'GetServiceQuery' =>
 ['string', 'An SQL statement to get a service. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'GetServiceQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with GetServiceQuery.', 1],

 'AddServiceQuery' =>
 ['string', 'An SQL statement to add a new service. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'AddServiceQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with AddServiceQuery.', 1],

 'UpdateServiceQuery' =>
 ['string', 'An SQL statement to update an existing service. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'UpdateServiceQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with UpdateServiceQuery.', 1],

 'DeleteServiceQuery' =>
 ['string', 'An SQL statement to delete a service. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'DeleteServiceQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with DeleteServiceQuery.', 1],

 'GetSubscriptionQuery' =>
 ['string', 'An SQL statement to get a subscription. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'GetSubscriptionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with GetSubscriptionQuery.', 1],

 'AddSubscriptionQuery' =>
 ['string', 'An SQL statement to add a new subscription. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'AddSubscriptionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with AddSubscriptionQuery.', 1],

 'UpdateSubscriptionQuery' =>
 ['string', 'An SQL statement to update an existing subscription. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'UpdateSubscriptionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with UpdateSubscriptionQuery.', 1],

 'DeleteSubscriptionQuery' =>
 ['string', 'An SQL statement to delete a subscription. Special variable \'%2\' contains a tenant id, \'%3\' contains object\'s id and \'%4\' contains object\'s name.', 1],

 'DeleteSubscriptionQueryParam' =>
 ['stringarray', 'This optional parameter enables the use of bound variables with DeleteSubscriptionQuery.', 1],
);

# RCS version number of this module
$Radius::ServSQL::VERSION = '$Revision$';

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->Radius::ServGeneric::initialize();
    $self->Radius::SqlDb::initialize();

    $self->{GetServiceQuery} = "SELECT * FROM SERVICES WHERE tenant_id=%2 AND (name=%4 OR id=%3)";
    $self->{AddServiceQuery} = "INSERT INTO SERVICES (%0) VALUES (%1)";
    $self->{UpdateServiceQuery} = "UPDATE SERVICES SET name=%4 WHERE tenant_id=%2 AND id=%3";
    $self->{DeleteServiceQuery} = "DELETE FROM SERVICES WHERE tenant_id=%2 AND id=%3";

    $self->{GetSubscriptionQuery} = "SELECT * FROM SUBSCRIPTIONS WHERE tenant_id=%2 AND (id=%3 OR name=%4)";
    $self->{AddSubscriptionQuery} = "INSERT INTO SUBSCRIPTIONS (%0) VALUES (%1)";
    $self->{UpdateSubscriptionQuery} = "UPDATE SUBSCRIPTIONS SET %0 WHERE tenant_id=%2 AND id=%3";
    $self->{DeleteSubscriptionQuery} = "DELETE FROM SUBSCRIPTIONS WHERE tenant_id=%2 AND id=%3";

    return;
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->Radius::ServGeneric::check_config();
    $self->Radius::SqlDb::check_config();

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->Radius::ServGeneric::activate();
    $self->Radius::SqlDb::activate();

    return;
}

#####################################################################
sub flush
{
    my ($self) = @_;

    return 1;
}

#####################################################################
sub get_service
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    return undef unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;
    return undef unless $self->reconnect();

    my ($service, @row);
    if ($self->{GetServiceQuery})
    {
	my ($q, @bind_values);
	if ($self->{GetServiceQueryParam})
	{
	    @bind_values = map { Radius::Util::format_special($_, undef, $self, undef, undef, $tenant_id, $id, $name) } @{$self->{GetServiceQueryParam}};
	    $q = Radius::Util::format_special($self->{GetServiceQuery}, undef, $self);
	}
	else
	{
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{GetServiceQuery}, undef, $self, undef, undef, $qtenant_id, $qid, $qname);
	}

	my $sth = $self->prepareAndExecute($q, @bind_values);
	return undef unless $sth;

	if (@row = $self->getOneRow($sth))
	{
	    if ($row[2] && index($row[2], '{') == 0)
	    {
		$service = $self->new_service_from_string($row[2], $row[0], $row[1]);
	    }
	    else
	    {
		$service = $self->new_service_from_array(@row);
	    }
	}
    }

    return $service;
}

#####################################################################
sub add_service
{
    my ($self, $id, $name, $service, $tenant_id) = @_;

    return 0 unless $service;
    return 0 unless (defined $id || defined $name);

    $tenant_id = $service->{tenant_id} unless defined $tenant_id;
    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return 0 unless $self->reconnect();

    if ($self->{AddServiceQuery})
    {
	my ($sth, $q);
	my @values = $service->attr_values(1);
	if ($self->{AddServiceQueryParam})
	{
	    my @bind_values = map { Radius::Util::format_special($_, undef, $self, join(',', $service->attr_keys()), join(',', @values), @values) } @{$self->{AddServiceQueryParam}};
	    $q = Radius::Util::format_special($self->{AddServiceQuery}, undef, $self);
	    $sth = $self->prepareAndExecute($q, @bind_values);
	}
	else
	{
	    shift @values; shift @values; shift @values;
	    @values = map { (defined $_ && $_ ne 'NULL') ? $self->quote($_) : $_ } @values;
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{AddServiceQuery}, undef, $self, join(',', $service->attr_keys()), join(',', ($qtenant_id, $qid, $qname, @values)), $qtenant_id, $qid, $qname, @values);
	    $sth = $self->do($q);
	}

	return 0 unless $sth;
    }

    return 1;
}

#####################################################################
sub update_service
{
    my ($self, $id, $name, $service, $tenant_id) = @_;

    return 0 unless $service;
    return 0 unless (defined $id || defined $name);

    $tenant_id = $service->{tenant_id} unless defined $tenant_id;
    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return 0 unless $self->reconnect();

    if ($self->{UpdateServiceQuery})
    {
	my ($sth, $q);
	my @keys = $service->attr_keys();
	my @values = $service->attr_values();
	my $set_str = '';
	for (my $i = 5; $i < scalar @keys; $i++)
	{
	    if (defined $values[$i])
	    {
		$set_str .= "$keys[$i]='$values[$i]',";
	    }
	}
	substr($set_str, -1, 1, '') if $set_str;
	if ($self->{UpdateServiceQueryParam})
	{
	    my @bind_values = map { Radius::Util::format_special($_, undef, $self, $set_str, undef, @values) } @{$self->{UpdateServiceQueryParam}};
	    $q = Radius::Util::format_special($self->{UpdateServiceQuery}, undef, $self);
	    $sth = $self->prepareAndExecute($q, @bind_values);
	}
	else
	{
	    shift @values; shift @values; shift @values;
	    @values = map { (defined $_) ? $self->quote($_) : undef } @values;
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{UpdateServiceQuery}, undef, $self, $set_str, undef, $qtenant_id, $qid, $qname, @values);
	    $sth = $self->do($q);
	}

	return 0 unless $sth;
    }

    return 1;
}

#####################################################################
sub save_service
{
    my ($self, $service, $cb) = @_;

    return 0 unless $service;
    return 1 unless $service->{dirty};

    my $rc;
    if ($service->{new})
    {
	$rc = $self->add_service($service->{id}, $service->{name}, $service);
    }
    else
    {
	$rc = $self->update_service($service->{id}, $service->{name}, $service);
    }
    $service->{dirty} = 0 if $rc;

    return $rc;
}

#####################################################################
sub delete_service
{
    my ($self, $id, $name, $tenant_id) = @_;

    return 0 unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return 0 unless $self->reconnect();

    if ($self->{DeleteServiceQuery})
    {
	my ($sth, $q);
	if ($self->{DeleteServiceQueryParam})
	{
	    my @bind_values = map { Radius::Util::format_special($_, undef, $self, undef, undef, $tenant_id, $id, $name) } @{$self->{DeleteServiceQueryParam}};
	    $q = Radius::Util::format_special($self->{DeleteServiceQuery}, undef, $self);
	    $sth = $self->prepareAndExecute($q, @bind_values);
	}
	else
	{
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{DeleteServiceQuery}, undef, $self, undef, undef, $qtenant_id, $qid, $qname);
	    $sth = $self->do($q);
	}

	return 0 unless $sth;
    }

    return 1;
}

#####################################################################
sub del_service
{
    my ($self, $service, $cb) = @_;

    return 0 unless $service;

    my $rc = $self->delete_service($service->{id}, $service->{name}, $service->{tenant_id});
    $service->{dirty} = 0 if $rc;

    return $rc;
}

#####################################################################
sub get_subscription
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    return undef unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return undef unless $self->reconnect();

    my ($subscription, @row);
    if ($self->{GetSubscriptionQuery})
    {
	my ($q, @bind_values);
	if ($self->{GetSubscriptionParam})
	{
	    @bind_values = map { Radius::Util::format_special($_, undef, $self, undef, undef, $tenant_id, $id, $name) } @{$self->{GetSubscriptionParam}};
	    $q = Radius::Util::format_special($self->{GetSubscriptionQuery}, undef, $self);
	}
	else
	{
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{GetSubscriptionQuery}, undef, $self, undef, undef, $qtenant_id, $qid, $qname);
	}

	my $sth = $self->prepareAndExecute($q, @bind_values);
	return undef unless $sth;

	if (@row = $self->getOneRow($sth))
	{
	    $subscription = $self->new_subscription_from_array(@row);
	}
    }

    return $subscription;
}

#####################################################################
sub add_subscription
{
    my ($self, $id, $name, $subscription, $tenant_id) = @_;

    return 0 unless $subscription;
    return 0 unless (defined $id || defined $name);

    $tenant_id = $subscription->{tenant_id} unless defined $tenant_id;
    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return 0 unless $self->reconnect();

    if ($self->{AddSubscriptionQuery})
    {
	my ($sth, $q);
	my @values = $subscription->attr_values(1);
	if ($self->{AddSubscriptionQueryParam})
	{
	    my @bind_values = map { Radius::Util::format_special($_, undef, $self, join(',', $subscription->attr_keys()), join(',', @values), @values) } @{$self->{AddSubscriptionQueryParam}};
	    $q = Radius::Util::format_special($self->{AddSubscriptionQuery}, undef, $self);
	    $sth = $self->prepareAndExecute($q, @bind_values);
	}
	else
	{
	    shift @values; shift @values; shift @values;
	    @values = map { (defined $_ && $_ ne 'NULL') ? $self->quote($_) : $_ } @values;
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{AddSubscriptionQuery}, undef, $self, join(',', $subscription->attr_keys()), join(',', ($qtenant_id, $qid, $qname, @values)), $qtenant_id, $qid, $qname, @values);
	    $sth = $self->do($q);
	}

	return 0 unless $sth;
    }

    return 1;
}

#####################################################################
sub update_subscription
{
    my ($self, $id, $name, $subscription, $tenant_id) = @_;

    return 0 unless $subscription;
    return 0 unless (defined $id || defined $name);

    $tenant_id = $subscription->{tenant_id} unless defined $tenant_id;
    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return 0 unless $self->reconnect();

    if ($self->{UpdateSubscriptionQuery})
    {
	my ($sth, $q);
	my @keys = $subscription->attr_keys();
	my @values = $subscription->attr_values();
	my $set_str = '';
	for (my $i = 5; $i < scalar @keys; $i++)
	{
	    if (defined $values[$i])
	    {
		$set_str .= "$keys[$i]='$values[$i]',";
	    }
	}
	substr($set_str, -1, 1, '') if $set_str;
	if ($self->{UpdateSubscriptionQueryParam})
	{
	    my @bind_values = map { Radius::Util::format_special($_, undef, $self, $set_str, undef, $tenant_id, $id, $name) } @{$self->{UpdateSubscriptionQueryParam}};
	    $q = Radius::Util::format_special($self->{UpdateSubscriptionQuery}, undef, $self);
	    $sth = $self->prepareAndExecute($q, @bind_values);
	}
	else
	{
	    shift @values; shift @values; shift @values;
	    @values = map { (defined $_) ? $self->quote($_) : undef } @values;
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{UpdateSubscriptionQuery}, undef, $self, $set_str, undef, $qtenant_id, $qid, $qname, @values);
	    $sth = $self->do($q);
	}

	return 0 unless $sth;
    }

    return 1;
}

#####################################################################
sub save_subscription
{
    my ($self, $subscription, $cb) = @_;

    return 0 unless $subscription;
    return 1 unless $subscription->{dirty};

    my $rc;
    if ($subscription->{new})
    {
	$rc = $self->add_subscription($subscription->{id}, $subscription->{name}, $subscription);
    }
    else
    {
	$rc = $self->update_subscription($subscription->{id}, $subscription->{name}, $subscription);
    }
    $subscription->{dirty} = 0 if $rc;

    return $rc;
}

#####################################################################
sub delete_subscription
{
    my ($self, $id, $name, $tenant_id) = @_;

    return 0 unless (defined $id || defined $name);

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    return 0 unless $self->reconnect();

    if ($self->{DeleteSubscriptionQuery})
    {
	my ($sth, $q);
	if ($self->{DeleteSubscriptionQueryParam})
	{
	    my @bind_values = map { Radius::Util::format_special($_, undef, $self, undef, undef, $tenant_id, $id, $name) } @{$self->{DeleteSubscriptionQueryParam}};
	    $q = Radius::Util::format_special($self->{DeleteSubscriptionQuery}, undef, $self);
	    $sth = $self->prepareAndExecute($q, @bind_values);
	}
	else
	{
	    my $qid = ($id) ? $self->quote($id) : '';
	    my $qname = ($name) ? $self->quote($name) : '';
	    my $qtenant_id = ($tenant_id) ? $self->quote($tenant_id) : '';
	    $q = Radius::Util::format_special($self->{DeleteSubscriptionQuery}, undef, $self, undef, undef, $qtenant_id, $qid, $qname);
	    $sth = $self->do($q);
	}

	return 0 unless $sth;
    }

    return 1;
}

#####################################################################
sub del_subscription
{
    my ($self, $subscription, $cb) = @_;

    return 0 unless $subscription;

    my $rc = $self->delete_subscription($subscription->{id}, $subscription->{name}, $subscription->{tenant_id});
    $subscription->{dirty} = 0 if $rc;

    return $rc;
}

1;
