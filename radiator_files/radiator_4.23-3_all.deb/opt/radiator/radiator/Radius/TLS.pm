# TLS.pm
#
# Radiator module for supporting some TLS operations, including some
# that should
# really be available in openssl
#
# Requires Net_SSLeay.pm-1.16 or later
# Requires openssl 0.9.8 or later
# See example in goodies/eap_ttls.cfg
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002 Open System Consultants
# $Id$
package Radius::TLS;
use Radius::Select;
use Net::SSLeay qw(ERROR_WANT_READ ERROR_WANT_WRITE);
use strict;

# RCS version number of this module
$Radius::TLS::VERSION = '$Revision$';

# Whether or not the TLS library has been initialised
$Radius::TLS::initialised = 0;

# From RFC 2716:
$Radius::TLS::FLAG_LENGTH_INCLUDED = 0x80;
$Radius::TLS::FLAG_MORE_FRAGMENTS  = 0x40;
$Radius::TLS::FLAG_START           = 0x20;

$Radius::TLS::EXT_TYPE_SESSION_TICKET  = 35; # TLS Hello Extension type


# This is the closure to be called when a client certificate is to be verified
# There is only one, due to limitations in SSLeay, so it must be set and cleared
# during each call to openssl that might result in a ceritifacte verification 
# ie before calling accept().
# It is required to return 0 if there is no error in validating the certificate
# else an error code from the set X509_V_ERR* in openssl/include/x509_vfy.h
$Radius::TLS::verifyFn = undef;

# This is the closure to be called when a client certificate verification failed.
# It is required to return 0 if there is no error in validating the certificate,
# or an error code from the set X509_V_ERR* in openssl/include/x509_vfy.h,
# or < 0 for a failure
$Radius::TLS::verifyFailedFn = undef;

# Certificate Verify codes from verify(1) and x509_txt.c
# Remove them when Net::SSLeay::X509_verify_cert_error_string becomes available
%Radius::TLS::verify_results = 
(
 0   => 'ok',
 2   => 'unable to get issuer certificate',
 3   => 'unable to get certificate CRL',
 4   => 'unable to decrypt certificate\'s signature',
 5   => 'unable to decrypt CRL\'s signature',
 6   => 'unable to decode issuer public key',
 7   => 'certificate signature failure',
 8   => 'CRL signature failure',
 9   => 'certificate is not yet valid',
 10   => 'certificate has expired',
 11   => 'CRL is not yet valid',
 12   => 'CRL has expired',
 13   => 'format error in certificate\'s notBefore field',
 14   => 'format error in certificate\'s notAfter field',
 15   => 'format error in CRL\'s lastUpdate field',
 16   => 'format error in CRL\'s nextUpdate field',
 17   => 'out of memory',
 18   => 'self signed certificate',
 19   => 'self signed certificate in certificate chain',
 20   => 'unable to get local issuer certificate',
 21   => 'unable to verify the first certificate',
 22   => 'certificate chain too long',
 23   => 'certificate revoked',
 24   => 'invalid CA certificate',
 25   => 'path length constraint exceeded',
 26   => 'unsupported certificate purpose',
 27   => 'certificate not trusted',
 28   => 'certificate rejected',
 29   => 'subject issuer mismatch',
 30   => 'authority and subject key identifier mismatch',
 31   => 'authority and issuer serial number mismatch',
 32   => 'key usage does not include certificate signing',
 33   => 'unable to get CRL issuer certificate',
 34   => 'unhandled critical extension',
 35   => 'key usage does not include CRL signing',
 36   => 'unhandled critical CRL extension',
 37   => 'invalid non-CA certificate (has CA markings)',
 38   => 'proxy path length constraint exceeded',
 39   => 'key usage does not include digital signature',
 40   => 'proxy cerificates not allowed, please set the appropriate flag',
 41   => 'invalid or inconsistent certificate extension',
 42   => 'invalid or inconsistent certificate policy extension',
 43   => 'no explicit policy',
 44   => 'different CRL scope',
 45   => 'unsupported extension feature',
 46   => 'RFC 3779 resource not subset of parent\'s resources',
 47   => 'permitted subtree violation',
 48   => 'excluded subtree violation',
 49   => 'name constraints minimum and maximum not supported',
 50   => 'application verification failure',
 51   => 'unsupported name constraint type',
 52   => 'unsupported or invalid name constraint syntax',
 53   => 'unsupported or invalid name syntax',
 54   => 'CRL path validation error',
 );


#####################################################################
# Generate $req_len bytes of key material from the constant string $s using the
# masterkey and client and server random strings as described in 
# draft-ietf-pppext-eap-ttls-01.txt and See rfc2716
# This should really be implemented inside openssl
sub PRF
{
    my ($context, $s, $req_len) = @_;

    # Use Net::SSLeay::export_keying_material if present (OpenSSL 1.0.1 and later, NetSSLeay 1.52+latest patches and later)
    if (exists &Net::SSLeay::export_keying_material)
    {
	return &Net::SSLeay::export_keying_material($context->{ssl}, $req_len, $s, undef);
    }
    else
    {
	my $client_random = &Net::SSLeay::get_client_random($context->{ssl});
	my $server_random = &Net::SSLeay::get_server_random($context->{ssl});
	my $session = &Net::SSLeay::get_session($context->{ssl});
	my $master_key = $session ? Net::SSLeay::SESSION_get_master_key($session) : Radius::Util::random_string(16);

	return &tls1_PRF($master_key, $s, $client_random . $server_random, $req_len);
    }
}

#####################################################################
# TLS PRF function as per RFC 2246
sub tls1_PRF
{
    my ($secret, $label, $seed, $req_len) = @_;

    # Split the secret into 2. If its odd length, overlap by 1
    my $slen = length($secret);
    my $len = int($slen / 2);
    my $s2 = substr($secret, $len);
    $len += ($slen & 1); # add for odd, make longer
    my $s1 = substr($secret, 0, $len);

    my $md5 = &tls_p_md5($s1, $label . $seed, $req_len);
    my $sha = &tls_p_sha1($s2, $label . $seed, $req_len);
    return $md5 ^ $sha;
}

#####################################################################
# P_hash for MD5 as per RFC 2246
sub tls_p_md5
{
    my ($secret, $seed, $req_len) = @_;

    use Digest::HMAC_MD5;
    my ($result, $temp);
    my $ai = $seed;
    my $i = 0;
    while ($i < $req_len)
    {
	$ai = Digest::HMAC_MD5::hmac_md5($ai, $secret);
	$result .= Digest::HMAC_MD5::hmac_md5($ai . $seed, $secret);
	$i += 16;
    }
    return substr($result, 0, $req_len);
}


#####################################################################
# P_hash for SHA-1 as per RFC 2246
sub tls_p_sha1
{
    my ($secret, $seed, $req_len) = @_;

    use Digest::HMAC_SHA1;
    my ($result, $temp);
    my $ai = $seed;
    my $i = 0;
    while ($i < $req_len)
    {
	$ai = Digest::HMAC_SHA1::hmac_sha1($ai, $secret);
	$result .= Digest::HMAC_SHA1::hmac_sha1($ai . $seed, $secret);
	$i += 20;
    }
    return substr($result, 0, $req_len);
}

#####################################################################
# Initialise openssl exactly once
sub tlsInit
{
    if (!$Radius::TLS::initialised)
    {
	&Net::SSLeay::randomize();
	&Net::SSLeay::load_error_strings();
	&Net::SSLeay::ERR_load_crypto_strings();
	&Net::SSLeay::SSLeay_add_ssl_algorithms();
	# Initialize SHA256 digest if available, required for WiMAX
	&Net::SSLeay::EVP_add_digest(&Net::SSLeay::EVP_sha256())
	    if exists &Net::SSLeay::EVP_sha256;
	# Enable hardware acceleration if available
	# These are not available before Net::SSLeay 1.33:
	eval { &Net::SSLeay::ENGINE_load_builtin_engines();
	       &Net::SSLeay::ENGINE_register_all_complete();
	       # This should be configurable?
	       my $e = &Net::SSLeay::ENGINE_by_id('pkcs11');
	       &Net::SSLeay::ENGINE_set_default($e, 0xFFFF)
		   if $e;
	   };
	$Radius::TLS::initialised++;

	my $version = $Net::SSLeay::VERSION;
	eval
	{
	    # Not available in Net-SSLeay-1.42 and before
	    $version .= ", " . Net::SSLeay::SSLeay_version();
	};
	main::log($main::LOG_DEBUG, "Initialised SSL library: Net::SSLeay $version");
	Radius::RuntimeChecks::check_net_ssleay_capability();
	Radius::TLS::resolve_nsl_constants();
    }
}

sub resolve_nsl_constants
{
    # Values for constants that are not defined for this runtime
    # combination of Net::SSLeay and *SSL library. Constant value can
    # be undefined if Net::SSLeay does not know the constant or knows
    # the constant but *SSL library does not define it.
    #
    # This hash provides values we can use when the constant is not
    # defined for the above reasons. The value to use when
    # Net::SSLeay's constant is undefined depends on the constant and
    # it's use. Remember: SSL_ prefix is dropped. Order is nearly
    # alphabetical.
    my %constants = (
	# GEN_* since 1.33_01
	GEN_OTHERNAME => 0,
	GEN_EMAIL     => 1,
	GEN_DNS       => 2,
	GEN_X400      => 3,
	GEN_DIRNAME   => 4,
	GEN_EDIPARTY  => 5,
	GEN_URI       => 6,
	GEN_IPADD     => 7,
	GEN_RID       => 8,

	OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION => 0x40000,  # Since 1.43
	OP_NO_COMPRESSION => 0,  # Since 1.33_01. Use zero because old value 0x20000 was recycled by LibreSSL
	OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION => 0x10000,  # Since 1.33_01
	OP_DONT_INSERT_EMPTY_FRAGMENTS => 0x800,  # 1.31_01
	OP_SINGLE_DH_USE => 0, # Since 1.02
	OP_SINGLE_ECDH_USE => 0,  # Since 1.43
	OP_NO_TICKET => 0x4000,  # Since 1.33_01
	OP_NO_SSLv2 => 0,  # Since 1.02
	OP_NO_SSLv3 => 0,  # Since 1.02
	OP_NO_TLSv1 =>  0,  # Since 1.02
	OP_NO_TLSv1_1 => 0,  # Since 1.46
	OP_NO_TLSv1_2 => 0,  # Since 1.46
	OP_NO_TLSv1_3 => 0,  # Since 1.83
	OP_NO_RENEGOTIATION => 0, # Since 1.83

	SESS_CACHE_OFF => 0,  # Since 1.83
	SESS_CACHE_SERVER => 0x0002,  # Since 1.83

	# TLSEXT_* not in Net::SSLeay yet
	TLSEXT_ERR_OK => 0,
	TLSEXT_ERR_ALERT_WARNING => 1,
	TLSEXT_ERR_ALERT_FATAL => 2,
	TLSEXT_ERR_NOACK => 3,

	# V_OCSP_* since 1.59
	V_OCSP_CERTSTATUS_GOOD => 0,
	V_OCSP_CERTSTATUS_UNKNOWN => 1,
	V_OCSP_CERTSTATUS_REVOKED => 2,

	# X509_V_* since 1.83
	X509_V_ERR_APPLICATION_VERIFICATION => 50,
	X509_V_ERR_CERT_HAS_EXPIRED => 10,

	X509_V_FLAG_PARTIAL_CHAIN => 0x80000,
	X509_V_FLAG_TRUSTED_FIRST => 0x8000,
	);

    foreach my $name (sort keys %constants)
    {
	# String eval works better with autoloader than block eval that uses glob access.
	my $c = undef;
	$c = eval "Net::SSLeay::$name();"; ## no critic (Perl::Critic::Policy::BuiltinFunctions::ProhibitStringyEval)
	main::log($main::LOG_EXTRA_DEBUG, "TLS: Using 0x" . sprintf("%x", $constants{$name}) . " ($constants{$name}) for Net::SSLeay constant $name") if $@;
	${$Radius::TLS::NSL::{$name}} = defined $c ? $c : $constants{$name};
    }

    foreach my $constant (sort keys %Radius::TLS::NSL::)
    {
	my $c = ${$Radius::TLS::NSL::{$constant}};
	main::log($main::LOG_ERR, "Radius::TLS::NSL::$constant is undefined") unless defined $c;

	my $c_hex = sprintf("%x", $c);
	#main::log($main::LOG_DEBUG, "Radius::TLS::NSL::$constant 0x$c_hex (${$Radius::TLS::NSL::{$constant}})");
    }
}

# Returns TLS options bitmask for enabling the desired SSL/TLS
# protocols. The returned options is suitable for passing to
# CTX_set_options. Returns undef if an error occurred.
sub tls_protocol_options
{
    my ($object, $tls_protocols, $prohibited_protocols) = @_;
    my $type = ref($object);

    # The common SSL and TLS protocols + placeholders for the ones
    # which may not be defined in our SSL library
    my %protocol2op = (
	SSLv3    => Net::SSLeay::OP_NO_SSLv3(),
	TLSv1    => Net::SSLeay::OP_NO_TLSv1(),
	"TLSv1.1" => $Radius::TLS::NSL::OP_NO_TLSv1_1,
	"TLSv1.2" => $Radius::TLS::NSL::OP_NO_TLSv1_2,
	"TLSv1.3" => $Radius::TLS::NSL::OP_NO_TLSv1_3,
	);

    # By default turn all protocols off
    my $options =
	    Net::SSLeay::OP_NO_SSLv2()
	  | Net::SSLeay::OP_NO_SSLv3()
	  | Net::SSLeay::OP_NO_TLSv1()
	  | $protocol2op{"TLSv1.1"}
	  | $protocol2op{"TLSv1.2"}
	  | $protocol2op{"TLSv1.3"};

    # Now enable the configured protocols
    $object->log($main::LOG_DEBUG, "$type $object->{Identifier} setting TLS protocols to: @$tls_protocols");
    foreach my $proto (@{$tls_protocols})
    {
	my $op = $protocol2op{$proto};
	unless (defined $op)
	{
	    $object->log($main::LOG_ERR, "Unknown value $proto for $type $object->{Identifier}. Ignoring.");
	    next;
	}
	if (grep {$proto eq $_} @{$prohibited_protocols})
	{
	    $object->log($main::LOG_WARNING, "TLS_Protocols value $proto is not allowed for $type $object->{Identifier}. Ignoring.");
	    next;
	}
	if ($op == 0)
	{
	    $object->log($main::LOG_WARNING, "TLS_Protocols value $proto not available. Ignoring.");
	    next;
	}
	$options &= ~$op;  # Enable this protocol
    }

    return $options;
}

#####################################################################
# Initialise TLS
# Initialise a per AuthBy TLS context
# Initialise a per-client context (passed in as $context);
# $parent is the current AuthBy
# $p is the current request (if any)
sub contextInit
{
    my ($context, $parent, $p) = @_;

    &tlsInit();

    $context->{ssl_verify_mode} = &Net::SSLeay::VERIFY_CLIENT_ONCE;

    # Maybe disable all client certificate checks
    $context->{ssl_verify_mode} = &Net::SSLeay::VERIFY_NONE
	if ($parent->{EAPTLS_NoClientCert});

    if (!$parent->{ssl_ctx})
    {
	# First one for this AuthBy. Initialise the SSL
	# context and configuration
	# We create an SSL context once for each AuthBY
	# since each one may have different configuration paramters
	# We enable the SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS, otherwise the
	# empty fragement sent by the server at the beginning of the applicaiotn data
	# confuses Windows Vista Beta 2. Consider using SSL_OP_ALL to enable
	# all workarounds
	my $options;
	if ($parent->{EAPTLS_Protocols})
	{
	    $options = Radius::TLS::tls_protocol_options($parent, $parent->{EAPTLS_Protocols}, [qw(SSLv3)]);
	    return unless defined $options;

	    $options |= Net::SSLeay::OP_SINGLE_DH_USE();
	    $options |= $Radius::TLS::NSL::OP_DONT_INSERT_EMPTY_FRAGMENTS;
	    $options |= $Radius::TLS::NSL::OP_NO_TICKET;
	}
	else
	{
	    # Old (Radiator 4.14 and earlier) way of configuring options
	    $options = &Net::SSLeay::OP_NO_SSLv2
		| &Net::SSLeay::OP_NO_SSLv3
		| $Radius::TLS::NSL::OP_NO_TLSv1_3
		| &Net::SSLeay::OP_SINGLE_DH_USE
		| $Radius::TLS::NSL::OP_DONT_INSERT_EMPTY_FRAGMENTS
		| $Radius::TLS::NSL::OP_NO_TICKET;
	}

	if ($main::eaptls_upto_v11)
	{
	    $parent->log($main::LOG_INFO, "TLSv1.2 disabled because of Net::SSLeay version $Net::SSLeay::VERSION. See startup log messages for more information");
	    $options |=  Net::SSLeay::OP_NO_TLSv1_2();
	}

	# Renegotiation is not useful with EAP
	$options |= $Radius::TLS::NSL::OP_NO_RENEGOTIATION;
	# Set SSL_OP_NO_COMPRESSION in case we run on a system that still defaults using compression
	$options |= $Radius::TLS::NSL::OP_NO_COMPRESSION;
	# Maybe set SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION
	$options |= $Radius::TLS::NSL::OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION unless Radius::Util::format_special($parent->{EAPTLS_SessionResumption});
	# Maybe set SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION
	# Requires OpenSSL 0.9.8m and later. Only needed with OpenSSL 0.9.8m and unpatched clients
	$options |= $Radius::TLS::NSL::OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION if $parent->{EAPTLS_AllowUnsafeLegacyRenegotiation};

	my $certtype = &Radius::Util::format_special($parent->{EAPTLS_CertificateType}, $p) eq 'PEM' 
	    ? &Net::SSLeay::FILETYPE_PEM : &Net::SSLeay::FILETYPE_ASN1;

	$parent->{ssl_ctx} = !$main::eaptls_upto_v10 ? Net::SSLeay::CTX_new() : Net::SSLeay::CTX_tlsv1_new();
	if (!$parent->{ssl_ctx})
	{
	    $parent->log($main::LOG_ERR, 'TLS could not ' . (!$main::eaptls_upto_v10 ? 'CTX_new' : 'CTX_tlsv1_new'));
	    return;
	}

	my $type = ref($parent);
	my $eaptls_ciphers = Radius::Util::format_special($parent->{EAPTLS_Ciphers}, $p);
	$parent->log($main::LOG_DEBUG, "$type $parent->{Identifier} setting EAPTLS_Ciphers to: $eaptls_ciphers");
	if (Net::SSLeay::CTX_set_cipher_list($parent->{ssl_ctx}, $eaptls_ciphers) != 1)
	{
	    my $errs = &Net::SSLeay::print_errs();
	    $parent->log($main::LOG_ERR, "TLS could not set_cipher_list to '$eaptls_ciphers'. Check EAPTLS_Ciphers: $errs");
	    $parent->{ssl_ctx} = undef;
	    return;
	}

	&Net::SSLeay::CTX_set_options($parent->{ssl_ctx}, $options);
	if (Radius::Util::format_special($parent->{EAPTLS_SessionResumption}))
	{
	    # Ensure openssl is using our timeout
	    Net::SSLeay::CTX_set_timeout
		($parent->{ssl_ctx},
		 &Radius::Util::format_special($parent->{EAPTLS_SessionResumptionLimit}, $p));
	}
	else
	{
	    # Disable session caching. Resume won't be possible
	    Net::SSLeay::CTX_set_session_cache_mode($parent->{ssl_ctx}, $Radius::TLS::NSL::SESS_CACHE_OFF);
	}

	# Only set up client cert verification if verify is not completely disabled
	if ($context->{ssl_verify_mode})
	{
	    my $ca_file = Radius::Util::format_special($parent->{EAPTLS_CAFile}, $p);
	    my $ca_path = Radius::Util::format_special($parent->{EAPTLS_CAPath}, $p);

	    if (&Net::SSLeay::CTX_load_verify_locations(
		$parent->{ssl_ctx}, $ca_file, $ca_path)
		!= 1)
	    {
		$parent->log($main::LOG_ERR, "TLS could not load_verify_locations $ca_file, $ca_path: " . Net::SSLeay::print_errs());
		$parent->{ssl_ctx} = undef;
		return;
	    }

	    # Accept also all CA certificates installed in OpenSSL default paths
	    if ($parent->{EAPTLS_UseCADefaultLocations} &&
	        &Net::SSLeay::CTX_set_default_verify_paths($parent->{ssl_ctx}) != 1)
	    {
		my $errs = &Net::SSLeay::print_errs();
		$parent->log($main::LOG_ERR, "TLS could not set_default_verify_paths: $errs");
		$parent->{ssl_ctx} = undef;
		return;
	    }

	    if ($parent->{EAPTLS_CAPartialChain})
	    {
		eval {&Net::SSLeay::X509_STORE_set_flags
		    (&Net::SSLeay::CTX_get_cert_store($parent->{ssl_ctx}),
		     $Radius::TLS::NSL::X509_V_FLAG_PARTIAL_CHAIN | $Radius::TLS::NSL::X509_V_FLAG_TRUSTED_FIRST);};
		if ($@)
		{
		    $parent->log($main::LOG_WARNING, "EAPTLS_CAPartialChain cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 and OpenSSL to 1.0.2 or later: $@");
		}
	    }

	    # set_client_CA_list only when EAPTLS_CAFile has been defined
	    if ($ca_file)
	    {
		my $cert_names = Net::SSLeay::load_client_CA_file($ca_file);
		unless ($cert_names)
		{
		    $parent->log($main::LOG_ERR, "TLS could not load_client_CA_file $ca_file: " . Net::SSLeay::print_errs());
		    $parent->{ssl_ctx} = undef;
		    return;
		}
		Net::SSLeay::CTX_set_client_CA_list($parent->{ssl_ctx}, $cert_names);
	    }

	    if ($parent->{EAPTLS_OCSPStapling})
	    {
		# Set a callback for OCSP stapling
		Net::SSLeay::CTX_set_tlsext_status_cb($parent->{ssl_ctx}, \&ocspCallback, $parent);
	    }
	}

	# There is only one callback, but since the callback will
	# only be called once during the subsequent CTX_use_PrivateKey_file
	# we dont care if it is overwritten later
	# prevent references to $parent	
	my $pw = &Radius::Util::format_special($parent->{EAPTLS_PrivateKeyPassword}, $p);
	&Net::SSLeay::CTX_set_default_passwd_cb($parent->{ssl_ctx}, sub {return $pw;});
	if (defined $parent->{EAPTLS_CertificateFile}
	    && &Net::SSLeay::CTX_use_certificate_file
	    ($parent->{ssl_ctx}, &Radius::Util::format_special($parent->{EAPTLS_CertificateFile}, $p), 
	     $certtype) != 1)
	{
	    my $errs = &Net::SSLeay::print_errs();
	    $parent->log($main::LOG_ERR, "TLS could not use_certificate_file " . &Radius::Util::format_special($parent->{EAPTLS_CertificateFile}, $p) . ", $certtype: $errs");
	    $parent->{ssl_ctx} = undef;
	    return;
	}

	# Versions of openssl up to 0.9.8e and perhaps later get a bogus 
	# 'file not found' error from 
	# CTX_use_certificate_chain_file unless we clear the error stack first.
	&Net::SSLeay::ERR_clear_error();

	if (defined $parent->{EAPTLS_CertificateChainFile}
	    && &Net::SSLeay::CTX_use_certificate_chain_file
	    ($parent->{ssl_ctx}, &Radius::Util::format_special($parent->{EAPTLS_CertificateChainFile}, $p)) != 1)
	{
	    my $errs = &Net::SSLeay::print_errs();
	    $parent->log($main::LOG_ERR, "TLS could not use_certificate_chain_file " . &Radius::Util::format_special($parent->{EAPTLS_CertificateChainFile}, $p) . ": $errs");
	    $parent->{ssl_ctx} = undef;
	    return;
	}

	if (defined $parent->{EAPTLS_PrivateKeyFile}
	    && &Net::SSLeay::CTX_use_PrivateKey_file
	    ($parent->{ssl_ctx}, &Radius::Util::format_special($parent->{EAPTLS_PrivateKeyFile}, $p), 
	     $certtype) != 1)
	{
	    my $errs = &Net::SSLeay::print_errs();
	    $parent->log($main::LOG_ERR, "TLS could not use_PrivateKey_file " . &Radius::Util::format_special($parent->{EAPTLS_PrivateKeyFile}, $p) . ", $certtype: $errs");
	    $parent->{ssl_ctx} = undef;
	    return;
	}
	# Remove the callback to prevent thread problems that can cause crashes at exit.
	&Net::SSLeay::CTX_set_default_passwd_cb($parent->{ssl_ctx}, undef);

	if (defined $parent->{EAPTLS_RandomFile})
	{
	    my $rand_file = Radius::Util::format_special($parent->{EAPTLS_RandomFile}, $p);
	    if (Net::SSLeay::RAND_load_file($rand_file, 1024*1024) < 1)
	    {
		$parent->log($main::LOG_ERR, "TLS Could not load randomness: " . Net::SSLeay::print_errs(), $p);
		$parent->{ssl_ctx} = undef;
		return;
	    }
	}

	# Maybe load the DH group file
	if (defined $parent->{EAPTLS_DHFile})
	{
	    my $dh_file = Radius::Util::format_special($parent->{EAPTLS_DHFile}, $p);
	    my $bio = &Net::SSLeay::BIO_new_file($dh_file, 'r');
	    unless($bio)
	    {
		$parent->log($main::LOG_ERR, "TLS BIO_new_file failed for ephemeral DH key file $dh_file: " . Net::SSLeay::print_errs(), $p);
		$parent->{ssl_ctx} = undef;
		return;
	    }

	    my $dh = &Net::SSLeay::PEM_read_bio_DHparams($bio);
	    unless ($dh)
	    {
		$parent->log($main::LOG_ERR, "TLS PEM_read_bio_DHparams failed for ephemeral DH key file $dh_file: " . Net::SSLeay::print_errs(), $p);
		$parent->{ssl_ctx} = undef;
		return;
	    }
	    if (Net::SSLeay::CTX_set_tmp_dh($parent->{ssl_ctx}, $dh) != 1)
	    {
		$parent->log($main::LOG_ERR, "TLS Could not set ephemeral DH key from file $dh_file", $p);
		$parent->{ssl_ctx} = undef;
		return;
	    }
	    &Net::SSLeay::BIO_free($bio);
	    &Net::SSLeay::DH_free($dh);
	}

        if (defined $parent->{EAPTLS_ECDH_Curve})
        {
            if (defined &Net::SSLeay::CTX_set_tmp_ecdh)
            {
              	my $curve_config = $parent->{EAPTLS_ECDH_Curve};
                my $curve = Net::SSLeay::OBJ_txt2nid($curve_config);
                unless ($curve)
                {
		    $parent->log($main::LOG_ERR, "TLS Could not find NID for curve '$curve_config'", $p);
		    $parent->{ssl_ctx} = undef;
		    return;
                }
                my $ecdh = Net::SSLeay::EC_KEY_new_by_curve_name($curve);
                unless ($ecdh)
                {
		    $parent->log($main::LOG_ERR, "TLS Could not create curve $curve_config with NID '$curve': " . Net::SSLeay::print_errs(), $p);
		    $parent->{ssl_ctx} = undef;
		    return;
                }
                if (Net::SSLeay::CTX_set_tmp_ecdh($parent->{ssl_ctx}, $ecdh) != 1)
                {
		    $parent->log($main::LOG_ERR, "TLS Could not set ephemeral EC key for curve $curve_config: " . Net::SSLeay::print_errs(), $p);
		    $parent->{ssl_ctx} = undef;
		    return;
                }

                Net::SSLeay::CTX_set_options($parent->{ssl_ctx}, Net::SSLeay::OP_SINGLE_ECDH_USE());
                Net::SSLeay::EC_KEY_free($ecdh);
	    }
	    else
	    {
		$parent->log($main::LOG_WARNING, 'TLS Could not use Ephemeral ECDH: too old Net::SSLEAY and/or OpenSSL');
		$parent->{ssl_ctx} = undef;
		return;
	    }
        }

	# Maybe check a certificate revocation file (CRL)
	# Caution: if this flag is turned on, we must be able to find a CRL
	# file in EAPTLS_CAPath. CRL files are conventionally named with the hash
	# of the subject name and a suffix that depends on the serial number.
	# eg ab1331b2.r0, ab1331b2.r1 etc.
	# You can find out the hash of the issuer name in a CRL with
	#  openssl crl -in crl.pem -hash -noout
	# If a CRL file cant be found for a given client certificate, the client
	# authentication will fail with a n error:
	#   SSL3_GET_CLIENT_CERTIFICATE:no certificate returned
	if ($parent->{EAPTLS_CRLCheck})
	{
	    # Sigh, some versions of Net::SSLeay dont have this necessary function
	    eval {&Net::SSLeay::X509_STORE_set_flags
		    (&Net::SSLeay::CTX_get_cert_store($parent->{ssl_ctx}), 
		     &Net::SSLeay::X509_V_FLAG_CRL_CHECK);};
	    if ($@)
	    {
		$parent->log($main::LOG_WARNING, "EAPTLS_CRLCheck cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 and OpenSSL to 0.9.8 or later: $@");
	    }

	    if ($parent->{EAPTLS_CRLCheckUseDeltas})
	    {
		eval {Net::SSLeay::X509_STORE_set_flags
			  (Net::SSLeay::CTX_get_cert_store($parent->{ssl_ctx}),
			   (Net::SSLeay::X509_V_FLAG_USE_DELTAS() | Net::SSLeay::X509_V_FLAG_EXTENDED_CRL_SUPPORT()));};
		if ($@)
		{
		    $parent->log($main::LOG_WARNING, "EAPTLS_CRLCheckUseDeltas cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 and OpenSSL to 0.9.8 or later: $@");
		}
	    }
	}

	# X509_V_FLAG_CRL_CHECK_ALL turns on CRL checking for the
	# entire certificate chain. X509_V_FLAG_CRL_CHECK above is
	# also needed for any CRL check to happen.
	if ($parent->{EAPTLS_CRLCheckAll})
	{
	    eval {&Net::SSLeay::X509_STORE_set_flags
		    (&Net::SSLeay::CTX_get_cert_store($parent->{ssl_ctx}),
		     &Net::SSLeay::X509_V_FLAG_CRL_CHECK_ALL);};
	    if ($@)
	    {
		$parent->log($main::LOG_WARNING, "EAPTLS_CRLCheckAll cannot be enabled since the installed version of Net::SSLeay does not support X509_STORE_set_flags. Upgrade Net::SSLeay to 1.30 and OpenSSL to 0.9.8 or later: $@");
	    }
	}

	# Maybe set policy OIDs that are required to be in the certificate path
	# Caution, this requires a number of functions that were added to Net-SSLeay SVN in 1.36, and 
	# 1.37 and later
	if (defined $parent->{EAPTLS_PolicyOID})
	{
	    my $pm;
	    eval {$pm = &Net::SSLeay::X509_VERIFY_PARAM_new()};
	    if ($@ || !$pm)
	    {
		$parent->log($main::LOG_ERR, "EAPTLS_PolicyOID cannot be enabled since the installed version of Net::SSLeay does not support X509_VERIFY_PARAM_new. Upgrade Net::SSLeay to 1.37 or later");
	    }
	    else
	    {
		# Required Net-SSLeay functions must be present
		foreach my $oid (@{$parent->{EAPTLS_PolicyOID}})
		{
		    my $pobject = &Net::SSLeay::OBJ_txt2obj($oid, 0);
		    if ($pobject)
		    {
			next if Net::SSLeay::X509_VERIFY_PARAM_add0_policy($pm, $pobject) == 1;
			$parent->log($main::LOG_WARNING, "TLS X509_VERIFY_PARAM_add0_policy failed for EAPTLS_PolicyOID: $oid: " . Net::SSLeay::print_errs(), $p);
			$parent->{ssl_ctx} = undef;
			return;
		    }
		    $parent->log($main::LOG_WARNING, "TLS Could not resolve TLS_PolicyOID: $oid: " . Net::SSLeay::print_errs(), $p);
		    $parent->{ssl_ctx} = undef;
		    return;
		}
		if (Net::SSLeay::X509_VERIFY_PARAM_set_flags($pm, Net::SSLeay::X509_V_FLAG_POLICY_CHECK() | Net::SSLeay::X509_V_FLAG_EXPLICIT_POLICY()) != 1)
		{
		    $parent->log($main::LOG_WARNING, "TLS X509_VERIFY_PARAM_set_flags failed when setting TLS_PolicyOID", $p);
		    $parent->{ssl_ctx} = undef;
		    return;
		}
		my $store = &Net::SSLeay::CTX_get_cert_store($parent->{ssl_ctx});
		if (Net::SSLeay::X509_STORE_set1_param($store, $pm) != 1)
		{
		    $parent->log($main::LOG_WARNING, "TLS X509_STORE_set1_param failed when setting TLS_PolicyOID: " . Net::SSLeay::print_errs(), $p);
		    $parent->{ssl_ctx} = undef;
		    return;
		}
		Net::SSLeay::X509_VERIFY_PARAM_free($pm);
	    }
	}

	&Radius::TLS::reloadCrls($parent, $p);

	# See contextSessionInit() for more about TLS state tracing
	&Net::SSLeay::CTX_set_info_callback($parent->{ssl_ctx}, \&Radius::TLS::infoCallback, $parent)
	    if exists &Net::SSLeay::set_state && $parent->{EAPTLS_TraceState};
    }

    # OK, now we make the per-client context. When EAP_UseState
    # behaviour is always on, see if we can get rid of most of these
    $context->{first_frag} = 1; # output
    $context->{handshake_finished} = undef;
    delete $context->{eaptls_did_inner_auth};
    delete $context->{inner_auth_success};
    delete $context->{eaptls_session_reuse_method};
    $context->{parent} = $parent;

    return unless contextSessionInit($context, $parent, $p);

    # Maybe reload a CRL
    &Radius::TLS::reloadCrls($parent, $p);

    return $context;
}

#####################################################################
# Load for the first time all the CRL files configured.
# Subsequently, if the CRL files timestamp has changed, releoad it.
# Reloading will replace the previous version
sub reloadCrls
{
    my ($self, $p) = @_;

    # Maybe load some additional CRL files. If defined, openssl will look in these
    # before looking for file named with the issuer name hash
    if (defined $self->{EAPTLS_CRLFile})
    {
	my $cert_store = &Net::SSLeay::CTX_get_cert_store($self->{ssl_ctx});
	foreach my $fileglob (@{$self->{EAPTLS_CRLFile}})
	{
	    $fileglob = &Radius::Util::format_special($fileglob, $p);
	    foreach my $file (glob $fileglob)
	    {
		# See if it is the first load, or if it has changed since the last time
		my $new_time = (stat($file))[9];
		$self->log($main::LOG_ERR, "TLS Could not stat '$file': $!", $p), next unless $new_time;

		next if $new_time == $self->{LastModTime}{$file};
		$self->{LastModTime}{$file} = $new_time;

		$self->log($main::LOG_DEBUG, "(Re)loading CRL file '$file'", $p);
		my $bio = &Net::SSLeay::BIO_new_file($file, 'r');
                $self->log($main::LOG_ERR, "TLS BIO_new_file failed for CRL file $file: " . Net::SSLeay::print_errs(), $p), next unless $bio;

		my $crl = &Net::SSLeay::PEM_read_bio_X509_CRL($bio);
		if ($crl)
		{
		    # Replaces any previous CRL from the same issuer
		    if (Net::SSLeay::X509_STORE_add_crl($cert_store, $crl) != 1)
		    {
			$self->log($main::LOG_ERR, "TLS X509_STORE_add_crl failed for CRL file $file: " . Net::SSLeay::print_errs(), $p);
		    }
		}
		else
		{
		    $self->log($main::LOG_ERR, "TLS PEM_read_bio_X509_CRL failed for CRL file '$file': " . Net::SSLeay::print_errs(), $p);
		}
		&Net::SSLeay::BIO_free($bio);
	    }
	}
    }
}

#####################################################################
# This is called for each certificate in the certificate chain. If it returns 0
# then further checking will be stopped.
# We call a local verification routin, which could be a closure etc.
sub verifyCallback
{
    my ($ok, $x509_store_ctx) = @_;

    my $err = 0;    # 0 means no verify error

    # Bail out if a previous callback failed already
    unless ($ok)
    {
	if ($Radius::TLS::verifyFailedFn)
	{
	    # Call a protocol specific verify routine as a closure, if present
	    $err = &$Radius::TLS::verifyFailedFn($x509_store_ctx);
	    return 0 if $err < 0;
	}
	else
	{
	    return 0;
	}
    }
    else
    {
	# Call a protocol specific verify routine as a closure, if present
	$err = &$Radius::TLS::verifyFn($x509_store_ctx) if $Radius::TLS::verifyFn;
    }

    unless (defined $err)
    {
	main::log($main::LOG_ERR, "TLS verifyCallback: undefined return value from verify function");
	Net::SSLeay::X509_STORE_CTX_set_error($x509_store_ctx, $Radius::TLS::NSL::X509_V_ERR_APPLICATION_VERIFICATION);
	return 0;
    }

    # Tell the caller what the problem was. This is available as Net::SSLeay::get_verify_result()
    &Net::SSLeay::X509_STORE_CTX_set_error($x509_store_ctx, $err) if $err;

    # Return 1 if no error from local callback
    return $err == 0;
}

#####################################################################
# This is called during TLS session setup and use to obtain state
# information.
sub infoCallback
{
    my ($ssl, $where, $ret, $data) = @_;

    # Force packet trace with a dummy $p
    my $dummy_p = Radius::AttrVal->new();
    $dummy_p->{PacketTrace} = 1;
    $dummy_p->{trace_id} = '00000000';

    my $rv = Net::SSLeay::state_string_long($ssl);
    $data->log($main::LOG_EXTRA_DEBUG, "EAP TLS state: $rv", $dummy_p);

    return;
}

#####################################################################
# This is called during TLS session setup and use to obtain and
# verify OCSP responses (aka. OCSP staples)
# Return values:
# When called without $ocsp_response: 0 (SSL_TLSEXT_ERR_OK), 3 (SSL_TLSEXT_ERR_NOACK), 1 (SSL_TLSEXT_ERR_ALERT_WARNING), 2 (SSL_TLSEXT_ERR_ALERT_FATAL)
# When called with    $ocsp_response: < 0 (ERROR), 0 (OCSP RESPONSE NOT ACCEPTED), > 0 (OCSP RESPONSE ACCEPTED)
sub ocspCallback
{
    my ($ssl, $ocsp_response, $parent) = @_;

    if ($ocsp_response)
    {
	# Callback called to verify/accept received OCSP response.
	# This should not happen as only a client can request the server
	# to send OCSP response/staple.

	# Get peer cert
	my $cert = Net::SSLeay::get_peer_certificate($ssl);

	if (!$cert)
	{
	    $parent->log($main::LOG_ERR, "TLS getting peer certificate to verify OCSP staple failed");
	    return 0; # OCSP RESPONSE NOT ACCEPTED
	}

	my $ret = run_ocsp($ssl, $parent, $cert, $ocsp_response);
	Net::SSLeay::X509_free($cert);

	if (!$ret)
	{
	    $parent->log($main::LOG_ERR, "TLS verifying received OCSP staple failed");
	    return 0; # OCSP RESPONSE NOT ACCEPTED
	}

	$parent->log($main::LOG_DEBUG, "TLS accepting received OCSP staple");
	return 1; # OCSP RESPONSE ACCEPTED

    }
    else
    {
	# I'm a server
	unless (defined &Net::SSLeay::set_tlsext_status_ocsp_resp)
	{
	    $parent->log($main::LOG_INFO, "OCSP stapling disabled because of Net::SSLeay version $Net::SSLeay::VERSION. See startup log messages for more information");
	    return $Radius::TLS::NSL::TLSEXT_ERR_NOACK;
	}

	# Callback called to provide OCSP response
	if (!$parent->{OCSP_response} || $parent->{OCSP_response}->[1] < time())
	{
	    if (!run_ocsp($ssl, $parent))
	    {
		$parent->log($main::LOG_ERR, "TLS acquiring OCSP response failed");
		return $Radius::TLS::NSL::TLSEXT_ERR_NOACK;
	    }
	}

	if ($parent->{OCSP_response})
	{
	    # Set OCSP staple
	    Net::SSLeay::set_tlsext_status_ocsp_resp($ssl, $parent->{OCSP_response}->[0]);
	    return $Radius::TLS::NSL::TLSEXT_ERR_OK;
	}

	return $Radius::TLS::NSL::TLSEXT_ERR_NOACK;
    }

    return -1;
}

#####################################################################
# Obtain and verify OCSP response
# Returns false for failure, 1 for ok and 2 for async operation
sub run_ocsp
{
    my ($ssl, $parent, $cert, $ocsp_resp, $context, $async) = @_;

    my $now = time();
    my $set_ocsp_staple = 0;
    unless ($cert)
    {
	# Use my own cert
	$cert = Net::SSLeay::get_certificate($ssl);
	++$set_ocsp_staple;
	# Reset current OCSP staple
	$parent->{OCSP_response} = undef;
    }

    # Get id only for given $cert
    my $cert_id = eval { Net::SSLeay::OCSP_cert2ids($ssl, $cert) };

    if ($@ || !$cert_id)
    {
	$parent->log($main::LOG_ERR, "TLS could not get certificate identifiers for OCSP: $@");
	return;
    }

    my $cert_id_hex = unpack('H*', $cert_id);

    # Is there a valid cache entry?
    $parent->{OCSP_cache} = {} unless $parent->{OCSP_cache};
    if ($parent->{OCSP_cache}->{$cert_id})
    {
	if ($parent->{OCSP_cache}->{$cert_id}->[1] >= $now)
	{
	    if (!$parent->{OCSP_cache}->{$cert_id}->[0])
	    {
		# valid
		return 1;
	    }
	    else
	    {
		# invalid
		return;
	    }
	}
	else
	{
	    delete $parent->{OCSP_cache}->{$cert_id};
	    --$parent->{OCSP_cache_size};
	}
    }

    my ($ocsp_req, $ocsp_resp_data);
    unless ($ocsp_resp)
    {
	unless ($context && $context->{ocsp_response_data})
	{
	    my $ocsp_uri;
	    if ($parent->{EAPTLS_OCSPURI})
	    {
		$ocsp_uri = $parent->{EAPTLS_OCSPURI};
	    }
	    else
	    {
		$ocsp_uri = Net::SSLeay::P_X509_get_ocsp_uri($cert);
	    }

	    unless ($ocsp_uri)
	    {
		$parent->log($main::LOG_DEBUG, "TLS could not get OCSP URI for certificate: $cert_id_hex");
		# Allow unless strict mode configured
		unless ($parent->{EAPTLS_OCSPStrict})
		{
		    return 1;
		}
		return;
	    }

	    if ($parent->{OCSP_backoff_until}->{$ocsp_uri} && $parent->{OCSP_backoff_until}->{$ocsp_uri} > $now)
	    {
		$parent->log($main::LOG_WARNING, "TLS still backing off from trying OCSP responder '$ocsp_uri'");
		# Allow unless strict mode configured
		unless ($parent->{EAPTLS_OCSPStrict})
		{
		    return 1;
		}
		return;
	    }
	    delete $parent->{OCSP_backoff_until}->{$ocsp_uri};

	    $ocsp_req = Net::SSLeay::OCSP_ids2req($cert_id);

	    unless ($ocsp_req)
	    {
		$parent->log($main::LOG_ERR, "TLS creating OCSP request failed: $cert_id_hex");
		return;
	    }

	    my $ocsp_req_data = Net::SSLeay::i2d_OCSP_REQUEST($ocsp_req);

	    unless ($ocsp_req_data)
	    {
		$parent->log($main::LOG_ERR, "TLS invalid OCSP request for certificate: $cert_id_hex");
		return;
	    }

	    $ocsp_resp_data = get_ocsp_response($parent, $cert_id, $ocsp_req_data, $ocsp_uri, $context, $async);

	    unless ($ocsp_resp_data)
	    {
		$parent->log($main::LOG_ERR, "TLS getting OCSP response '$cert_id_hex' failed: $@");
		$parent->{OCSP_backoff_until}->{$ocsp_uri} = $now + $parent->{EAPTLS_OCSPFailureBackoffTime};
		# Allow unless strict mode configured
		unless ($parent->{EAPTLS_OCSPStrict})
		{
		    return 1;
		}
		return;
	    }
	    if ($async && $ocsp_resp_data == $main::ASYNC)
	    {
		return 2;
	    }
	}
	else
	{
	    $ocsp_resp_data = $context->{ocsp_response_data};
	}

	$ocsp_resp = eval { Net::SSLeay::d2i_OCSP_RESPONSE($ocsp_resp_data) };

	if ($@)
	{
	    $parent->log($main::LOG_ERR, "TLS parsing OCSP response '$cert_id_hex' failed: $@");
	    return;
	}
    }

    my $ocsp_status = Net::SSLeay::OCSP_response_status($ocsp_resp);
    if ($ocsp_status != Net::SSLeay::OCSP_RESPONSE_STATUS_SUCCESSFUL())
    {
	$parent->log($main::LOG_DEBUG, "TLS OCSP response '$cert_id_hex' failed: " . Net::SSLeay::OCSP_response_status_str($ocsp_status));
	return;
    }

    my $ocsp_verify;
    if ($ocsp_req)
    {
	$ocsp_verify = eval { Net::SSLeay::OCSP_response_verify($ssl, $ocsp_resp, $ocsp_req) };
    }
    else
    {
	$ocsp_verify = eval { Net::SSLeay::OCSP_response_verify($ssl, $ocsp_resp) };
    }

    if ($@)
    {
	$parent->log($main::LOG_ERR, "TLS verifying OCSP response '$cert_id_hex' failed: $@");
	return;
    }

    if (!$ocsp_verify)
    {
	$parent->log($main::LOG_DEBUG, "TLS OCSP response verification '$cert_id_hex' failed: $ocsp_verify");
	return;
    }

    my @ocsp_results = Net::SSLeay::OCSP_response_results($ocsp_resp);
    foreach my $result (@ocsp_results)
    {
	# @results are in the same order as the @ids and contain:
	# $r->[0] - OCSP_CERTID
	# $r->[1] - undef if no error (certificate good) OR error message as string
	# $r->[2] - hash with details:
	#   thisUpdate - time_t of this single response
	#   nextUpdate - time_t when update is expected
	#   statusType - integer:
	#      V_OCSP_CERTSTATUS_GOOD(0)
	#      V_OCSP_CERTSTATUS_REVOKED(1)
	#      V_OCSP_CERTSTATUS_UNKNOWN(2)
	#   revocationTime - time_t (only if revoked)
	#   revocationReason - integer (only if revoked)
	#   revocationReason_str - reason as string (only if revoked)

	if ($result->[0] eq $cert_id)
	{
	    my $this_update = $result->[2]->{thisUpdate};
	    # Allow 5 minutes time difference
	    if (!$this_update || $this_update < ($now - 300))
	    {
		$this_update = $now;
	    }
	    my $next_update = $result->[2]->{nextUpdate};

	    my $cache_time = $parent->{EAPTLS_OCSPCacheTime};
	    if (!$next_update || $next_update < $this_update)
	    {
		# Cache OCSP staple for 1h when not specified by nextUpdate.
		$cache_time = 3600 if $set_ocsp_staple;
		$next_update = $now + $cache_time;
	    }
	    elsif (($next_update - $now) > $parent->{EAPTLS_OCSPCacheTime})
	    {
		# Cache OCSP staple for time specified by nextUpdate.
		$next_update = $now + $cache_time unless $set_ocsp_staple;
	    }

	    if ($set_ocsp_staple)
	    {
		# Set our OCSP staple
		$parent->{OCSP_response} = [];
		$parent->{OCSP_response}->[0] = $ocsp_resp_data;
		$parent->{OCSP_response}->[1] = $next_update;
		return 1;
	    }
	    else
	    {
		# Cache the result
		if ($parent->{OCSP_cache} && $parent->{OCSP_cache}->{$cert_id})
		{
		    # Update cache entry
		    $parent->{OCSP_cache}->{$cert_id}->[0] = $result->[2]->{statusType};
		    $parent->{OCSP_cache}->{$cert_id}->[1] = $next_update;
		}
		else
		{
		    $parent->{OCSP_cache_size} += 0;
		    if ($parent->{OCSP_cache_size} >= $parent->{EAPTLS_OCSPCacheSize})
		    {
			# Flush an expired entry
			foreach my $cache_cert_id (keys %{$parent->{OCSP_cache}})
			{
			    if ($parent->{OCSP_cache}->{$cache_cert_id}->[1] < $now)
			    {
				delete $parent->{OCSP_cache}->{$cache_cert_id};
				--$parent->{OCSP_cache_size};
				last;
			    }
			}
		    }
		    if ($parent->{OCSP_cache_size} < $parent->{EAPTLS_OCSPCacheSize})
		    {
			# Add a new cache entry
			++$parent->{OCSP_cache_size};
			$parent->{OCSP_cache}->{$cert_id}->[0] = $result->[2]->{statusType};
			$parent->{OCSP_cache}->{$cert_id}->[1] = $next_update;
		    }
		}

		if ($result->[2]->{statusType} == $Radius::TLS::NSL::V_OCSP_CERTSTATUS_GOOD)
		{
		    $parent->log($main::LOG_DEBUG, "TLS OCSP response states '$cert_id_hex' as good");
		    return 1;
		}
		else
		{
		    my $err = "invalid: err: ";
		    $err .= $result->[1] || '';
		    $err .= " status:$result->[2]->{statusType} reason:$result->[2]->{revocationReason_str}";
		    $parent->log($main::LOG_DEBUG, "TLS OCSP response states '$cert_id_hex' as $err");
		    return;
		}
	    }
	}
    }

    return;
}

#####################################################################
# Get OCSP response
sub get_ocsp_response
{
    my ($parent, $cert_id, $ocsp_request_data, $ocsp_uri, $context, $async) = @_;

    my $cert_id_hex = unpack('H*', $cert_id);
    my $resp;

    # TODO: FIXME: Get OCSP response data from external OCSP querier process
    $parent->log($main::LOG_DEBUG, "TLS sending OCSP request to URI '$ocsp_uri' for certificate: $cert_id_hex");

    my ($req, $res, $ok);
    if ($async)
    {
	unless ($parent->{ocsp_async})
	{
	    eval {
		require HTTP::Async;
		require HTTP::Request;
	    };

	    if ($@)
	    {
		$parent->log($main::LOG_DEBUG, "TLS sending OCSP async request to URI '$ocsp_uri' failed: $@");
		return;
	    }

	    $parent->{ocsp_async} = HTTP::Async->new(
		slots => 20,
		timeout => 2,
		max_request_time => 2,
		max_redirect => 7,
		ssl_options => { SSL_verify_mode => 0 },
	    );
	}

	$req = HTTP::Request->new('POST', $ocsp_uri);
	#$req->header('User-Agent' => 'ocsp-client/0.1');
	$req->header('Content-Type' => 'application/ocsp-request');
	$req->content($ocsp_request_data);

	my $id = $parent->{ocsp_async}->add($req);
	if (defined $id)
	{
	    $parent->{ocsp_async_map}->{$id} = [$context, $ocsp_uri, $cert_id_hex, undef];

	    if (exists $parent->{ocsp_async}->{in_progress}->{$id} && $parent->{ocsp_async}->{in_progress}->{$id}->{handle})
	    {
		my $fileno = fileno($parent->{ocsp_async}->{in_progress}->{$id}->{handle});
		$parent->{ocsp_async_map}->{$id}->[3] = $fileno;
		Radius::Select::add_file($fileno, 1, undef, undef,
		    \&Radius::TLS::handle_ocsp_async_replies, $parent);
	    }

	    unless ($parent->{ocsp_async_timer})
	    {
		$parent->{ocsp_async_timer} = Radius::Select::add_timeout
		    (time + 2, \&handle_ocsp_async_replies, $parent);
	    }

	    return $main::ASYNC;
	}
	else
	{
	    $parent->log($main::LOG_ERR, "TLS allocating OCSP async request id failed");
	}
    }
    else
    {
	unless ($parent->{ocsp})
	{
	    eval {
		require LWP::UserAgent;
		require HTTP::Request;
	    };

	    if ($@)
	    {
		$parent->log($main::LOG_ERR, "TLS sending OCSP request to URI '$ocsp_uri' failed: $@");
		return;
	    }

	    $parent->{ocsp} = LWP::UserAgent->new();
	    $parent->{ocsp}->timeout(2);
	    $parent->{ocsp}->ssl_opts(verify_hostname => 0);
	    #$parent->{ocsp}->agent('ocsp-client/0.1');
	}

	$req = HTTP::Request->new(POST => $ocsp_uri);
	$req->content_type('application/ocsp-request');
	$req->content($ocsp_request_data);

	$res = $parent->{ocsp}->request($req);

	if ($res && $res->is_success() && $res->content_type() eq "application/ocsp-response")
	{
	    ++$ok;
	    $resp = $res->content();
	}
    }

    if ($ok)
    {
	$parent->log($main::LOG_DEBUG, "TLS OCSP response received for certificate: $cert_id_hex");
    }
    else
    {
	$parent->log($main::LOG_ERR, "TLS receiving OCSP response failed for certificate: $cert_id_hex");
    }

    if ($context && $resp)
    {
	$context->{ocsp_response_data} = $resp;
    }

    return $resp;
}

#####################################################################
# Handle HTTP::Async replies
sub handle_ocsp_async_replies
{
    my ($handle, $parent, $fileno) = @_;

    my ($res, $id, $entry);
    my ($context, $ocsp_uri, $cert_id_hex, $req_fileno);

    while (($res, $id) = $parent->{ocsp_async}->next_response())
    {
	# Get mapping for $id
	$entry = $parent->{ocsp_async_map}->{$id};
	next unless $entry;
	($context, $ocsp_uri, $cert_id_hex, $req_fileno) = @{$entry};

	# Deregister a socket from select
	Radius::Select::remove_file($req_fileno, 1, undef, undef) if defined $req_fileno;

	if ($res && $res->is_success && $res->content_type() eq "application/ocsp-response")
	{
	    $context->{ocsp_response_data} = $res->content();
	}
	else
	{
	    my $res_status = $res->status_line();
	    $parent->log($main::LOG_ERR, "TLS getting OCSP response from '$ocsp_uri' for '$cert_id_hex' failed: $res_status");
	    $parent->{OCSP_backoff_until}->{$ocsp_uri} = time() + $parent->{EAPTLS_OCSPFailureBackoffTime};
	    $context->{ocsp_response_data} = 0;
	    $context->{ocsp_response_ret} = 0;
	}

	$context->{request}->{Handler}->handlerResult($context->{request});
    }

    my $in_progress = 0;
    foreach my $in_progress_id (keys %{$parent->{ocsp_async}->{in_progress}})
    {
	++$in_progress;
	# Register new sockets in select
	unless (defined $parent->{ocsp_async_map}->{$in_progress_id}->[3])
	{
	    my $fileno = fileno($parent->{ocsp_async}->{in_progress}->{$in_progress_id}->{handle});
	    if (defined $fileno)
	    {
		$parent->{ocsp_async_map}->{$in_progress_id}->[3] = $fileno;
		Radius::Select::add_file($fileno, 1, undef, undef,
		    \&Radius::TLS::handle_ocsp_async_relies, $parent);
	    }
	}
    }

    if ($in_progress)
    {
	# Run a callback after 2 seconds
	Radius::Select::remove_timeout($parent->{ocsp_async_timer}) if $parent->{ocsp_async_timer};
	$parent->{ocsp_async_timer} = Radius::Select::add_timeout
	    (time + 2, \&handle_ocsp_async_replies, $parent);
    }
    elsif ($parent->{ocsp_async_timer})
    {
	Radius::Select::remove_timeout($parent->{ocsp_async_timer});
	$parent->{ocsp_async_timer} = undef;
    }

    return;
}

#####################################################################
# Clean a new clean session context. Returns false on failure.
sub contextSessionInit
{
    my ($context, $parent, $p) = @_;

    &Net::SSLeay::free($context->{ssl}) if $context->{ssl};
    $context->{ssl} = &Net::SSLeay::new($parent->{ssl_ctx});
    if (!$context->{ssl})
    {
	$parent->log($main::LOG_ERR, 'TLS could not create SSL: Net::SSLeay::new failed: ' . &Net::SSLeay::print_errs() . ",". $!);
	return;
    }

    # Quote from the OpenSSL manual:
    #   If the session id context is not set on an SSL/TLS server and
    #   client certificates are used, stored sessions will not be
    #   reused but a fatal error will be flagged and the handshake
    #   will fail.
    #
    # Also, when session id context is set, the stored session id
    # context must match this session id context. Otherwise session is
    # not resumed and full handshake will be done.
    my $contextid = Digest::SHA::sha1(Radius::Util::format_special($parent->{EAPTLS_SessionContextId}, $p, $parent, $p->{Client}, $p->{Handler}, $p->{AuthBy}, $p->{EAPType}));
    if (Net::SSLeay::set_session_id_context($context->{ssl}, $contextid, length($contextid)) != 1)
    {
	my $errs = Net::SSLeay::print_errs();
	$parent->log($main::LOG_ERR, "TLS could not set_session_id_context with EAPTLS_SessionContextId $parent->{EAPTLS_SessionContextId} to $contextid: $errs", $p);
	Radius::TLS::contextSessionClear($context);
	return;
    }

    # Create 2 memory BIOs to do the IO with SSL
    $context->{rbio} = &Net::SSLeay::BIO_new(&Net::SSLeay::BIO_s_mem());
    $context->{wbio} = &Net::SSLeay::BIO_new(&Net::SSLeay::BIO_s_mem());
    &Net::SSLeay::set_bio($context->{ssl}, $context->{rbio}, $context->{wbio});
    
    # Arrange for our SSL per-client context to be destroyed when the EAP
    # per-client context is destroyed. $_[0] is the context being destroyed
    # Make sure any TLS session associated with this context is also destroyed, otherwise, 
    # TLS may try to resurrect the sess, but we wont be able to deal with it properly
    $context->destroy_callback
	(sub {if ($_[0]->{ssl})
	      {#my $sess = &Net::SSLeay::get_session($_[0]->{ssl});
	       #&Net::SSLeay::CTX_remove_session($parent->{ssl_ctx}, $sess) if $sess; 
	       &Net::SSLeay::free($_[0]->{ssl});
	       $_[0]->{ssl} = undef;
	      }});

    # Set the callback for TLS session setup and use. Requires
    # Net::SLeay 1.65 or later. Ampersand is needed to turn off
    # prototype checks with earlier versions without working
    # callbacks. Third argument and set_state() were added in 1.65
    &Net::SSLeay::set_info_callback($context->{ssl}, \&Radius::TLS::infoCallback, $parent)
	if exists &Net::SSLeay::set_state && !$parent->{EAPTLS_TraceState} && main::willLog($main::LOG_EXTRA_DEBUG, $p);

    return 1;
}

#####################################################################
# Remove a session entirely so it can never be reused or resumed.
# Can be called when ssl object isn't yet present or is already freed.
sub contextSessionClear
{
    my ($context) = @_;

    delete $context->{inner_auth_success};
    delete $context->{eap_context_inner_key};
    return unless $context->{ssl};

    # Mark session unresumable when e.g., resumed authentication fails
    if (Radius::Util::format_special($context->{parent}->{EAPTLS_SessionResumption}))
    {
	my $sess = Net::SSLeay::get1_session($context->{ssl});
	my $ret = Net::SSLeay::CTX_remove_session($context->{parent}->{ssl_ctx}, $sess);
	Net::SSLeay::SESSION_free($sess) unless $ret; # Not cached, undo get1
    }

    &Net::SSLeay::free($context->{ssl});
    $context->{ssl} = undef;

    return;
}

#####################################################################
# Tell SSL this session is allowed to be reused, even if the SSL struct is freed
# Sets the shutdown flag, otherwise the session will never be reused
sub contextSessionAllowReuse
{
    my ($context) = @_;

    if (Radius::Util::format_special($context->{parent}->{EAPTLS_SessionResumption}))
    {
	my $ret = &Net::SSLeay::shutdown($context->{ssl});
    }

    &Net::SSLeay::free($context->{ssl});
    $context->{ssl} = undef;
    delete $context->{inner_auth_success};
    delete $context->{eap_context_inner_key};
    $context->{eaptls_session_reuse_method} = 2 if ($context->{eaptls_session_reuse_method} == 1 && $context->{eaptls_did_inner_auth});
}

#####################################################################
# Check if TLS session resume is happening now or needs to be prepared
# for.
sub contextSessionCheckReuse
{
    my ($object, $context, $p) = @_;

    delete $context->{inner_auth_success};
    my $session_reused = Net::SSLeay::session_reused($context->{ssl});
    $context->{eaptls_session_reuse_method} = $session_reused ? 1 : 0; # Updated later if inner auth is done

    if (!Radius::Util::format_special($object->{EAPTLS_SessionResumption}))
    {
	if ($session_reused)
	{
	    $object->log($main::LOG_ERR, "EAP $p->{EAPTypeName} resumed session but EAPTLS_SessionResumption is disabled", $p);
	    return ($main::REJECT, "EAP $p->{EAPTypeName} resumed session but EAPTLS_SessionResumption is disabled");
	}
	# Don't need to save context for resume
	return $main::ACCEPT;
    }

    my $this_session = $p->{EAPContext}->{EAPTLS_Session}->{Session_ID};
    unless ($this_session)
    {
	$object->log($main::LOG_ERR, "EAP $p->{EAPTypeName} could not get TLS session id", $p);
	return ($main::REJECT, "EAP $p->{EAPTypeName} could not get TLS session id");
    }

    my $key = "eap:resume:$this_session";

    if (!$session_reused)
    {
	# Allow the resume context to outlive the TLS session
	$context->{eap_resume_context} = Radius::Context->new($key, Radius::Util::format_special($object->{EAPTLS_SessionResumptionLimit}, $p) + 2);
	return $main::ACCEPT;
    }

    # We don't want to reset the timeout
    my $resume_context = Radius::Context::find($key);
    if ($resume_context)
    {
	$object->eap_recover_resume_context($p, $context, $resume_context);
	$object->log($main::LOG_DEBUG, "EAP $p->{EAPTypeName} session resumed", $p);
	return $main::ACCEPT;
    }
    else
    {
	# Problem: resume was done but previously saved resume context was not found.
	return ($main::REJECT, "EAP $p->{EAPTypeName} failed session resumption");
    }

    return ($main::REJECT, "EAP $p->{EAPTypeName} unknown failure with resume");
}

sub verify_error_string
{
    my ($result) = @_;

    # Use this when it becomes available in Net_SSLeay:
    my $ret;
    # if Net::SSLeay::X509_verify_cert_error_string is available, use it
    eval {$ret = &Net::SSLeay::X509_verify_cert_error_string($result);};
    if (@!)
    {
	$ret = $Radius::TLS::verify_results{$result};
	$ret = "error number $result" unless defined $ret;
    }
    return $ret;
}

#####################################################################
# Net_SSLeay has only one callback handle. Sigh. Some other users of 
# Net_SSLeay may be operating within our code too, so to prevent collisions with their
# use of the verify callback, we have to explicitly set it every time we need it 
sub set_verify
{
    my ($parent, $context, $cb, $cb_failed) = @_;

    $Radius::TLS::verifyFn = $cb;
    $Radius::TLS::verifyFailedFn = $cb_failed;
    # Call a callback to verify the client certificate chain
    # SSLeay only supports on one calback, which we are forced to share
    # Reset it here in case someone else has been using it
    &Net::SSLeay::set_verify($context->{ssl}, $context->{ssl_verify_mode}, \&verifyCallback);
}

# Reset and remove the verify callback. This has the effect of removing the previously set
# verify callback. You must do this in the same thread as set_verify else Net::SSLeay may have 
# thread safety problems in a threaded environment
sub reset_verify
{
    my ($parent, $context) = @_;

    &Net::SSLeay::set_verify($context->{ssl}, $context->{ssl_verify_mode}, undef);
}

#####################################################################
# Add TLS extension to require OCSP response from peer
sub set_ocsp_stapling_required
{
    my ($parent, $context) = @_;

    if (defined &Net::SSLeay::set_tlsext_status_type)
    {
	# Set TLS extension to require OCSP staple before doing SSL_accept
	Net::SSLeay::set_tlsext_status_type($context->{ssl}, Net::SSLeay::TLSEXT_STATUSTYPE_ocsp());
    }
    else
    {
	$parent->log($main::LOG_INFO, "OCSP stapling disabled because of Net::SSLeay version $Net::SSLeay::VERSION. See startup log messages for more information");
    }
}

######################################################################
# Store TLS session related information in the context for logging and
# other later use
sub get_session_info
{
    my ($context) = @_;

    my $session = Net::SSLeay::get_session($context->{ssl});
    my $bio = Net::SSLeay::BIO_new(Net::SSLeay::BIO_s_mem());
    Net::SSLeay::SESSION_print($bio, $session);
    my $info = Net::SSLeay::BIO_read($bio);

    my $ctx_info;
    foreach my $line (split(/\n/, $info))
    {
	$ctx_info->{Protocol} = $1,next if $line =~ /\s+Protocol\s*:\s+(\S+)$/;
	$ctx_info->{Cipher} = $1,next if $line =~ /\s+Cipher\s*:\s*(\S+)$/;
	$ctx_info->{Session_ID} = $1,next if $line =~ /\s+Session-ID\s*:\s+(\S+)$/;
	$ctx_info->{Start_Time} = $1,next if $line =~ /\s+Start Time\s*:\s+(\d+)$/; # Value is unix time stamp
	$ctx_info->{Timeout} = $1,next if $line =~ /\s+Timeout\s*:\s+(\d+)/; # Has (sec) after the value
    }

    $context->{EAPTLS_Session} = $ctx_info;
    Net::SSLeay::BIO_free($bio);

    return;
}

######################################################################
# Get a reason string from Net::SSLeay::print_errs() output
sub get_errs_reason
{
    my ($errs) = @_;

    my @errs = $errs ? split(m/\n/s, $errs) : ();
    @errs = map { (split(':'))[-1] } @errs;

    return join(',', @errs);
}

# Used by multiple modules to to log information about a certificate.
# $p is allowed to be undefined
sub log_certificate
{
    my ($self, $p, $cert, $subject) = @_;

    my $issuer_name = Net::SSLeay::X509_get_issuer_name($cert);
    my $issuer = Net::SSLeay::X509_NAME_oneline($issuer_name);

    $self->log($main::LOG_DEBUG, "Certificate Issuer Name is $issuer", $p);
    $self->log($main::LOG_DEBUG, "Certificate Subject Name is $subject", $p);
    if (defined &Net::SSLeay::X509_get_serialNumber)
    {
	my $serial_number = Net::SSLeay::X509_get_serialNumber($cert);
	my $serial_dec = Net::SSLeay::P_ASN1_INTEGER_get_dec($serial_number);
	my $serial_hex = Net::SSLeay::P_ASN1_INTEGER_get_hex($serial_number);
	$self->log($main::LOG_DEBUG, "Certificate Serial Number is $serial_dec (0x$serial_hex)", $p);
    }
    else
    {
	$self->log($main::LOG_DEBUG, "Certificate Serial Number access requires Net::SSLeay 1.46 or later", $p);
    }

    return;
}

1;

