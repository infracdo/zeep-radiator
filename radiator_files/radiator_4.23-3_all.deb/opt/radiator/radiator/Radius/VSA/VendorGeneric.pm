# VendorGeneric.pm
#
# Implements a base class for custom unpacking and packing of RADIUS VSAs.
#
# Copyright (C) 2017 Open System Consultants
# Author: Tuure Vartiainen (vartiait@open.com.au)
# $Id$

package Radius::VSA::VendorGeneric;
use strict;
use warnings;

# RCS version number of this module
$Radius::VSA::VendorGeneric::VERSION = '$Revision$';

sub new
{
    my ($class, @args) = @_;

    my $self = {@args};
    bless $self, $class;
    return $self;
}

# The derived vendor specific classes need to implement pack and
# unpack methods for each VSA they support.
#
# Using vendor 3GPP (10415) as an example, to encode and decode
# 3GPP-User-Location-Info (VSA 22), you need to:
#
# - Create file VSA/Vendor_10415.pm that derives from this class
# - Create method pack_22 to pack 3GPP-User-Location-Info
# - Create method unpack_22 to unpack 3GPP-User-Location-Info
#
# Both methods receive $vendor, $value, $p as their arguments.
# The methods must return a defined scalar if they are successful.

1;
