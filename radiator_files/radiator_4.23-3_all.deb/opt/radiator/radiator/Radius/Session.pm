# Session.pm
#
# Object for handling session details
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::Session;
use strict;
use warnings;
our @ISA = qw(Radius::Subscription);
use Radius::Subscription;

# RCS version number of this module
$Radius::Session::VERSION = '$Revision$';

# Session states
$Radius::Session::NEW = 0;
$Radius::Session::PROVISIONED = 1;
$Radius::Session::INACTIVE = 2;
$Radius::Session::ACTIVE = 4;
$Radius::Session::ENDED = 8;
$Radius::Session::DELETED = 16;

#####################################################################
sub new
{
    my ($class, $id, $name, $subscription_id, $subscription_name, $tenant_id) = @_;

    # Call Subscription class constructor
    my $self = $class->SUPER::new($subscription_id, $subscription_name, undef, undef, $tenant_id);

    # Copy Subscription class attributes into new attributes
    $self->{parent_id} = $self->{id};
    $self->{parent_name} = $self->{name};

    # Session id
    $self->{id} = $id;
    # Which attribute to use for id
    $self->{id_attribute} = undef;

    # Session name
    $self->{name} = $name;
    # Which attribute to use for name
    $self->{name_attribute} = undef;

    # Address from which a request was received
    $self->{recv_from_addr} = undef;
    # Ref to NAS Client object?
    $self->{nas} = undef;
    # NAS-Identifier
    $self->{nas_id} = undef;
    # NAS-IP-Address
    $self->{nas_ipv4} = undef;
    # NAS-IPv6-Address
    $self->{nas_ipv6} = undef;
    # NAS-Port / NAS-Port-Id
    $self->{nas_port} = undef;
    # Called-Station-Id
    $self->{called_station} = undef;
    # Calling-Station-Id
    $self->{calling_station} = undef;
    # SSID
    $self->{ssid} = undef;

    # RADIUS Class
    $self->{class} = undef;

    # Single IPv4 address
    $self->{ipv4} = undef;
    # Single IPv6 address
    $self->{ipv6} = undef;

    # Session state: new, provisioned, inactive, active, ended, deleted
    $self->{state} = $Radius::Session::NEW;
    # Session status
    $self->{status} = undef;

    # How long session has been active
    $self->{duration} = 0;
    $self->{duration_prev} = 0;
    # How many bytes of data base been transferred (in + out)
    $self->{data_used} = 0;
    $self->{data_used_prev} = 0;

    # A fraction of remaining subscription quota to reserve for a new session
    $self->{quota_fraction} = 0.2;

    # Quota thresholds for resupplying session quotas from a subscription
    # Usage percentage
    $self->{quota_threshold} = 0.8;
    # Time lef in seconds
    $self->{quota_time_left_threshold} = 0;
    # Data left in octets
    $self->{quota_octets_left_threshold} = 0;

    # End reason
    $self->{end_reason} = undef;

    # Timestamp when session was ended
    $self->{ended_at} = undef;

    # Extra attributes
    $self->{extra_attr} = {};

    return $self;
}

sub new_from_session
{
    my ($class, $id, $name, $session) = @_;

    return undef unless $session;

    my $self = $class->new($id, $name, $session->{tenant_id});

    $self->set_from_service($session);
    $self->{new} = 1;

    return $self;
}

sub set_from_session
{
    my ($self, $session) = @_;

    $self->set_quota_thresholds($session->set_quota_thresholds());

    return;
}

sub new_from_subscription
{
    my ($class, $id, $name, $subscription) = @_;

    return undef unless $subscription;

    # Create a new session from a subscription
    my $self = $class->new($id, $name, $subscription->{id}, $subscription->{name}, $subscription->{tenant_id});
    # Copy user charge params and remaining quotas
    $self->set_from_subscription($subscription);
    $self->{new} = 1;

    # Get remaining quotas
    my @quotas = $self->get_quotas_left();
    # Allocate quotas from a subscription for a session
    # Get a fraction of remaining quotas
    my @quotas_left_for_session = $self->get_quotas_left($self->{quota_fraction}, $self->{quota_octets_left_threshold}, $self->{quota_time_left_threshold});
    # (Overwrite) session remaining quotas
    # All sessions will have all remaining time quota
    $quotas_left_for_session[0] = $quotas[0];
    $quotas_left_for_session[1] = $quotas[1];
    $self->set_quotas_left(@quotas_left_for_session);

    # Redact allocated quotas from the subscription
    # Do not redact time quotas from the subscription so that
    # multiple sessions can share the same time quota
    # Prepaid time quota
    $quotas_left_for_session[0] = undef;
    # Postpaid time quota
    $quotas_left_for_session[1] = undef;
    $subscription->deplete_quotas(@quotas_left_for_session);
    $self->{parent} = $subscription;

    return $self;
}

sub get_subscription
{
    my ($self) = @_;

    $self->get_parent();

    return $self->{parent};
}

sub supply_from_subscription
{
    my ($self, $subscription, $time_required, $octets_required) = @_;

    unless ($subscription)
    {
	unless ($self->{parent})
	{
	    $self->get_parent();
	}
	$subscription = $self->{parent};
    }

    if ($subscription)
    {
	main::log($main::LOG_DEBUG, "Supplying quotas from a subscription for a session");
	$time_required = $self->{quota_time_left_threshold} unless $time_required;
	$octets_required = $self->{quota_octets_left_threshold} unless $octets_required;
	# Get a fraction of remaining session quotas
	my @quotas_left = $subscription->get_quotas_left($self->{quota_fraction}, $time_required, $octets_required);
	# Reset fraction if needed
	if (exists $self->{quota_fraction_prev})
	{
	    $self->{quota_fraction} = $self->{quota_fraction_prev} if $self->{quota_fraction_prev};
	    delete $self->{quota_fraction_prev};
	}
	# Redact allocated quotas from the subscription
	# Do not redact time quotas from the subscription so that
	# multiple sessions can share the same time quota
	# Prepaid time quota
	$quotas_left[0] = undef;
	# Postpaid time quota
	$quotas_left[1] = undef;
	$subscription->deplete_quotas(@quotas_left);
	#my $rc = $subscription->save();
	#main::log($main::LOG_WARNING, "Saving a subscription failed: $subscription->{id}, $subscription->{name}") unless $rc;
	$self->supply_quotas(@quotas_left);

	$self->{refill_number} += 1;
	$self->{refilled_at} = time();
	$self->{resupply} = 0;
    }

    return;
}

sub set_id_name_attributes
{
    my ($self, $id_attribute, $name_attribute) = @_;

    $self->{id_attribute} = $id_attribute if $id_attribute;
    $self->{name_attribute} = $name_attribute if $name_attribute;

    return;
}

sub get_id_name_attributes
{
    my ($self) = @_;

    return ($self->{id_attribute}, $self->{name_attribute});
}

sub set_quota_thresholds
{
    my ($self, $quota_fraction, $quota_threshold, $quota_time_left_threshold, $quota_octets_left_threshold) = @_;

    $self->{quota_fraction} = $quota_fraction;
    $self->{quota_threshold} = $quota_threshold;
    $self->{quota_time_left_threshold} = $quota_time_left_threshold;
    $self->{quota_octets_left_threshold} = $quota_octets_left_threshold;
    $self->{dirty} = 1;

    return;
}

sub get_quota_thresholds
{
    my ($self) = @_;

    return ($self->{quota_fraction}, $self->{quota_threshold}, $self->{quota_time_left_threshold}, $self->{quota_octets_left_threshold});
}

sub get_total_usage
{
    my ($self) = @_;

    return ($self->{duration}, $self->{data_used});
}

sub get_prev_usage
{
    my ($self) = @_;

    return ($self->{duration_prev}, $self->{data_used_prev});
}

sub check_quota_usage
{
    my ($self) = @_;

    #my $duration = $self->{duration};
    my $duration = $self->{duration_prev};
    #my $data_used = $self->{data_used};
    my $data_used = $self->{data_used_prev};

    my ($quota_time_pre_usage, $quota_time_post_usage, $quota_octets_pre_usage, $quota_octets_post_usage) = (0, 0, 0, 0);

    if (defined $self->{quota_time_pre_left})
    {
	my $quota_time_pre_left = ($self->{quota_time_pre_left}) ? $self->{quota_time_pre_left} : 1;
	$quota_time_pre_usage = $duration / $quota_time_pre_left;

	if ($quota_time_pre_usage > 1 || $quota_time_pre_left == 1)
	{
	    main::log($main::LOG_DEBUG, "Session quota_time_pre_usage $quota_time_pre_usage");
	    $quota_time_pre_usage = 1;
	    $duration -= $self->{quota_time_pre_left};
	    $self->{resupply} = 1;
	}
	elsif ($quota_time_pre_usage > $self->{quota_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_time_pre_usage $quota_time_pre_usage > $self->{quota_threshold}");
	    $self->{resupply} = 1;
	}
	elsif (($self->{quota_time_pre_left} - $duration) < $self->{quota_time_left_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_time_pre_left $self->{quota_time_pre_left} - $duration < $self->{quota_time_left_threshold}");
	    $self->{resupply} = 1;
	    # Increase factor
	    $self->{quota_fraction_prev} = $self->{quota_fraction};
	    $self->{quota_fraction} = 1;
	}
    }

    if (defined $self->{quota_time_post_left})
    {
	my $quota_time_post_left = ($self->{quota_time_post_left}) ? $self->{quota_time_post_left} : 1;
	$quota_time_post_usage = $duration / $quota_time_post_left;

	if ($quota_time_post_left == 1)
	{
	    main::log($main::LOG_DEBUG, "Session quota_time_post_left $quota_time_post_left");
	    $quota_time_post_usage = 1;
	    $self->{resupply} = 1;
	}
	elsif ($quota_time_post_usage > $self->{quota_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_time_post_usage $quota_time_post_usage > $self->{quota_threshold}");
	    $self->{resupply} = 1;
	}
	elsif (($self->{quota_time_post_left} - $duration) < $self->{quota_time_left_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_time_post_left $self->{quota_time_post_left} - $duration < $self->{quota_time_left_threshold}");
	    $self->{resupply} = 1;
	    # Increase factor
	    $self->{quota_fraction_prev} = $self->{quota_fraction};
	    $self->{quota_fraction} = 1;
	}
    }

    if (defined $self->{quota_octets_pre_left})
    {
	my $quota_octets_pre_left = ($self->{quota_octets_pre_left}) ? $self->{quota_octets_pre_left} : 1;
	$quota_octets_pre_usage = $data_used / $quota_octets_pre_left;

	if ($quota_octets_pre_usage > 1 || $quota_octets_pre_left == 1)
	{
	    main::log($main::LOG_DEBUG, "Session quota_octets_pre_usage $quota_octets_pre_usage");
	    $quota_octets_pre_usage = 1;
	    $data_used -= $self->{quota_octets_pre_left};
	    $self->{resupply} = 1;
	}
	elsif ($quota_octets_pre_usage > $self->{quota_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_octets_pre_usage $quota_octets_pre_usage > $self->{quota_threshold}");
	    $self->{resupply} = 1;
	}
	elsif (($self->{quota_octets_pre_left} - $data_used) < $self->{quota_octets_left_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_octets_pre_left $self->{quota_octets_pre_left} - $data_used < $self->{quota_octets_left_threshold}");
	    $self->{resupply} = 1;
	    # Increase factor
	    $self->{quota_fraction_prev} = $self->{quota_fraction};
	    $self->{quota_fraction} = 1;
	}
    }

    if (defined $self->{quota_octets_post_left})
    {
	my $quota_octets_post_left = ($self->{quota_octets_post_left}) ? $self->{quota_octets_post_left} : 1;
	$quota_octets_post_usage = $data_used / $quota_octets_post_left;

	if ($quota_octets_post_left == 1)
	{
	    main::log($main::LOG_DEBUG, "Session quota_octets_post_left $quota_octets_post_left");
	    $quota_octets_pre_usage = 1;
	    $self->{quota_fraction_prev} = $self->{quota_fraction};
	    $self->{resupply} = 1;
	}
	elsif ($quota_octets_post_usage > $self->{quota_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_octets_post_usage $quota_octets_post_usage > $self->{quota_threshold}");
	    $self->{resupply} = 1;
	}
	elsif (($self->{quota_octets_post_left} - $data_used) < $self->{quota_octets_left_threshold})
	{
	    main::log($main::LOG_DEBUG, "Session quota_octets_post_left $self->{quota_octets_post_left} - $data_used < $self->{quota_octets_left_threshold}");
	    $self->{resupply} = 1;
	    # Increase factor
	    $self->{quota_fraction_prev} = $self->{quota_fraction};
	    $self->{quota_fraction} = 1;
	}
    }

    return ($quota_time_pre_usage, $quota_time_post_usage, $quota_octets_pre_usage, $quota_octets_post_usage);
}

sub get_leaked_quota
{
    my ($self, $quota_time_used, $quota_octets_used) = @_;

    my ($leaked_time, $leaked_octets) = (0, 0);

    if ($quota_time_used)
    {
	if ($self->{quota_time_pre_left})
	{
	    $leaked_time += $self->{quota_time_pre_left};
	}
	if ($self->{quota_time_post_left})
	{
	    $leaked_time += $self->{quota_time_post_left};
	}

	$leaked_time -= $quota_time_used;
	$leaked_time = ($leaked_time < 0) ? -1 * $leaked_time : 0;
    }

    if ($quota_octets_used)
    {
	if ($self->{quota_octets_pre_left})
	{
	    $leaked_octets += $self->{quota_octets_pre_left};
	}
	if ($self->{quota_octets_post_left})
	{
	   $leaked_octets += $self->{quota_octets_post_left};
	}

	$leaked_octets -= $quota_octets_used;
	$leaked_octets = ($leaked_octets < 0) ? -1 * $leaked_octets : 0;
    }

    return ($leaked_time, $leaked_octets);
}

sub exceeded
{
    my ($self) = @_;

    my $exceeded = 0;

    my @quota_usages = $self->check_quota_usage();
    foreach my $quota_usage (@quota_usages)
    {
	if ($quota_usage >= 1)
	{
	    $exceeded = 1;
	}
    }

    if ($exceeded)
    {
	main::log($main::LOG_DEBUG, "Session quota exceeded");
    }

    if ($exceeded || $self->{resupply})
    {
	$self->supply_from_subscription();

	# Check again
	@quota_usages = $self->check_quota_usage();

	$exceeded = 0;
	foreach my $quota_usage (@quota_usages)
	{
	    if ($quota_usage >= 1)
	    {
		$exceeded = 1;
	    }
	}
    }

    if ($exceeded)
    {
	main::log($main::LOG_DEBUG, "Session quota exceeded after resupply");
    }

    return $exceeded;
}

sub is_ended
{
    my ($self) = @_;

    return ($self->{state} == $Radius::Session::ENDED);
}

sub handle_accounting
{
    my ($self, $p, $extra_attrs) = @_;

    # User-Name string
    my $name;
    if ($self->{name_attribute})
    {
	$name = $p->get_attr($self->{name_attribute});
    }
    else
    {
	$name = $p->getAttrByNum($Radius::Radius::USER_NAME);
    }
    if (defined $name)
    {
	$self->{user_name} = $name;
    }

    # Session id string
    my $acct_sess_id;
    if ($self->{id_attribute})
    {
	$acct_sess_id = $p->get_attr($self->{id_attribute});
    }
    else
    {
	# Acct-Session-Id string
	$acct_sess_id = $p->getAttrByNum($Radius::Radius::ACCT_SESSION_ID);
    }
    $self->{id} = $acct_sess_id unless $self->{id};

    # Received from
    $self->{recv_from_addr} = Radius::Util::inet_ntop($p->{RecvFromAddress});

    # NAS-Identifier can be different even when NAS-IP-Address/NAS-IPv6-Address is the same
    # NAS-Identifier string
    my $nas_id = $p->getAttrByNum($Radius::Radius::NAS_IDENTIFIER);
    $self->{nas_id} = $nas_id if defined $nas_id;

    # NAS-IP-Address IPv4 address
    my $nas_ip = $p->getAttrByNum($Radius::Radius::NAS_IP_ADDRESS);
    $self->{nas_ipv4} = $nas_ip if defined $nas_ip;

    # NAS-IPv6-Address IPv6 address
    my $nas_ipv6 = $p->getAttrByNum($Radius::Radius::NAS_IPV6_ADDRESS);
    $self->{nas_ipv6} = $nas_ipv6 if defined $nas_ipv6;

    # NAS-Port and NAS-Port-Id may not differ between clients
    # NAS-Port integer
    my $nas_port = $p->getAttrByNum($Radius::Radius::NAS_PORT);
    $self->{nas_port} = $nas_port if defined $nas_port;

    # NAS-Port-Id string
    my $nas_port_id = $p->get_attr('NAS-Port-Id');
    $self->{nas_port} = $nas_port_id if defined $nas_port_id;

    # TODO: FIXME: Unify received formats
    # Called-Station-Id can contain also SSID
    # Called-Station-Id string
    my $called_station = $p->getAttrByNum($Radius::Radius::CALLED_STATION_ID);
    $self->{called_station} = $called_station;

    # TODO: FIXME: Unify received formats
    # Calling-Station-Id string
    my $calling_station = $p->getAttrByNum($Radius::Radius::CALLING_STATION_ID);
    $self->{calling_station} = $calling_station;

    # Framed-IP-Address IPv4 address
    my $framed_ip = $p->getAttrByNum($Radius::Radius::FRAMED_IP_ADDRESS);
    $self->{ipv4} = $framed_ip if defined $framed_ip;

    # Client can have multiple IPv6 addresses
    # Framed-IPv6-Address(es) IPv6 address(es)
    my $framed_ipv6 = $p->get_attr('Framed-IPv6-Address');
    $self->{ipv6} = $framed_ipv6 if defined $framed_ipv6;

    # Accounting-Request can contain multiple Classes
    # Class(es) string(s)
    my $class = $p->getAttrByNum($Radius::Radius::CLASS);
    $self->{class} = $class if defined $class;

    # Timestamp
    my $time = time();

    # Event-Timestamp integer
    my $event_timestamp = $p->get_attr('Event-Timestamp');
    $time = $event_timestamp if $event_timestamp;

    # (Radiator internal) Timestamp integer
    my $timestamp = $p->get_attr('Timestamp');
    $time = $timestamp if (!$time && $timestamp);

    # Acct-Session-Time integer
    my $acct_session_time = $p->getAttrByNum($Radius::Radius::ACCT_SESSION_TIME);
    if (defined $acct_session_time)
    {
	$self->{duration_prev} = $acct_session_time - $self->{duration};
	$self->{duration_prev} = 0 if $self->{duration_prev} < 0;
	$self->{duration} = $acct_session_time;
    }

    # Acct-Input-Gigawords integer
    my $acct_in_gigawords = $p->getAttrByNum($Radius::Radius::ACCT_INPUT_GIGAWORDS);

    # Acct-Input-Octets integer
    my $acct_in_bytes = $p->getAttrByNum($Radius::Radius::ACCT_INPUT_OCTETS);

    # Acct-Input-Octets + Acct-Input-Gigawords
    my $acct_in_data = Radius::Util::convert_from_gigawords($acct_in_bytes, $acct_in_gigawords);

    # Acct-Output-Gigawords integer
    my $acct_out_gigawords = $p->getAttrByNum($Radius::Radius::ACCT_OUTPUT_GIGAWORDS);

    # Acct-Output-Octets integer
    my $acct_out_bytes = $p->getAttrByNum($Radius::Radius::ACCT_OUTPUT_OCTETS);

    # Acct-Output-Octets + Acct-Output-Gigawords
    my $acct_out_data = Radius::Util::convert_from_gigawords($acct_out_bytes, $acct_out_gigawords);
    my $acct_data = 0;
    $acct_data += $acct_in_data if defined $acct_in_data;
    $acct_data += $acct_out_data if defined $acct_out_data;
    $self->{data_used_prev} = $acct_data - $self->{data_used};
    $self->{data_used_prev} = 0 if $self->{data_used_prev} < 0;
    $self->{data_used} = $acct_data;

    # Acct-Status-Type integer / string 'Start', 'Alive', 'Stop'
    my $acct_status = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE);
    if (defined $acct_status)
    {
	$self->{status} = $acct_status;
	if ($acct_status eq 'Start')
	{
	    $self->{state} = $Radius::Session::ACTIVE;
	    $self->{created_at} = $time;
	}
	elsif ($acct_status eq 'Alive')
	{
	    $self->{state} = $Radius::Session::ACTIVE;
	}
	elsif ($acct_status eq 'Stop')
	{
	    $self->{state} = $Radius::Session::ENDED;
	    $self->{ended_at} = $time;

	    # Acct-Terminate-Cause integer / string?
	    my $acct_end_cause = $p->getAttrByNum($Radius::Radius::ACCT_TERMINATE_CAUSE);
	    $self->{end_reason} = $acct_end_cause;
	}
    }

    # Extra attributes
    if ($extra_attrs)
    {
	while (my ($e_name, $e_attr) = each %{$extra_attrs})
	{
	    my $value = $p->get_attr($e_attr);
	    $self->{extra_attr}->{$e_name} = $value if defined $value;
	}
    }

    $self->{updated_at} = $time;
    $self->{dirty} = 1;

    return 1;
}

sub reset_session
{
    my ($self) = @_;

    $self->{duration_prev} = 0 if defined $self->{duration_prev};
    $self->{data_used_prev} = 0 if defined $self->{data_used_prev};

    return;
}

sub attr_keys
{
    my ($self) = @_;

    # 33 keys
    my @session_attr_keys = qw/tenant_id id name parent_id parent_name
	quota_time_pre_left quota_time_post_left quota_octets_pre_left quota_octets_post_left
	refill_number refilled_at user_name created_at deleted_at updated_at saved_at
	recv_from_addr nas_id nas_ipv4 nas_ipv6 nas_port
	called_station calling_station ssid class ipv4 ipv6 duration data_used status
	end_reason ended_at state/;

    # extra_attr(s) in alphabetical order
    foreach my $extra_attr (sort keys %{$self->{extra_attr}})
    {
	push(@session_attr_keys, $extra_attr);
    }

    return @session_attr_keys;
}

sub attr_values
{
    my ($self, $null) = @_;

    my @array = ();

    my @session_attr_keys = $self->attr_keys();
    foreach my $session_attr_key (@session_attr_keys)
    {
	if ($null && !defined $self->{$session_attr_key})
	{
	    push(@array, 'NULL');
	}
	else
	{
	    push(@array, $self->{$session_attr_key});
	}
    }

    # extra_attr(s) in alphabetical order
    foreach my $extra_attr (sort keys %{$self->{extra_attr}})
    {
	if ($null && !defined $self->{extra_attr}->{$extra_attr})
	{
	    push(@array, 'NULL');
	}
	else
	{
	    push(@array, $self->{extra_attr}->{$extra_attr});
	}
    }

    return @array;
}

1;
