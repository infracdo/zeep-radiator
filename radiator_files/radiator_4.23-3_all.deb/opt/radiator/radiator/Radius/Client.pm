# Client.pm
#
# Object for handling radius clients
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::Client;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Radius;
use Radius::Nas;
use Socket;
use strict;
use warnings;

%Radius::Client::ConfigKeywords = 
('Secret'                        => 
 ['string', 'This defines the shared secret that will be used to decrypt RADIUS messages that are received from this client. You must define a shared secret for each Client, and it must match the secret configured into the client RADIUS software. ', 0],

 'EncryptedSecret'               =>
 ['string', 'This defines the shared secret that will be used to decrypt RADIUS messages that are received from this client. You must define a shared secret for each Client, and it must match the secret configured into the client RADIUS software. EncryptedSecret is in encrypted format and is preferred over Secret.', 0],

 'DynAuthSecret'                 => 
 ['string', 'This defines the shared secret that will be used to encrypt RADIUS messages of dynamic authorization that are sent to this client. Defaults to clients Secret.', 2],

 'EncryptedDynAuthSecret'        =>
 ['string', 'This defines the shared secret that will be used to encrypt RADIUS messages of dynamic authorization that are sent to this client. EncryptedDynAuthSecret is in encrypted format and is preferred over DynAuthSecret.', 2],

 'TACACSPLUSKey'                 => 
 ['string', 'Per-client TACACSPLUS key which will be used as the TACACS+ key.', 1],

 'EncryptedTACACSPLUSKey'        =>
 ['string', 'Per-client TACACSPLUS key which will be used as the TACACS+ key. EncryptedTACACSPLUSKey is in encrypted format and is preferred over TACACSPLUSKey.', 1],

 'IgnoreAcctSignature'           => 
 ['flag', 'If defined, this parameter prevents the server from checking the "authenticator" (sometimes called the signature) in accounting requests received from this client. (Contrary to its name, it also affects the checking of Message-Authenticator in Access-Request messages). This parameter is useful because some clients (notably early Merit RADIUS servers and the GoRemote (GRIC) server when forwarding) do not send Authenticators that conform to RFC 2139, while some other NASs do not set the authenticator at all. ', 1],

 'DupInterval'                   => 
 ['integer', 'The Duplicate detection interval. If more than 1 RADIUS request is received with the same source and destination IP address, source port, authenticator and and RADIUS Identifier is received within DupInterval seconds, it is deemed to be a duplicate or retransmissions. If the earlier request has already been replied to, then that reply will be resent back to the NAS. Otherwise the duplicate request will be dropped. A value of 0 means duplicates are always accepted, which might not be very wise, except during testing. RFC 5080 recommends a value between 5 and 30 seconds. Default is 10 seconds.', 1],

 'DefaultRealm'                  => 
 ['string', 'This optional parameter can be used to specify a default realm to use for requests that have a User-Name that does not include a realm. The realm can then be used to trigger a specific <Realm> or <Handler> clause. This is useful if you operate a number of NASs for different customer groups and where some or all of your customers log in without specifying a realm.', 1],

 'NasType'                       => 
 ['string', 'This optional parameter specifies the vendor type of this Client. It is required if you want Radiator to directly query the NAS to check on simultaneous sessions.', 1],

 'VsaVendor' =>
 ['string', 'This optional parameter specifies the vendor type of this Client. It is required if you want Radiator to translate between OSC attributes and vendor-specific attributes.', 1],

 'VsaType' =>
 ['string', 'This optional parameter specifies the vendor sub type of this Client. It is required if you want Radiator to translate between OSC attributes and vendor-specific attributes.', 1],

 'VsaTranslateIn' =>
 ['splitstringhash', 'This optional parameter specifies the how to translate VSAs received from this Client.', 2],

 'VsaTranslateOut' =>
 ['splitstringhash', 'This optional parameter specifies the how to translate VSAs sent to this Client.', 2],

 'VsaTranslationHook' =>
 ['hook', 'This optional parameter allows you to define a Perl function that will be called during packet processing. VsaTranslationHook is called for each request when it is received and before it is sent out. The current request is passed as the first argument, the second argument defines whether translation is for in (0) or out (1), the third argument, if defined, is the destination object for the translated attributes.', 2],

 'SNMPCommunity'                 => 
 ['string', 'This optional parameter specifies the SNMP Community name to use to connect to the NAS when NasType uses SNMP. It is ignored for any other NasType. Defaults to "public".', 1],

 'LivingstonOffs'                => 
 ['integer', 'Specifies the value of where the last S port is before the one or tw ports specified in LivingstonHole are skipped (usually 22 for US, 29 for Europe). This optional parameter is only used if you are using Simultaneous-Use with a NasType of Livingston in this Client clause. Defaults to the value of LivingstonOffs in ServerConfig.', 1],

 'LivingstonHole'                => 
 ['integer', 'Specifies the value of the size of the hole in the port list (usually 1 for US, 2 for Europe) that occurs at LivingstonOffs. This optional parameter is only used if you are using Simultaneous-Use with a NasType of Livingston in this Client clause. Defaults to the value of LivingstonOffs from ServerConfig.', 1],

 'FramedGroupBaseAddress'        => 
 ['stringarray', 'This optional parameter is used in conjunction with the Framed-Group reply attribute or the FramedGroup AuthBy parameter to automatically generate IP addresses for users logging in. It is ignored unless the user has a Framed-Group reply item, or unless their AuthBy clause contains a FramedGroup parameter. You can have as many FramedGroupBaseAddress items as you like.', 1],

 'FramedGroupMaxPortsPerClassC'  => 
 ['integer', 'This optional parameter defines the maximum number of ports that can be mapped to a class C or class B FramedGroupBaseAddress. The default is 255, which means that any address from 0 up to 255 in the 3rd or 4th octets will be permitted. It actually specifies the modulus for computing the 3rd and 4th octets of addresses calculated from FramedGroupBaseAddress. You might use this to limit the number of addresses used in each address block, or to prevent the allocation of the last address in a class C address block.', 1],

 'FramedGroupPortOffset'         => 
 ['integer', 'Optional number to subtract from Framed Group port number. May be required for Cisco ISDN port numbers whcih start at a non-standard number ', 2],

 'RewriteUsername'               => 
 ['stringarray', 'This parameter enables you to alter the user name in all authentication and accounting requests from this client before being despatched to any Realm or Handler. ', 1],

 'UseOldAscendPasswords'         => 
 ['flag', 'This optional parameter tells Radiator to decode all passwords received from this Client using the old style (non RFC compliant) method that Ascend used to use on some NASs. The symptom that might indicate a need for this parameter is that passwords longer than 16 characters are not decoded properly.', 1],

 'StatusServerShowClientDetails' => 
 ['flag', 'Normally, when a Status-Server request is received, Radiator will reply with some statistics including the total number of requests handled, the current request rate etc. When you set the optional StatusServerShowClientDetails for a Client, the reply to Status-Server will also include details about that Client. This can result in a lengthy reply packet. Requires StatusServer parameter set to reply with statistics. The default is not to send the additional Client details for any Clients.', 1],

 'StatusServer' => 
 ['string', 'Normally, when a Status-Server request is received, Radiator will reply with some statistics including the total number of requests handled, the current request rate etc. You can control Status-Server response by setting StatusServer to off, minimal or default.', 1],

 'PreHandlerHook'                => 
 ['hook', 'This optional parameter allows you to define a Perl function that will be called during packet processing. PreHandlerHook is called for each request after per-Client username rewriting and duplicate rejection, and before it is passed to a Realm or Handler clause. A reference to the current request is passed as the only argument.', 1],

 'PacketTrace'                   => 
 ['flag', 'This optional flag forces all packets that pass through this module to be logged at trace level 4. This is useful for logging packets that pass through this clause in more detail than other clauses during testing or debugging. The packet tracing will stay in effect until it passes through another clause with PacketTrace set to off or 0.', 1],

 'IdenticalClients'              => 
 ['splitstringarray', 'This optional parameter specifies a list of other clients that have an identical setup. You can use this parameter to avoid having to create separate Client clauses for lots of otherwise identical clients. The value is a list of client names or addresses, separated by white space or comma.  Each client may be be specified as an IP address (IPV4 or IPV6), a MAC address in the form MAC:aa-bb-cc-dd-ee-ff, or an IPV4 CIDR address in the form nn.nn.nn/nn. You can have any number of IdenticalClients lines.', 1],

 'NoIgnoreDuplicates'            => 
 ['counthash', 'This optional parameter specifies one or more RADIUS packet types where duplicates are not ignored. NoIgnoreDuplicates is a comma or space separated list of request types, such as Access-Request,Accounting-Request,Status-Server', 1],

 'DefaultReply'                   => 
 ['string', 
  'Adds attributes to an Access-Accept only if there would otherwise be no reply attributes. StripFromReply will never remove any attributes added by DefaultReply. Value is a list of comma separated attribute value pairs ', 
  1],

 'FramedGroup'                    => 
 ['integer', 
  'If FramedGroup is set and a matching FramedGroupBaseAddress is set in the Client from where the request came, then a Framed-IP-Address reply item is automatically calculated by adding the NAS-Port in the request to the FramedGroupBaseAddress specified by FramedGroup. ', 
  1],

 'StripFromReply'                 => 
 ['string', 
  'Strips the named attributes from Access-Accepts before replying to the originating client. The value is a comma separated list of Radius attribute names. StripFromReply removes attributes from the reply before AddToReply adds any to the reply.', 
  1],

 'AllowInReply'                   => 
 ['string', 
  'Specifies the only attributes that are permitted in an Access-Accept. It is most useful to limit the attributes that will be passed back to the NAS from a proxy server. That way, you can prevent downstream customer Radius servers from sending back illegal or troublesome attributes to your NAS.', 
  1],

 'AddToReply'                     => 
 ['string', 
  'Adds attributes reply packets. Value is a list of comma separated attribute value pairs all on one line, exactly as for any reply item. StripFromReply removes attributes from the reply before AddToReply adds any to the reply. ', 
  1],

 'AddToReplyIfNotExist'           => 
 ['string', 
  'Similar to AddToReply, but only adds an attribute to a reply if and only if it is not already present in the reply. Therefore it can be used to add, but not override a reply attribute.', 
  1],

 'DynamicReply'                   => 
 ['stringarray', 
  'Specifies reply items that will be eligible for run-time variable   substitution. That means that you can use any of the % substitutions in that reply item.', 
  1],

 'AddToRequest'                   => 
 ['string', 
  'Adds attributes to the request before passing it to any authentication modules. Value is a list of comma separated attribute value pairs', 
  1],

 'AddToRequestIfNotExist'         => 
 ['string', 
  'Adds attributes to the request before passing it to any authentication modules. Unlike AddToRequest, an attribute will only be added if it does not already exist in the request. Value is a list of comma separated attribute value pairs ', 
  1],

 'StripFromRequest'               => 
 ['string', 
  'Strips the named attributes from the request before passing it to any authentication modules. The value is a comma separated list of attribute names. StripFromRequest removes attributes from the request before AddToRequest adds any to the request. ', 
  1],

 'AllowInReject'                  =>
 ['string',
  'Specifies the only attributes that are permitted in an Access-Reject.',
  1],

 'ClearTextTunnelPassword'     => 
 ['flag', 
  'Prevents Radiator decrypting and reencrypting Tunnel-Password attributes in replies during proxying. This is provided in order to support older NASs that do not support encrypted Tunnel-Password.', 
  2],

 'ClientHook'      => 
 ['hook',
  'Perl hook that is run for each request when delivered to this Client clause',
  2],

 'UseContentsForDuplicateDetection'     => 
 ['flag', 
  'Causes duplicates to be detected based only on the contents of each request, and ignoring the source port and RADIUS identifier. This is necessary for coorect detection of duplicates in a server-farm environment.', 
  2],

 'UseMessageAuthenticator'     => 
 ['flag', 
   'Adds a Message-Authenticator attribute to dynauth requests for this Client. Disabled by default.',
  2],

 'RequireMessageAuthenticator'     => 
 ['flag', 
  'Causes this Client to require a (correct) Message-Authenticator attribute to be present in all incoming requests', 
  2],

 'DynAuthPort'     => 
 ['string', 
  'Defines a destination port to which send RADIUS requests of dynamic authorization. Unset by default.', 
  2],

 );

# RCS version number of this module
$Radius::Client::VERSION = '$Revision$';

# Make sure we get reinitialized on sighup
push(@main::reinitFns, \&reinitialize);

# Tell radiusd how to get to our find function
push(@main::clientFindFns, \&find);

# Patterns for recognising CIDRs
my $ipv4cidrpat = qr/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/(\d+)/;
my $ipv6cidrpat = qr/(.*:.*)\/(\d+)$/;
my @cidrmasks =
(
 0x00000000, # /0
 0x80000000,
 0xc0000000,
 0xe0000000,
 0xf0000000,
 0xf8000000,
 0xfc000000,
 0xfe000000,
 0xff000000,
 0xff800000,
 0xffc00000,
 0xffe00000,
 0xfff00000,
 0xfff80000,
 0xfffc0000,
 0xfffe0000,
 0xffff0000,
 0xffff8000,
 0xffffc000,
 0xffffe000,
 0xfffff000,
 0xfffff800,
 0xfffffc00,
 0xfffffe00,
 0xffffff00,
 0xffffff80,
 0xffffffc0,
 0xffffffe0,
 0xfffffff0,
 0xfffffff8,
 0xfffffffc,
 0xfffffffe,
 0xffffffff, # /32
 );

# IPv6 netmasks are calculated only if there are IPv6 CIDR Clients.
my @ipv6cidrmasks;

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    # Complain if we are building from config file, but there
    # was no secret or TACACS+ key. Dont complain if we are being
    # built by CListSQL
    $self->log($main::LOG_ERR,
        "No Secret, EncryptedSecret, TACACSPLUSKey or EncryptedTACACSPLUSKey defined for $self->{log_class_name} in '$main::config_file'")
	if !defined $self->{Secret} && !defined $self->{EncryptedSecret} &&
	   !defined $self->{TACACSPLUSKey} && !defined $self->{EncryptedTACACSPLUSKey};

    # See if the encrypted secrets can be decrypted
    foreach my $crypted (qw(EncryptedSecret EncryptedDynAuthSecret EncryptedTACACSPLUSKey))
    {
	next unless $self->{$crypted};
	$self->log($main::LOG_ERR, "$self->{log_class_name} Config check could not decrypt $crypted $self->{$crypted}")
	    unless Radius::Util::decrypt_value(Radius::Util::format_special($self->{$crypted}));
    }

    # ServerConfig has a default for this, but lets do a check anyway
    unless (defined $main::config->{DupCache})
    {
	$self->log($main::LOG_ERR, "$self->{log_class_name} Global DupCache configuration parameter is not defined");
    }

    # See if the names can be resolved to IP addresses and CIDR blocks
    # are correctly specified. Resolve will complain if it fails.
    foreach ($self->{Name},
	     @{$self->{IdenticalClients}})
    {
	$self->resolve($_);
	if ($_ =~ /^$ipv4cidrpat/)
	{
	    $self->log($main::LOG_ERR, "Could not resolve address in IPv4 CIDR pattern $_")
		unless Radius::Util::inet_pton($1);
	    $self->log($main::LOG_ERR, "Bad mask length $2 in IPv4 CIDR pattern $_")
		unless $2 >= 0 && $2 <= 32;
	}
	elsif ($_ =~ /^$ipv6cidrpat/)
	{
	    # Calculate the IPv6 masks to trigger a warning if there
	    # is nothing but pure Perl BigInt lib available
	    Radius::Client::calculate_ipv6masks()
		unless @Radius::Client::ipv6cidrmasks;

	    $self->log($main::LOG_ERR, "Could not resolve address in IPv6 CIDR pattern $_")
		unless Radius::Util::inet_pton($1);
	    $self->log($main::LOG_ERR, "Bad mask length $2 in IPv6 CIDR pattern $_")
		unless $2 >= 0 && $2 <= 128;
	}
    }

    $self->SUPER::check_config();
    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    $self->{DupCache} = {};
    $self->{DupCacheOrder} = [];

    $self->decrypt_secrets();

    require Radius::Gossip
	    if $main::config->{DupCache} eq $Radius::ServerConfig::DupCache::GLOBAL;

    # The packed address. We skip Names that can not be resolved from
    # DNS.
    if ($self->{Name} eq 'DEFAULT')
    {
	$self->{Host} = Socket::INADDR_ANY;
    }
    else
    {
	$self->{Host} = $self->resolve($self->{Name});
    }

    # So we can look up either by name/dotted quad or by 
    # packed IP V4 or V6 address or by MAC address
    $self->addClientAddress($self->{Name});

    # Add entries for all the IdenticalClients
    foreach (@{$self->{IdenticalClients}})
    {
	$self->addClientAddress($_);
    }
}

# Decrypt, possibly again, the secret, dynauth secret and TACACS+ key
sub decrypt_secrets
{
    my ($self) = @_;

    # Decrypt secret, dynauth secret and TACACS+ key if they are set
    $self->{_decrypted_secret} = Radius::Util::decrypt_value(Radius::Util::format_special($self->{EncryptedSecret}))
	if $self->{EncryptedSecret};
    $self->{_decrypted_dynauth_secret} = Radius::Util::decrypt_value(Radius::Util::format_special($self->{EncryptedDynAuthSecret}))
	if $self->{EncryptedDynAuthSecret};
    $self->{_decrypted_tacacsplus_key} = Radius::Util::decrypt_value(Radius::Util::format_special($self->{EncryptedTACACSPLUSKey}))
	if $self->{EncryptedTACACSPLUSKey};
}

#####################################################################
# Add a Client address to the set of exact matching addresses
# $client_addr is a name or address or a MAC address or a CIDR mask address
sub addClientAddress
{
    my ($self, $client_addr) = @_;

    if ($client_addr =~ /^$ipv6cidrpat/)
    {
	my $addr    = $1; # From regexp
	my $masklen = $2; # From regexp

	# Calculate the IPv6 masks when they are first needed.
	Radius::Client::calculate_ipv6masks()
	    unless @Radius::Client::ipv6cidrmasks;

	# We calculate network address and save it for later use when
	# requests need to be matched with Clients.
	$addr = "ipv6:$addr" unless $addr =~ /^ipv6:/i;   # Make sure address starts with ipv6:
	my $addr_int = Radius::Util::inet_pton("$addr"); 
	my $net = Math::BigInt->new("0x" . unpack("H*", $addr_int));   # Address as BigInt
	$net->band($Radius::Client::ipv6cidrmasks[$masklen]);   # Do bitwise and to get network address
	$self->{IPv6AddrMasked} = $net;
    }
    # So we can find with a literal name or address or MAC or CIDR
    my $type = 'LITERAL:';
    if ($client_addr eq 'DEFAULT' ||
	$client_addr =~ /^MAC:/)
    {
	$type = '';
    }
    elsif ($client_addr =~ /^$ipv4cidrpat/ ||
	   $client_addr =~ /^$ipv6cidrpat/)
    {
	$type = 'CIDR:';
    }
    $Radius::Client::clients{$type.$client_addr} = $self;

    # Maybe add the packed address too
    my $addr = $self->resolve($client_addr);
    $Radius::Client::clients{'PACKED:'.$addr} = $self
	if $addr;

    return;
}

#####################################################################
# Try to resolve names and textual IP address to packed addresses
# while skipping DEFAULT, MAC:, CIDR blocks and other valid Client
# names. The callers expect us to complain if resolvation fails.
sub resolve
{
    my ($self, $client_addr) = @_;

    my $addr;
    if (   $client_addr ne 'DEFAULT'
	&& $client_addr !~ /^MAC:/
	&& $client_addr !~ /^$ipv4cidrpat/
	&& $client_addr !~ /^$ipv6cidrpat/)
    {
 	$addr = Radius::Util::inet_pton($client_addr);
 	$self->log($main::LOG_ERR, "Could not resolve address $client_addr for Client $self->{Name}")
 	    unless defined $addr;
    }

    return $addr;
}

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Statistics} = Radius::StatsLogGeneric::make_object_statistics($self);
    $self->{DupInterval} = 10;
    $self->{NasType} = 'unknown';   # Default NAS type
    $self->{SNMPCommunity} = 'public';
    $self->{FramedGroupMaxPortsPerClassC} = 255;
    $self->{LivingstonHole} = $main::config->{LivingstonHole};
    $self->{LivingstonOffs} = $main::config->{LivingstonOffs};
    $self->{ObjType} = 'Client'; # Auto register with Configurable
    $self->{StatusServer} = $main::config->{StatusServer};
    $self->{DynAuthPort} = undef;
}

#####################################################################
# Pre-calculate IPv6 netmasks for IPv6 CIDR Clients
sub calculate_ipv6masks
{
    # We use run time require to make sure that any warnings about
    # missing libs are not printed when IPv6 CIDR clients are not
    # configured. Later, when everyone uses recent enough BigInt, we
    # can use try instead of lib to suppress warnings.
    require Math::BigInt;
    Math::BigInt->import(lib => 'Pari,GMP');
    my $lib = Math::BigInt->config()->{lib};
    main::log($main::LOG_INFO, 'Consider installing Math::BigInt::GMP or Math::BigInt::Pari for faster IPv6 CIDR Client matching. Falling back to pure Perl implementation.')
	if $lib eq 'Math::BigInt::Calc';

    # Create 128 bits for exclusive or (bxor).
    my $max = Math::BigInt->new('0b' . '1' x 128);

    foreach my $masklen (0 .. 128)
    {
	my $mask = Math::BigInt->new('0b' . '1' x 128); # 128 1 bits
	$mask->brsft($masklen);  # Shift bit rights
	$mask->bxor($max);       # Flip them to get the mask
	
	$Radius::Client::ipv6cidrmasks[$masklen] = $mask;
    }

    return;
}

#####################################################################
# Add $finder to the front of Clients' current findFn array.
sub prepend_handler_finder
{
    my ($finder) = @_;

    unshift(@Radius::Client::handlerFindFn, $finder);

    return;
}

# Remove all instances of $finder from Clients' findFn array.
sub remove_handler_finder
{
    my ($finder) = @_;

    # Find matching indexes and shrink array starting from the back
    my @idxs = grep { $Radius::Client::handlerFindFn[$_] eq $finder } 0 .. $#Radius::Client::handlerFindFn;
    splice (@Radius::Client::handlerFindFn, $_, 1) foreach reverse(@idxs);

    return;
}

#####################################################################
# Find a Client with the packed Host same as the RecvFrom host
# If not found, try to find one with the MAC address given in Called-Station-Id
# If not found, try to find one for DEFAULT
# REVISIT: Should probably add regexp matching too?
sub find
{
    my ($p) = @_;

    my $client_addr = $p->{RecvFromAddress};
    my $ret = $Radius::Client::clients{'PACKED:'.$client_addr};
    # Look for a IPV4 or IPv6 CIDR match.
    $ret = findCidrAddress($client_addr)
	unless defined $ret;
    if (!defined $ret)
    {
	# Try to deduce a MAC address from Called-Station-Id
	my $mac = $p->getAttrByNum($Radius::Radius::CALLED_STATION_ID);
	$ret = $Radius::Client::clients{'MAC:' . $1}
	    if (defined $mac && $mac =~ /^([0-9a-fA-F]{2}-?[0-9a-fA-F]{2}-?[0-9a-fA-F]{2}-?[0-9a-fA-F]{2}-?[0-9a-fA-F]{2}-?[0-9a-fA-F]{2})/);

	# Still nothing, fall back to the default
	$ret = $Radius::Client::clients{DEFAULT}
            unless defined $ret;
    }
    return $ret;
}

#####################################################################
# Converts addresses into 32 bit unsigned ints for IPv4 and 128 bit
# BigInt object for IPv6 and applies CIDR mask
# CAUTION: linear search
sub findCidrAddress
{
    my ($client_addr) = @_;

    my @cidrs = grep { $_ =~ m/^CIDR:/ } keys %Radius::Client::clients;
    return unless @cidrs;

    my $addr_len = length($client_addr);
    my $client_addr_int = unpack('N', $client_addr);  # For IPv4
    my $client_addr_hex = "0x" . unpack("H*", $client_addr); # For IPv6

    my @keys = sort { ($b =~ /\/(\d+)/)[0] <=> ($a =~ /\/(\d+)/)[0] } @cidrs;
    foreach my $key (@keys)
    {
	if ($addr_len == 4 && $key =~ /^CIDR:$ipv4cidrpat/)
	{
	    my $addr_int = unpack('N', &Radius::Util::inet_pton($1));
	    return $Radius::Client::clients{$key}
		if (   ($addr_int & $cidrmasks[$2]) 
		    == ($client_addr_int & $cidrmasks[$2]));
	}
	elsif ($addr_len == 16 && $key =~ /^CIDR:$ipv6cidrpat/)
	{
	    my $client = $Radius::Client::clients{$key};
	    my $a = Math::BigInt->new($client_addr_hex);  # Client address as a BigInt
	    $a->band($Radius::Client::ipv6cidrmasks[$2]); # Do bitwise and with CIDR mask
	    return $client
	        if ($client->{IPv6AddrMasked} == $a);
	}
    }
    return; # Not found
}

#####################################################################
# Find a Client with the packed IPv4 or IPv6 address $addr
# If not found, check CIDR Clients and finally try to find one for
# DEFAULT
sub findAddress
{
    my ($addr) = @_;

    my $ret = $Radius::Client::clients{'PACKED:'.$addr};
    $ret = findCidrAddress($addr)
	unless defined $ret;
    $ret = $Radius::Client::clients{DEFAULT}
	unless defined $ret;
    return $ret;
}

#####################################################################
# We may have Secret and EncryptedSecret. We prefer the encrypted
# secret but only if it's been successfully decrypted
sub secret
{
    my ($self) = @_;

    return defined $self->{_decrypted_secret} ?
	$self->{_decrypted_secret} :
	$self->{Secret};
}

# For dynauth prefer the encrypted dynauth secret too
sub dynauth_secret
{
    my ($self) = @_;

    return defined $self->{_decrypted_dynauth_secret} ?
	$self->{_decrypted_dynauth_secret} :
	$self->{DynAuthSecret};
}

# For TACACS+ prefer the encrypted TACACSPLUSKey too
sub tacacsplus_key
{
    my ($self) = @_;

    return defined $self->{_decrypted_tacacsplus_key} ?
	$self->{_decrypted_tacacsplus_key} :
	$self->{TACACSPLUSKey};
}

#####################################################################
# Handle a request from a client
sub handle_request
{
    my ($self, $p) = @_;

    # We tuck the Client pointer into the packet
    # so replying will be easier for other modules: they can just call
    # $originalPacket->{Client}->replyTo($originalPacket);
    $p->{Client} = $self;

    $p->{PacketTrace} = $self->{PacketTrace} 
        if defined  $self->{PacketTrace}; # Optional extra tracing

    my $secret = $self->secret();

    # Decrypt and unpack attrs from the raw wire
    $p->decode_attrs($secret, $p);

    $self->translateVSAsIn($p) if $self->{VsaTranslateIn};
    $self->runHook('VsaTranslationHook', $p, $p, 0) if $self->{VsaTranslationHook};

    $p->recv_debug_dump($self) if (main::willLog($main::LOG_DEBUG, $p));

    # Call the server config ClientHook, if there is one
    $main::config->runHook('ClientHook', $p, \$p, $self);

    # Call our ClientHook, if there is one
    $self->runHook('ClientHook', $p, \$p);

    # Arrange to deliver replies back to this client
    $p->{replyFn} = [\&replyFn, $self];

    my $code = $p->code;

    if (!$self->{IgnoreAcctSignature}
	&& !$p->check_authenticator($secret, undef, $self->{RequireMessageAuthenticator}))
    {

	# get the NAS id
	my $nas_id = $p->getNasId();
	
	# we might have failed because there is no secret defined for this
	# client but there is a TACACSPLUS Key (which passes the config checks
	# in ->new()
	if (defined $secret)
	{
	    # Log where this stuff is coming from, hopefully we can fix
	    # it. Contributed by Shawn Instenes <shawni@teleport.com>
	    $self->log($main::LOG_WARNING,
		       "Bad authenticator in request from $self->{Name} ($nas_id)", $p);
	    $p->statsIncrement('badAuthRequests');
	    $p->statsIncrement('badAuthAccessRequests')
		if $code eq 'Access-Request';
	    $p->statsIncrement('badAuthAccountingRequests')
		if $code eq 'Accounting-Request';
	}
	else 
	{
	    $self->log($main::LOG_WARNING,
		       "No secret defined in request from $self->{Name} ($nas_id)", $p);
	}
	$p->statsIncrement('droppedRequests');
	$p->statsIncrement('droppedAccessRequests')
	    if $code eq 'Access-Request';
	$p->statsIncrement('droppedAccountingRequests')
	    if $code eq 'Accounting-Request';
    }
    else
    {
	$p->rewriteUsername($self->{RewriteUsername})
	    if defined $self->{RewriteUsername};

	# Add and strip attributes before forwarding. 
	map {$p->delete_attr($_)} (split(/\s*,\s*/, $self->{StripFromRequest}))
	    if defined $self->{StripFromRequest};

	$p->parse(&Radius::Util::format_special($self->{AddToRequest}, $p))
	    if defined $self->{AddToRequest};

	$p->parse_ifnotexist(&Radius::Util::format_special
			     ($self->{AddToRequestIfNotExist}, $p))
	    if defined $self->{AddToRequestIfNotExist};

	if ($code eq 'Status-Server')
	{
	    $self->handle_status_server($p);
	}
	else
	{
	    # Check that its not a duplicate. dups resulting from
	    # retransmission are ignored. For this client, we keep 
	    # a hash of arrays. The key for the hash is the 
	    # NAS-IP-Address or NAS-Identifier or client IP address
	    # of the incoming packet
	    # the index of the array is the Identifer of the packet. 
	    # The value is the receipt time.
	    
	    # On NAS reboot, forget about all previous identifiers
	    my $is_reboot;
	    if ($code eq 'Accounting-Request')
	    {
		my $acct_status_type = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE) || '';
		my $acct_session_id= $p->getAttrByNum($Radius::Radius::ACCT_SESSION_ID) || '';
		if (   ($acct_status_type eq 'Accounting-On')
		    || ($acct_status_type eq 'Start' && $acct_session_id eq '00000000'))
		{
		    # Remove all the recent identifiers from this address only
		    $self->clearDuplicateCacheForSource($p->{RecvFromAddress});
		    $is_reboot = 1;
		}
	    }
	    # BUG ALERT: this _wont_ catch retransmissions of
	    # accounting where the Acct-Delay-Time has changed, because
	    # the identifier will also have changed. Radius protocol sucks.
	    my $dup;
	    $dup = $self->findDuplicate($p) unless $self->{NoIgnoreDuplicates}{$code};
	    if ($dup)
	    {
		if (!$is_reboot)
		{
		    my $id = $p->identifier;
		    my ($udpAddrPrint) = &Radius::Util::inet_ntop($p->{RecvFromAddress});

		    # Its a duplicate. If we have already replied to it
		    # resend the reply, else drop it. See RFC 5080
		    if (exists $dup->{rp}->{Packet})
		    {
			$self->log($main::LOG_INFO, "Duplicate request id $id received from $udpAddrPrint($p->{RecvFromPort}): retransmit reply", $p);
			if ($self->{UseContentsForDuplicateDetection} && $dup->{rp}->identifier != $p->identifier)
			{
			    # Need to change the RADIUS identifier and recompute 
			    # authenticators, repack the request etc
			    $dup->{rp}->set_identifier($p->identifier);
			    $dup->{rp}->set_authenticator($p->authenticator);
			    $dup->{rp}->assemble_packet($secret, $p,
			      ClearTextTunnelPassword => $self->{ClearTextTunnelPassword});
			}
			# it's a retransmission, so we won't store it again in a dup cache
			$p->{retransmission} = 1;
			$dup->{rp}->sendReplyTo($p);
			$p->statsIncrement('duplicateRequests');
			$p->statsIncrement('dupAccessRequests')
			    if $code eq 'Access-Request';
			$p->statsIncrement('dupAccountingRequests')
			    if $code eq 'Accounting-Request';
		    }
		    else
		    {
			$self->log($main::LOG_INFO, "Duplicate request id $id received from $udpAddrPrint($p->{RecvFromPort}): ignored", $p);
			$p->statsIncrement('duplicateRequests', 
					   'droppedRequests');
			$p->statsIncrement('dupAccessRequests',
					   ' droppedAccessRequests')
			    if $code eq 'Access-Request';
			$p->statsIncrement('dupAccountingRequests',
					   ' droppedAccountingRequests')
			    if $code eq 'Accounting-Request';
		    }
		}
	    }
	    else
	    {
		# its not a dup, save for later dup checking
		if ($main::config->{DupCache} eq $Radius::ServerConfig::DupCache::LOCAL) {
		    $self->addToDuplicateCache($p)
			unless $self->{NoIgnoreDuplicates}{$code};
		}

		my ($user, $realmName) = split(/@/, $p->getUserNameString());
		# Maybe use a default realm to find the Realm
		# or Handler later?
		if (defined $user 
		    && (!defined $realmName || $realmName eq '')
		    && defined $self->{'DefaultRealm'})
		{
		    $realmName = $self->{'DefaultRealm'};
		    $p->changeUserName("$user\@$realmName");
		}

		# Call the PreHandlerHook, if there is one
		$self->runHook('PreHandlerHook', $p, \$p);

		# Look in the finder array in order until
		# we find a function that knows how to get a 
		# subclass of handler. This allows you to 
		# add new subclasses of Handler that have
		# new more efficinet ways of finding the righty
		# Handler to use
		my ($handler);
		foreach my $finder (@Radius::Client::handlerFindFn)
		{
		    if ($handler = &$finder($p, $user, $realmName))
		    {
			# Make sure the handler is updated with stats
			push(@{$p->{StatsTrail}}, $handler->{Statistics});

			$handler->handle_request($p);
			last;
		    }
		}
		if (!$handler)
		{
		    my $user = $p->getOriginalUserName();
		    $user = (defined $user) ? "user '$user'" : 'message with no User-Name attribute';
		    $self->log($main::LOG_WARNING, "Could not find a handler for $user: request is ignored", $p);

		    $p->statsIncrement('droppedRequests');
		    $p->statsIncrement('droppedAccessRequests')
			if $code eq 'Access-Request';
		    $p->statsIncrement('droppedAccountingRequests')
			if $code eq 'Accounting-Request';
		}
	    }
	}
    }

    $p->statsIncrement('requests');
    $p->statsIncrement('accessRequests') 
	if $code eq 'Access-Request';
    $p->statsIncrement('accountingRequests') 
	if $code eq 'Accounting-Request';
}

#####################################################################
# Check whether we have received an identical request in the DupCache
# in the last DupInterval seconds. If so, return it.
sub findDuplicate
{
    my ($self, $p) = @_;

    return unless $self->{DupInterval};

    my $key = $p->{RecvFromPort} . $p->authenticator . $p->identifier;

    if ($main::config->{DupCache} eq $Radius::ServerConfig::DupCache::SHARED)
    {
	#$self->log($main::LOG_DEBUG, "Client $self->{Name}: Checking for a reply from the shared duplicate cache");

	my $cache_entry = $main::config->{shared_dup_cache}->get($key);

	# Cache entries are automatically, but not instantly,
	# purged. We need to check if this entry is still valid.
	if ($cache_entry) {
	    my $expiry_time = unpack("N", $cache_entry);

	    if ($expiry_time > time) {
		my $reply_packet = unpack("x4 a*", $cache_entry);

		my $dup = Radius::Radius->new($main::dictionary);
		$dup->unpackRadiusAttrs($reply_packet);
		$dup->{rp} = $dup;
		$dup->{rp}->{Packet} = $reply_packet;

		return $dup;
	    }
	}

	return;
    }
    elsif ($main::config->{DupCache} eq $Radius::ServerConfig::DupCache::GLOBAL)
    {
	return unless defined $Radius::Gossip::handle;
	my $cache_key = unpack("H*", $key);

	#$self->log($main::LOG_DEBUG, "Client $self->{Name}: Checking for a reply from the global duplicate cache");

	my $message = $Radius::Gossip::handle->ask("dupcache:$cache_key");

	if ($message && $message->{type} eq "Client-DupCache-Entry") {
	    my $dup = Radius::Radius->new($main::dictionary);
	    $dup->unpackRadiusAttrs($message->{packet});
	    $dup->{rp} = $dup;
	    $dup->{rp}->{Packet} = $message->{packet};

	    return $dup;
	}

	return;
    }
    else
    {
	# First remove old expired requests from the beginning of the
	# time-ordered list
	my $cutoff = time - $self->{DupInterval};
	while (@{$self->{DupCacheOrder}}
	       && $self->{DupCacheOrder}[0]->{RecvTime} < $cutoff)
	{
	    my $oldp = shift(@{$self->{DupCacheOrder}});
	    my $oldkey = $oldp->{DupCacheKey};
	    if ($self->{UseContentsForDuplicateDetection})
	    {
		delete $self->{DupCache}->{$oldkey};
	    }
	    else
	    {
		delete $self->{DupCache}->{$oldp->{RecvFromAddress}}->{$oldkey};
	    }
	}
	# Then see if there is matching request in our cache
	if ($self->{UseContentsForDuplicateDetection})
	{
	    # Look at the packet contents not the envelope
	    # The key includes the authenticator, in line with RFC5080
	    my $key = $p->authenticator
		. ($p->getAttrByNum($Radius::Radius::USER_NAME) || '')
		. ($p->getAttrByNum($Radius::Radius::CALLED_STATION_ID)  || '')
		. ($p->getAttrByNum($Radius::Radius::CALLING_STATION_ID) || '');
	    return $self->{DupCache}->{$key};
	}
	else
	{
	    # The key includes the authenticator, in line with RFC5080
	    my $key = $p->{RecvFromPort} . $p->authenticator . $p->identifier;
	    return $self->{DupCache}->{$p->{RecvFromAddress}}->{$key};
	}

	return; # Not reached
    }
}

#####################################################################
# Add a request to the DupCache
sub addToDuplicateCache
{
    my ($self, $p) = @_;

    return unless $self->{DupInterval};
    if ($self->{UseContentsForDuplicateDetection})
    {
	my $key = $p->authenticator 
	    . ($p->getAttrByNum($Radius::Radius::USER_NAME) || '')
	    . ($p->getAttrByNum($Radius::Radius::CALLED_STATION_ID)  || '')
	    . ($p->getAttrByNum($Radius::Radius::CALLING_STATION_ID) || '');
	$p->{DupCacheKey} = $key;
	push (@{$self->{DupCacheOrder}}, $p);
	$self->{DupCache}->{$key} = $p;
    }
    else
    {
	# The key includes the authenticator, in line with RFC5080
	my $key = $p->{RecvFromPort} . $p->authenticator . $p->identifier;
	# Add to the end of the ordered time list of recent requests
	$p->{DupCacheKey} = $key;
	push (@{$self->{DupCacheOrder}}, $p);
	$self->{DupCache}->{$p->{RecvFromAddress}}->{$key} = $p;
    }
}

# Add a request to the shared DupCache on this server
sub addToSharedDuplicateCache {
    my ($self, $p) = @_;

    return unless $self->{DupInterval};

    my $key = $p->{RecvFromPort} . $p->authenticator . $p->identifier;
    #$self->log($main::LOG_DEBUG, "Client $self->{Name}: Storing the reply in the shared duplicate cache");

    my $header = pack("N", time() + $self->{DupInterval});
    my $cache_value = "$header$p->{rp}->{Packet}";
    unless ($main::config->{shared_dup_cache}->set($key, $cache_value))
    {
	$self->log($main::LOG_WARNING, "Client $self->{Name}: Failed to store the reply in the shared duplicate cache");
    }

    return;
}

# Add a request to the DupCache accessed with Gossip
sub addToGlobalDuplicateCache {
    my ($self, $p) = @_;

    return unless $self->{DupInterval};

    my $key = $p->{RecvFromPort} . $p->authenticator . $p->identifier;

    if (defined $Radius::Gossip::handle) {
	my $cache_key = unpack("H*", $key);

	my $message = {
	    version => 1,
	    type    => "Client-DupCache-Entry",
	    key	    => $key,
	    code    => $p->{Code},
	    identifier => $p->{Identifier},
	    authenticator => $p->{Authenticator},
	    packet  => $p->{rp}->{Packet},
	};

	#$self->log($main::LOG_DEBUG, "Client $self->{Name}: Storing the reply in the global duplicate cache");

	$Radius::Gossip::handle->note("dupcache:$cache_key", $message, $self->{DupInterval});

	return;
    }
}

#####################################################################
# Clears the duplicate cache of all requests from a particular source address.
sub clearDuplicateCacheForSource
{
    my ($self, $source) = @_;

    $self->{DupCache}->{$source} = {};
}

#####################################################################
# Assemble the reply packet {rp} in reply to packet $p
# Caution this API changed post 2.19, was $self, $rp, $p
sub replyTo
{
    my ($self, $p) = @_;

    # Honour DefaultReply etc
    $self->adjustReply($p);

    my $code = $p->{rp}->code;
    $p->statsIncrement('accessAccepts')
	if $code eq 'Access-Accept';
    $p->statsIncrement('accessRejects')
	if $code eq 'Access-Reject';
    $p->statsIncrement('accessChallenges')
	if $code eq 'Access-Challenge';
    $p->statsIncrement('accountingResponses')
	if $code eq 'Accounting-Response';

    # Do the translation here to include it in the response time
    $self->translateVSAsOut($p) if $self->{VsaTranslateOut};
    $self->runHook('VsaTranslationHook', $p, $p, 1, $p->{rp}) if $self->{VsaTranslationHook};

    my $response_time = &Radius::Util::timeInterval($p->{RecvTime}, $p->{RecvTimeMicros}, &Radius::Util::getTimeHires);
    $p->statsAverage($response_time, 'responseTime');

    if ($main::config->{ResponseTimeThreshold} && ($response_time * 1000) > $main::config->{ResponseTimeThreshold})
    {
	my $response_time_ms = $response_time * 1000;
	my $log_msg = "Response time $response_time_ms ms for " . $p->code();
	$log_msg .= " id $p->{Identifier} exceeded $main::config->{ResponseTimeThreshold} ms. (User: '" . $p->getUserName();
	$log_msg .= "', Client: '$p->{Client}->{Name}' ($p->{Client}->{Identifier}), Handler: '$p->{Handler}->{Name}'";
	$log_msg .= " ($p->{Handler}->{Identifier}), Last AuthBy: '$p->{AuthBy}->{Name}' ($p->{AuthBy}->{Identifier}))";
	$self->log($main::LOG_WARNING, $log_msg, $p);
    }

    $p->{rp}->assemble_packet($self->secret(), $p,
			      ClearTextTunnelPassword => $self->{ClearTextTunnelPassword});
    $p->{rp}->sendReplyTo($p);

    unless ($p->{retransmission} && $self->{NoIgnoreDuplicates}{$code}) {
	if ($main::config->{DupCache} eq $Radius::ServerConfig::DupCache::SHARED) {
	    $self->addToSharedDuplicateCache($p);
	}
	elsif ($main::config->{DupCache} eq $Radius::ServerConfig::DupCache::GLOBAL) {
	    $self->addToGlobalDuplicateCache($p);
	}
    }
}

#####################################################################
# This fn is called by Handler when the reply to the request is ready to go back
# This works even for delayed or asynch replies.
sub replyFn
{
    my ($p, $self) = @_;
    $self->replyTo($p);
}

#####################################################################
# Reinitialize this module
sub reinitialize
{
    # Remove circular references that would prevent auto destruction
    foreach my $clientname (keys %Radius::Client::clients)
    {
	my $client = $Radius::Client::clients{$clientname};
	$client->{DupCache} = {};
	$client->{DupCacheOrder} = [];
    }

    # This will DESTROY any objects left from a previous initialization
    %Radius::Client::clients = ();
}

#####################################################################
# Check whether user is still online at the given NAS, port 
# and session ID
# Returns 1 if they are still online, according to the NAS
# REVISIT: The NAS functions should really be in plug-in modules
# for future extensibility
sub isOnline
{
    my ($self, $name, $nas_id, $nas_port, $session_id, $framed_ip_address) = @_;

    return Radius::Nas::isOnline
	    ($self->{NasType}, $name, $nas_id, $nas_port, 
	     $session_id, $self, $framed_ip_address);
}

#####################################################################
sub translateVSAsIn
{
    my ($self, $p) = @_;

    Radius::Nas::translateVSAsIn($self->{VsaVendor}, $self->{VsaType}, $self->{VsaTranslateIn}, $p);

    return;
}

#####################################################################
sub translateVSAsOut
{
    my ($self, $p) = @_;

    Radius::Nas::translateVSAsOut($self->{VsaVendor}, $self->{VsaType}, $self->{VsaTranslateOut}, $p, $p->{rp});

    return;
}

#####################################################################
# Process a Status-Server request by sending a reply with interesting 
# statistics in it.
sub handle_status_server
{
    my ($self, $p) = @_;

    return if lc($self->{StatusServer}) eq 'off'; # Ignore Status-Server requests
    return unless $p->get_attr('Message-Authenticator'); # Required by RFC 5997

    $p->{rp} = Radius::Radius->new($main::dictionary);
    $p->{rp}->set_code('Access-Accept');
    $p->{rp}->set_identifier($p->identifier);
    $p->{rp}->set_authenticator($p->authenticator);
    $p->{rp}->{skip_message_authenticator} = 1; # For interoperability with certain clients

    # Not off or minimal: the default is to send statistics.
    if (lc($self->{StatusServer}) ne 'minimal')
    {
	# Probably should have a clever way so any module can
	# add to the list of statistics returned
	$p->{rp}->addAttrByNum($Radius::Radius::REPLY_MESSAGE,
			       "Radiator Radius server version $main::VERSION");
	$p->{rp}->addAttrByNum($Radius::Radius::REPLY_MESSAGE,
			       "Running on $main::hostname since " . scalar localtime($main::statistics{start_time}));
	$p->{rp}->addAttrByNum($Radius::Radius::REPLY_MESSAGE,
			       "$main::statistics{packet_rate} Requests in the last second");

	my ($value);
	foreach my $key (sort keys %Radius::StatsLogGeneric::statistic_names)
	{
	    $value = $main::config->{Statistics}{$key};
	    $p->{rp}->addAttrByNum($Radius::Radius::REPLY_MESSAGE,
				   "$value $Radius::StatsLogGeneric::statistic_names{$key}");
	}

	# show statistics for each client if requested
	foreach my $client (@{$main::config->{Client}})
	{
	    if ($client->{StatusServerShowClientDetails})
	    {
		$p->{rp}->addAttrByNum($Radius::Radius::REPLY_MESSAGE,
				       "Client $client->{Name}:");
		foreach my $key (sort keys %Radius::StatsLogGeneric::statistic_names)
		{
		    $value = $client->{Statistics}{$key};
		    $p->{rp}->addAttrByNum($Radius::Radius::REPLY_MESSAGE,
					   " $value $Radius::StatsLogGeneric::statistic_names{$key}");
		}
	    }
	}
    }

    # Make sure any Proxy-Sttae is honoured. This is normaly done in Handler
    $p->{rp}->delete_attr('Proxy-State'); # Remove bogus or cached state
    map {$p->{rp}->addAttrByNum($Radius::Radius::PROXY_STATE, $_)} $p->get_attr('Proxy-State');

    $self->replyTo($p);
}

1;
