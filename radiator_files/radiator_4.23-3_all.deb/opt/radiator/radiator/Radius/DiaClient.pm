# DiaClient.pm
#
# Object that acts as a simple Diameter client
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2002 Open System Consultants
# $Id$
package Radius::DiaClient;
use Radius::Configurable;
use Radius::TLSConfig;
use Radius::DiaUtil;
use Radius::DiaDict;
use Radius::DiaPeer;
use Radius::Diameter;
use strict;
use warnings;

our @ISA = qw(Radius::Configurable Radius::Diameter);

%Radius::DiaClient::ConfigKeywords =
('Host' =>
 ['string', 'Name or IP address of the Diameter peer. IPV4 and IPV6 addresses are supported', 0],

 'SCTPPeer' =>
 ['stringarray', 'With this parameter, you can specify any number of names or IP addresses of the Diameter SCTP peers. When defined, SCTPPeer is used instead of Host. IPV4 and IPV6 addresses are supported', 0],

 'Port' =>
 ['string', 'The port name or number of the Diameter peer.', 0],

 'Protocol' =>
 ['string', 'This optional parameter specifies which Stream protocol will be used to carry Diameter.', 1],

 'OriginHost' =>
 ['string', 'This parameter specifies the value of Origin-Host attribute. This is the name this Diameter client will use to identify itself to the Diameter peers. It is sent to the peer in the Diameter CER and other messages. It is not optional an must be specified. Diameter peers may use Origin-Host to determine whether they have connected to the correct peer, so it may be critical that it be configured correctly.', 1],

 'OriginRealm' =>
 ['string', 'This parameter specifies the Origin-Realm that is used in Diameter messages. It is not optional an must be specified. Diameter peers may use Origin-Realm to determine whether they have connected to the correct peer, so it may be critical that it be configured correctly.', 1],

 'DestinationHost' =>
 ['string', 'This parameters specifies the default value of Destination-Host attribute. THe use of this attribute depends on the Diameter client module.', 1],

 'DestinationRealm' =>
 ['string', 'This parameters specifies the default value of Destination-Realm attribute. The use of this attribute depends on the Diameter client module.', 1],

 'UseTLS' =>
 ['flag', 'This optional parameter forces the use of TLS for authentication and encryption of the Diameter connection. Requires Net::SSLeay Perl module from CPAN. When this parameter is enabled, the other TLS_* parameters become available for use. Defaults to disabled.', 1],

 'NoreplyTimeout' =>
 ['integer', 'If no reply is received to a proxied request within this number of seconds, the NoReplyHook will be called for this request. Defaults to 5 seconds.', 1],

 'NoReplyHook' =>
 ['hook', 'Perl function that will be called if no reply is received from any Diameter server. ', 2],

 @Radius::TLSConfig::clientkeywords,
 );

# RCS version number of this module
$Radius::DiaClient::VERSION = '$Revision$';

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    if ($self->{TLS_Protocols} || $self->{UseTLS})
    {
	if (!eval{require Radius::StreamTLS;})
	{
	    $self->log($main::LOG_ERR, "DiaClient has UseTLS, but could not load required modules: $@");
	}
	else
	{
	    Radius::StreamTLS::init($self);
	}
    }

    # Helps using the same config for multiple instances
    $self->{OriginHost}  = Radius::Util::format_special($self->{OriginHost});
    $self->{OriginRealm} = Radius::Util::format_special($self->{OriginRealm});
    $self->{DestinationHost}  = Radius::Util::format_special($self->{DestinationHost});
    $self->{DestinationRealm} = Radius::Util::format_special($self->{DestinationRealm});

    # Resolve the application names in SupportedAuth- and
    # SupportedVendorAuth and -AcctApplicationIds to numeric
    # values. Load any dictionaries the applications need. Then
    # resolve the supported vendors and vendor parts in supported
    # vendor apps.
    Radius::DiaUtil::resolve_application_ids($self);
    Radius::DiaUtil::load_dictionaries($self);
    Radius::DiaUtil::resolve_vendor_ids($self);

    $self->{DiaPeer} = Radius::DiaPeer->new
	(IConn => $self,
	 RecvMessageCallback => sub {$self->client_recv_callback(@_)},
#	 ErrorCallback => \&client_error_callback,
#	 TransportUpCallback => \&client_connection_up,
	 Dictionary => $self->{Dictionary},
	 OriginHost => $self->{OriginHost},
	 OriginRealm => $self->{OriginRealm},
	 Trace => $self->{Trace},
	 TLS_Protocols => $self->{TLS_Protocols},
	 UseTLS => $self->{UseTLS},
	 SupportedVendorIds        => $self->{Ids}{SupportedVendorIds},
	 AuthApplicationIds        => $self->{Ids}{AuthApplicationIds},
	 AcctApplicationIds        => $self->{Ids}{AcctApplicationIds},
	 VendorAuthApplicationIds  => $self->{Ids}{VendorAuthApplicationIds},
	 VendorAcctApplicationIds  => $self->{Ids}{VendorAcctApplicationIds},
	 InbandSecurityIds      => [($self->{TLS_Protocols} || $self->{UseTLS} ?
				     $Radius::DiaAttrList::INBAND_SECURITY_ID_TLS :
				     $Radius::DiaAttrList::INBAND_SECURITY_ID_NO_INBAND_SECURITY  )],
	 );
    $self->{DiaPeer}->activate();

    Radius::Select::add_timeout(
	time(),
	sub {
	    $self->{DiaPeer}->connect();
	});

    return $self;
}

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Port} = 3868;
    $self->{MaxBufferSize} = 100000;
    $self->{Protocol} = 'tcp';
    $self->{NoreplyTimeout} = 5;
    $self->{SupportedVendorIds} = "$Radius::DiaAttrList::VCODE_BASE";
    $self->{AuthApplicationIds} = "$Radius::DiaMsg::APPID_BASE, $Radius::DiaMsg::APPID_NASREQ";
    $self->{AcctApplicationIds} = "$Radius::DiaMsg::APPID_BASE, $Radius::DiaMsg::APPID_BASE_ACCOUNTING";
    $self->{InbandSecurityIds}  = [$Radius::DiaAttrList::INBAND_SECURITY_ID_TLS];

    return;
}

#####################################################################
sub client_recv_callback
{
    my ($self, $peer, $msg) = @_;

    # Support for simple clients with only one pending request and simple main loop
    if (defined $self->{waiting_for_eeid} && ($msg->eeid() == $self->{waiting_for_eeid}))
    {
	# This is the one we were waiting for
	$self->{found_reply} = $msg;
	delete $self->{waiting_for_eeid};
	$Radius::Select::exit_simple_main_loop = 1;
    }
    else
    {
	# Support for asynchronous clients, multiple pending requests
	my $eeid = $msg->eeid();
	my $ref = $self->{pendingRequests}{$eeid};
	if (!defined $ref)
	{
	    $self->log($main::LOG_WARNING, "Unknown reply received in DiaClient for request $eeid from $peer->{PeerOriginHost}", $msg->p_log());
	}
	else
	{
	    $self->log($main::LOG_DEBUG, "Received reply in DiaClient for req $eeid from $peer->{PeerOriginHost}", $msg->p_log());

	    # Cross it off our pending list
	    delete $self->{pendingRequests}{$eeid};

	    # sp is the packet we forwarded to the remote diameter
	    # user_data was suplied to send_request
	    my ($sp, $user_data) = @$ref;

	    # Cross it of our timeout list
	    Radius::Select::remove_timeout($sp->{noreplyTimeoutHandle})
		|| $self->log($main::LOG_ERR, "Timeout $sp->{noreplyTimeoutHandle} was not in the timeout list", $msg->p_log());

	    $self->handleReply($peer, $msg, $sp, $user_data);
	}
    }

    return;
}

#####################################################################
# Called by DiaPeer when a message is recived but not handled by superclass
sub handleReply
{
    my ($self, $peer, $msg, $sp, $user_data) = @_;
    return;
}

#####################################################################
# Handle the disconnection of the other end.
sub stream_disconnected
{
    my ($self) = @_;

    $self->SUPER::stream_disconnected();
    $self->{DiaPeer}->event('I-Peer-Disc');
    return;
}

#####################################################################
sub stream_client_connected
{
    my ($self) = @_;

    $self->SUPER::stream_client_connected();
    $self->{DiaPeer}->connect();
    return;
}

#####################################################################
# Called by DiaPeer when the connection is to be connected
sub connect        ## no critic (Subroutines::ProhibitBuiltinHomonyms)
{
    my ($self) = @_;

    $self->stream_connect();
    return $self->{socket};
}

#####################################################################
# Called by DiaPeer when the connection is to be closed
sub close          ## no critic (Subroutines::ProhibitBuiltinHomonyms)
{
    my ($self) = @_;

    return $self->stream_disconnected();
}

#####################################################################
sub hostipaddress
{
    my ($self) = @_;

    my ($port, $addr) = Radius::Util::unpack_sockaddr_in(getsockname($self->{socket}));
    return $addr;
}

#####################################################################
# Called by DiaPeer when an assembled message is to be sent
sub send          ## no critic (Subroutines::ProhibitBuiltinHomonyms)
{
    my ($self, $msg) = @_;

    $self->write($msg);
    return;
}

#####################################################################
# Called when a complete request has been received
# Parse and process it
# Version has been checked
sub recv_diameter
{
    my ($self, $rec) = @_;

    # If we have already got our peer, use it.
    return $self->{DiaPeer}->i_recv_callback($self, $rec);
}

#####################################################################
# A serious stream error has occurred, log it and disconnect
sub stream_error
{
    my ($self, $msg) = @_;

    $self->SUPER::stream_error($msg);
    $self->{DiaPeer}->i_error_callback($self, $msg) if $self->{DiaPeer};
    return;
}

#####################################################################
# handle_noreply_timeout
# This is called from within Select::process_timeouts for each packet
# we have forwarded but not received a reply within the timeout period
sub handle_noreply_timeout
{
    my ($handle, $self, $msg, $user_data) = @_;

    my $eeid = $msg->eeid();
    $self->log($main::LOG_INFO, "DiaClient: No reply from Diameter server for message $eeid", $msg->p_log());
    delete $self->{pendingRequests}{$eeid};
    $self->runHook('NoReplyHook', $msg, \$msg, $user_data);

    return;
}

#####################################################################
# Send a request and set up no reply and reply callbacks
# Returns the EEID
sub send_request
{
    my ($self, $msg, $user_data) = @_;

    $self->{DiaPeer}->send_request($msg);

    my $eeid = $msg->eeid();

    $self->{pendingRequests}{$eeid} = [$msg, $user_data];
    # Arrange for no reply timeout
    # We remember the timeout handle so we can remove
    # it if we get a reply
    # Arrange for noreply retransmission timeout
    # We remember the timeout handle so we can remove
    # it if we get a reply
    $msg->{noreplyTimeoutHandle} =
	Radius::Select::add_timeout
	(time + $self->{NoreplyTimeout},
	 \&handle_noreply_timeout,
	 $self, $msg, $user_data);

    return $eeid;
}

#####################################################################
# Simple client sending interface
sub sendAndWait
{
    my ($self, $msg) = @_;

    $self->send_request($msg);
    # Loop will be terminated when client_recv_callback
    # sees we have received a reply
    $self->{waiting_for_eeid} = $msg->eeid();

    # Add a timeout so that we don't wait a reply indefinitely
    my $timeout_handle = Radius::Select::add_timeout(time + $self->{NoreplyTimeout}, \&Radius::Select::exit_simple_main_loop);
    Radius::Select::simple_main_loop();
    Radius::Select::remove_timeout($timeout_handle);

    return $self->{found_reply};
}

1;
