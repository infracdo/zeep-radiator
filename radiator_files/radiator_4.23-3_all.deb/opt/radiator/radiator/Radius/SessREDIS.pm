# SessREDIS.pm
#
# Implement the session database in Redis by using GossipRedis
#
# Author: Tuure Vartiainen (vartiait@archred.com)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::SessREDIS;
@ISA = qw(Radius::SessGeneric);
use Radius::SessGeneric;
use Radius::Client;
use Radius::Gossip;
use Radius::Util;
use Radius::Context;
use strict;
use warnings;

# Gossip
# SessionKey (HASH) -> (key1 => value1, ...)
# SessionEndedKey (SET) (session_key, ...)
# NasKey (SET) -> (session_key, ...)
# UserKey (SET) -> (session_key, ...)
#
# add($name, $nas_id, $nas_port, $p) ->
# update($name, $nas_id, $nas_port, $p) ->
# delete($name, $nas_id, $nas_port, $p, $session_id, $framed_ip_address) ->
# clearNas($nas_id, $p) -> delete all sessions on $nas_id
# clearNasSession($nas_id, $session, $p) -> delete $session from $nas_id
# sessionOnNAS($nas_id, $p)) -> (1, @session_ids) from $nas_id
# exceeded($max, $name, $p) -> boolean(does $name has > $max sessions)?

%Radius::SessREDIS::ConfigKeywords =
(
 'SessionKey' =>
 ['string', 'Redis key to store Redis Hash for sessions.', 1],

 'SessionEndedKey' =>
 ['string', 'Optional Redis key to store Redis Set of ended sessions. If defined, session information for a session will not be deleted when ending the session, but an id of ended session will be added to Redis Set defined by this key.', 1],

 'SessionUpdateKey' =>
 ['string', 'Optional Redis key to store Redis Hash of session updates. If defined, session update for a session will not be stored to SessionKey, but to this separate SessionUpdateKey.', 1],

 'NasKey' =>
 ['string', 'Redis key to store Redis Set of sessions on NAS.', 1],

 'UserKey' =>
 ['string', 'Redis key to store Redis Set of sessions for a user.', 1],

 'AddSessionParamDef' =>
 ['stringarray', 'Allows you to specify Redis Hash attributes to store session information. The general format is: AddSessionParamDef redishashattributename, radiusattributename[, defaultvalue[, type[, formatted]]]', 1],

 'UpdateSessionParamDef' =>
 ['stringarray', 'Allows you to specify Redis Hash attributes to update session information. The general format is: UpdateSessionParamDef redishashattributename, radiusattributename[, defaultvalue[, formatted[, operator[, attribtype]]]]. Supported values for operator are add, sub, sub_to_zero and supported values for attribtype are postpaid, prepaid.', 1],

 'DeleteSessionParamDef' =>
 ['stringarray', 'Allows you to specify Redis Hash attributes to update session information when ending a session. The general format is: DeleteSessionParamDef redishashattributename, radiusattributename[, defaultvalue[, formatted[, operator[, attribtype]]]]. Supported values for operator are add, sub, sub_to_zero and supported values for attribtype are postpaid, prepaid.', 1],

 'ContextTimeout' =>
 ['integer', 'Specifies the number of seconds to store session attributes in context.', 1],
);

# RCS version number of this module
$Radius::SessREDIS::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{SessionKey} = "Radiator:SessREDIS:Session:%1:%2:%3:%0";
    $self->{NasKey} = "Radiator:SessREDIS:NAS:%0";
    $self->{UserKey} = "Radiator:SessREDIS:User:%0";
    $self->{ContextTimeout} = 2;

    $self->{AddSessionParamDef} = [];
    $self->{UpdateSessionParamDef} = [];
    $self->{DeleteSessionParamDef} = [];

    $self->{redis};
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    unless ($self->{AddSessionParamDef})
    {
	$self->log($main::LOG_WARNING, "Configuration check: No AddSessionParamDef(s) defined for SessionDatabase REDIS '$self->{Identifier}' in '$main::config_file'");
    }

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    unless (defined $Radius::Gossip::handle &&
	    ref($Radius::Gossip::handle) eq 'Radius::GossipRedis')
    {
	$self->log($main::LOG_WARNING, "SessionDatabase REDIS requires GossipRedis, but no GossipRedis defined in '$main::config_file'");
    }
    else
    {
	$self->{redis} = \$Radius::Gossip::handle;
    }

    $self->{process_values_on_update} = [];
    $self->{process_values_on_delete} = [];
    foreach my $attrdef_set (@{$self->{UpdateSessionParamDef}})
    {
	my ($redisname, $attrib, $default_value, $formatting, $operator, $attribtype) = split (/,\s*/, $attrdef_set);
	if ($operator)
	{
	    push(@{$self->{process_values_on_update}}, $redisname);
	}
    }
    foreach my $attrdef_set (@{$self->{DeleteSessionParamDef}})
    {
	my ($redisname, $attrib, $default_value, $formatting, $operator, $attribtype) = split (/,\s*/, $attrdef_set);
	if ($operator)
	{
	    push(@{$self->{process_values_on_delete}}, $redisname);
	}
    }
}

sub add
{
    my ($self, $name, $nas_id, $nas_port, $p) = @_;
    my $session_id = $p->get_attr($self->{SessionIdentifier}) || "";
    $nas_id .= '';
    $nas_port += 0;

    return unless $self->{SessionKey};

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Adding a session for $name, $nas_id, $nas_port", $p);

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not add a session, no GossipRedis defined", $p);
	return;
    }

    my %redis_hash;

    $redis_hash{_nas_id} = $nas_id;
    $redis_hash{_nas_port} = $nas_port;
    $redis_hash{_session_id} = $session_id;
    $redis_hash{_framed_ip} = $p->get_attr("Framed-IP-Address") || $p->get_attr("Framed-IPv6-Address") || "";
    $redis_hash{_username} = $name;
    $redis_hash{_timestamp} = time;
    $redis_hash{_trace_id} = $p->{trace_id} || "";

    foreach my $attrdef_set (@{$self->{AddSessionParamDef}})
    {
	my ($redisname, $attrib, $default_value, $type, $formatting) = split(/,\s*/, $attrdef_set);
	$type = lc($type) if $type;
	$formatting = lc($formatting) if $formatting;
	$default_value = "" unless defined $default_value;

	if ($formatting && $formatting eq 'formatted')
	{
	    $redis_hash{$redisname} = Radius::Util::format_special($attrib, $p, $self, $name, $nas_id, $nas_port, $session_id) || $default_value;
	}
	else
	{
	    if ($type && $type eq 'reply')
	    {
		$redis_hash{$redisname} = $p->{rp}->get_attr($attrib) || $default_value;
	    }
	    else
	    {
		$redis_hash{$redisname} = $p->get_attr($attrib) || $default_value;
	    }
	}
    }

    my $redis_session_key = Radius::Util::format_special($self->{SessionKey}, $p, $self, $name, $nas_id, $nas_port, $session_id);
    my $redis_nas_session_key = $self->{NasKey} ? Radius::Util::format_special($self->{NasKey}, $p, $self, $nas_id) : undef;
    my $redis_user_session_key = $self->{UserKey} ? Radius::Util::format_special($self->{UserKey}, $p, $self, $name) : undef;

    ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->hmset($redis_session_key, %redis_hash, $_[0]->get_redis_callback(sub {})); });

    if ($redis_nas_session_key)
    {
	my $session_info = "($redis_session_key);($session_id)";
	$session_info .= ";($redis_user_session_key)"
	    if $redis_user_session_key;
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->sadd($redis_nas_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
    }

    if ($redis_user_session_key)
    {
	my $session_info = "($redis_session_key);($session_id)";
	$session_info .= ";($redis_nas_session_key)"
	    if $redis_nas_session_key;
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->sadd($redis_user_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
    }
}

sub update
{
    my ($self, $name, $nas_id, $nas_port, $p) = @_;
    my $session_id = $p->get_attr($self->{SessionIdentifier}) || "";
    $nas_id .= '';
    $nas_port += 0;

    return unless ($self->{SessionKey} || $self->{SessionUpdateKey});

    # do we want to support old behaviour?
    return $self->add($name, $nas_id, $nas_port, $p) unless @{$self->{UpdateSessionParamDef}};

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Updating a session for $name, $nas_id, $nas_port", $p);

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not update a session, no GossipRedis defined", $p);
	return;
    }

    if (@{$self->{UpdateSessionParamDef}})
    {
	# TODO: FIXME: When using SessionUpdateKey, NasKey and UserKey do contain (only) SessionKey and in delete() only SessionKey is used!
	my $redis_session_key = Radius::Util::format_special($self->{SessionUpdateKey} || $self->{SessionKey}, $p, $self, $name, $nas_id, $nas_port, $session_id);

	my %existing_values;
	if (@{$self->{process_values_on_update}})
	{
	    my $redis_session = ${$self->{redis}}->exec_call(
		sub { $_[0]->{redis}->hmget($redis_session_key, @{$self->{process_values_on_update}}); }
		);
	    my $i;
	    %existing_values = map {$_ => ${$redis_session}[$i++];} @{$self->{process_values_on_update}};
	}

	my (%redis_hash, $skip_next);

	$redis_hash{_nas_id} = $nas_id;
	$redis_hash{_nas_port} = $nas_port;
	$redis_hash{_session_id} = $session_id;
	$redis_hash{_framed_ip} = $p->get_attr("Framed-IP-Address") || $p->get_attr("Framed-IPv6-Address") || "";
	$redis_hash{_username} = $name;
	$redis_hash{_timestamp} = time;
	$redis_hash{_trace_id} = $p->{trace_id} || "";

	my $i = 0;
	foreach my $attrdef_set (@{$self->{UpdateSessionParamDef}})
	{
	    if ($skip_next)
	    {
		$skip_next = 0;
		next;
	    }
	    my ($redisname, $attrib, $default_value, $formatting, $operator, $attribtype) = split (/,\s*/, $attrdef_set);
	    $formatting = lc($formatting) if $formatting;
	    $default_value = "" unless defined $default_value;

	    if ($formatting && $formatting eq 'formatted')
	    {
		$redis_hash{$redisname} = Radius::Util::format_special($attrib, $p, $self, $name, $nas_id, $nas_port, $session_id) || $default_value;
	    }
	    else
	    {
		$redis_hash{$redisname} = $p->get_attr($attrib) || $default_value;
	    }
	    if ($operator)
	    {
		$operator = lc($operator);
		$redis_hash{$redisname} = 0 unless ($redis_hash{$redisname} && $redis_hash{$redisname} =~ /^\d+$/);
		$existing_values{$redisname} = 0 unless ($existing_values{$redisname} && $existing_values{$redisname} =~ /^\d+$/);
		if ($operator eq 'add')
		{
		    $redis_hash{$redisname} = int($existing_values{$redisname}) + int($redis_hash{$redisname});
		}
		elsif ($operator eq 'sub')
		{
		    $redis_hash{$redisname} = int($existing_values{$redisname}) - int($redis_hash{$redisname});
		}
		elsif ($operator eq 'sub_to_zero')
		{
		    $redis_hash{$redisname} = int($existing_values{$redisname}) - int($redis_hash{$redisname});
		    # if value goes below zero, and next attrib is also prepaid/postpaid, decrease rest from it
		    if ($redis_hash{$redisname} < 0)
		    {
			my $remaining = $redis_hash{$redisname};
			$redis_hash{$redisname} = 0;
			if ($attribtype && $i < $#{$self->{UpdateSessionParamDef}})
			{
			    # lookup next attr def for remaining
			    my @next = split (/,\s*/, ${$self->{UpdateSessionParamDef}}[$i + 1]);
			    if (@next == 6)
			    {
				if (($next[1] && $next[1] eq $attrib) &&
				    ($next[5] && $next[5] ne $attribtype))
				{
				    $existing_values{$next[0]} = 0 unless $existing_values{$next[0]} =~ /^\d+$/;
				    $redis_hash{$next[0]} = int($existing_values{$next[0]}) - $remaining;
				    $redis_hash{$next[0]} = 0 if ($next[4] && $next[4] eq 'sub_to_zero' && $redis_hash{$next[0]} < 0);
				    $skip_next = 1;
				}
			    }
			}
		    }
		}
	    }
	    $i++;
	}

	if ($self->{ContextTimeout})
	{
	    my $key = "sessredis:$redis_session_key";
	    my $context = Radius::Context::get($key, $self->{ContextTimeout});
	    $context->{session_attrs} = \%redis_hash;
	}
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->hmset($redis_session_key, %redis_hash, $_[0]->get_redis_callback(sub {})); });
    }
}

sub delete
{
    my ($self, $name, $nas_id, $nas_port, $p, $session_id, $framed_ip_address, $backend_session_id) = @_;
    $session_id = "" unless $session_id;
    $nas_id .= '';
    $nas_port += 0;

    return unless $self->{SessionKey};

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Deleting a session for $name, $nas_id, $nas_port", $p);

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not delete a session, no GossipRedis defined", $p);
	return;
    }

    my ($redis_session_key, $redis_update_session_key, $redis_nas_session_key, $redis_user_session_key);

    if ($backend_session_id)
    {
	$redis_session_key = $backend_session_id;

	# get session_data if nas_id, nas_port or session_id are missing
	# so that redis_nas_session_key can be constructed.
	my $session_data;
	unless ($nas_id)
	{
	    unless ($session_data)
	    {
		$session_data = $self->getSessionData($name, $nas_id, $nas_port, $p, $session_id, $backend_session_id);
	    }
	    if ($session_data)
	    {
		$nas_id = $session_data->{_nas_id};
	    }
	}
	unless ($nas_port)
	{
	    unless ($session_data)
	    {
		$session_data = $self->getSessionData($name, $nas_id, $nas_port, $p, $session_id, $backend_session_id);
	    }
	    if ($session_data)
	    {
		$nas_port = $session_data->{_nas_port};
	    }
	}
	unless ($session_id)
	{
	    unless ($session_data)
	    {
		$session_data = $self->getSessionData($name, $nas_id, $nas_port, $p, $session_id, $backend_session_id);
	    }
	    if ($session_data)
	    {
		$nas_port = $session_data->{_session_id};
	    }
	}
    }
    else
    {
	$redis_session_key = Radius::Util::format_special($self->{SessionKey}, $p, $self, $name, $nas_id, $nas_port, $session_id);
    }

    if ($self->{SessionUpdateKey})
    {
	$redis_update_session_key = Radius::Util::format_special($self->{SessionUpdateKey}, $p, $self, $name, $nas_id, $nas_port, $session_id);
    }

    $redis_nas_session_key = Radius::Util::format_special($self->{NasKey}, $p, $self, $nas_id)
	if $self->{NasKey};
    $redis_user_session_key = Radius::Util::format_special($self->{UserKey}, $p, $self, $name)
	if $self->{UserKey};

    if ($self->{SessionEndedKey})
    {
	# update session info and mark it as ended
	my (@paramdef, $process_values);
	if (@{$self->{DeleteSessionParamDef}})
	{
	    @paramdef = @{$self->{DeleteSessionParamDef}};
	    $process_values = $self->{process_values_on_delete};
	}
	elsif (@{$self->{UpdateSessionParamDef}})
	{
	    @paramdef = @{$self->{UpdateSessionParamDef}};
	    $process_values = $self->{process_values_on_update};
	}
	if (@paramdef)
	{
	    my %existing_values;
	    if (@{$process_values})
	    {
		my $redis_session = ${$self->{redis}}->exec_call(
		    sub { $_[0]->{redis}->hmget($redis_session_key, @{$process_values}); }
		    );
		my $i;
		%existing_values = map {$_ => ${$redis_session}[$i++];} @{$process_values};
	    }

	    my (%redis_hash, $skip_next);

	    $redis_hash{_nas_id} = $nas_id;
	    $redis_hash{_nas_port} = $nas_port;
	    $redis_hash{_session_id} = $session_id;
	    $redis_hash{_framed_ip} = $p->get_attr("Framed-IP-Address") || $p->get_attr("Framed-IPv6-Address") || "";
	    $redis_hash{_username} = $name;
	    $redis_hash{_timestamp} = time;
	    $redis_hash{_trace_id} = $p->{trace_id} || "";

	    my $i = 0;
	    foreach my $attrdef_set (@paramdef)
	    {
		if ($skip_next)
		{
		    $skip_next = 0;
		    next;
		}
		my ($redisname, $attrib, $default_value, $formatting, $operator, $attribtype) = split (/,\s*/, $attrdef_set);
		$formatting = lc($formatting) if $formatting;
		$default_value = "" unless defined $default_value;

		if ($formatting && $formatting eq 'formatted')
		{
		    $redis_hash{$redisname} = Radius::Util::format_special($attrib, $p, $self, $name, $nas_id, $nas_port, $session_id) || $default_value;
		}
		else
		{
		    $redis_hash{$redisname} = $p->get_attr($attrib) || $default_value;
		}
		if ($operator)
		{
		    $operator = lc($operator);
		    $redis_hash{$redisname} = 0 unless ($redis_hash{$redisname} && $redis_hash{$redisname} =~ /^\d+$/);
		    $existing_values{$redisname} = 0 unless ($existing_values{$redisname} && $existing_values{$redisname} =~ /^\d+$/);
		    if ($operator eq 'add')
		    {
			$redis_hash{$redisname} = int($existing_values{$redisname}) + int($redis_hash{$redisname});
		    }
		    elsif ($operator eq 'sub')
		    {
			$redis_hash{$redisname} = int($existing_values{$redisname}) - int($redis_hash{$redisname});
		    }
		    elsif ($operator eq 'sub_to_zero')
		    {
			$redis_hash{$redisname} = int($existing_values{$redisname}) - int($redis_hash{$redisname});
			if ($redis_hash{$redisname} < 0)
			{
			    my $remaining = $redis_hash{$redisname};
			    $redis_hash{$redisname} = 0;
			    if ($attribtype && $i < $#paramdef)
			    {
				# lookup next attr def for remaining
				my @next = split (/,\s*/, $paramdef[$i + 1]);
				if (@next == 6)
				{
				    if (($next[1] && $next[1] eq $attrib) &&
					($next[5] && $next[5] ne $attribtype))
				    {
					$existing_values{$next[0]} = 0 unless $existing_values{$next[0]} =~ /^\d+$/;
					$redis_hash{$next[0]} = int($existing_values{$next[0]}) - $remaining;
					$redis_hash{$next[0]} = 0 if ($next[4] && $next[4] eq 'sub_to_zero' && $redis_hash{$next[0]} < 0);
					$skip_next = 1;
				    }
				}
			    }
			}
		    }
		}
		$i++;
	    }

	    ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->hmset($redis_session_key, %redis_hash, $_[0]->get_redis_callback(sub {})); });
	}

	# mark session ended
	my $redis_ended_session_key = Radius::Util::format_special($self->{SessionEndedKey}, $p, $self, $nas_id);
	my $session_info = "($redis_session_key);($session_id)";
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->sadd($redis_ended_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
    }
    else
    {
	# delete session information
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->del($redis_session_key, $_[0]->get_redis_callback(sub {})); });
	if ($redis_update_session_key)
	{
	    ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->del($redis_update_session_key, $_[0]->get_redis_callback(sub {})); });
	}
    }

    # remove session from nas/user sets
    if ($redis_user_session_key)
    {
	my $session_info = "($redis_session_key);($session_id)";
	$session_info .= ";($redis_nas_session_key)" if $redis_nas_session_key;
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->srem($redis_user_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
	# Try also to remove an entry without a session id
	$session_info = "($redis_session_key);()";
	$session_info .= ";($redis_nas_session_key)" if $redis_nas_session_key;
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->srem($redis_user_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
    }

    if ($redis_nas_session_key)
    {
	my $session_info = "($redis_session_key);($session_id)";
	$session_info .= ";($redis_user_session_key)" if $redis_user_session_key;
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->srem($redis_nas_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
	# Try also to remove an entry without a session id
	$session_info = "($redis_session_key);()";
	$session_info .= ";($redis_user_session_key)" if $redis_user_session_key;
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->srem($redis_nas_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
    }
}

sub clearNas
{
    my ($self, $nas_id, $p) = @_;
    $nas_id .= '';

    return unless $self->{NasKey};

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Deleting all sessions for '$nas_id'", $p);

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not delete sessions, no GossipRedis defined", $p);
	return;
    }

    my $redis_nas_session_key = Radius::Util::format_special($self->{NasKey}, $p, $self, $nas_id);
    my $redis_sessions = ${$self->{redis}}->exec_call(
	sub { $_[0]->{redis}->smembers($redis_nas_session_key); }
	);

    foreach my $redis_session (@{$redis_sessions})
    {
	# (Radiator:SessREDIS:Session:203.63.154.1:1:00001234:mikem);(00001234);(Radiator:SessREDIS:User:mikem)
	my ($redis_session_key, $session_id, $n, $redis_user_session_key) = $redis_session =~ /^\(([^)]*)\);\(([^)]*)\)(;\(([^)]*)\))?$/;
	if ($self->{SessionEndedKey})
	{
	    # mark session ended
	    my $redis_ended_session_key = Radius::Util::format_special($self->{SessionEndedKey}, $p, $self, $nas_id);
	    my $session_info = "($redis_session_key);($session_id)";
	    ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->sadd($redis_ended_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
	}
	else
	{
	    # delete session information
	    ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->del($redis_session_key, $_[0]->get_redis_callback(sub {})); });
	}

	# delete session from per user set
	my $session_info = "($redis_session_key);($session_id);($redis_nas_session_key)";
	${$self->{redis}}->exec_call(sub { $_[0]->{redis}->srem($redis_user_session_key, $session_info, $_[0]->get_redis_callback(sub {})); });
    }

    # delete per nas set
    ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->del($redis_nas_session_key, $_[0]->get_redis_callback(sub {})); });
}

sub clearNasSession
{
    my ($self, $nas_id, $session_id, $p) = @_;
    $session_id = "" unless $session_id;
    $nas_id .= '';

    return unless $self->{NasKey};

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: clearNasSession() not implemented", $p);

    return;
}

sub exceeded
{
    my ($self, $max, $name, $p) = @_;

    return 0 unless $self->{UserKey};

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not get session count, no GossipRedis defined", $p);
	return 0;
    }

    my $redis_user_session_key = Radius::Util::format_special($self->{UserKey}, $p, $self, $name);
    my $count = ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->scard($redis_user_session_key); });

    unless (defined $count && $count =~ /^\d+$/)
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Redis returned invalid number ('$count') of sessions for '$name'", $p);
	return 0;
    }

    if ($count >= $max)
    {
	my ($redis_sessions, @sessions);
	$redis_sessions = ${$self->{redis}}->exec_call(
	    sub { $_[0]->{redis}->smembers($redis_user_session_key); }
	    );

	foreach my $redis_session (@{$redis_sessions})
	{
	    # (Radiator:SessREDIS:Session:203.63.154.1:1:00001234:mikem);(00001234);(Radiator:SessREDIS:NAS:203.63.154.1)
	    my ($redis_session_key, $session_id, $n, $redis_nas_session_key) = $redis_session =~ /^\(([^)]*)\);\(([^)]*)\)(;\(([^)]*)\))?$/;
	    my ($client, $nas_id, $nas_port, $username, $framed_ip_address);
	    my $session = ${$self->{redis}}->exec_call(
		sub { $_[0]->{redis}->hgetall($redis_session_key); }
	    );
	    my $session_hash = $session ? {@{$session}} : undef;
	    if ($session_hash)
	    {
		$nas_id = $session_hash->{_nas_id};
		$nas_port = $session_hash->{_nas_port};
		$session_id = $session_hash->{_session_id};
		$framed_ip_address = $session_hash->{_framed_ip};
		$username = $session_hash->{_username};
	    }
	    $username ||= $name;
	    if ($client = Radius::Client::findAddress(Radius::Util::inet_pton($nas_id)))
	    {
		if (!$client->isOnline($username, $nas_id, $nas_port, $session_id, $framed_ip_address))
		{
		    $self->log($main::LOG_INFO, "SessREDIS $self->{Identifier}: Session for '$name' at $nas_id, $nas_port has gone away", $p);
		    $self->delete($name, $nas_id, $nas_port, $p, $session_id, $framed_ip_address);
		    $count--;
		    last if $count < $max;
		}
	    }
	    else
	    {
		$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Could not find a Client for NAS $nas_id to double-check Simultaneous-Use. Perhaps you do not have a reverse DNS for that NAS?", $p);
	    }
	}
    }

    return $count >= $max;
}

# returns an array of session ids on nas $nas_id
sub sessionsOnNAS
{
    my ($self, $nas_id, $p, $get_backend_session_id) = @_;

    return unless $self->{NasKey};
    $nas_id .= '';

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Counting sessions for NAS '$nas_id'", $p);

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not count sessions for NAS, no GossipRedis defined", $p);
	return;
    }

    my $redis_nas_session_key = Radius::Util::format_special($self->{NasKey}, $p, $self, $nas_id);
    my $redis_sessions = ${$self->{redis}}->exec_call(
	sub { $_[0]->{redis}->smembers($redis_nas_session_key); }
	);

    my @sessions;
    foreach my $redis_session (@{$redis_sessions})
    {
	# (Radiator:SessREDIS:Session:203.63.154.1:1:00001234:mikem);(00001234);(Radiator:SessREDIS:User:mikem)
	my ($redis_session_key, $session_id, $n, $redis_user_session_key) = $redis_session =~ /^\(([^)]*)\);\(([^)]*)\)(;\(([^)]*)\))?$/;
	$session_id = $redis_session_key if $get_backend_session_id;
	push(@sessions, $session_id);
    }

    return (1, @sessions);
}

# returns an array of session ids for user $name
sub sessionsForUser
{
    my ($self, $name, $nas_id, $p, $get_backend_session_id) = @_;

    return unless $self->{UserKey};
    $nas_id .= '';

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Looking up all session IDs for user '$name'", $p);

    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not get sessions for user '$name', no GossipRedis defined", $p);
	return;
    }

    my $redis_user_session_key = Radius::Util::format_special($self->{UserKey}, $p, $self, $name);
    my $redis_sessions = ${$self->{redis}}->exec_call(sub { $_[0]->{redis}->smembers($redis_user_session_key); });

    my @sessions;
    foreach my $redis_session (@{$redis_sessions})
    {
	# (Radiator:SessREDIS:Session:203.63.154.1:1:00001234:mikem);(00001234);(Radiator:SessREDIS:User:mikem)
	my ($redis_session_key, $session_id, $n, $redis_nas_session_key) = $redis_session =~ /^\(([^)]*)\);\(([^)]*)\)(;\(([^)]*)\))?$/;
	# return actual redis session key when asked explicitly
	$session_id = $redis_session_key if $get_backend_session_id;
	if ($nas_id)
	{
	    $nas_id = quotemeta($nas_id);
	    push(@sessions, $session_id)
		if ($redis_nas_session_key && $redis_nas_session_key =~ /$nas_id/i);
	}
	else
	{
	    push(@sessions, $session_id);
	}
    }

    return (1, @sessions);
}

sub getSessionData
{
    my ($self, $name, $nas_id, $nas_port, $p, $session_id, $backend_session_id) = @_;

    if ($p)
    {
	$nas_id = $p->getNasId() unless $nas_id;
	$nas_port = $p->getAttrByNum($Radius::Radius::NAS_PORT) unless $nas_port;
	$session_id = $p->get_attr($self->{SessionIdentifier}) unless $session_id;
    }
    $nas_id .= '';
    $nas_port += 0;
    $session_id = "" unless $session_id;

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: Looking up session data for $name, $nas_id, $nas_port", $p);

    my $redis_session_key = $backend_session_id || Radius::Util::format_special($self->{SessionUpdateKey} || $self->{SessionKey}, $p, $self, $name, $nas_id, $nas_port, $session_id);
    my $context;
    if ($self->{ContextTimeout})
    {
	my $key = "sessredis:$redis_session_key";
	$context = Radius::Context::find($key);
    }
    if ($context)
    {
	return $context->{session_attrs};
    }
    else
    {
	unless (defined $self->{redis} && defined ${$self->{redis}})
	{
	    $self->log($main::LOG_WARNING, "SessREDIS $self->{Identifier}: Can not get session data, no GossipRedis defined", $p);
	    return;
	}

	my $redis_session = ${$self->{redis}}->exec_call(
	    sub { $_[0]->{redis}->hgetall($redis_session_key); }
	    );

	my $hash = $redis_session ? {@{$redis_session}} : undef;
	if ($hash && $self->{ContextTimeout})
	{
	    my $key = "sessredis:$redis_session_key";
	    $context = Radius::Context::get($key, $self->{ContextTimeout});
	    $context->{session_attrs} = $hash;
	}
	return $hash;
    }
    return;
}

sub mapSessionData
{
    my ($self, $caller, $name, $nas_id, $nas_port, $p, $session_id, $backend_session_id) = @_;

    $self->log($main::LOG_DEBUG, "SessREDIS $self->{Identifier}: MapSessionData for user '$name'", $p);

    my $session_data = $self->getSessionData($name, $nas_id, $nas_port, $p, $session_id, $backend_session_id);
    if ($session_data)
    {
	$caller->sessionReady($p, $session_data);
    }

    return;
}

1;
