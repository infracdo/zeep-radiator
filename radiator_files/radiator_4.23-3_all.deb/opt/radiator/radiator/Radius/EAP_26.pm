# EAP_26.pm
#
# Module for  handling Authentication via EAP type 26: MSCHAP-V2
# Hmmmm, Iana assigned 29 for MSCHAP-V2 and 
# 26 for MS-EAP-Authentication. What gives?
#
# See RFCs 2759 draft-kamath-pppext-eap-mschapv2-00.txt
# MS document: [MS-CHAP] https://msdn.microsoft.com/en-us/library/cc224612.aspx
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2001 Open System Consultants
# $Id$

package Radius::EAP_26;
use Radius::MSCHAP;
use strict;
use warnings;

# RCS version number of this module
$Radius::EAP_26::VERSION = '$Revision$';

# Definitions for MSCHAP Type
$Radius::EAP_26::MSCHAP_TYPE_CHALLENGE   = 1;
$Radius::EAP_26::MSCHAP_TYPE_RESPONSE    = 2;
$Radius::EAP_26::MSCHAP_TYPE_SUCCESS     = 3;
$Radius::EAP_26::MSCHAP_TYPE_FAILURE     = 4;
$Radius::EAP_26::MSCHAP_TYPE_CHANGE_PASS = 7;

# EAP-MSCHAP-V2 server states from [MS-CHAP]
$Radius::EAP_26::STATE::CHALLENGE_SENT       = 1;
$Radius::EAP_26::STATE::SUCCESS_REQUEST_SENT = 2;
$Radius::EAP_26::STATE::CHANGE_PASSWORD_SENT = 3;
$Radius::EAP_26::STATE::FAILURE_REQUEST_SENT = 4;
$Radius::EAP_26::STATE::SUCCESS              = 5;
$Radius::EAP_26::STATE::FAILED               = 6;
$Radius::EAP_26::STATE::OSC_CONVERT_PROXIED  = 20;  # Request was converted to RADIUS MSCHAP-V2 and then proxied

# Maps MSCHAP typesnumbers to names
%Radius::EAP_26::type2text =
(
 $Radius::EAP_26::MSCHAP_TYPE_CHALLENGE   => 'Challenge',
 $Radius::EAP_26::MSCHAP_TYPE_RESPONSE    => 'Response',
 $Radius::EAP_26::MSCHAP_TYPE_SUCCESS     => 'Success',
 $Radius::EAP_26::MSCHAP_TYPE_FAILURE     => 'Failure',
 $Radius::EAP_26::MSCHAP_TYPE_CHANGE_PASS => 'Change-Password',
);

# Maps EAP-MSCHAP-V2 server states to state names
%Radius::EAP_26::state2text =
(
 $Radius::EAP_26::STATE::CHALLENGE_SENT       => 'CHALLENGE_SENT',
 $Radius::EAP_26::STATE::SUCCESS_REQUEST_SENT => 'SUCCESS_REQUEST_SENT',
 $Radius::EAP_26::STATE::CHANGE_PASSWORD_SENT => 'CHANGE_PASSWORD_SENT',
 $Radius::EAP_26::STATE::FAILURE_REQUEST_SENT => 'FAILURE_REQUEST_SENT',
 $Radius::EAP_26::STATE::SUCCESS              => 'SUCCESS',
 $Radius::EAP_26::STATE::FAILED               => 'FAILED',
 $Radius::EAP_26::STATE::OSC_CONVERT_PROXIED  => 'OSC_CONVERT_PROXIED',
);

#####################################################################
# Called by EAP.pm when the caller wants to know the EAP type name this class supports
sub type_name
{
    my ($classname) = @_;

    return 'MSCHAP-V2';
}

#####################################################################
# request
# Called by EAP.pm when a rexquest is received for this protocol type
sub request
{
    my ($classname, $self, $context, $p, $data) = @_;

    $context->{eap_26_success} = 0;
    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'Unexpected EAP request');
}

#####################################################################
# Called by EAP.pm when an EAP Response/Identity is received
sub response_identity
{
    my ($classname, $self, $context, $p) = @_;

    if (length($context->{identity}) < 1)
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP MSCHAP-V2 failed: Identity too short', $p);
    }

    # Generate a MS-CHAP-V2 Challenge into $context->{mschapv2_challenge} as per RFC 2759
    # Remember the challenge for later
    $context->{mschapv2_challenge} = undef;
    unless($self->mschapv2_challenge($context, $p))
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP MSCHAP-V2 failed: Could not generate challenge', $p);
    }

    my $name = $main::hostname; # system name
    my $message = pack('C C n C a16 a*', 
		       $Radius::EAP_26::MSCHAP_TYPE_CHALLENGE,
		       $context->{next_id},    # MS-CHAPv2-ID
		       length($name) + 21, # MS-Length
		       16,     # value-sizelength
		       $context->{mschapv2_challenge},
		       $name);
    delete $context->{eap_26_multiauthby};
    delete $context->{ignoring_auth_bys};
    delete $context->{success_auth_by};
    $context->{eap_26_success} = 0;
    $context->{eap_26_state} = $Radius::EAP_26::STATE::CHALLENGE_SENT;
    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_MSCHAPV2, $message);
    return ($main::CHALLENGE, 'EAP MSCHAP-V2 Challenge');
}

#####################################################################
# Called by EAP.pm when an EAP Response (other than Identity)
# is received
sub response
{
    my ($classname, $self, $context, $p, $type, $typedata) = @_;

    # If there are multiple AuthBys that may be tried, we need to do
    # state handling a bit differently
    if ($self->{EAP_MSCHAPv2_UseMultipleAuthBys} &&
	!$self->{EAP_PEAP_MSCHAP_Convert})
    {
	if (++$context->{eap_26_multiauthby}->{$self} > 2)
	{
	    # Even if there are multiple AuthBys that can be tried,
	    # there's a limit how many times each AuthBy is called for
	    # a single authentication
	    $context->{eap_26_success} = 0;
	    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, "EAP MSCHAP V2 failed: too many tries");
	}

	# Ignore if this AuthBy is currently ignoring requests
	return ($main::IGNORE, 'Ignored by this AuthBy') if grep {$self == $_} @{$context->{ignoring_auth_bys}};
    }

    if (length($typedata) < 1)
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP MSCHAP-V2 Message too short');
    }

    my ($mschaptype, $mschapdata) = unpack('C a*', $typedata);
    if ($mschaptype == $Radius::EAP_26::MSCHAP_TYPE_SUCCESS
	&& $context->{eap_26_success}
	&& $context->{eap_26_state} == $Radius::EAP_26::STATE::SUCCESS_REQUEST_SENT)
    {
	if ($self->{EAP_MSCHAPv2_UseMultipleAuthBys})
	{
	    # May have multiple AuthBys in a chain.
	    # Reject if the success did not come from this AuthBy
	    return ($main::REJECT, 'Not authenticated by this AuthBy') unless $context->{success_auth_by} == $self;
	}

	# Client liked our MSCHAP V2 Success Request and sent an ACK,
	# so we reply with an EAP-Success
	$context->{eap_26_success} = 0;
	$context->{eap_26_state} = $Radius::EAP_26::STATE::SUCCESS;
	$p->{rp}->add_attr_list($context->{last_reply_attrs});
	$self->adjustReply($p);

	if ($self->{AutoMPPEKeys})
	{
	    $p->{rp}->add_attr('MS-MPPE-Send-Key', $context->{send_key});
	    $p->{rp}->add_attr('MS-MPPE-Recv-Key', $context->{recv_key});
	}
	$self->eap_success($p->{rp}, $context);
	return ($main::ACCEPT, 'EAP MSCHAP-V2 Success'); # Success, all done
    }

    $context->{eap_26_success} = 0;
    if ($mschaptype == $Radius::EAP_26::MSCHAP_TYPE_FAILURE)
    {
	# Client acknowledges our MSCHAP_TYPE_FAILURE request
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT); # Failure, all done
    }
    elsif ($mschaptype == $Radius::EAP_26::MSCHAP_TYPE_RESPONSE
	   && $context->{eap_26_state} == $Radius::EAP_26::STATE::CHALLENGE_SENT)
    {
	# Fixed length + one octet of name at minimum
	if (length($mschapdata) < 54)
	{
	    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'EAP MSCHAP-V2 Response too short');
	}

	# Maybe convert to ordinary Radius-MSCHAPV2 and redespatch
	return &convert_to_mschapv2($self, $context, $mschapdata, $p) 
	    if $self->{EAP_PEAP_MSCHAP_Convert};

	my $identity = $context->{identity};
	$identity =~ s/@[^@]*$//
	    if $self->{UsernameMatchesWithoutRealm};
	$identity = $self->eap_rewrite_identity($p, $identity, $self->{RewriteUsername})
	    if (defined $self->{RewriteUsername});

	$identity = $p->get_attr($self->{AuthenticateAttribute})
            if $self->{AuthenticateAttribute};
	my ($user, $result, $reason) = $self->get_user($identity, $p);
	if ($result == $main::IGNORE)
	{
	    if ($self->{EAP_MSCHAPv2_UseMultipleAuthBys})
	    {
		# No state change so that the next AuthBy can continue
		push @{$context->{ignoring_auth_bys}}, $self;
	    }
	    else
	    {
		$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    }
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::IGNORE, "User database access error");
	}
	if (!$user || $result != $main::ACCEPT)
	{
	    unless ($self->{EAP_MSCHAPv2_UseMultipleAuthBys})
	    {
		# There are no other AuthBys to try, request failed
		$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    }
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, "EAP MSCHAP V2 failed: no such user $identity");
	}

	# Got a user record for this user. Password in specific format needed now
	my $password = $self->get_plaintext_password($user);
	my $pw_format = $self->get_pw_format($password, 0);
	unless ($pw_format eq 'clear' || $pw_format eq 'NT hash' || $pw_format eq 'undefined pw')
	{
	    my $msg = "Bad password format for user $identity from user database for EAP-MSCHAP-V2";
	    $self->log($main::LOG_WARNING, $msg, $p);
	    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, $msg);
	}

	my ($mschapid, $mslength, $valuesize, $peerchallenge, $reserved, $response, $flags, $name) 
	    = unpack('C n C a16 a8 a24 C a*', $mschapdata);

	unless (lc($name) eq lc($context->{identity}))
	{
	    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, "EAP MSCHAP-V2 name $name does not match EAP identity $context->{identity}");
	}

	# This may have come from EAP-FAST, in which case the peer and auth 
	# challenges were derived from the outer TLS session
	$peerchallenge = $p->{FASTClientChallenge} 
	    if defined $p->{FASTClientChallenge};
	$context->{mschapv2_challenge} = $p->{FASTServerChallenge} 
	    if defined $p->{FASTServerChallenge};

	my ($authenticator_response, $mppekeys, $check_result); # Returned by check_mschapv2
	my $nthash = $self->get_packed_nthash($password, $pw_format, 0);
	$check_result = $self->check_mschapv2
	    ($p, $name, $nthash, $context->{mschapv2_challenge},
	     $peerchallenge, $response, \$mppekeys, \$authenticator_response, undef, $context);

	if ($check_result)
	{
	    # Password must be right, send back an MSCHAP V2 Success Request
	    if ($self->{AutoMPPEKeys})
	    {
		# Compute and save the MPPE keys for later.
		($context->{send_key}, $context->{recv_key}) = unpack('a16 a16', $mppekeys);
	    }
	    # Save the users reply items for later, when the MSCHAP_TYPE_SUCCESS comes
	    my $temp =  Radius::Radius->new($main::dictionary);
	    $temp->{internal_vars} = $p->{internal_vars}; # Not a copy, refer to the same hash
	    $temp->{rp} = Radius::Radius->new($main::dictionary);
	    $temp->{rp}->{internal_vars} = $p->{rp}->{internal_vars}; # As with $p
	    $context->{last_reply_attrs} = Radius::AttrVal->new();
	    $self->authoriseUser($user, $temp);
	    $context->{last_reply_attrs}->add_attr_list($temp->{rp});

	    # Build a success request packet
	    $authenticator_response .= ' M=success';
	    my $message = pack('C C n a*', 
			       $Radius::EAP_26::MSCHAP_TYPE_SUCCESS,
			       $context->{this_id}, # XP MSCHAP-V2 expects the same as before!
			       length($authenticator_response) + 4,
			       $authenticator_response);
	    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_MSCHAPV2, $message);
	    $context->{eap_26_state} = $Radius::EAP_26::STATE::SUCCESS_REQUEST_SENT;
	    $context->{eap_26_success} = 1;
	    $context->{success_auth_by} = $self;
	    # Make sure we dont use this challenge again.
	    $context->{mschapv2_challenge} = undef;
	    return ($main::CHALLENGE, 'EAP MSCHAP V2 Challenge: Success');
	}
	else
	{
	    # Windows XP SP1 via PEAP is much happier with this. The PEAP server
	    # code detects the inner EAP failure and then does an acknowledged
	    # fail handshake
	    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'EAP MSCHAP-V2 Authentication failure');

	    # Authentication failed, send an EAP/MSCHAPV2/Fail as per 
	    # draft-kamath-pppext-eap-mschapv2-00.txt
	    # Client will ACK this
#	    my $errormsg = 'E=691 R=0 V=3 M=Authentication Failed';
#	    my $message = pack('C C n a*',
#			       $Radius::EAP_26::MSCHAP_TYPE_FAILURE,
#			       $context->{this_id},
#			       length($errormsg) + 4,
#			       $errormsg);
#	    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_MSCHAPV2, $message);
#	    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILURE_REQUEST_SENT;
#	    return ($main::CHALLENGE, 'EAP MSCHAP-V2 Challenge: Fail');
	}
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
    }
    elsif ($mschaptype == $Radius::EAP_26::MSCHAP_TYPE_CHANGE_PASS)
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'EAP MSCHAP-V2 Change-Password not suported');
    }
    else
    {
	my $eap_26_type = $Radius::EAP_26::type2text{$mschaptype};
	$eap_26_type = "Unknown ($mschaptype)" unless defined $eap_26_type;
	my $eap_26_state = $Radius::EAP_26::state2text{$context->{eap_26_state}};
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "EAP MSCHAP-V2 mschaptype $eap_26_type in state $eap_26_state");
    }

    $context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
    $self->eap_failure($p->{rp}, $context);
    return ($main::REJECT, 'EAP MSCHAP-V2 Unhandled message');
}

#####################################################################
# Convert this inner EAP-MSCHAPV2 into a conventional Radius MSCHAPV2 request
# and redespatch it for proxying (or perhaps local handling)
sub convert_to_mschapv2
{
    my ($self, $context, $mschapdata, $p) = @_;

    my ($mschapid, $mslength, $valuesize, $peerchallenge, $reserved, $response, $flags, $name) 
	= unpack('C n C a16 a8 a24 C a*', $mschapdata);

    unless (lc($name) eq lc($context->{identity}))
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "EAP MSCHAP-V2 name $name does not match EAP identity $context->{identity}");
    }

    # Make a new fake packet that contains something that looks like 
    # an ordinary Radius MSCHAPV2 request
    my $tp = Radius::Radius->new($main::dictionary);
    $tp->{trace_id} = $p->{trace_id};
    $tp->set_code('Access-Request');
    $tp->{Client} = $p->{Client};
    $tp->{RecvTime} = $p->{RecvTime};
    $tp->{StatsTrail} = $p->{StatsTrail};
    $tp->{CachedAttrs}{NasId} = $p->getNasId();
    $tp->set_authenticator(&Radius::Util::random_string(16));
    # Arrange to call our reply function when we get a reply
    $tp->{replyFn} = [\&Radius::EAP_26::replyFn, $context];
    $tp->{outerRequest} = $p;

    # Now add the attributes to make it a fake radius request
    $tp->changeUserName($name);
    $tp->add_attr('ConvertedFromEAPMSCHAPV2', 1); # Pseudo attribute to signal dispatcher
    my $responseattr = pack('C C a16 a8 a24', 1, 0, $peerchallenge, 0, $response);
    $tp->add_attr('MS-CHAP2-Response', $responseattr);
    $tp->add_attr('MS-CHAP-Challenge', $context->{mschapv2_challenge});
    
    $tp->{OriginalUserName} = $name;
    $context->{parent} = $self;

    # Call the PreHandlerHook, if there is one
    $self->runHook('PreHandlerHook', $tp, \$tp);
    &main::log($main::LOG_DEBUG,"Converted EAP-MSCHAPV2 Packet dump:\n" . $tp->dump, $p)
	if (&main::willLog($main::LOG_DEBUG, $p));

    my ($user, $realmName) = split(/@/, $name);
    my ($handler, $result);
    foreach my $finder (@Radius::Client::handlerFindFn)
    {
	if ($handler = &$finder($tp, $user, $realmName))
	{
	    # Make sure the handler is updated with stats
	    push(@{$p->{StatsTrail}}, $handler->{Statistics});

	    # replyFn will be called from inside the handler when the
	    # reply is available
	    ($result, undef) = $handler->handle_request($tp);
	    last;
	}
    }
    unless ($handler)
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "No Handler for converted EAP-MSCHAPV2 authentication");
    }

    # At this point replyFn has done its processing for requests that
    # were not proxied but were processed locally
    if ($tp->{proxied})
    {
	# If the converted request was proxied, the reply will arrive later
	$p->{proxied} = $tp->{proxied};
	$context->{eap_26_state} = $Radius::EAP_26::STATE::OSC_CONVERT_PROXIED;
    }
    else
    {
	# Can't handle other reply types now, maybe password change later
	my $reply_code = $tp->{rp}->code();
	if ($reply_code ne 'Access-Accept' &&
	    $reply_code ne 'Access-Reject')
	{
	    $result = $main::IGNORE;
	    $self->log($main::LOG_WARNING, "Converted EAP-MSCHAPV2 response with code $reply_code ignored", $p);
	}
    }

    # Usually the reply to the converted auth is an accept, which
    # we have to make into a challenge.
    $result = $main::CHALLENGE if $tp->{make_a_challenge};

    return ($result, "EAP-MSCHAPV2 converted to Radius MSCHAPV2 and redispatched to a Handler");
}

#####################################################################
# This is called when a the EAP-MSCHAPV2 repsonse is converted
# into a conventional Radus MSCHAPV2 request, proxied or handled locally and then completed
# $tp is the (fake) request packet containing the radius MSCHAPV2 request
sub replyFn
{
    my ($tp, $context) = @_;

    my $reply_code = $tp->{rp}->code();  # The result of the inner auth
    my $self = $context->{parent};
    my $op = $tp->{outerRequest}; # This is the EAP 26 request that was converted
    $op->{proxied} = $tp->{proxied};

    &main::log($main::LOG_DEBUG,"Converted EAP-MSCHAPV2 response Packet dump:\n" . $tp->{rp}->dump, $op)
	if (&main::willLog($main::LOG_DEBUG, $op));

    # See that we are still waiting for a reply
    if ($tp->{proxied} &&
	$context->{eap_26_state} != $Radius::EAP_26::STATE::OSC_CONVERT_PROXIED)
    {
	my $eap_26_state = $Radius::EAP_26::state2text{$context->{eap_26_state}};
	$self->log($main::LOG_WARNING, "Converted EAP-MSCHAPV2 response received in unexpected state $eap_26_state", $op);
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($op->{rp}, $context);
	$op->{Handler}->handlerResult($op, $main::REJECT, 'Converted EAP-MSCHAPV2 authentication failed');
	return;
    }

    if ($reply_code eq 'Access-Accept')
    {
	my $attr = $tp->{rp}->get_attr('MS-CHAP2-Success');
	if (defined $attr)
	{
	    # This is the MS-CHAP2-Success received from the proxy,
	    # convert it back into a MSCHAP_TYPE_SUCCESS
	    my ($ident, $authenticator_response) = unpack('C a42', $attr);
	    $authenticator_response .= ' M=success';

	    my $message = pack('C C n a*', 
			       $Radius::EAP_26::MSCHAP_TYPE_SUCCESS,
			       $context->{this_id}, # XP MSCHAP-V2 expects the same as before!
			       length($authenticator_response) + 4,
			       $authenticator_response);
	    $self->eap_request($op->{rp}, $context, $Radius::EAP::EAP_TYPE_MSCHAPV2, $message);
	}

	# Copy reply attrs
	$context->{last_reply_attrs} = Radius::AttrVal->new();
	$context->{last_reply_attrs}->add_attr_list($tp->{rp});
	$context->{last_reply_attrs}->delete_attr('MS-CHAP2-Success');

	$tp->{make_a_challenge}++;
	$context->{eap_26_state} = $Radius::EAP_26::STATE::SUCCESS_REQUEST_SENT;
	$context->{eap_26_success} = 1;
	$context->{success_auth_by} = $self;
	# Make sure we dont use this challenge again.
	$context->{mschapv2_challenge} = undef;

	$op->{Handler}->handlerResult($op, $main::CHALLENGE, 'Converted MSCHAPV2 authentication success')
	    if $tp->{proxied};
    }    
    elsif ($reply_code eq 'Access-Reject')
    {
	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($op->{rp}, $context);
	$op->{Handler}->handlerResult
	    ($op, $main::REJECT, 'Converted EAP-MSCHAPV2 authentication failed')
	    if $tp->{proxied};	
    }
    else
    {
	# Don't call handlerResult for other codes, just log the problem
	$self->log($main::LOG_WARNING, "Converted EAP-MSCHAPV2 response from proxy with code $reply_code ignored", $op)
	    if $tp->{proxied};

	$context->{eap_26_state} = $Radius::EAP_26::STATE::FAILED;
	$self->eap_failure($op->{rp}, $context);
    }

    return;
}


1;
