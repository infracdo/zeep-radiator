# ServerConfig.pm
#
# Object for holding configuration for a server
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::ServerConfig;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::ServerRADIUS;
use Radius::RDict;
use Radius::Log;
use Radius::RuntimeChecks;
use Radius::MessageLogGeneric;
use Radius::Util;
use Radius::Select;
use File::Basename;
use Digest::MD5;
use strict;
use warnings;

%Radius::ServerConfig::ConfigKeywords = 
('AuthPort'           => 
 ['string',
  'Comma separated list of port names or numbers used for RADIUS Authentication requests. Defaults to 1645.',
  0],

 'AcctPort'           => 
 ['string',
  'Comma separated list of port names or numbers used for RADIUS Accounting requests. Defaults to 1646.',
  0],

 'BindAddress'        => 
 ['string',
  'Host IP address to listen on for connections. IPV4 or IPV6 addresses are permitted. Defaults to 0.0.0.0, meaning all the hosts IP addresses.',
  1],

'BindV6Only'   =>
 ['flag',
  'When set, does setsockopt() to turn IPV6_V6ONLY on or off for IPv6 wildcard sockets. See RFC 3493 for details. This option is not set by default and thus no setsockopt() is called and system default is used. Using this option requires support from Perl socket modules.',
  1],

 'Foreground'         => 
 ['flag',
  'Run the program in the foreground instead of as a background server (daemon). Unix only.',
  0],

 'DbDir'              => 
 ['string',
  'Default database directory. Available as special character %D',
  0],

 'LogDir'             => 
 ['string',
  'Default log file directory. Available as special character %L',
  0],

 'LogFile'            => 
 ['string',
  'Default log file name',
  0],

 'LogRejectLevel'            => 
 ['integer',
  'Log level for rejected authentication attempts. Can be overridden by Handler. Defaults to 3.',
  2],

 'DictionaryFile'     => 
 ['string',
  'Name of the RADIUS dictionary to use to translate RADIUS requests',
  1],

  'DictionaryReloadInterval' =>
  ['integer',
   'Interval in seconds for checking whether the files defined by DictionaryFile have changed. If there are changes, all files are reloaded. Not enabled by default and the files are only loaded during server initialisation.',
   1],

 'PidFile'            => 
 ['string',
  'Name of a file that will be used to save the process ID of this process. If not defined, the PID wil not be saved.',
  1],

 'LogStdout'          => 
 ['flag',
  'Controls whether messages will be logged to STDOUT',
  0],

 'SnmpgetProg'        => 
 ['string',
  'Full path name of program used for SNMP get',
  2],

 'SnmpsetProg'        => 
 ['string',
  'Full path name of program used for SNMP set',
  2],

 'SnmpwalkProg'       => 
 ['string',
  'Full path name of program used for SNMP walk',
  2],

 'FingerProg'         => 
 ['string',
  'Full path name of an alternate program used to implement finger. If not defined an internal finger client will be used.',
  2],

 'PmwhoProg'          => 
 ['string',
  'Name of the Livingston SNMP MIB. It is only used if you are using Simultaneous-Use with a NasType of Livingston in one of your Client clauses',
  2],

 'LivingstonMIB'      => 
 ['string',
  'Default bas MIB for extracting login information from Portmaster and Livingston NASs using SNMP',
  2],

 'LivingstonOffs'     => 
 ['integer',
  'Default value of the location where the last S port is before the one or two ports specified in LivingstonHole are skipped. Can be overridden on a per-Client basis.',
  2],

 'LivingstonHole'     => 
 ['integer',
  'The size of the hole in the port list (usually 1 for US, 2 for Europe) that occurs at LivingstonOffs. Can be overridden on a per-Client basis.',
  2],

 'RewriteUsername'    => 
 ['stringarray',
  'Regular expressions that will be used to rewrite User-Name before any Hadnlers or Realms are called. Format is a perl regular expression, such as s/fred/jim/',
  1],

 'SocketQueueLength'  => 
 ['integer',
  'The maximum length of the RADIUS socket queue in octets. Longer queues mean that more RADIUS requests can be waiting to be processed',
  1],

 'LicenseFile'     =>
 ['string',
  'Name of the file with Radiator license configuration parameters',
  1],

 'LicenseVersion'     => 
 ['string',
  'Specific Radiator version number that this license key applies to. Can be a static version number or a regular expression',
  1],

 'LicenseHostname'    => 
 ['string',
  'Specific hostname that this license key applies to. Can be a static host name or a regular expression',
  1],

 'LicenseMaxRequests' => 
 ['integer',
  'Maximum number of RADIUS requests this license permits. After this number have been processed, all requests will be ignored. 0 means no limit',
  1],

 'LicenseExpires'     => 
 ['string',
  'Date this license expires. Format is yyyy-mm-dd. 0000-00-00 means no expiry.',
  1],

 'LicenseOwner'       => 
 ['string',
  'Name of the owner of this license',
  1],

 'LicenseVendor'      => 
 ['string',
  'Name of the vendor that sold this license to the end user',
  1],

 'LicenseKey'         => 
 ['string',
  'License key string. Case insensitive',
  1],

 'PreClientHook'      => 
 ['hook',
  'Perl hook that is run for each request before despatching to any Client clause',
  2],

 'HandlerFindHook'    =>
 ['hook',
  'Perl hook that is run for each request to find Handler clause to handle the request',
  2],

 'StartupHook'        => 
 ['hook',
  'Perl hook that is run once when Radiator is started or restarted',
  2],

 'ShutdownHook'       => 
 ['hook',
  'Perl hook that is run when Radiator shuts down cleanly, just prior to exiting',
  2],

 'USR1Hook'           => 
 ['hook',
  'Perl hook that is run when a USR1 signal is received. If this hook is not defined, USR1 increases the global trace level',
  2],

 'USR2Hook'           => 
 ['hook',
  'Perl hook that is run when a USR2 signal is received. If this hook is not defined, USR2 decreases the global trace level',
  2],

 'WINCHHook'          => 
 ['hook',
  'Perl hook that is run when a WINCH signal is received',
  2],

 'UsernameCharset'    => 
 ['string',
  'List of characters permitted in User-Name. Request with User-Name containing characters not in this set are rejected. Perl character set formats are permitted, such as "a-zA-Z0-9" which permits all alphanumeric characters',
  1],

 'MainLoopHook'       => 
 ['hook',
  'Perl hook that is run every time Radiator executes the main event handling loop',
  2],

 'DelayedShutdownHook' =>
 ['hook',
  'Perl hook that is run just before the delayed shutdown is started',
  2],

 'DelayedShutdownTime' =>
 ['integer',
  'The time in seconds Radiator restart or termination is delayed after being requested with e.g., SIGHUP or SIGTERM. After the delay any incoming requests are processed before continuing with the shutdown. Defaults to not set.',
  1],

 'ForkClosesFDs'      => 
 ['flag',
  'Tells Radiator to forcibly close all the child processes files descriptors after a fork() on Unix. This is only necessary in very unusual circumstances where child processes interfere with the parents connections to an SQL database',
  2],

 'User'               => 
 ['string',
  'On Unix, this optional parameter sets the effective user ID (UID) that radiusd will run as, provided radiusd starts as a suitably priveleged user (usually as root). The value can be a valid Unix user name or an integer UID.',
  1],

 'Group'              => 
 ['splitstringarray',
  'On Unix, this optional parameter sets the effective group ID (GID) and supplementary groups that radiusd will run as, provided radiusd starts as a suitably priveleged user (usually as root). The value can be a comma separated list of valid Unix group names or integer GIDs. The first group will be set as the effective group ID.',
  1],

 'AuthBy'             => 
 ['objectlist',
  'List of AuthBy clauses that are referenced by their Identifier in other clauses',
  1],

 'Handler'            => 
 ['objectlist',
  'List of Handlers that will be consulted in order to find how to handle each incoming request. This list will only be consulted if no Realm can be found to handle the request',
  1],

 'Realm'              => 
 ['objectlist','List of Realms that will be consulted in order to find how to handle each incoming request. Realm DEFAULT will be used for requests that dont have a more speific exact or regexp match. If no Realms match, the Handlers list will be consulted',
  0],

 'Client'             => 
 ['objectlist',
  'One or more Client objects which specify which remote clients we will accept requests from',
  0],

 'Server'             => 
 ['objectlist',
  'List of additional servers for handling protocols other than RADIUS.',
  1],

 'Trace'              => 
 ['integer',   # Actually interpreted by sub keyword below
  'Logging trace level. Only messages with the specified or higher priority will be logged',
  0],

 'SnmpNASErrorTimeout' => 
 ['integer',
  'Specifies for how long (in seconds) SNMP simultaneous use checks will be blocked after an SNMP error during communications with a given NAS',
  2],

 'MaxChildren'        => 
 ['integer',
  'Specifies the maximum number of Fork children permitted at any one time. Any attempt by an AuthBy to Fork (if so configured) will fail and the Radius request will be ignored if there are already that many Forked children in existence. 0 Means no limit.',
  1],

 'FarmSize'        => 
 ['string',
  'Specifies the number of Radiator farm instances to run. Each fork runs independently and takes requests from incoming sockets in a round-robin fashion. The main process acts as a supervisor for the farm children. Unix only. The default means just the standard single instance',
  1],

 'FarmChildHook'        => 
 ['hook',
  'Perl hook that is run in each child when FarmSize is used. The hook is run when the child is started or restarted.',
  2],

 'DupCache'     =>
 ['enum',
  'This optinal parameter defines if duplicate cache is implemented locally within the process, shared between processes with mmapped memory or if a  gossip cluster will use a global shared cache for detecting duplicate requests. Defaults to \'local\'.',
  1, \@Radius::ServerConfig::dup_cache_enum],

 'DupCacheFile'     =>
 ['string',
  "Name of the shared duplicate cache file. Defaults to '/tmp/radiator-dupcache-sharefile%0' or 'C:\radiator-dupcache-sharefile%0' on Windows. Special characters are allowed. %0 is by -pid-timestamp-random where the actual values are generated dynamically.",
  1],

 'DiameterDictionaryFile'=> 
 ['string',
  'Name of an additional dictionary file to use for translating Diameter requests',
  1],

 'SessionDatabase'=> 
 ['objectlist',
  'List of session databases. By giving the SessionDatabase object an Identifier, you can refer to it by name for individual Realms or Handlers',
  1],

 'StatsLog'=> 
 ['objectlist',
  'List of statistics loggers. Each logger wgill log statistics from every internal Radiator object every Interval seconds',
  1],

 'LogMicroseconds' => 
 ['flag', 
  'In all loggers, when logging, include microseconds in the time (requires Time::HiRes)', 
  1],

 'GlobalMessageLog' =>
 ['stringarray',
  'This optional parameter defines the Identifier of global MessageLog clause to log all Radius, RadSec, Diameter and TACACS+ requests. Not set by default.',
  1],

 'LogTraceId'  =>
 ['flag',
  'Prepend tracing identifier to log messages logged to stdout and the default LogFile configured with global LogFile configuration parameter.',
  1],

 'DefineGlobalVar'  => 
 ['stringarray', 
  'Defines a global variable. Format is \'name value\'. The value is taken literally (ie no special characters are supported or translated in defining the value). The value can be used wherever special characters are supported with the %{GlobalVar:xxxxx} format', 
  2],

 'DefineFormattedGlobalVar'  => 
 ['stringarray', 
  'Defines a global variable. Format is \'name value\'. The value can be defined using special characters. The value can be used wherever special characters are supported with the %{GlobalVar:xxxxx} format', 
  2],

 'ClientHook'      => 
 ['hook',
  'Perl hook that is run for each request after delivery to a Client clause',
  2],

 'DisableMTUDiscovery'      => 
 ['flag',
  'Disables MTU discovery on platforms that support that behaviour (currently Linux only). This can be used to prevent discarding of certain large RADIUS packet fragments on supporting operating systems.',
  2],

 'PacketDumpOmitAttributes'  => 
 ['splitstringarray', 
  'Defines a list of packet attributes that will not be printed in packet dumps in logs.', 
  2],

 'ClientList' => 
 ['objectlist',
  'ClientList objects that are searched for Clients to match each incoming request.',
  2],

 'ProxyUnknownAttributes'      => 
 ['flag',
  'If set, enables proxying unknown attributes in requests and responses received by the server. Defaults to off.',
  2],

 'StatusServer'      =>
 ['string',
  'Global default for Client specific StatusServer parameter. See StatusServer in Client for the details and default value.',
  2],

 'KeepSocketsOnReload' =>
 ['flag',
  'Controls whether opened RADIUS listen sockets should be left intact on a reload request. When enabled, the changes in BindAddress, AuthPort and AcctPort are ignored during reload.',
  2],

 'DisabledRuntimeChecks'      =>
 ['string',
  'Comma separated list of runtime checks that should be disabled. See the reference manual for the currently supported tests.',
  2],

 'UseProxyLabel' =>
 ['flag',
  'Controls whether the presence of OSC\'s proprietary label is checked from the incoming UDP RADIUS requests. Defaults to not set.',
  2],

 'EAP_UseState' =>
 ['flag',
  'For EAP authentication, this optional parameter tells Radiator to base EAP context lookup on the Radius State attribute. Defaults to not set, but will be changed to set.', 1],

 'ResponseTimeThreshold' =>
 ['integer',
  'This optional parameter tells Radiator to log a warning if processing time exceeds configured millisecond threshold. The warning contains request\'s User-Name and names of Client, Handler and AuthBy which processed the request.', 2],

 'PBKDF2_MinRounds' =>
 ['integer',
  'Minimum rounds for PBKDF2 algorithm Radiator will accept. If the stored user password information uses a smaller number of rounds, the password check will fail. Defaults to 100.',
  2],

 'PBKDF2_MaxRounds' =>
 ['integer',
  'Maximum rounds for PBKDF2 algorithm Radiator will accept. If the stored user password information uses a larger number of rounds, the password check will fail. Defaults to 200000.',
  2],
 );

# RCS version number of this module
$Radius::ServerConfig::VERSION = '$Revision$';

# The different ways duplicate caching can be configured.
$Radius::ServerConfig::DupCache::LOCAL = "local";    # Local to each process
$Radius::ServerConfig::DupCache::SHARED = "shared";  # Shared between processes on the same server
$Radius::ServerConfig::DupCache::GLOBAL = "global";  # Shared between processes using the Gossip framework

@Radius::ServerConfig::dup_cache_enum = ($Radius::ServerConfig::DupCache::LOCAL, $Radius::ServerConfig::DupCache::SHARED, $Radius::ServerConfig::DupCache::GLOBAL);

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # We keep the old ServerRADIUS, if any, on reload when KeepSocketsOnReload is set
    # REVISIT: check if $self->{radius_server} is ever defined without KeepSocketsOnReload
    $self->{radius_server}->destroy() if $self->{radius_server} && !$self->{KeepSocketsOnReload};
    $self->{radius_server} = Radius::ServerRADIUS->new
	(undef, undef,
	 'AuthPort'           => $self->{AuthPort},
	 'AcctPort'           => $self->{AcctPort},
	 'BindAddress'        => $self->{BindAddress},
	 'DisableMTUDiscovery' => $self->{DisableMTUDiscovery},
	) unless $self->{radius_server};

    if ($self->{DictionaryReloadInterval})
    {
	reload_dictionary(undef, $self);
    }
    else
    {
	$self->load_dictionary();
    }
    $self->change_uid_gid();
    $self->write_pid();
    Radius::RuntimeChecks::do_startup_checks();
    $self->{radius_server}->activate();

    # Initialize the shared dupcache
    if ($self->{DupCache} eq $Radius::ServerConfig::DupCache::SHARED)
    {
	my $max_rps = 20000; # 20000 requests per second
	my $max_dup_interval = 0; # 0 seconds

	foreach my $client (@{$main::config->{Client}}) {
	    $max_dup_interval = $client->{DupInterval}
	    if $client->{DupInterval} > $max_dup_interval;
	}

	# 1476 is the max size we use for UDP requests. Page size must
	# be a power of two.
	my $cache_size = $max_rps * 1476 * $max_dup_interval;
	my $page_size = 64*1024;
	my $num_pages = int($cache_size / $page_size);

	# Adjust page_size to the nearest prime
	while (1)
	{
	    my $limit = int(sqrt(++$num_pages));
	    my $i = 1;
	    while ($i++ < $limit)
	    {
		last if ($num_pages % $i == 0);
	    }
	    last if $i > $limit;
	}

	my $rand_suffix = "-" . $$ . "-" . time . "-" . int(rand(100000));

	# FIXME: Use File::Temp here?
	my $dup_cache_file = Radius::Util::format_special($self->{DupCacheFile}, undef, $self, $rand_suffix);

	$self->log($main::LOG_INFO, "Creating a shared cache file $dup_cache_file for a duplicate detection (" . ($num_pages * $page_size) / (1024 * 1024) . " MB)");
	$self->log($main::LOG_DEBUG, "... with longest DupInterval being $max_dup_interval seconds, page_size $page_size, num_pages $num_pages.");

	$self->{shared_dup_cache} =
	    Cache::FastMmap->new(share_file => $dup_cache_file,
				 serializer => '',
				 raw_values => 1,  # FIXME: This is deprecated by serializer (v. 1.4.5) and should be removed
				 init_file => 1,
				 unlink_on_exit => 1,
				 expire_time => $max_dup_interval,
				 page_size => $page_size,
				 num_pages => $num_pages);

	unless ($self->{shared_dup_cache})
	{
	    my $msg = "Failed to while creating shared DupCache file $dup_cache_file. Exciting";
	    $self->log($main::LOG_ERR, $msg);
	    die $msg;
	}
    }

    # Create possibly unique identifiers for the server. The hash must be 32 octets long.
    $self->{Identifier} = Radius::Util::format_special($self->{Identifier}, undef, $self);
    $self->{identifier_hash} = Digest::MD5::md5_hex($self->{Identifier});

    # Use HandlerFindHook
    if ($self->{HandlerFindHook})
    {
	if ($self->{"HandlerFindHook.compiled"})
	{
	    # Make sure HandlerFindHook is called before other find functions.
	    Radius::Client::prepend_handler_finder($self->{"HandlerFindHook.compiled"});
	}
	else
	{
	    $self->log($main::LOG_ERR, "Failed to compile HandlerFindHook");
	}
    }

    return;
}

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Statistics} = Radius::StatsLogGeneric::make_object_statistics($self);
    # REVISIT: should be 1812? see rfc2138
    $self->{AuthPort} = 1645;
    $self->{AcctPort} = 1646;
    $self->{BindAddress} = '0.0.0.0';
    $self->{DbDir} = '/usr/local/etc/raddb';
    $self->{LogDir} = '/var/log/radius'; 
    $self->{LogFile} = '%L/logfile'; 
    $self->{LogRejectLevel} = 3;
    $self->{DictionaryFile} = '%D/dictionary';
    $self->{DupCache} = $Radius::ServerConfig::DupCache::LOCAL;
    $self->{DupCacheFile} = ($^O eq "MSWin32" ? 'C:\\' : '/tmp/') . 'radiator-dupcache-sharefile%0';
    $self->{PidFile} = '%L/radiusd.pid';
    $self->{Foreground} = 0;
    $self->{Trace} = 0;
    $self->{SnmpgetProg} = '/usr/bin/snmpget';
    $self->{SnmpwalkProg} = '/usr/bin/snmpwalk';
    $self->{SnmpsetProg} = '/usr/bin/snmpset';
    $self->{PmwhoProg} = '/usr/local/sbin/pmwho';
    $self->{LivingstonOffs} = 29;
    $self->{LivingstonHole} = 2;
    $self->{LivingstonMIB} = '.iso.org.dod.internet.private.enterprises.307';
    $self->{SnmpNASErrorTimeout} = 60; 
    $self->{MaxChildren} = 0;
    $self->{StatusServer} = 'default'; # Reply to Status-Server with default verbosity
    $self->{ServerTokenFormat} = "%0";

    $self->{delayedShutdownFns} = [];    # Delayed shutdown functions
    $self->{reinitFns}          = [];    # Reinit functions
    $self->{shutdownFns}        = [];    # Shutdown functions
    $self->{startupFns}         = [];    # Functions after radiusd has started
    $self->{perchildinitFns}    = [];    # Farm child after fork functions

    Radius::RuntimeChecks::do_initialize_checks();
}

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    if ($self->{DupCache} eq $Radius::ServerConfig::DupCache::SHARED)
    {
	eval { require Cache::FastMmap; };
	if ($@)
	{
	    my $msg = "DupCache $Radius::ServerConfig::DupCache::SHARED requires Cache::FastMmap";
	    $self->log($main::LOG_ERR, "$msg");
	    die "$msg";
	}
    }

    # For GlobalMessage log we need at least proto,identifier
    if ($self->{GlobalMessageLog})
    {
	foreach my $param (@{$self->{GlobalMessageLog}})
	{
	    my ($proto, $identifier, @extras) = split(/,\s*/, $param);
	    next if $identifier && $Radius::MessageLogGeneric::protocol_to_name{$proto};
	    $self->log($main::LOG_WARNING, "Incorrectly formatted parameter: MessageLog $param");
	}
    }

    # License params are not needed, for example, when upgrading from
    # evaluation to full version. Log a message when unneeded license
    # parameters were included with LicenseFile, plain Include or
    # written directory to the configuration file.
    unless ($main::requires_key)
    {
	if ($self->{LicenseFile})
	{
	    my $lic_file_name = Radius::Util::format_special($self->{LicenseFile});
	    $self->log($main::LOG_INFO, "This instance of Radiator is fully licensed and does not require any license keys, ignoring LicenseFile $lic_file_name");
	}

	my @lic_params;
	foreach my $lic_param (qw(LicenseVersion LicenseHostname LicenseMaxRequests LicenseExpires LicenseOwner LicenseVendor LicenseKey))
	{
	    next unless defined $self->{$lic_param};
	    push(@lic_params, $lic_param);
	}
	$self->log($main::LOG_INFO, "This instance of Radiator is fully licensed and does not require any license keys, ignoring license configuration parameters: @lic_params")
	    if @lic_params;
    }

    return;
}

#####################################################################
# Override the object function in Configurable. Need this because of the odd
# naming conventions of some Server modules.
sub object
{
    my ($self, $file, $keyword, $name, @args) = @_;

    if ($keyword =~ /^Server/ || $keyword eq 'Monitor')
    {
	my $class = "Radius::$keyword";
	my $o = &Radius::Configurable::load($file, $class, $name, @args);
	if (!$o)
	{
	    $self->log($main::LOG_ERR, "Could not load Server module $class: $@");
	    return;
	}
	push(@{$self->{Server}}, $o);
	return $o;
    }
    elsif ($keyword =~ /^ClientList/)
    {
	my $class = "Radius::$keyword";
	my $o = &Radius::Configurable::load($file, $class, $name, @args);
	if (!$o)
	{
	    $self->log($main::LOG_ERR, "Could not load ClientList module $class: $@");
	    return;
	}
	push(@{$self->{ClientList}}, $o);
	return $o;
    }
    return $self->SUPER::object($file, $keyword, $name, @args);
}


#####################################################################
# Reinitialize this module
sub destroy
{
    my ($self) = @_;
    # This will DESTROY any Server objects left from a previous initialization
    
    $self->{radius_server}->destroy() if $self->{radius_server} && !$self->{KeepSocketsOnReload};
    map $_->destroy, @{$main::config->{Server}};
    map $_->destroy, @{$main::config->{ClientList}};
    map $_->destroy, @{$main::config->{StatsLog}};
    map $_->destroy, @{$main::config->{SessionDatabase}};

    Radius::Client::remove_handler_finder($self->{"HandlerFindHook.compiled"})
	if $self->{"HandlerFindHook.compiled"};

    return;
}

#####################################################################
# Override the keyword function in Configurable
sub keyword
{
    my ($self, $file, $keyword, $value) = @_;

    if ($keyword eq 'DefineGlobalVar')
    {
	# Deprecated: see DefineFormattedGlobalVar 
	push(@{$self->{$keyword}}, $value);
	my ($name, $v) = split(/\s+/, $value, 2);
	&main::setVariable($name, $v);
	return 1;
    }
    elsif ($keyword eq 'DefineFormattedGlobalVar')
    {
	push(@{$self->{$keyword}}, $value);
	my ($name, $v) = split(/\s+/, $value, 2);
	&main::setVariable($name, &Radius::Util::format_special($v));
	return 1;
    }
    elsif ($keyword eq 'LogFile')
    {
	$self->{LogFile} = $value;
	# Allow the default logger to be rejigged during startup
	&Radius::Log::setupDefaultLogger
	    ($self->{LogFile}, $self->{Trace}, $self->{LogTraceId});
	return 1;
    }
    elsif ($keyword eq 'Trace')
    {
	$self->{Trace} = $value;
	# Allow the default logger to be rejigged during startup
	&Radius::Log::setupDefaultLogger
	    ($self->{LogFile}, $self->{Trace}, $self->{LogTraceId});
	return 1;
    }
    elsif ($keyword eq 'LogTraceId')
    {
	$value = $self->SUPER::keyword($file, $keyword, $value); # Flag is set when value is empty
	$self->{LogTraceId} = $value;
	# Allow the default logger to be rejigged during startup
	&Radius::Log::setupDefaultLogger
	    ($self->{LogFile}, $self->{Trace}, $self->{LogTraceId});
	return 1;
    }
    else
    {
	return $self->SUPER::keyword($file, $keyword, $value);
    }
}

#####################################################################
# Here we override Configureable::log, otherwise we get duplicate logging
# of errors from ServerConfig, as the ServerConfig loggers _are_ the global
# loggers.
sub log
{
    my ($self, @args) = @_;

    # Then call any global loggers
    &main::log(@args);
}

#####################################################################
# Recursively save this object and sub-objects named in objectlists
sub save_config
{
    my ($self, $file) = @_;

    my %alreadyseen; # Hash of already seen objects to prevent recursion
    return $self->save_object($file, \%alreadyseen, -1);
}

#####################################################################
# Check if our list of desired groups matches currently effective
# groups. If not, return a string suitable for setting $) or undef
# otherwise.
sub need_setgroups
{
    my ($self, @desired_gids) = @_;

    my $desired_egid = $desired_gids[0];
    my ($current_egid) = split(/ /, $)); # Get the first gid

    # Reading $) can result in long lists like "500 500 400 200". We
    # use a hash to weed out duplicates from the desired new groups
    # and current groups.
    my (%desired_gids, %current_gids);
    map {$desired_gids{$_} = 1} @desired_gids;
    map {$current_gids{$_} = 1} split(/ /, $));

    # Sort and add the egids so that they get compared too
    my $desired = $desired_egid . ' ' . join(' ', sort(keys %desired_gids));
    my $current = $current_egid . ' ' . join(' ', sort(keys %current_gids));

    return ($desired eq $current) ? undef : $desired;
}

#####################################################################
sub change_uid_gid
{
    my ($self) = @_;

    return if $^O eq 'MSWin32';

    # Change user and group if required
    if (defined $self->{Group} && @{$self->{Group}})
    {
	my (@desired_gids, $failed);
	foreach my $group (@{$self->{Group}})
	{
	    my $gid = $group;
	    $gid = (getgrnam($group))[2] if ($group !~ /^\d+$/);

	    if (defined $gid)
	    {
		push @desired_gids, $gid;
	    }
	    else
	    {
		$failed++;
		$self->log($main::LOG_ERR, "$group is not a valid group");
	    }
	}
	
	# Only change if it not the same already and we were able to
	# resolve all groups. If resolution fails we may create files
	# with incorrect ownership.
	if (!$failed)
	{
	    my $new_gids = $self->need_setgroups(@desired_gids);
	    if ($new_gids)
	    {
		# Unusual format for $). It requires "gid1 gid1 gid2 gid3 ..."
		$self->log($main::LOG_DEBUG, "Setting effective groups to: $new_gids");
		$! = 0; $) = "$new_gids";
		if ($!)
		{
		    $self->log($main::LOG_ERR, "Could not set effective groups: $!");
		}
		else
		{
		    $self->log($main::LOG_DEBUG, "Effective groups are: $)");
		}

		my $real_gid = (split(' ', $new_gids))[0];

		# getgrgid returns undef if no entry exists
		my $grname = getgrgid($real_gid);
		$grname = 'N/A' unless defined $grname;

		$self->log($main::LOG_DEBUG, "Setting real gid to $grname ($real_gid)");
		$! = 0; $( = $real_gid;
		if ($!)
		{
		    $self->log($main::LOG_ERR, "Could not set real group: $!");
		}
		else
		{
		    $self->log($main::LOG_DEBUG, "Real groups are: $(");
		}

		# Check if we'd still need to do the change
		$new_gids = $self->need_setgroups(@desired_gids);
		$self->log($main::LOG_ERR, "Failed to set effective groups to @desired_gids. Current effective groups: $)")
		    if $new_gids;

		# Try to change log file group if log file exists
		my $logfile = &Radius::Util::format_special($self->{LogFile});
		if (-e $logfile
		    && chown(-1, $real_gid, $logfile) != 1)
		{
		    $self->log($main::LOG_ERR, "Could not change log file $logfile group to $grname ($real_gid): $!");
		}
	    }
	}
	else
	{
	    $self->log($main::LOG_ERR, "Failed to resolve all Group parameter groups: @{$self->{Group}}. Not setting groups.");
	}
    }

    if (defined $self->{User})
    {
	my ($uid, $name);
	$uid = $self->{User};
	$uid = (getpwnam($self->{User}))[2] if ($self->{User} !~ /^\d+$/);

	# getpwuid returns undef if no entry exists
	$name = getpwuid($uid) if defined $uid;
	$name = 'N/A' unless defined $name;

	if (!defined $uid)
	{
	    $self->log($main::LOG_ERR, "$self->{User} is not a valid User");
	}
	else
	{
	    # Try to change log file owner first if log file exists
	    my $logfile = &Radius::Util::format_special($self->{LogFile});
	    if (-e $logfile
		&& chown($uid, -1, $logfile) != 1)
	    {
		$self->log($main::LOG_ERR, "Could not change log file $logfile owner to $name ($uid): $!");
	    }

	    if ($> != $uid || $< != $uid)
	    {
		# Effective or real uid is not the desired uid: change
		# them both.
		$self->log($main::LOG_DEBUG, "Setting effective uid to $name ($uid)");
		$! = 0; $> = $uid;
		if ($!)
		{
		    $self->log($main::LOG_ERR, "Could not set effective uid to $name ($uid): $!");
		}
		else
		{
		    $self->log($main::LOG_ERR, "Successfully set effective uid to $name ($uid) but still got $>")
			unless $> == $uid;
		}

		$self->log($main::LOG_DEBUG, "Setting real uid to $name ($uid)");
		$! = 0; $< = $uid;
		if ($!)
		{
		    $self->log($main::LOG_ERR, "Could not set real uid to $name ($uid): $!");
		}
		else
		{
		    $self->log($main::LOG_ERR, "Successfully set real uid to $name ($uid) but still got $<")
			unless $< == $uid;
		}
	    }
	    else
	    {
		# Both effective and real uid are already the desired uid
		$self->log($main::LOG_INFO, "No need to change effective and real user. Already running as $name ($uid)");
	    }
	}
    }

    # Log if gid or uid changes were tried
    if ((defined $self->{Group} && @{$self->{Group}}) || (defined $self->{User}))
    {
	$self->log($main::LOG_DEBUG, "Effective uid $>, real uid $<");
	$self->log($main::LOG_DEBUG, "Effective gids $), real gid $(");
    }
}

#####################################################################
sub write_pid
{
    my ($self) = @_;

    # Write our pid into a file.
    my $pidfile = &Radius::Util::format_special($self->{PidFile});
    return if $pidfile eq '';

    # Make sure the directory exists
    eval {File::Path::mkpath(dirname($pidfile), 0, oct(755))}
        unless -d dirname($pidfile);
    if (open(my $fh, '>', "$pidfile"))
    {
	print $fh "$$\n";
	close($fh);
	return 1;
    }
    $self->log($main::LOG_ERR, "Could not open pid file '$pidfile': $!");
    return;
}

#####################################################################
sub load_dictionary
{
    my ($self) = @_;

    # multiple comma separated dictionary file names are supported
    my $filename = &Radius::Util::format_special($self->{DictionaryFile});
    return $main::dictionary = Radius::RDict->new(split(/,/, $filename));
}

#####################################################################
sub reload_dictionary
{
    my ($handle, $self) = @_;

    # setup a timer to hot reload the dictionary
    if ($self->{dict_reload_timer})
    {
	Radius::Select::remove_timeout($self->{dict_reload_timer});
	$self->{dict_reload_timer} = undef;
    }
    if ($self->{DictionaryReloadInterval})
    {
	$self->{dict_reload_timer} = Radius::Select::add_timeout(time() + $self->{DictionaryReloadInterval}, \&reload_dictionary, $self);
    }

    my $filename = Radius::Util::format_special($self->{DictionaryFile});
    my @filenames = split(/,/, $filename);

    $self->{dict_reloaded} = {} unless defined $self->{dict_reloaded};

    my $need_reload = 0;
    foreach my $dict_filename (@filenames)
    {
	# Is the dictionary file readable?
	if (-r $dict_filename)
	{
	    my $new_time = (stat($dict_filename))[9];
	    my $last_time = $self->{dict_reloaded}->{$dict_filename} || 0;
	    $need_reload++ if (!$new_time || $new_time != $last_time);
	    $self->{dict_reloaded}->{$dict_filename} = $new_time;
	}
	elsif ($self->{dict_reloaded}->{$dict_filename})
	{
	    # File no longer readable. Note: it may become so later.
	    $need_reload++;
	    delete $self->{dict_reloaded}->{$dict_filename};
	}
    }

    if ($need_reload)
    {
	$self->log($main::LOG_INFO, "Reloading DictionaryFile '$filename'");
	return $self->load_dictionary();
    }

    return;
}

#####################################################################
# Handle a new request
sub dispatch_request
{
    my ($self, $p) = @_;

    # Apply any global username rewriting rules
    $p->rewriteUsername($self->{RewriteUsername})
	if (defined $self->{RewriteUsername});

    # Make sure config is updated with stats
    push(@{$p->{StatsTrail}}, $self->{Statistics});

    # Call the PreClientHook, if there is one
    $self->runHook('PreClientHook', $p, \$p);

    # Find out the client that it came from. We iterate
    # through the clientFindFns fn array in order to find
    # a function that will find the right subclass
    # of Client.pm. This allows you to add new subclasses
    # of Client.pm with different behaviour
    my ($client);
    foreach my $finder (@main::clientFindFns)
    {
	if ($client = &$finder($p))
	{
	    # Make sure the client is updated with stats
	    push(@{$p->{StatsTrail}}, $client->{Statistics});

	    $client->handle_request($p);
	    last;
	}
    }

    # If the handler forked and we are in the child
    # we can now exit.
    exit if $main::handler_forked;

    if (!$client)
    {
	my $client_name = Radius::Util::inet_ntop($p->{RecvFromAddress});
	$self->log($main::LOG_NOTICE, "Request from unknown client $client_name: ignored");
	$p->statsIncrement('invalidClientAddresses');
    }
}

#####################################################################
sub readConfig
{
    my ($self, $filename) = @_;

    $self->{configFilename} = $filename;
    my $ret = $self->readFile($filename);

    # Check that all <Clause>s were closed correctly
    while (my $start_info = shift @{$main::config->{config_object_stack}})
    {
	my ($start_type, $start_file, $start_line) = @$start_info;
	main::log($main::LOG_WARNING, "Clause $start_type still open. Opened in $start_file line $start_line");
    }

    # Here we can any final processing after the configuration has
    # been fully read
    $self->setup_global_messagelog();

    return $ret;
}

#####################################################################
# Set up global message loggers for the different protocols we support
sub setup_global_messagelog
{
    my ($self) = @_;

    $main::message_log = {};

    return unless $self->{GlobalMessageLog};

    foreach my $param (@{$self->{GlobalMessageLog}})
    {
	my ($proto, $identifier, @extras) = split(/,\s*/, $param);
	my $msg_log = Radius::MessageLogGeneric::find($identifier);
	$self->log($main::LOG_WARNING, "Could not find MessageLog $identifier for MessageLog $param") unless $msg_log;

	$main::message_log->{$proto} = $msg_log if $Radius::MessageLogGeneric::protocol_to_name{$proto};
    }
}


#####################################################################
# Setters for functions to be run in various phases of operation

# Register delayed shutdown fn to be run on the beginning of radiusd
# delayed shutdown
sub register_delayed_shutdown_fn
{
    my ($self, $coderef, @args) = @_;

    # If there is DelayedShutdownTime, register it as delayed shutdown fn, register as shutdown fn
    # otherwise
    if (defined $self->{DelayedShutdownTime})
    {
	$self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: registering delayed shutdown fn from " . (caller(1))[0]);
	push (@{$self->{delayedShutdownFns}}, [$coderef, @args]);
    }
    else
    {
	$self->register_shutdown_fn($coderef, @args);
    }

    return;
}

# Register reinit fn to be run on radiusd reinit
sub register_reinit_fn
{
    my ($self, $coderef, @args) = @_;

    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: registering reinit fn from " . (caller(1))[0]);
    push (@{$self->{reinitFns}}, [$coderef, @args]);
    return;
}

# Register shutdown fn to be run on radiusd shutdown
sub register_shutdown_fn
{
    my ($self, $coderef, @args) = @_;

    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: registering shutdown fn from " . (caller(1))[0]);
    push (@{$self->{shutdownFns}}, [$coderef, @args]);
    return;
}

# Register startup fn to be run on radiusd startup
# Startup fn mimics the use of StartupHook
sub register_startup_fn
{
    my ($self, $coderef, @args) = @_;

    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: registering startup fn from " . (caller(1))[0]);
    push (@{$self->{startupFns}}, [$coderef, @args]);
    return;
}

# Register shutdown fn to be run on radiusd shutdown
sub register_childinit_fn
{
    my ($self, $coderef, @args) = @_;

    $self->log($main::LOG_EXTRA_DEBUG, "$self->{log_class_identifier}: registering childinit fn from " . (caller(1))[0]);
    push @{$self->{perchildinitFns}}, [ $coderef, @args ];
    return;
}

#####################################################################
# Getters for functions to be run in various phases of operation

# Return delayed shutdown coderefs
sub get_delayed_shutdown_fns { my ($self) = @_; return $self->{delayedShutdownFns} }

# Return reinit coderefs
# Note: concatenate with @main::reinitFns to be backwards compatible
# Note2: @main::reinitFns contains function references, when new version
# allows adding function parameters as well. This is why @main::reinitFns
# needs to be converted to arrayrefs.
sub get_reinit_fns {
    my ($self) = @_;
    my @reinitfns = map { [$_] } @main::reinitFns;
    return [@reinitfns, @{$self->{reinitFns}}];
}


# Return shutdown coderefs
sub get_shutdown_fns { my ($self) = @_; return $self->{shutdownFns} }

# Return startup coderefs
sub get_startup_fns { my ($self) = @_; return $self->{startupFns} }

# Return childinit coderefs
# note: concatenate with @main::perchildinitFns to be compatible with radiusd's main::addChildInitFn
sub get_childinit_fns { my ($self) = @_; return [@main::perchildinitFns, @{$self->{perchildinitFns}}]; }

1;
