# EAP.pm
#
# Code for handling Authentication via EAP.
# We automatically keep a Context object for each current EAP conversation.
# The key to finding the context is "eap:$nas_id:$nas_port:$calling_station$rad_user_name"
# which relies on the NAS-Id, NAS-Port and Calling-Station-ID being present
# in the Radius request to be sure of uniquely determining the context.
#
# See RFCs 2869 2284 1994
# Supports multiple types in NAK as per RFC 3748
# Supports expanded types as per RFC 3748
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2001 Open System Consultants
# $Id$

# Extends AuthGeneric
package Radius::AuthGeneric; ## no critic (Perl::Critic::Policy::Modules::RequireFilenameMatchesPackage)
use Radius::Context;
use strict;
use warnings;

# RCS version number of this module
$Radius::EAP::VERSION = '$Revision$';

# Some constants from the EAP protocol
$Radius::EAP::EAP_CODE_REQUEST = 1;
$Radius::EAP::EAP_CODE_RESPONSE = 2;
$Radius::EAP::EAP_CODE_SUCCESS = 3;
$Radius::EAP::EAP_CODE_FAILURE = 4;

# EAP types, see http://www.iana.org/assignments/ppp-numbers
$Radius::EAP::EAP_TYPE_RESERVED = 0;
$Radius::EAP::EAP_TYPE_IDENTITY = 1;
$Radius::EAP::EAP_TYPE_NOTIFICATION = 2;
$Radius::EAP::EAP_TYPE_NAK = 3;
$Radius::EAP::EAP_TYPE_MD5_CHALLENGE = 4;
$Radius::EAP::EAP_TYPE_OTP = 5;
$Radius::EAP::EAP_TYPE_TOKEN = 6;
$Radius::EAP::EAP_TYPE_TLS = 13;
$Radius::EAP::EAP_TYPE_SECURID = 15;
$Radius::EAP::EAP_TYPE_LEAP = 17;
$Radius::EAP::EAP_TYPE_SIM = 18;
$Radius::EAP::EAP_TYPE_TTLS = 21;
$Radius::EAP::EAP_TYPE_AKA = 23;
$Radius::EAP::EAP_TYPE_PEAP = 25;
$Radius::EAP::EAP_TYPE_MSCHAPV2 = 26;
$Radius::EAP::EAP_TYPE_EXTENSIONS = 33;
$Radius::EAP::EAP_TYPE_FAST = 43;
$Radius::EAP::EAP_TYPE_PAX = 46;
$Radius::EAP::EAP_TYPE_PSK = 47;
$Radius::EAP::EAP_TYPE_AKA_PRIME = 50;
$Radius::EAP::EAP_TYPE_PWD = 52;

$Radius::EAP::EAP_TYPE_EXPANDED_TYPE = 254;
$Radius::EAP::EAP_TYPE_EXPERIMENTAL = 255;

# Maps our EAPType names to EAP type numbers
# Handle a few common aliases too
%Radius::EAP::eap_name_to_type = 
(
 'MD5'               => $Radius::EAP::EAP_TYPE_MD5_CHALLENGE,
 'MD5-Challenge'     => $Radius::EAP::EAP_TYPE_MD5_CHALLENGE,
 'OTP'               => $Radius::EAP::EAP_TYPE_OTP,
 'One-Time-Password' => $Radius::EAP::EAP_TYPE_OTP,
 'GTC'               => $Radius::EAP::EAP_TYPE_TOKEN,
 'Generic-Token'     => $Radius::EAP::EAP_TYPE_TOKEN,
 'TLS'               => $Radius::EAP::EAP_TYPE_TLS,
 'SecurID'           => $Radius::EAP::EAP_TYPE_SECURID,
 'LEAP'              => $Radius::EAP::EAP_TYPE_LEAP,
 'SIM'               => $Radius::EAP::EAP_TYPE_SIM,
 'TTLS'              => $Radius::EAP::EAP_TYPE_TTLS,
 'AKA'               => $Radius::EAP::EAP_TYPE_AKA,
 'PEAP'              => $Radius::EAP::EAP_TYPE_PEAP,
 'MSCHAP-V2'         => $Radius::EAP::EAP_TYPE_MSCHAPV2,
 'FAST'              => $Radius::EAP::EAP_TYPE_FAST,
 'PAX'               => $Radius::EAP::EAP_TYPE_PAX,
 'PSK'               => $Radius::EAP::EAP_TYPE_PSK,
 'AKA-PRIME'         => $Radius::EAP::EAP_TYPE_AKA_PRIME,
 'PWD'               => $Radius::EAP::EAP_TYPE_PWD,
 );
# Reverse hash of %eap_name_to_type
%Radius::EAP::eap_type_to_name = reverse(%Radius::EAP::eap_name_to_type);

# A hash of EAP type classes we have already loaded
my %typeClasses;

#####################################################################
# authenticateUserEAP
# Called by AuthGeneric
# $self is a ref to the current AuthBy
# $user is Radius::User record for the user being authenticated
# $p is the current request
sub authenticateUserEAP
{
    my ($self, $p) = @_;

    # Must have at least one EAPType configured to continue
    return ($main::REJECT, "EAP authentication is not permitted.") 
	unless ($self->{EAPType} && @{$self->{EAPType}});

    # The EAP message may need to be concatenated, but getAttrByNum
    # does not support multiple attributes
    my ($name, $rest) = $p->{Dict}->attrByNum($Radius::Radius::EAP_MESSAGE);
    my $message = join('', $p->get_attr($name));

    return ($main::REJECT, 'Missing EAP-Message') 
	unless defined $message;

    my $message_len = length($message);
    if (!$message_len)
    {
	# Its an EAP start, send an Access-Challenge/EAP-Message/Identity
	# Do not create an EAP context yet
	my $tmp_context;
	$tmp_context->{next_id} = 1;
	$self->eap_request($p->{rp}, $tmp_context, $Radius::EAP::EAP_TYPE_IDENTITY, '');
	return ($main::CHALLENGE, 'EAP Identity Request Challenge');
    }

    # 5 because we don't handle Success or Failure codes
    if ($message_len < 5)
    {
	my ($code, $identifier) = unpack('C C', $message);
	$self->log($main::LOG_INFO, "Too short EAP message, code $code, length $message_len", $p);
	my $tmp_context; $tmp_context->{this_id} = defined $identifier ? $identifier : 0;
	$self->eap_reply($p->{rp}, $tmp_context, $Radius::EAP::EAP_CODE_FAILURE, '');
	return ($main::REJECT, "Too short EAP message, code $code, length $message_len", $p);
    }

    my ($code, $identifier, $length, $type, $typedata) = unpack('C C n C a*', $message);
    if (($message_len < $length) || ($message_len > $length + 4))
    {
	# Allow 4 octets extra in case the sender has not accounted for the fixed EAP header
	$self->log($main::LOG_INFO, "Bad EAP message length $message_len, EAP length $length", $p);
	my $tmp_context; $tmp_context->{this_id} = $identifier;
	$self->eap_reply($p->{rp}, $tmp_context, $Radius::EAP::EAP_CODE_FAILURE, '');
	return ($main::REJECT, "Bad EAP message length $message_len, EAP length $length");
    }

    my $context = ($main::config->{EAP_UseState}) ? $self->getEAPContextState($p, $code, $type) : $self->getEAPContext($p);
    unless ($context)
    {
	$self->log($main::LOG_WARNING, 'Failed to get EAP context', $p);
	my $tmp_context; $tmp_context->{this_id} = $identifier;
	$self->eap_reply($p->{rp}, $tmp_context, $Radius::EAP::EAP_CODE_FAILURE, '');
	return ($main::REJECT, 'Failed to get EAP context');
    }

    # Set up a callback to log unfinished EAP authentications
    $context->timeout_callback(\&Radius::AuthGeneric::authlog_context_timeout);

    $p->{EAPContext} = $context;

    $self->log($main::LOG_DEBUG, "Handling with EAP: code $code, $identifier, $length, $type", $p);
    $context->{this_eap_message} = $message;
    $context->{this_id} = $identifier;
    $context->{next_id} = ($identifier + 1) % 256; # May need this before the reply
    $context->{request} = $p;
    $p->{EAPIdentity} = $context->{identity}; # Sometimes useful for hooks, also %x special character
    $p->{EAPType} = $type;

    if ($code == $Radius::EAP::EAP_CODE_REQUEST)
    {
	# Request
	$self->log($main::LOG_DEBUG, "EAP Request $type", $p);
	if ($type == $Radius::EAP::EAP_TYPE_RESERVED ||
	    $type == $Radius::EAP::EAP_TYPE_EXPERIMENTAL)
	{
	    $self->log($main::LOG_INFO, "EAP reserved or experimental type: $type", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Request reserved or experimental type');
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_NOTIFICATION)
	{
	    $self->log($main::LOG_INFO, "EAP Notification: $typedata", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Request Notification');
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_IDENTITY)
	{
	    $self->log($main::LOG_INFO, "EAP Identity: $typedata", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Request Identity');
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_NAK)
	{
	    $self->log($main::LOG_INFO, "EAP NAK: $typedata", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Request NAK');
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_EXPANDED_TYPE)
	{
	    # None of our EAP methods support EAP/Request/Expanded type
	    $self->log($main::LOG_INFO, "EAP Expanded: $typedata", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Request Expanded type');
	}
	elsif ($type)
	{
	    unless (defined $context->{eap_type})
	    {
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "EAP Request type $type, but no expected type known. NAS did RADIUS server failover for an ongoing EAP authentication?");
	    }

	    unless ($context->{eap_type} == $type)
	    {
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "Mismatching EAP Request type $type, expected type $context->{eap_type}");
	    }

	    my $class = $self->getEAPClass($type)
		|| return ($main::REJECT, "Unsupported EAP Request $type");
	    $p->{EAPType} = $type;
	    $p->{EAPTypeName} = $Radius::EAP::eap_type_to_name{$type};
	    return $class->request($self, $context, $p, $type, $typedata);
	}

	# Anything else indicates a failure handling the message, should not get this far
	$self->log($main::LOG_INFO, 'Invalid EAP type in EAP request', $p);
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'Invalid EAP type in EAP request');
    }
    elsif ($code == $Radius::EAP::EAP_CODE_RESPONSE)
    {
	# Response
	$self->log($main::LOG_DEBUG, "Response type $type", $p);
	if ($type == $Radius::EAP::EAP_TYPE_RESERVED ||
	    $type == $Radius::EAP::EAP_TYPE_EXPERIMENTAL)
	{
	    $self->log($main::LOG_INFO, "EAP reserved or experimental type: $type", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Response reserved or experimental type');
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_IDENTITY)
	{
	    @{$context->{start_time}} = Radius::Util::getTimeHires();
	    delete $context->{eap_type}; delete $context->{eap_vendor}; delete $context->{eap_vendor_type};

	    # First see that identity length and charset are acceptable
	    my $max_identity_length = (defined $self->{EAP_Identity_MaxLength}) ? $self->{EAP_Identity_MaxLength} : 253;
	    if (length($typedata) > $max_identity_length)
	    {
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "EAP_Identity_MaxLength $max_identity_length exceeded. Received length " . length($typedata));
	    }

	    my $global_usernamecharset = $main::config->{UsernameCharset};
	    my $handler_usernamecharset = $p->{Handler} && $p->{Handler}->{UsernameCharset};
	    foreach my $usernamecharset ($global_usernamecharset, $handler_usernamecharset)
	    {
		next unless defined $usernamecharset;
		next unless $typedata =~ /[^$usernamecharset]/;

		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "Invalid character in EAP Identity: " . Radius::AttrVal::pclean($typedata));
	    }

	    # OK, now have the identity of the supplicant,
	    # send a challenge depending
	    # on the type of the most preferred EAP protocol
	    # we are configured to use

	    my $typename = $self->{EAPType}[0]; # Default preferred
	    # Allow an outer to enforce a preferred type
	    $typename = $p->{PreferredEAPType}
	        if    defined $p->{PreferredEAPType}
	           && grep $_ eq $p->{PreferredEAPType}, @{$self->{EAPType}};


	    $p->{EAPType} = $Radius::EAP::eap_name_to_type{$typename};
	    $p->{EAPTypeName} = $typename;
	    return ($main::REJECT, "Unknown EAP type name '$typename' for EAP Response/Identity. Check EAPType configuration parameter")
		unless $p->{EAPType};
	    my $class = $self->getEAPClass($p->{EAPType})
		|| return ($main::REJECT, "Unsupported default EAP Response/Identity $typename");
	    $context->{eap_type} = $Radius::EAP::eap_name_to_type{$typename};
	    $context->{eap_vendor} = $context->{eap_vendor_type} = undef;
	    $context->{identity} = $p->{EAPIdentity} = $typedata;
	    $context->{eap_method_state} = 'propose method';

	    my ($eap_result, $reason) = $class->response_identity($self, $context, $p, $typedata);
	    $context->{eap_result} = $eap_result;
	    return ($eap_result, $reason);
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_NOTIFICATION)
	{
	    $self->log($main::LOG_INFO, "EAP Notification: $typedata", $p);
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, 'Unexpected EAP/Response Notification');
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_NAK)
	{
	    # Legacy NAK (Response only). NAS requests a different EAP type.
	    # The type data should indicate the type
	    # of authentication desired by the supplicant

	    delete $context->{eap_type}; delete $context->{eap_vendor}; delete $context->{eap_vendor_type};
	    unless ($context->{eap_method_state} &&
		    $context->{eap_method_state} eq 'propose method')
	    {
		$self->log($main::LOG_INFO, 'Received EAP NAK in unexpected state', $p);
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, 'EAP NAK in unexpected state');
	    }

	    if (length($typedata) > 253)
	    {
		my $nak_len = length($typedata);
		$self->log($main::LOG_INFO, "Received EAP NAK with excessive length: $nak_len", $p);
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "EAP NAK excessive length: $nak_len");
	    }

	    # If the type is in our list of permitted types, use it, else reject
	    my @desired = unpack('C*', $typedata);
	    foreach (@desired)
	    {
		my $desired = $_;
		$self->log($main::LOG_DEBUG, "EAP Nak desires type $desired", $p);
		if ($desired == $Radius::EAP::EAP_TYPE_EXPANDED_TYPE)
		{
		    next unless $self->{eap_expanded_enabled};

		    # RFC 3748 5.3.1: Legacy Nak. Client indicates desire for an Expanded authentication Type
		    # Send expanded type request (Type 254). Clniet will reply
		    # with Expanded NAK and list of desired types in expanded format (see below).
		    $self->eap_request($p->{rp}, $context, $Radius::EAP::EAP_TYPE_EXPANDED_TYPE, '');
		    
		    return ($main::CHALLENGE, 'EAP Expanded Type Request Challenge');
		}
		elsif ($desired == 0)
		{
		    $self->log($main::LOG_DEBUG, "Desired EAP type 0 tells peer has no proposed alternative", $p);
		    $self->eap_failure($p->{rp}, $context);
		    return ($main::REJECT, 'EAP NAK 0 from peer: No proposed alternative');
		}
		elsif ($desired < 4 || $desired > 253)
		{
		    $self->log($main::LOG_DEBUG, "Desired EAP type $desired is invalid", $p);
		    $self->eap_failure($p->{rp}, $context);
		    return ($main::REJECT, "EAP NAK desired type $desired from peer is invalid");
		}
		elsif ($self->eap_type_permitted($desired))
		{
		    my $class = $self->getEAPClass($desired);
		    if ($class)
		    {
			$p->{EAPType} = $desired;
			$context->{eap_type} = $desired;
			$context->{eap_vendor} = $context->{eap_vendor_type} = undef;
			$p->{EAPTypeName} = $Radius::EAP::eap_type_to_name{$desired};
			my ($eap_result, $reason) = $class->response_identity($self, $context, $p);
			$context->{eap_result} = $eap_result;
			return ($eap_result, $reason);
		    }
		    $self->log($main::LOG_DEBUG, "Desired EAP type $desired not supported. This may be due to a broken client, or a problem loading the required EAP module", $p);
		}
		$self->log($main::LOG_DEBUG, "Desired EAP type $Radius::EAP::eap_type_to_name{$desired} ($desired) not permitted", $p);
		
	    }
	    $self->eap_failure($p->{rp}, $context);
	    return ($main::REJECT, "None of the desired EAP types (@desired) are available");
	}
	elsif ($type == $Radius::EAP::EAP_TYPE_EXPANDED_TYPE)
	{
	    unless ($self->{eap_expanded_enabled})
	    {
		$self->log($main::LOG_INFO, 'Received EAP Expanded type in EAP response, rejecting', $p);
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, 'Invalid EAP Expanded type in EAP response');
	    }

	    my ($vendor_high, $vendor_low, $vendor_type, $rest) = unpack('CnNa*', $typedata);
	    my $vendor = ($vendor_high << 16) | $vendor_low;
	    if ($vendor == 0 && $vendor_type == $Radius::EAP::EAP_TYPE_NAK)
	    {
		delete $context->{eap_type}; delete $context->{eap_vendor}; delete $context->{eap_vendor_type};
		unless ($context->{eap_method_state} &&
			$context->{eap_method_state} eq 'propose method')
		{
		    $self->log($main::LOG_INFO, 'Received EAP Expanded NAK in unexpected state', $p);
		    $self->eap_failure($p->{rp}, $context);
		    return ($main::REJECT, 'EAP Expanded NAK in unexpected state');
		}

		# Expanded NAK response with a list of acceptable types in expanded format
		# Look for types we can support, and if found one, send its identity response
		while (length($rest) >= 8)
		{
		    my $dummy;
		    ($dummy, $vendor_high, $vendor_low, $vendor_type, $rest) = unpack('CCnNa*', $rest);
		    my $vendor = ($vendor_high << 16) | $vendor_low;
		    if ($self->eap_type_permitted($vendor_type, $vendor))
		    {
			my $class = $self->getEAPClass($vendor_type, $vendor);
			if ($class)
			{
			    $p->{EAPType} = $vendor_type; # Not very helpful
			    # Until all classes have type_name present
			    $p->{EAPTypeName} = $vendor ? $class->type_name() 
				: $Radius::EAP::eap_type_to_name{$vendor_type};
			    $context->{eap_type} = $Radius::EAP::EAP_TYPE_EXPANDED_TYPE;
			    $context->{eap_vendor} = $vendor;
			    $context->{eap_vendor_type} = $vendor_type;
			    my ($eap_result, $reason) = $class->response_identity($self, $context, $p);
			    $context->{eap_result} = $eap_result;
			    return ($eap_result, $reason);
			}
			$self->log($main::LOG_DEBUG, "Desired EAP extended type $vendor_type, vendor $vendor not supported. This may be due to a broken client, or a problem loading the required EAP module", $p);
		    }
		}
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "None of the desired EAP extended types are available");
	    }
	    else
	    {
		# Expanded type response
		unless ($context->{eap_method_state} &&
			($context->{eap_method_state} eq 'propose method' ||
			 $context->{eap_method_state} eq 'continue'))
		{
		    $self->log($main::LOG_INFO, "Received EAP Expanded Response type $vendor_type, vendor $vendor in unexpected state", $p);
		    $self->eap_failure($p->{rp}, $context);
		    return ($main::REJECT, "EAP Expanded Response type $vendor_type, vendor $vendor in unexpected state");
		}

		$context->{eap_method_state} = 'continue';
		return ($main::REJECT, "EAP Response extended vendor type $vendor_type and vendor $vendor, but no expected vendor type and vendor known. NAS did RADIUS server failover for an ongoing EAP authentication?")
		    unless (defined $context->{eap_vendor_type} &&
			    defined $context->{eap_vendor});

		return ($main::REJECT, "Mismatching EAP Response extended type $vendor_type and vendor $vendor, expected type $context->{eap_vendor_type} vendor $context->{eap_vendor}")
		    unless ($context->{eap_vendor_type} == $vendor_type &&
			    $context->{eap_vendor} == $vendor);

		my $class = $self->getEAPClass($vendor_type, $vendor)
		    || return ($main::REJECT, "Unsupported EAP Extended type $type");
		$p->{EAPTypeName} = $class->type_name();
		my ($eap_result, $reason) = $class->response($self, $context, $p, $vendor_type, $rest);
		$context->{eap_result} = $eap_result;
		return ($eap_result, $reason);
	    }
	}
	elsif ($type)
	{
	    unless ($context->{eap_method_state} &&
		    ($context->{eap_method_state} eq 'propose method' ||
		     $context->{eap_method_state} eq 'continue' ||
		     (defined $context->{eap_type} && $context->{eap_type} == $Radius::EAP::EAP_TYPE_MSCHAPV2 && $self->{EAP_MSCHAPv2_UseMultipleAuthBys})))
	    {
		my $to_log = "EAP Response type $type in unexpected state. NAS did RADIUS server failover for an ongoing EAP authentication?";
		$self->log($main::LOG_INFO, $to_log, $p);
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, $to_log);
	    }

	    $context->{eap_method_state} = 'continue';
	    unless (defined $context->{eap_type})
	    {
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "EAP Response type $type, but no expected type known. NAS did RADIUS server failover for an ongoing EAP authentication?");
	    }

	    unless ($context->{eap_type} == $type)
	    {
		$self->eap_failure($p->{rp}, $context);
		return ($main::REJECT, "Mismatching EAP Response type $type, expected type $context->{eap_type}");
	    }

	    my $class = $self->getEAPClass($type)
		|| return ($main::REJECT, "Unsupported EAP Response $type");
	    $p->{EAPTypeName} = $Radius::EAP::eap_type_to_name{$type};
	    my ($eap_result, $reason) = $class->response($self, $context, $p, $type, $typedata);
	    $context->{eap_result} = $eap_result;
	    return ($eap_result, $reason);
	}

	# Anything else indicates a failure handling the message, should not get this far
	$self->log($main::LOG_INFO, 'Invalid EAP type in EAP response', $p);
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, 'Invalid EAP type in EAP response');
    }
    else
    {
	$self->log($main::LOG_INFO, "Unknown EAP code from client ignored: $code" , $p);
	$self->eap_failure($p->{rp}, $context);
	return ($main::REJECT, "Unknown EAP code from client: $code");
    }

    # Should not get this far, so log an error
    $self->log($main::LOG_ERR, 'Unhandled EAP message ignored', $p);
    $self->eap_failure($p->{rp}, $context);
    return ($main::REJECT, 'Unhandled EAP message');
}

#####################################################################
# Return true if the specified eap type number and vendor is permitted
sub eap_type_permitted
{
    my ($self, $type, $vendor) = @_;

    $vendor = 0 unless defined $vendor;
    foreach my $name (@{$self->{EAPType}})
    {
	return 1 if $name =~ /^(\d+):(\d+)$/ && $1 == $vendor && $2 == $type; # vendornumber:typenumber
	return 1 if $name =~ /^(\d+)$/ && $vendor == 0 && $1 == $type;    # typenumber
	return 1 if $Radius::EAP::eap_name_to_type{$name} == $type;       # typename
    }
    return; # Not permitted
}

#####################################################################
# Find a context for this request, in such a way that we always find the same 
# context for requests originating from the same user, unless its the inner request tunnelled from an outer
sub getEAPContext
{
    my ($self, $p) = @_;

    # Form up a unique key, so we can find a preexisting EAP context for this authenticatio
    # conversation.
    return $p->{EAPContext} if defined $p->{EAPContext};

    # Prevent inner requests getting the same context as outers, 
    # and get the correct one independent of changes to User-Name
    my $rad_user_name;
    if (defined $p->{OuterSSL})
    {
	$rad_user_name = $p->{outerRequest}->{EAPContext}->{eap_context_inner_key};
	unless ($rad_user_name)
	{
	    $self->log($main::LOG_ERR, 'Could not get TLS session id for context key', $p);
	    return;
	}
	$rad_user_name = "inner:$rad_user_name";
    }
    else
    {
	$rad_user_name = "outer:" . $p->getUserNameString();
    }

    my $nas_id = $p->getNasId();
    my $nas_port = $p->getAttrByNum($Radius::Radius::NAS_PORT) || 0;
    my $calling_station = $p->getAttrByNum($Radius::Radius::CALLING_STATION_ID) || 'N/A-Calling';
    my $called_station = $p->getAttrByNum($Radius::Radius::CALLED_STATION_ID) || 'N/A-Called';
    my $key = "eap:$rad_user_name:$nas_id:$nas_port:$called_station:$calling_station";
    return &Radius::Context::get($key, $self->{EAPContextTimeout});
}

#####################################################################
# Find or create a context for this request based on State attribute.
# Inner EAPS are linked to their outer EAPs.
sub getEAPContextState
{
    my ($self, $p, $code, $type) = @_;

    my $inner_key = '';
    if (defined $p->{OuterSSL})
    {
	$inner_key = $p->{outerRequest}->{EAPContext}->{eap_context_inner_key};
	unless ($inner_key)
	{
	    $self->log($main::LOG_ERR, 'Could not get TLS session id for EAP context key', $p);
	    return;
	}
    }

    my $state;
    if (   ($code == $Radius::EAP::EAP_CODE_RESPONSE && $type == $Radius::EAP::EAP_TYPE_IDENTITY)
	|| !defined $code) # For EAP-Start. Not handled here currently, but keep for now
    {
	# Start of new EAP conversation: Response/Identity or EAP-Start
	if ($inner_key)
	{
	    # At this point outer EAP is past Start and Identity
	    $state = $p->{outerRequest}->get_attr('State');
	}
	else
	{
	    $state = Radius::Util::compose_state(TraceId => $p->{trace_id},
						 StateId => unpack('H*', Radius::Util::random_string(16)));
	}
    }
    else
    {
	# Ongoing EAP conversation
	$state = $inner_key ? $p->{outerRequest}->get_attr('State') : $p->get_attr('State');
	$self->log($main::LOG_WARNING, "No State attribute in Radius request from " . Radius::Util::inet_ntop($p->{RecvFromAddress}), $p)
	    unless $state;
    }
    return unless $state;

    # We use just part of the State value for context key
    my (undef, undef, undef, $state_id) = Radius::Util::decompose_state($state);
    unless ($state_id)
    {
	$self->log($main::LOG_WARNING, 'Could not get state id from State attribute for EAP context key', $p);
	return;
    }

    my $nas_id = $p->getNasId();
    my $calling_station = $p->getAttrByNum($Radius::Radius::CALLING_STATION_ID) || 'N/A-Calling';
    my $key = "eap:$inner_key:$nas_id:$calling_station:$state_id";
    my $context = Radius::Context::get($key, $self->{EAPContextTimeout});
    $context->{state_attr} = $state unless $inner_key;

    return $context;
}

#####################################################################
# Set up EAP fields in a reply packet $p
# $code is one of EAP_CODE_*
# $message is the EAP message (if any)
sub eap_reply
{
    my ($self, $p, $context, $code, $message) = @_;

    $p->changeAttrByNum($Radius::Radius::EAP_MESSAGE, 
		      pack
		      ('C C n a*', 
		       $code,
		       $context->{this_id},
		       length($message) + 4,
		       $message));
    # The MESSAGE_AUTHENTICATOR will be filled in 
    # correctly during message packing, we just make space for it
    # here, and alert the packer to its required presence
    $p->changeAttrByNum($Radius::Radius::MESSAGE_AUTHENTICATOR, "\000" x 16);
}

#####################################################################
# Build an EAP Request field in a reply packet $p
# $message is the EAP message (if any)
# Handle long messages by dividing into multiple EAP_MESSAGE
# attributes
sub eap_request
{
    my ($self, $p, $context, $type, $message, $msg_proc) = @_;

    my $m = pack
	('C C n C a*', 
	 $Radius::EAP::EAP_CODE_REQUEST,
	 $context->{next_id},
	 length($message) + 5,
	 $type,
	 $message);

    # Maybe call a processing function on the fully assembled message.
    # Useful for in-band MACs etc
    &$msg_proc($self, $p, $context, $m) if $msg_proc;

    # Divide into multiple instances of EAP-Message, leave enough
    # room in each in each one for the radius attribute id and length
#    my $x = unpack('H*', $m);
#    print "eap_request: $x\n";
    $p->deleteAttrByNum($Radius::Radius::EAP_MESSAGE); # Make sure there is not an old one there
    my $mpart;
    while (length($mpart = substr($m, 0, 253, '')))
    {
	$p->addAttrByNum($Radius::Radius::EAP_MESSAGE, $mpart);
    }

    # Tunnelled inner EAPs may have not State
    $p->add_attr('State', $context->{state_attr}) if defined $context->{state_attr};

    # The MESSAGE_AUTHENTICATOR will be filled in 
    # correctly during message packing, we just make space for it
    # here, and alert the packer to its required presence
    $p->changeAttrByNum($Radius::Radius::MESSAGE_AUTHENTICATOR, "\000" x 16);
}

#####################################################################
# Build an EAP expanded type Request field in a reply packet $p
# $message is the EAP message (if any)
# Handle long messages by dividing into multiple EAP_MESSAGE
# attributes
sub eap_request_expanded
{
    my ($self, $p, $context, $type, $vendor, $message, $msg_proc) = @_;

    my $m = pack
	('C C n N N a*', 
	 $Radius::EAP::EAP_CODE_REQUEST,
	 $context->{next_id},
	 length($message) + 12,
	 $vendor | ($Radius::EAP::EAP_TYPE_EXPANDED_TYPE << 24),
	 $type,
	 $message);

    # Maybe call a processing function on the fully assembled message.
    # Useful for in-band MACs etc
    &$msg_proc($self, $p, $context, $m) if $msg_proc;

    # Divide into multiple instances of EAP-Message, leave enough
    # room in each in each one for the radius attribute id and length
#    my $x = unpack('H*', $m);
#    print "eap_request: $x\n";
    $p->deleteAttrByNum($Radius::Radius::EAP_MESSAGE); # Make sure there is not an old one there
    my $mpart;
    while (length($mpart = substr($m, 0, 253, '')))
    {
	$p->addAttrByNum($Radius::Radius::EAP_MESSAGE, $mpart);
    }
    # The MESSAGE_AUTHENTICATOR will be filled in 
    # correctly during message packing, we just make space for it
    # here, and alert the packer to its required presence
    $p->changeAttrByNum($Radius::Radius::MESSAGE_AUTHENTICATOR, "\000" x 16);
}

#####################################################################
# Methods to save and recover information that needs to be stored over
# resumed TLS sessions. Some information is saved and recovered
# automatically and functions are provided for additional access from
# Hooks for customisation.

# Save some of the EAP context for TLS resume.
# $p is the current request
# $context contains the information that needs to be retained
sub eap_save_resume_context
{
    my ($self, $p, $context) = @_;

    # eap_resume_context is not created for all EAP methods
    my $resume_context = $context->{eap_resume_context};
    if ($resume_context)
    {
	$resume_context->{inner_auth_success} = $context->{inner_auth_success};
	$resume_context->{inner_identity} = $context->{inner_identity};
	$resume_context->{inner_username} = $context->{inner_username};
	$resume_context->{tls_authenticated_cn} = $context->{tls_authenticated_cn};
	$resume_context->{last_reply_attrs} = $context->{last_reply_attrs};
    }
}

# Recover to EAP context what was previously saved by
# eap_save_resume_context
# $p is the current request
# $context is our context for the newly resumed TLS session
# $resume_context contains what was saved earlier
sub eap_recover_resume_context
{
    my ($self, $p, $context, $resume_context) = @_;

    # Note: be careful to copy only the keys that are part of the
    # resume context. Do not overwrite id, _timeouthandle etc.
    $context->{eap_resume_context} = $resume_context;
    $context->{inner_auth_success} = $resume_context->{inner_auth_success};
    $context->{inner_identity} = $resume_context->{inner_identity};
    $context->{inner_username} = $resume_context->{inner_username};
    $context->{tls_authenticated_cn} = $resume_context->{tls_authenticated_cn};
    $context->{last_reply_attrs} = $resume_context->{last_reply_attrs};

}

# Copies the keys from EAP context to resume context for storage over
# resumed TLS sessions. May be used from Hooks.
# Keys not present in EAP context are silently skipped.
# $p is the current request
# $context is the EAP context
# Returns 0 if resume context was not found
# Returns 1 for success
sub eap_copy_to_resume_context
{
    my ($p, $context, @keys) = @_;

    my $resume_context = $context->{eap_resume_context};
    unless ($resume_context)
    {
	# If TLS session was not accepted, context was not recovered
	main::log($main::LOG_ERR, "EAP No resume context to copy to", $p);
	return 0;
    }

    foreach my $key (@keys)
    {
	next unless exists $context->{$key};
	$resume_context->{$key} = $context->{$key};
    }

    return 1;
}

# Copies the keys from resume context to the current EAP context. May
# be used from Hooks.
# Keys not present in resume context are silently skipped.
# $p is the current request
# $context is the EAP context
# Returns 0 if resume context was not found
# Returns 1 for success
sub eap_copy_from_resume_context
{
    my ($p, $context, @keys) = @_;

    my $resume_context = $context->{eap_resume_context};
    unless ($resume_context)
    {
	# If TLS session was not accepted, context was not recovered
	main::log($main::LOG_DEBUG, "EAP No resume context to copy from", $p);
	return 0;
    }

    foreach my $key (@keys)
    {
	next unless exists $resume_context->{$key};
	$context->{$key} = $resume_context->{$key};
    }

    return 1;
}

# Adds to reply attributes returned by inner authentication. May be
# used from Hooks.
# $p is the current request
# $context is the EAP context
# $name and $value are the attribute and its value to add
# Returns 0 if resume context was not found
# Returns 1 if reply attributes were present in resume context
# Returns 2 if reply attributes were not present in resume context
sub eap_copy_to_resume_attrs
{
    my ($p, $context, $name, $value) = @_;

    my $resume_context = $context->{eap_resume_context};
    unless ($resume_context)
    {
	main::log($main::LOG_DEBUG, "EAP No resume context to copy attributes to", $p);
	return 0;
    }
    unless ($resume_context->{last_reply_attrs})
    {
	main::log($main::LOG_DEBUG, "EAP No last_reply_attrs in resume context. Not copying anything", $p);
	return 2;
    }

    $resume_context->{last_reply_attrs}->add_attr($name, $value);

    return 1;
}

#####################################################################
# Build an EAP success packet
# $p is the reply packet we are building
sub eap_success
{
    my ($self, $p, $context) = @_;

    $context->{eap_method_state} = 'end';

    # Save anything needed after session resumption
    $self->eap_save_resume_context($p, $context);

    my $interval = Radius::Util::timeInterval(@{$context->{start_time}}, Radius::Util::getTimeHires());
    $self->log($main::LOG_DEBUG, "EAP Success, elapsed time $interval", $p);
    $self->eap_reply($p, $context, $Radius::EAP::EAP_CODE_SUCCESS, '');
}

#####################################################################
# Build an EAP failure packet
# $p is the reply packet we are building
sub eap_failure
{
    my ($self, $p, $context) = @_;

    $context->{eap_method_state} = 'end';

    # In case we failed before EAP-Respose/Identity
    @{$context->{start_time}} = Radius::Util::getTimeHires() unless $context->{start_time};

    my $interval = Radius::Util::timeInterval(@{$context->{start_time}}, Radius::Util::getTimeHires());
    delete $context->{start_time}; # Can go when EAP_UseState is always on
    $interval = sprintf("%.6f", $interval);
    $self->log($main::LOG_DEBUG, "EAP Failure, elapsed time $interval", $p);
    $self->eap_reply($p, $context, $Radius::EAP::EAP_CODE_FAILURE, '');
}

#####################################################################
# Call this when an EAP TLS handshake fails. Normally such a failure would 
# result in IGNORE, but in some circumstances we want to REJECT instead
sub eap_error
{
    my ($self, $message) = @_;

    return ($self->{EAPErrorReject} ? $main::REJECT : $main::IGNORE, $message);
}

#####################################################################
# Similar to Radius::rewriteUsername but for EAP identity.
sub eap_rewrite_identity
{
    my ($self, $p, $identity, $rules) = @_;

    foreach my $rule (@{$rules})
    {
	# We use an eval so an error in the pattern wont kill us.
	eval("\$identity =~ $rule"); ## no critic (Perl::Critic::Policy::BuiltinFunctions::ProhibitStringyEval)
	$self->log($main::LOG_ERR, "Error while rewriting EAP identity $identity: $@", $p)
	    if $@;
	$self->log($main::LOG_DEBUG, "Rewrote EAP identity to $identity", $p);
    }

    return $identity;
}

#####################################################################
# Given an EAP protocol type number and perhaps type vendor, return
# the class name of the module that has been already loaded.
# If the vendor is undefined, assume IETF vendor 0
sub getEAPClass
{
    my ($self, $type, $vendor) = @_;

    $vendor = 0 unless defined $vendor;
    return $self->{eap_typeClasses}{$vendor}{$type} if exists $self->{eap_typeClasses}{$vendor}{$type};
    return undef;
}

#####################################################################
# Calculate the MSK using the TLS PRF and the TLS master secret
# Possibly set the MPPE send and recv keys in the reply
# Using the TLS master secret, work out the asymmetrical master keys
# and set them in the reply packet.
# Also export the MSK and EMSK if required
sub setTLSMppeKeys
{
    my ($self, $context, $p, $key) = @_;

    my ($msk, $emsk);
    if ($self->{ExportEMSK})
    {
	# Need to do more work
	($msk, $emsk) = unpack('a64 a64', &Radius::TLS::PRF($context, $key, 128));
	$p->{rp}->{msk} = $msk;
	$p->{rp}->{emsk} = $emsk;
    }
    else
    {
	$msk = $p->{rp}->{msk} = &Radius::TLS::PRF($context, $key, 64);
    }
    if ($self->{AutoMPPEKeys})
    {
	my ($send, $recv) = unpack('a32 a32', $msk);
	# Note these are swapped because its for the AP end of the encryption
	$p->{rp}->change_attr('MS-MPPE-Send-Key', $recv);
	$p->{rp}->change_attr('MS-MPPE-Recv-Key', $send);

	# Return EAP Session-ID with EAP-Key-Name attribute required
	# by MACsec, if requested by the NAS. RFC 7268 specifies that
	# with RADIUS, NAS must send single NUL character. RFC 4072
	# specifies that with Diameter the value must be
	# empty. However, some vendors use empty value with RADIUS.
	my $eapkeyname = $p->get_attr('EAP-Key-Name');
	if (defined $eapkeyname && ($eapkeyname eq "\000" || $eapkeyname eq ""))
	{
	    my $method = $context->{eap_type};

	    # With TLS based methods server_random and client_random
	    # are used to create EAP Session-Id
	    if ($method == $Radius::EAP::EAP_TYPE_TLS  ||
		$method == $Radius::EAP::EAP_TYPE_PEAP ||
		$method == $Radius::EAP::EAP_TYPE_TTLS)
	    {
		my $server_random = Net::SSLeay::get_server_random($context->{ssl});
		my $client_random = Net::SSLeay::get_client_random($context->{ssl});
		my $method_id = $client_random . $server_random;
		my $type_code = pack('C', $method);
		my $session_id = $type_code . $method_id;
		$p->{rp}->change_attr('EAP-Key-Name', $session_id);
	    }
	}
    }
}

1;
