# MessageLogFILE.pm
#
# Log incoming and outgoing RADIUS, Diameter and TACACS+ messages to a
# file
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::MessageLogFILE;
@ISA = qw(Radius::MessageLogGeneric);
use Radius::MessageLogGeneric;
use Radius::Util;
use strict;
use warnings;

%Radius::MessageLogFILE::ConfigKeywords =
(
 'Filename' =>
 ['string', 'This is the name of the file to log statistics to. Defaults to %L/messagelog. The file name can include special formatting characters.', 0],

 'Format' =>
 ['enum', 'This optional parameter defines the file output format. Possible values are: text and text2pcap. Unknown values default to text which is also the default value.', 0, \@Radius::MessageLogFILE::file_format_enum],

 'Encoding' =>
 ['enum', 'This optional parameter defines the file encoding. Possible values are: none and hex. Unknown values default to no encoding which is also the default value.', 0, \@Radius::MessageLogFILE::file_encoding_enum],

);

# RCS version number of this module
$Radius::MessageLogFILE::VERSION = '$Revision$';

@Radius::MessageLogFILE::file_format_enum = qw(text text2pcap);

@Radius::MessageLogFILE::file_encoding_enum = qw(none hex);

#####################################################################
# Do per-instance default initialization
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;

    # This allows registering new formatters later
    $self->{radius_formatters} =
    {
	text2pcap => \&format_radius_text2pcap,
	text => \&format_radius_text,
    };

    $self->{diameter_formatters} =
    {
	text2pcap => \&format_diameter_text2pcap,
	text => \&format_diameter_text,
    };

    $self->{tacacsplus_formatters} =
    {
	text2pcap => \&format_tacacsplus_text2pcap,
	text => \&format_tacacsplus_text,
    };

    $self->{messagelog_encoders} =
    {
	none => undef,
	hex => sub {unpack('H*', $_[0]) . "\n";}, # Single row for an entry
    };

    $self->{Filename} = "%L/messagelog";
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();
}

#####################################################################
# RADIUS formatters

# Log a RADIUS message to a file
sub log_radius_msg
{
    my ($self, $p, $from_ip, $from_port, $to_ip, $to_port, $data, $message_log_proto) = @_;

    my $format = $self->{Format} || $Radius::MessageLogFILE::file_format_enum[0];
    my $encoding = $self->{Encoding} || $Radius::MessageLogFILE::file_encoding_enum[0];
    my $filename = Radius::Util::format_special($self->{Filename}, $p, $self, $message_log_proto, $format, $encoding);

    my $formatter = $self->{radius_formatters}->{$format};
    my $message = &{$formatter}($self, $p, $data, $filename, $from_ip, $from_port, $to_ip, $to_port);

    my $encoder = $self->{messagelog_encoders}->{$encoding};
    $message = &{$encoder}($message) if $encoder;

    Radius::Util::append($filename, $message)
	|| warn "MessageLog could not append '$message' to log file '$filename': $!";
}

# Returns log message in Radiator Trace 5 dump format
# We don't need to know the file name here.
sub format_radius_text
{
    my ($self, $p, $data, undef, $from_ip, $from_port, $to_ip, $to_port) = @_;

    my ($sec, $usec) = $p->{RecvTime} ?
	($p->{RecvTime}, $p->{RecvTimeMicros}) :
	Radius::Util::getTimeHires();

    $from_ip = Radius::Util::inet_ntop($from_ip);
    $to_ip   = Radius::Util::inet_ntop($to_ip);
    my $t = "$sec.$usec " . localtime() . "\n";
    $t .= "RADIUS message from $from_ip port $from_port to $to_ip port $to_port ....\n";
    $t .= "Packet length = " . length($data) . "\n";

    for (my $i = 0; $i < length($data); $i += 16)
    {
	$t .= join ' ', map {sprintf "%02x", $_} unpack('C16', substr($data, $i, 16));
	$t .= "\n";
    }

    return $t . $p->dump() . "\n";
}

# Returns log message in format text2pcap understands
# We don't need to know the file name here.
sub format_radius_text2pcap
{
    my ($self, $p, $data, undef, $from_ip, $from_port, $to_ip, $to_port) = @_;

    my ($sec, $usec) = $p->{RecvTime} ?
	($p->{RecvTime}, $p->{RecvTimeMicros}) :
	Radius::Util::getTimeHires();

    $from_ip = Radius::Util::inet_ntop($from_ip);
    $to_ip   = Radius::Util::inet_ntop($to_ip);
    my $t = "##TEXT2PCAP -t %s. -i 17 -4 $from_ip,$to_ip -u $from_port,$to_port\n";
    $t .= sprintf('%d.%06d', $sec, $usec) . " 0000 ";
    $t .= join ' ', map {sprintf "%02x", $_} unpack('C*', $data);

    return "$t\n";
}

#####################################################################
# Diameter formatters

# Log a Diameter message to a file
sub log_diameter_msg
{
    my ($self, $m, $from_ip, $from_port, $to_ip, $to_port, $data) = @_;

    my $format = $self->{Format} || $Radius::MessageLogFILE::file_format_enum[0];
    my $encoding = $self->{Encoding} || $Radius::MessageLogFILE::file_encoding_enum[0];
    my $filename = Radius::Util::format_special($self->{Filename}, undef, $self, 'diameter', $format, $encoding);

    my $formatter = $self->{diameter_formatters}->{$format};
    my $message = &{$formatter}($self, $m, $data, $filename, $from_ip, $from_port, $to_ip, $to_port);

    my $encoder = $self->{messagelog_encoders}->{$encoding};
    $message = &{$encoder}($message) if $encoder;

    Radius::Util::append($filename, $message)
	|| warn "MessageLog could not append '$message' to log file '$filename': $!";
}

# Returns log message in Radiator Trace 5 dump format
# We don't need to know the file name here.
sub format_diameter_text
{
    my ($self, $m, $data, undef, $from_ip, $from_port, $to_ip, $to_port) = @_;

    my ($sec, $usec) = Radius::Util::getTimeHires();

    $from_ip = Radius::Util::inet_ntop($from_ip);
    $to_ip = Radius::Util::inet_ntop($to_ip);
    my $t = "$sec.$usec " . localtime() . "\n";
    $t .= "Diameter message from $from_ip port $from_port to $to_ip port $to_port ....\n";
    $t .= "Packet length = " . length($data) . "\n";

    for (my $i = 0; $i < length($data); $i += 16)
    {
	$t .= join ' ', map {sprintf "%02x", $_} unpack('C16', substr($data, $i, 16));
	$t .= "\n";
    }

    return "$t\n";
}

# Returns log message in format text2pcap understands
# We don't need to know the file name here.
sub format_diameter_text2pcap
{
    my ($self, $m, $data, undef, $from_ip, $from_port, $to_ip, $to_port) = @_;

    my ($sec, $usec) = Radius::Util::getTimeHires();

    $from_ip = Radius::Util::inet_ntop($from_ip);
    $to_ip   = Radius::Util::inet_ntop($to_ip);
    my $t = "##TEXT2PCAP -t %s. -i 132 -4 $from_ip,$to_ip -S $from_port,$to_port,0\n";
    $t .= sprintf('%d.%06d', $sec, $usec) . " 0000 ";
    $t .= join ' ', map {sprintf "%02x", $_} unpack('C*', $data);

    return "$t\n";
}

#####################################################################
# TACACS+ formatters

# Log a TACACS+ message to a file
sub log_tacacsplus_msg
{
    my ($self, $conn, $from_ip, $from_port, $to_ip, $to_port, $data) = @_;

    my $format = $self->{Format} || $Radius::MessageLogFILE::file_format_enum[0];
    my $encoding = $self->{Encoding} || $Radius::MessageLogFILE::file_encoding_enum[0];
    my $filename = Radius::Util::format_special($self->{Filename}, undef, $self, 'tacacsplus', $format, $encoding);

    my $formatter = $self->{tacacsplus_formatters}->{$format};
    my $message = &{$formatter}($self, $conn, $data, $filename, $from_ip, $from_port, $to_ip, $to_port);

    my $encoder = $self->{messagelog_encoders}->{$encoding};
    $message = &{$encoder}($message) if $encoder;

    Radius::Util::append($filename, $message)
	|| warn "MessageLog could not append '$message' to log file '$filename': $!";
}

# Returns log message in Radiator Trace 5 dump format
# We don't need to know the file name here.
sub format_tacacsplus_text
{
    my ($self, $conn, $data, undef, $from_ip, $from_port, $to_ip, $to_port) = @_;

    my ($sec, $usec) = Radius::Util::getTimeHires();

    $from_ip = Radius::Util::inet_ntop($from_ip);
    $to_ip = Radius::Util::inet_ntop($to_ip);
    my $t = "$sec.$usec " . localtime() . "\n";
    $t .= "TACACS+ message from $from_ip port $from_port to $to_ip port $to_port ....\n";
    $t .= "Packet length = " . length($data) . "\n";

    for (my $i = 0; $i < length($data); $i += 16)
    {
	$t .= join ' ', map {sprintf "%02x", $_} unpack('C16', substr($data, $i, 16));
	$t .= "\n";
    }

    return "$t\n";
}

# Returns log message in format text2pcap understands
# We don't need to know the file name here.
sub format_tacacsplus_text2pcap
{
    my ($self, $conn, $data, undef, $from_ip, $from_port, $to_ip, $to_port) = @_;

    my ($sec, $usec) = Radius::Util::getTimeHires();

    $from_ip = Radius::Util::inet_ntop($from_ip);
    $to_ip   = Radius::Util::inet_ntop($to_ip);
    my $t = "##TEXT2PCAP -t %s. -i 6 -4 $from_ip,$to_ip -T $from_port,$to_port\n";
    $t .= sprintf('%d.%06d', $sec, $usec) . " 0000 ";
    $t .= join ' ', map {sprintf "%02x", $_} unpack('C*', $data);

    return "$t\n";
}

1;
