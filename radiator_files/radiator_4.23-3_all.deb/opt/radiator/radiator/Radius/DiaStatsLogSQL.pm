# DiaStatsLogSQL.pm
#
# Log DIAMETER statistics to SQL
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::DiaStatsLogSQL;
@ISA = qw(Radius::DiaStatsLogGeneric Radius::SqlDb);
use Radius::DiaStatsLogGeneric;
use Radius::SqlDb;
use strict;
use warnings;


%Radius::DiaStatsLogSQL::ConfigKeywords =
(
 'InsertQuery' =>
 ['string', 'This optional parameter specifies the SQL query to be used for each log. It can include special formatting characters. Specials starting from %0 are replaced by statistics data as described in the Radiator Reference manual. If InsertQuery is not defined then a standard set of statistics will be logged', 1],

 'TableName' =>
 ['string', 'Name of the SQL table to insert into. Defaults to RADDIASTATSLOG', 1],
);

# RCS version number of this module
$Radius::DiaStatsLogSQL::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->Radius::DiaStatsLogGeneric::initialize();
    $self->Radius::SqlDb::initialize();

    $self->{PeerStatsPrefix} = 'PEER_';
    $self->{TotalStatsPrefix} = 'TOTAL_';
    $self->{TableName} = 'RADDIASTATSLOG';

    return;
}

sub check_config
{
    my ($self) = @_;

    $self->Radius::DiaStatsLogGeneric::check_config();
    $self->Radius::SqlDb::check_config();

    return;
}

sub activate
{
    my ($self) = @_;

    $self->Radius::DiaStatsLogGeneric::activate();
    $self->Radius::SqlDb::activate();

    return;
}

sub logObject
{
    my ($self, $diastats) = @_;

    return unless $self->reconnect();
    my $time = time();

    # Try to find name for application code.
    $diastats->{ApplicationID_text} = $Radius::DiaMsg::appcode_to_name{$diastats->{ApplicationID}}
        if ($diastats->{stats_type} eq $Radius::DiaStatsLogGeneric::STATS_TYPE{peer} &&
	    exists $Radius::DiaMsg::appcode_to_name{$diastats->{ApplicationID}});

    my $peer_port = ($diastats->{DiaPeerPort}) ? "," . $diastats->{DiaPeerPort} : '';
    my $peer_name = ($diastats->{DiaPeerIP}) ? $diastats->{DiaPeerIP} . $peer_port : 'total';
    my $origin_realm = ($diastats->{OriginRealm}) ? $diastats->{OriginRealm} : 'total';
    my $origin_host = ($diastats->{OriginHost}) ? $diastats->{OriginHost} : 'total';
    my $application = ($diastats->{ApplicationID_text}) ? $diastats->{ApplicationID_text} : (defined $diastats->{ApplicationID}) ? $diastats->{ApplicationID} : 'total';

    # Quoting at this point avoids possible multiple quotes
    $peer_name = $self->quote($peer_name);
    $origin_realm = $self->quote($origin_realm);
    $origin_host = $self->quote($origin_host);

    my $q;
    no warnings "uninitialized";
    if (defined $self->{InsertQuery})
    {
	$q = Radius::Util::format_special
	    ($self->{InsertQuery}, undef, undef,
	     $time, $diastats->{stats_type}, $peer_name, $origin_realm, $origin_host, $application,
	     map 0 + $diastats->{derivative_counters}->{$_},
	     sort keys %{$diastats->{derivative_counters}});
    }
    else
    {
	my $cols = join(',', 'TIME_STAMP', 'TYPE', 'PEER', 'ORIGIN_REALM', 'ORIGIN_HOST',
			map uc $_, sort keys %{$diastats->{derivative_counters}});
	my $vals = join(',', $time, $self->quote($diastats->{stats_type}), $peer_name, $origin_realm, $origin_host,
			map 0 + $diastats->{derivative_counters}->{$_},
			sort keys %{$diastats->{derivative_counters}});
	$q = "insert into $self->{TableName} ($cols) values ($vals)";
    }
    $self->do($q);

    return;
}

1;
