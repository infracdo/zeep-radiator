# AES_GCM.pm
#
# Radiator module implementing AES encryption in GCM mode
# Crypt::GCM is used for GCM mode
# Crypt::Rijndael is used for AES encryption
# Digest::SHA is used to make salt
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AES_GCM;
use Radius::PBKDF;
use Crypt::GCM;
use Crypt::Rijndael;
use Digest::SHA;
use strict;
use warnings;

# RCS version number of this module
$Radius::AES_GCM::VERSION = '$Revision$';

sub encrypt
{
    my ($key, $nonce, $data, $aad) = @_;

    my $c = Crypt::GCM->new(
        -key => $key,
        -cipher => 'Crypt::Rijndael',
	);

    $c->set_iv($nonce);
    $c->aad($aad);

    my $enc_data = $c->encrypt($data);
    my $tag = $c->tag();

    return ($enc_data, $tag);
}

sub decrypt
{
    my ($key, $nonce, $data, $aad, $tag) = @_;

    my $c = Crypt::GCM->new(
        -key => $key,
        -cipher => 'Crypt::Rijndael',
	);

    $c->set_iv($nonce);
    $c->aad($aad);
    $c->tag($tag);
    my $dec_data = $c->decrypt($data);

    return $dec_data;
}

sub make_key
{
    my ($passphrase, $key_length, $rounds) = @_;

    $rounds = 100000 unless defined $rounds;
    my $salt = Digest::SHA::sha256_hex($passphrase);
    $key_length = 32 unless defined $key_length;

    my $key = Radius::PBKDF::pbkdf2_hmac_sha256($passphrase, $salt, $rounds, $key_length);

    return $key;
}

1;
