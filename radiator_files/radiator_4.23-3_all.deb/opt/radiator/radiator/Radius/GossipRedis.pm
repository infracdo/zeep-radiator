# GossipRedis.pm
#
# Gossip implementation using Redis Pub/Sub connections.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::GossipRedis;
@ISA = qw(Radius::Gossip);
use Radius::Gossip;
use Radius::Util;
use Radius::Select;
use Redis;
use strict;
use warnings;

%Radius::GossipRedis::ConfigKeywords =
(
 'Host' =>
 ['string', 'Specifies Redis server to connect to. Defaults to 127.0.0.1 if Host, Sock or Sentinels is not specified.', 0],

 'Port' =>
 ['string', 'This optional parameter specifies the symbolic service name or port number of the Redis server. Defaults to 6379.', 1],

 'Sentinels' =>
 ['splitstringarray', 'Specifies Redis Sentinels to connect to.', 1],

 'Sock' =>
 ['string', 'Specifies Unix domain socket to connect to Redis server.', 1],

 'SentinelService' =>
 ['string', 'Specifies the name of the service to connect to. Defaults to \'mymaster\'.', 1],

 'SentinelPort' =>
 ['string', 'This optional parameter specifies the symbolic service name or port number of the Sentinels. Defaults to 26379.', 1],

 'Password' =>
 ['string', 'Specifies a password to be used to login the Redis host.', 1],

 'Prefix' =>
 ['string', "Specifies the prefix for the Redis connection name, pubsub channels and get/set keys. Defaults to 'radiator'", 1],

 'InstanceId' =>
 ['string', "Specifies the instance specific part of the Redis connection name and pubsub channels. Special formatting characters are supported. Defaults to '%h.%O' (hostname and farm instance number)", 1],

 'Timeout' =>
 ['integer', 'Sets the connection and command timeout period in seconds for the connection to the Redis server. Defaults to 1 second.', 1],

 'FailureBackoffTime' =>
 ['integer', 'If Radiator detects a Redis server failure, it will wait for this number of seconds before trying to contact the Redis server again. Defaults to 10 seconds.', 1],

 'DbIndex' =>
 ['integer', 'Specifies a Redis DB index. Defaults to 0.', 2],
);

# RCS version number of this module
$Radius::GossipRedis::VERSION = '$Revision$';

# Make sure we get reinitialized on sighup
push(@main::reinitFns, \&reinitialize);

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{Host} = undef;
    $self->{Port} = 6379;
    $self->{Sock} = undef;
    $self->{Sentinels} = undef;
    $self->{SentinelService} = undef;
    $self->{SentinelPort} = 26379;

    $self->{Prefix} = 'radiator';
    $self->{InstanceId} = "%h.%O"; # hostname . farm_instance

    $self->{Password} = undef;
    $self->{Timeout} = 1;
    $self->{FailureBackoffTime} = 10;
    $self->{DbIndex} = 0;
    $self->{RedisEndpoint} = "";

    $self->{ObjType} = 'Gossip'; # Auto register with Configurable

    # Redis sockets
    $self->{redis} = undef;
    $self->{redis_pubsub} = undef;
    $self->{redis_connected} = 0;
    $self->{redis_subscribed} = 0;
    $self->{pubsub_callback} = undef;
    $self->{reconnect_in_progress} = 0;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    unless ($self->{Sock} || $self->{Host} || $self->{Sentinels})
    {
	$self->log($main::LOG_WARNING, "No Sock, Host or Sentinels defined for Redis in '$main::config_file'. Setting redis host to 127.0.0.1.");
	$self->{Host} = '127.0.0.1';
    }

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    $self->{ConnectionName} = $self->{Prefix} . ':' . $self->{InstanceId};
    $self->{ConnectionName} .= ":$self->{Identifier}" if $self->{Identifier};

    $self->{MyChannel} = $self->{Prefix} . ':' . Radius::Util::format_special($self->{InstanceId});
    $self->{PubSubChannel} = $self->{Prefix};

    $self->{SentinelService} = "mymaster" if defined $self->{Sentinels} && ! defined $self->{SentinelService};
    if (defined $self->{Sentinels})
    {
	$self->{RedisEndpoint} = 'Sentinel service ' . $self->{SentinelService} . ', sentinels: ' . join(', ', @{$self->{Sentinels}});
    }
    else
    {
	$self->{RedisEndpoint} = 'server ' . $self->{Host} . ":" . $self->{Port} if defined $self->{Host};
	$self->{RedisEndpoint} = 'server ' . $self->{Sock} if defined $self->{Sock} && ! defined $self->{Host};
    }

    if (defined $self->{Sentinels})
    {
	foreach (@{$self->{Sentinels}})
	{
	    $_ .= ":$self->{SentinelPort}" if ! /:\d+$/;
	}
    }

    $self->{pubsub_callback} = sub {
	my ($message, $topic, $subscribed_topic) = @_;

	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Redis message was received from channel '$topic'")
	    if $self->{Debug};

	$self->handle_message_received($message);
    };

    try_reconnect_redis(undef, $self);

    $Radius::Gossip::handle = $self;

    # Register the function that is called for each farm instance
    main::addChildInitFn(\&Radius::GossipRedis::childInit, $self);
}

# Farm supervisor process call this after forking a new worker
sub childInit
{
    my ($self) = @_;

    # Each farm worker holds its own Gossip connection
    if ($Radius::Gossip::handle)
    {
        my $parents_gossip_handle = $Radius::Gossip::handle;
        $parents_gossip_handle->reinitialize();
        $parents_gossip_handle->activate();
    }

    return;
}

# This will DESTROY any redis client left from a previous initialization
# Note: logging will not likely work during reinitialize. Use print if
# you need to debug
sub reinitialize
{
    if ($Radius::Gossip::handle)
    {
	if ($Radius::Gossip::handle->{redis})
	{
	    exec_redis_call($Radius::Gossip::handle, sub {
		$_[0]->{redis}->quit();
		#print ("GossipRedis: The query socket to Redis server was closed\n");
			    });
	}

	if ($Radius::Gossip::handle->{redis_subscribed} && $Radius::Gossip::handle->{redis_pubsub})
	{
	    Radius::Select::remove_file($Radius::Gossip::handle->{redis_pubsub}->{sock}->fileno, 1, undef, undef) if defined $Radius::Gossip::handle->{redis_pubsub}->{sock};
	    #print ("GossipRedis: Removing the Redis pubsub socket from Radius::Select\n");
	}

	if ($Radius::Gossip::handle->{redis_pubsub})
	{
	    exec_redis_call($Radius::Gossip::handle, sub {
		$_[0]->{redis_pubsub}->quit();
		#print ("GossipRedis: The pubsub socket to Redis server was closed\n");
			    });
	}

	$Radius::Gossip::handle->{redis_subscribed} = 0;
	$Radius::Gossip::handle->{redis_connected} = 0;
	$Radius::Gossip::handle = undef;
    }

    return;
}

sub try_reconnect_redis {
    my ($handle, $self) = @_;

    $self->connect_redis() unless $self->{redis_connected};

    unless ($self->{redis_connected})
    {
	if ($self->{FailureBackoffTime})
	{
	    # Schedule a reconnect attempt
	    $self->log($main::LOG_INFO, "$self->{log_class_identifier}: Will try to reconnect in $self->{FailureBackoffTime} second(s)");
	    Radius::Select::add_timeout(time + $self->{FailureBackoffTime}, \&try_reconnect_redis, $self);
	    $self->{reconnect_in_progress} = 1;
	}
    }

    return;
}

sub connect_redis {
    my ($self) = @_;

    $self->log($main::LOG_INFO, "$self->{log_class_identifier}: Trying to connect to Redis $self->{RedisEndpoint}");

    # create Redis object for querying
    $self->{redis} = $self->exec_redis_call(sub {
	my %params = (
	    cnx_timeout => $self->{Timeout},
	    sentinels_cnx_timeout => $self->{Timeout},
	    read_timeout => $self->{Timeout},
	    sentinels_read_timeout => $self->{Timeout},
	    write_timeout => $self->{Timeout},
	    sentinels_write_timeout => $self->{Timeout},
	    name => Radius::Util::format_special($self->{ConnectionName}),
	    debug => $self->{Debug},
	);
	$params{sentinels} = $self->{Sentinels} if defined $self->{Sentinels};
	$params{service} = $self->{SentinelService} if defined $self->{SentinelService};
	$params{password} = $self->{Password} if defined $self->{Password};

	# Configure sock, host and port if there are no Sentinels configured
	unless (defined $self->{Sentinels})
	{
	    $params{sock} = $self->{Sock} if defined $self->{Sock} && ! defined $self->{Host};
	    $params{server} = $self->{Host} . ":" . $self->{Port} if ! defined $self->{Sock} && defined $self->{Host};
	}

	my $r = Redis->new(%params);
	$r->select($self->{DbIndex});

	return $r;
					    }, $self->{Timeout} + 1);

    if ($self->{redis})
    {
	$self->log($main::LOG_INFO, "$self->{log_class_identifier}: Query socket connected to Redis $self->{RedisEndpoint}");
	process_received_replies(undef, $self);
    }
    else
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Query socket could not connect to Redis $self->{RedisEndpoint}");
    }

    # create Redis object for pubsub and add its socket to select
    $self->{redis_pubsub} = $self->exec_redis_call(sub {
	my %params = (
	    cnx_timeout => $self->{Timeout},
	    sentinels_cnx_timeout => $self->{Timeout},
	    read_timeout => $self->{Timeout},
	    sentinels_read_timeout => $self->{Timeout},
	    write_timeout => $self->{Timeout},
	    sentinels_write_timeout => $self->{Timeout},
	    name => Radius::Util::format_special($self->{ConnectionName}),
	    debug => $self->{Debug},
	);
	$params{sentinels} = $self->{Sentinels} if defined $self->{Sentinels};
	$params{service} = $self->{SentinelService} if defined $self->{SentinelService};
	$params{password} = $self->{Password} if defined $self->{Password};
	$params{sock} = $self->{Sock} if defined $self->{Sock} && ! defined $self->{Host} && ! defined $self->{Sentinels};
	$params{server} = $self->{Host} . ":" . $self->{Port} if defined $self->{Host} && ! defined $self->{Sentinels};

	my $r = Redis->new(%params);
	$r->select($self->{DbIndex});

	return $r;
						   }, $self->{Timeout} + 1);

    if ($self->{redis_pubsub})
    {
	$self->log($main::LOG_INFO, "$self->{log_class_identifier}: Pubsub socket connected to Redis $self->{RedisEndpoint}");

	# try to subscribe pubsub channels
	try_subscribe_redis(undef, $self);
    }
    else
    {
	$self->log($main::LOG_WARNING,
		   "$self->{log_class_identifier}: Pubsub socket could not connect to Redis pubsub $self->{RedisEndpoint}");
    }

    if ($self->{redis} && $self->{redis_pubsub})
    {
	$self->{redis_connected} = 1;
	$self->{reconnect_in_progress} = 0;
    }
}

sub try_subscribe_redis {
    my ($handle, $self) = @_;

    # subscribe to channels
    my $subscribing_succeeded = 0;
    my $subscriptions = 0;

    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Trying to subscribe to Redis pubsub channel '$self->{MyChannel}'");

    $self->exec_redis_call(sub {
	$self->{redis_pubsub}->subscribe($self->{MyChannel}, \&{$self->{pubsub_callback}});
	$self->log($main::LOG_INFO, "$self->{log_class_identifier}: Subscribed to Redis pubsub channel '$self->{MyChannel}'");
	$subscribing_succeeded = 1;
	$subscriptions++;
			   }) if defined $self->{redis_pubsub};
    unless ($subscribing_succeeded)
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Subscribtion to Redis pubsub channel '$self->{MyChannel}' failed!");
    }

    $subscribing_succeeded = 0;
    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Trying to subscribe to Redis pubsub channel '$self->{PubSubChannel}'");

    $self->exec_redis_call(sub {
	$self->{redis_pubsub}->subscribe($self->{PubSubChannel}, \&{$self->{pubsub_callback}});
	$self->log($main::LOG_INFO, "$self->{log_class_identifier}: Subscribed to Redis pubsub channel '$self->{PubSubChannel}'");
	$subscribing_succeeded = 1;
	$subscriptions++;
			   }) if defined $self->{redis_pubsub};
    unless ($subscribing_succeeded)
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Subscribtion to Redis pubsub channel '$self->{PubSubChannel}' failed!");
    }

    unless ($subscriptions >= 2)
    {
	if ($self->{FailureBackoffTime})
	{
	    # Schedule a reconnect attempt
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Will try to resubscribe in $self->{FailureBackoffTime} seconds");
	    Radius::Select::add_timeout(time + $self->{FailureBackoffTime}, \&try_subscribe_redis, $self);
	}
    }
    else
    {
	# Now add a read handler which will be called whenever there is a
	# packet available to be read
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Adding the Redis pubsub socket to Radius::Select");
	Radius::Select::add_file($self->{redis_pubsub}->{sock}->fileno, 1, undef, undef,
				 \&Radius::GossipRedis::handle_socket_read, $self);

	$self->{redis_subscribed} = $subscriptions;
    }

    return;
}

sub reconnect_redis {
    my ($self) = @_;

    $self->connect_redis() unless $self->{redis_connected};

    return $self->{redis_connected} && $self->{redis_subscribed};
}

sub exec_redis_call
{
    my ($self, $coderef, $timeout) = @_;

    $timeout = $self->{Timeout} unless defined $timeout;
    my $ret;

    # $self passed in case the closure needs access to it.
    # Scalar $ret forces multiple values to be returned as an array
    # ref, not as a list. Redis.pm checks if the caller is looking for
    # a list value
    Radius::Util::exec_timeout($timeout, sub {
	$ret = &$coderef($self);
			       });

    if ($@)
    {
	if ($@ =~ /timeout/)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Redis call timed out after $timeout seconds");
	}
	else
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Redis call failed: " . $@);
	}

	# Disconnect and try to reconnect. However, if e.g., server
	# disconnected the socket may be already gone
	Radius::Select::remove_file($self->{redis_pubsub}->{sock}->fileno, 1, undef, undef) if defined $self->{redis_pubsub}->{sock};
	undef $self->{redis};
	undef $self->{redis_pubsub};
	$self->{redis_subscribed} = 0;
	$self->{redis_connected} = 0;

	# Schedule a reconnect attempt
	if ($self->{FailureBackoffTime} && !$self->{reconnect_in_progress})
	{
	    $self->log($main::LOG_INFO, "$self->{log_class_identifier}: Will try to reconnect in $self->{FailureBackoffTime} second(s)");
	    Radius::Select::add_timeout(time + $self->{FailureBackoffTime}, \&try_reconnect_redis, $self);
	    $self->{reconnect_in_progress} = 1;
	}
	return;
    }

    return $ret;
}

sub exec_call
{
    my ($self, $coderef) = @_;

    return unless (defined $self->{redis});

    return $self->exec_redis_call($coderef);
}

sub handle_socket_read
{
    my ($fileno, $self) = @_;

    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Calling redis->wait_for_messages(1)")
	if $self->{Debug};

    $self->exec_redis_call(sub {
	eval {
	    $self->{redis_pubsub}->wait_for_messages(0.01);
	};

	if ($@)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Redis socket read failed: $@");

	    Radius::Select::remove_file($self->{redis_pubsub}->{sock}->fileno, 1, undef, undef) if defined $self->{redis_pubsub}->{sock};
	    $self->{redis_pubsub}->quit();
	    $self->{redis}->quit();
	    $self->{redis_connected} = 0;
	    $self->{redis_subscribed} = 0;

	    # Schedule a reconnect attempt
	    if ($self->{FailureBackoffTime} && !$self->{reconnect_in_progress})
	    {
		$self->log($main::LOG_INFO, "$self->{log_class_identifier}: Will try to reconnect in $self->{FailureBackoffTime} second(s)");
		Radius::Select::add_timeout(time + $self->{FailureBackoffTime}, \&try_reconnect_redis, $self);
		$self->{reconnect_in_progress} = 1;
	    }
	}
			   });
}

sub handle_message_send {
    my ($self, $destination, $message, $time_to_live, $callback) = @_;

    return unless $self->reconnect_redis();

    my $key = $self->{Prefix} . ":$destination";
    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Sending a Redis message (element) with key $key")
	if $self->{Debug};

    my @args = ($key, $message);
    push (@args, $callback) if $callback;
    $self->exec_redis_call(sub {$self->{redis}->set(@args); });

    if (defined $time_to_live)
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: .. which will expire in $time_to_live seconds") if $self->{Debug};
	$self->exec_redis_call(sub { $self->{redis}->expire($key, $time_to_live) });
    }

    return;
}

sub handle_message_push
{
    my ($self, $destination, $message, $time_to_live, $callback) = @_;

    return unless $self->reconnect_redis();

    my $key = $self->{Prefix} . ":list:$destination";
    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Pushing a Redis message (element) with key $key")
	if $self->{Debug};

    my @args = ($key, $message);
    if ($callback)
    {
	my $wrapped_callback = $self->get_redis_callback($callback);
	push (@args, $wrapped_callback);
    }
    $self->exec_redis_call(sub {$self->{redis}->rpush(@args); });

    return;
}

sub handle_message_fetch {
    my ($self, $destination, $callback) = @_;

    return unless $self->reconnect_redis();

    my $key = $self->{Prefix} . ":$destination";
    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Fetching Redis message (element) with key $key")
	if $self->{Debug};

    my @args = $key;
    push (@args, $callback) if $callback;
    my $message = $self->exec_redis_call(sub { $self->{redis}->get(@args); });

    return $message;
}

sub handle_message_pop
{
    my ($self, $source, $callback) = @_;

    return unless $self->reconnect_redis();

    my $key = $self->{Prefix} . ":list:$source";
    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Popping Redis message (element) with key $key")
	if $self->{Debug};

    my @args = $key;
    if ($callback)
    {
	my $wrapped_callback = $self->get_redis_callback($callback);
	push (@args, $wrapped_callback);
    }
    my $message = $self->exec_redis_call(sub { $self->{redis}->lpop(@args); });

    return $message;
}

sub handle_message_delete {
    my ($self, $destination, $callback) = @_;

    return unless $self->reconnect_redis();

    my $key = $self->{Prefix} . ":$destination";
    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Deleting Redis message (element) with key $key")
	if $self->{Debug};

    my @args = $key;
    push (@args, $callback) if $callback;
    $self->exec_redis_call(sub { $self->{redis}->del(@args); });

    return;
}

sub handle_message_publish {
    my ($self, $message, $destination) = @_;

    return unless $self->reconnect_redis();

    if (defined $destination)
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Sending a Redis message (element) to channel '$self->{Prefix}:$destination'")
	    if $self->{Debug};

	$self->exec_redis_call(sub { $self->{redis}->publish($self->{Prefix} . ":$destination", $message); });
    }
    else
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Publishing a Redis message to channel '$self->{PubSubChannel}'")
	    if $self->{Debug};

	$self->exec_redis_call(sub { $self->{redis}->publish($self->{PubSubChannel}, $message); });
    }

    return;
}

sub check_reply_for_error
{
    #my ($reply, $error) = @_;

    if (defined $_[1])
    {
        main::log($main::LOG_WARNING, "Redis command returned an error: $_[1]");
        return 1;
    }

    return;
}

sub get_redis_callback
{
    my ($self, $callback) = @_;

    return sub { &$callback(@_) unless &check_reply_for_error(@_); };
}

sub process_received_replies
{
    my ($handle, $self) = @_;

    # run callbacks of received messages
    return unless (defined $self->{redis});

    $self->exec_redis_call(sub { $self->{redis}->wait_all_responses(); });

    Radius::Select::add_timeout(time + $self->{Timeout}, \&process_received_replies, $self);

    return;
}

1;
