# SessGeneric.pm
#
# Generic object for handling session databases
# In order to create a new sesion database, you need to 
# subclass this and override a number of functions
#
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::SessGeneric;
use strict;
our @ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Session;

%Radius::SessGeneric::ConfigKeywords = 
(
 'SessionIdentifier' =>
 ['string', 'Name of a Radius attribute which will be used to identify a session. Defaults to Acct-Session-Id.', 1],

 'Tenant' =>
 ['string', 'Name of a tenant.', 1],

 'SessionAttribute' =>
 ['stringhash', 'Extra RADIUS attributes to store within a session record. Format is: SessionAttribute session_attribute_name,radius_attribute_name', 1],
 );

# RCS version number of this module
$Radius::SessGeneric::VERSION = '$Revision$';

#####################################################################
# Do per-instance configuration check
# This is called by Configurable just before activate
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    # The last one in the config file is the default
    $Radius::SessGeneric::db = $self; 

    $self->{SessionIdentifier} = 'Acct-Session-Id';

    $self->SUPER::initialize;
    $self->{ObjType} = 'SessionDatabase'; # Automatically register this object

    $self->{Tenant} = 'default';

    $self->{quota_fraction} = 0.2;
    $self->{quota_threshold} = 0.8;
    $self->{quota_time_left_threshold} = 10 * 60;
    $self->{quota_octets_left_threshold} = 1000 * 1000;
}

#####################################################################
sub add
{
    my ($self, $name, $nas_id, $nas_port, $p) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override add in SessGeneric", $p);
}

#####################################################################
# By default update (called for Alive and similar packets)
# does the same as an add
sub update
{
    my ($self, $name, $nas_id, $nas_port, $p) = @_;

    $self->add($name, $nas_id, $nas_port, $p);
}

#####################################################################
sub delete
{
    my ($self, $name, $nas_id, $nas_port, $p, $session_id, $framed_ip_address, $backend_session_id) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override delete in SessGeneric", $p);
}

#####################################################################
sub clearNas
{
    my ($self, $nas_id, $p) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override clearNas in SessGeneric", $p);
}

#####################################################################
sub exceeded
{
    my ($self, $max, $name, $p) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override exceeded in SessGeneric", $p);
}

#####################################################################
# Returns an array of all the session IDs that should be up on this NAS
# returns 1, and a list of session IDs of the query succedded. If the 
# query failed, returns undef;
sub sessionsOnNAS
{
    my ($self, $nas_id, $p, $get_backend_session_id) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override sessionsOnNAS in SessGeneric", $p);
}

#####################################################################
# Find a Session Database with the given identifier
# If not found, return the main default one
sub find
{
    my ($identifier) = @_;

    my $ret = &Radius::Configurable::find('SessionDatabase', $identifier) 
	|| $Radius::SessGeneric::db;
    return $ret;
}

#####################################################################
# Returns an array of session ids for user $name
sub sessionsForUser
{
    my ($self, $name, $nas_id, $p, $get_backend_session_id) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override sessionsForUser in SessGeneric", $p);

    return;
}

#####################################################################
# Fetches session information for $nas_id, $nas_port, $name and
# $session_id. If there's no $session_id, uses Acct-Session-Id in $p
# instead. Returns hashref.
sub getSessionData
{
    my ($self, $name, $nas_id, $nas_port, $p, $session_id, $backend_session_id) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override getSessionData in SessGeneric", $p);

    return;
}

#####################################################################
# Looks up the session identified with $name and $p and calls
# $caller->sessionReady($p, $session_data) if the session was found.
sub mapSessionData
{
    my ($self, $caller, $name, $nas_id, $nas_port, $p, $session_id, $backend_session_id) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override mapSessionData in SessGeneric", $p);

    return;
}

# New SessionDatabase API

#####################################################################
#
sub handle_request
{
    my ($self, $p, $session, $subscription_backend) = @_;

    unless ($session)
    {
	# Lookup a session
	my $id = $p->get_attr($self->{SessionIdentifier});
	my $name = $p->getUserName();

	$session = $self->get_or_create_session($id, $name, undef, 1);
	unless ($session)
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Could not find a session", $p);
	    return 0;
	}
    }

    #$self->log($main::LOG_DEBUG, "SessGeneric: Using a session " . $session->str());

    if ($session->is_ended())
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Session '$session->{id}' has already ended", $p);
	return 1;
    }

    unless ($session->handle_accounting($p, $self->{SessionAttribute}))
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Session could not handle a request", $p);
	return 0;
    }

    # See whether session needs resupply
    my ($leaked_time, $leaked_octets) = $session->get_leaked_quota($session->{duration_prev}, $session->{data_used_prev});

    # Get subscription
    unless ($session->{parent})
    {
	my @parent_backend = $session->get_parent_backend();
	if (!$parent_backend[0] && $subscription_backend)
	{
	    $session->set_parent_backend($subscription_backend, $subscription_backend->can('refresh_subscription'));
	}

	# Get subscription
	$session->get_parent();

	unless ($session->{parent})
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Could not get session '$session->{id}' parent subscription", $p);
	    return 0;
	}
    }
    if ($session->{parent})
    {
	if ($leaked_time || $leaked_octets)
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Session '$session->{id}' requires quota supply $leaked_time, $leaked_octets", $p);
	    $session->supply_from_subscription(undef, $leaked_time, $leaked_octets);
	}
    }

    # Check for quotas
    if ($session->exceeded())
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Session '$session->{id}' exceeded for '$session->{user_name}'", $p);
	if ($session->{parent} && $session->{parent}->allow_to_exceed())
	{
	    # Mark session exceeded
	    $p->{SessionExceeded} = 0;
	}
	else
	{
	    # Mark session exceeded
	    $p->{SessionExceeded} = 1;
	}
    }
    else
    {
	# Mark session good
	$p->{SessionExceeded} = 0;
    }

    # Redact usage from allocated session quotas
    ($leaked_time, $leaked_octets) = $session->deplete($session->{duration_prev}, $session->{data_used_prev});

    if ($leaked_time || $leaked_octets)
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Session '$session->{id}' leaked quota $leaked_time, $leaked_octets after resupply", $p);
    }

    if ($session->{parent})
    {
	# Return remaining quotas back to a subscription
	$session->{parent}->update_from_session($session);
	#$self->log($main::LOG_DEBUG, "SessGeneric: Updated a subscription " .$session->{parent}->str());
    }
    #$self->log($main::LOG_DEBUG, "SessGeneric: Updated a session " .$session->str());

    # Save session's parent (subscription) and session
    #unless ($session->save_parent())
    if ($session->{parent} && !$session->{parent}->save())
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Could not save a subscription", $p);
    }
    unless ($session->save())
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Could not save a session", $p);
	return 0;
    }

    return 1;
}

#####################################################################
sub find_session
{
    my ($self, $p, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override find_session in SessGeneric");

    return undef;
}

#####################################################################
sub new_session
{
    my ($self, $id, $name, $subscription_id, $subscription_name, $tenant_id) = @_;

    $tenant_id = $self->{Tenant} unless defined $tenant_id;

    my $session = Radius::Session->new($id, $name, $subscription_id, $subscription_name, $tenant_id);
    if ($session)
    {
	$session->set_backend($self, $self->can('refresh_session'), $self->can('save_session'), $self->can('del_session'));
    }

    return $session;
}

#####################################################################
sub add_session
{
    my ($self, $session, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override add_session in SessGeneric");

    return 1;
}

#####################################################################
sub new_session_from_subscription
{
    my ($self, $id, $name, $subscription) = @_;

    return undef unless $subscription;

    my $session = Radius::Session->new_from_subscription($id, $name, $subscription);
    if ($session)
    {
	$session->set_quota_thresholds($self->get_quota_thresholds());
	$session->set_backend($self, $self->can('refresh_session'), $self->can('save_session'), $self->can('del_session'));

	# Set parent backend for getting a subscription
	my @subscription_backend = $subscription->get_backend();
	if (@subscription_backend && $subscription_backend[0])
	{
	    $session->set_parent_backend($subscription_backend[0], $subscription_backend[0]->can('refresh_subscription'));
	}
    }

    return $session;
}

#####################################################################
sub new_session_from_array
{
    my ($self, @array) = @_;

    my ($tenant_id, $id, $name, $parent_id, $parent_name) = @array[0 .. 4];
    $id = $name if (!$id && $name);
    $name = $id if (!$name && $id);

    my ($quota_time_pre_left, $quota_time_post_left,
	$quota_octets_pre_left,	$quota_octets_post_left,
	$refill_number, $refilled_at, $user_name,
	$created_at, $deleted_at,  $updated_at, $saved_at) = @array[5 .. 15];

    # Indexes 16 .. 26
    # recv_from_addr nas_id nas_ipv4 nas_ipv6 nas_port
    # called_station calling_station ssid class ipv4 ipv6

    my ($duration, $data_used, $status) = @array[27 .. 29];

    # Index 30
    # end_reason

    my ($ended_at, $state) = @array[31, 32];

    my $session = $self->new_session($id, $name, $parent_id, $parent_name);
    return undef unless $session;

    $session->set_quotas_left($quota_time_pre_left, $quota_time_post_left, $quota_octets_pre_left, $quota_octets_post_left);
    $session->{refill_number} = $refill_number;
    $session->{refilled_at} = $refilled_at;
    $session->{user_name} = $user_name;
    $session->{created_at} = $created_at;
    $session->{deleted_at} = $deleted_at;
    $session->{updated_at} = $updated_at;
    $session->{saved_at} = $saved_at;
    $session->{duration} = $duration;
    $session->{data_used} = $data_used;
    $session->{status} = $status;
    $session->{ended_at} = $ended_at;
    $session->{state} = $state;
    $session->{dirty} = 0;

    return $session;
}

#####################################################################
sub get_session
{
    my ($self, $id, $name, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override get_session in SessGeneric");

    return undef;
}

#####################################################################
sub get_or_create_session
{
    my ($self, $id, $name, $subscription, $dont_create, $tenant_id, $cb) = @_;

    my $session = $self->get_session($id, $name, $tenant_id);

    if ($session)
    {
	if ($subscription)
	{
	    # Set parent backend for getting a subscription
	    my @subscription_backend = $subscription->get_backend();
	    if (@subscription_backend && $subscription_backend[0])
	    {
		$session->set_parent_backend($subscription_backend[0], $subscription_backend[0]->can('refresh_subscription'));
	    }
	}
    }
    else
    {
	if ($subscription)
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Creating a new session '$id' for '$name'");
	    $session = $self->new_session_from_subscription($id, $name, $subscription, $tenant_id);
	}
    }

    return $session;
}

#####################################################################
sub get_sessions
{
    my ($self, $tenant_id, $cb) = @_;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override get_sessions in SessGeneric");

    return undef;
}

#####################################################################
sub set_quota_thresholds
{
    my ($self, $quota_fraction, $quota_threshold, $quota_time_left_threshold, $quota_octets_left_threshold) = @_;

    $self->{quota_fraction} = $quota_fraction if defined $quota_fraction;
    $self->{quota_threshold} = $quota_threshold if defined $quota_threshold;
    $self->{quota_time_left_threshold} = $quota_time_left_threshold if defined $quota_time_left_threshold;
    $self->{quota_octets_left_threshold} = $quota_octets_left_threshold if defined $quota_octets_left_threshold;

    return;
}

#####################################################################
sub get_quota_thresholds
{
    my ($self) = @_;

    return ($self->{quota_fraction}, $self->{quota_threshold}, $self->{quota_time_left_threshold}, $self->{quota_octets_left_threshold});
}

#####################################################################
sub refresh_session
{
    my ($self, $session, $child, $cb) = @_;

    return 0 unless $session;

    if (ref($session))
    {
	my ($id, $name, $tenant_id);
	if ($child)
	{
	    $id = $child->{parent_id} if $child;
	    $name = $child->{parent_name} if $child;
	    $tenant_id = $child->{tenant_id} if $child;
	}
	if (!${$session})
	{
	    ${$session} = Radius::Session->new($id, $name, $tenant_id);
	}
	$session = ${$session};
    }

    my $rc = 0;
    my $new_session = $self->get_session($session->{id}, $session->{name}, $session->{tenant_id});
    if ($new_session)
    {
	$session->set_from_session($new_session);
	$session->set_backend($self, $self->can('refresh_session'), $self->can('save_session'), $self->can('del_session'));
	$rc = 1;
    }

    if ($cb)
    {
	return 0;
    }

    return $rc;
}

#####################################################################
sub save_session
{
    my ($self, $session, $cb) = @_;

    return 0 unless $session;
    return 1 unless $session->{dirty};

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override save_session in SessGeneric");

    return 1;
}

#####################################################################
sub del_session
{
    my ($self, $session, $cb) = @_;

    return 0 unless $session;

    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: You did not override del_session in SessGeneric");

    return 1;
}

1;
