# RadiusProxyAlg.pm
#
# Proxy algorithms for forwarding RADIUS messages for both RADIUS and
# RadSec.
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2017 Open System Consultants
# $Id$

package Radius::RadiusProxyAlg;
use Radius::EAP;
use strict;
use warnings;

# RCS version number of this module
$Radius::RadiusProxyAlg::VERSION = '$Revision$';

sub activate
{
    my ($self, $fp, $p) = @_;

    # If no algorithm is configured, it means the default is used.
    my $proxy_alg = $self->{ProxyAlgorithm};
    $proxy_alg = $Radius::AuthRADSEC::proxy_algorithms_enum[0];
    return activate_eapbalance($self) if $proxy_alg eq 'EAPBalance';

    # The other algos don't need activate, but still check that the
    # algo is known and complain if not.
    return if grep { $_ eq $proxy_alg } @Radius::AuthRADSEC::proxy_algorithms_enum;
    $self->log($main::LOG_ERR, ref($self) . " Unknown ProxyAlgorithm in Radius::RadiusProxyAlg::activate: $proxy_alg", $p);
    return;
}

sub chooseHost
{
    my ($self, $fp, $p) = @_;

    my $proxy_alg = $self->{ProxyAlgorithm};
    return chooseHost_eapbalance($self, $fp, $p) if $proxy_alg eq 'EAPBalance';
    return chooseHost_hashbalance($self, $fp, $p) if $proxy_alg eq 'HashBalance';
    return chooseHost_loadbalance($self, $fp, $p) if $proxy_alg eq 'LoadBalance';
    return chooseHost_volumebalance($self, $fp, $p) if $proxy_alg eq 'VolumeBalance';
    return chooseHost_roundrobin($self, $fp, $p) if $proxy_alg eq 'RoundRobin';

    $self->log($main::LOG_ERR, ref($self) . " Unknown ProxyAlgorithm in Radius::RadiusProxyAlg::choose_host: $proxy_alg", $p);
    return; # No Host, make forwarding fail
}

sub succeeded
{
    my ($self, $host, $p, $op, $sp) = @_;

    my $proxy_alg = $self->{ProxyAlgorithm};
    return succeeded_loadbalance(@_) if $proxy_alg eq 'LoadBalance';

    # Check that the algo was known and complain if not.
    return if grep { $_ eq $proxy_alg } @Radius::AuthRADSEC::proxy_algorithms_enum;
    $self->log($main::LOG_ERR, ref($self) . " Unknown ProxyAlgorithm in Radius::RadiusProxyAlg::succeeded: $proxy_alg", $p);
    return;
}


#####################################################################
# EAP balance
#
sub activate_eapbalance
{
    my ($self) = @_;

    # We label backend Hosts so we can recover them using the State
    my $id = 0;
    foreach (@{$self->{Hosts}})
    {
	$_->{eapbalance_id} = $id++;
    }

    return;
}

# Choose a host for this request
# If there is a State attribtue use it to determine the backend, else
# let the HASHBALANCE choose one
sub chooseHost_eapbalance
{
    my ($self, $fp, $p) = @_;

    my $state = $p->getAttrByNum($Radius::Radius::STATE);
    if (defined $state && $state =~ /EAPBALANCE:id=(.*)/)
    {
	# Remove the FIRST instance of State. Subsequent instances may exist, set by the target host
	# This allows interoperation with othe RADIUS servers that rely on State
	# REVISIT: this should really be a function in AttrVal.pm
	my $i;
	for ($i = 0; $i < @{$fp->{Attributes}}; $i++)
	{
	    splice(@{$fp->{Attributes}}, $i--, 1), last
		if ($fp->{Attributes}->[$i]->[0] eq 'State');
	}

	# Make sure all replies in the stream get the State
	my $host = $self->{Hosts}[$1];
	if (!$p->{eapbalance_host_tried} && $host && $host->isWorking())
	{
	    $p->{rp}->changeAttrByNum($Radius::Radius::STATE, $state);
	    $p->{eapbalance_host_tried}++;
	    return $host;
	}

	$self->log($main::LOG_WARNING, "ProxyAlgorithm EAPBalance declines to break up an EAP stream after detecting failure of Host $host->{Name}:$host->{AuthPort}:$host->{AcctPort}", $p);
	$p->{RadiusResult} = $main::REJECT;
	return;
    }
    else
    {
	# No recognisable state, must be the first request in a conversation,
	# use HASHBALANCE to choose a target
	my $host = Radius::RadiusProxyAlg::chooseHost_hashbalance($self, $fp, $p);
	if ($host && $p->{rp})
	{
	    # Label the reply (if there is one: may be a keepalive) with the State
	    $p->{rp}->changeAttrByNum($Radius::Radius::STATE, "EAPBALANCE:id=$host->{eapbalance_id}")
		if $p->code() eq 'Access-Request';
	}
	return $host;
    }

    return;
}


#####################################################################
# Hash balance
#
# Choose the host for this request
sub chooseHost_hashbalance
{
    my ($self, $fp, $p) = @_;

    # Hash a number of attributes from the request and use that to choose
    # a preferred host
    my $numhosts = @{$self->{Hosts}};
    if (!defined $fp->{hashbalance_start_index})
    {
	my $hash_attrs = &Radius::Util::format_special($self->{HashAttributes}, $p);
	my $hash = Digest::MD5::md5($hash_attrs);
	# Take the top 32 bits of the hash, modulo the number of hosts
	$fp->{hashbalance_start_index} = unpack('N', $hash) % $numhosts;
	$fp->{hashbalance_index} = 0;
    }

    # Iterate over the hosts, starting at the preferred one until a working one is found
    my $desthost;
    while ($fp->{hashbalance_index} < $numhosts)
    {
	my $index = ($fp->{hashbalance_start_index} + $fp->{hashbalance_index}++)
	    % $numhosts;
	my $host = $self->{Hosts}[$index];
	$desthost = $host,last if $host->isWorking();
    }

    # Now make sure we never break up EAP streams from the same user
    # between failing hosts
    my $eapmessage = $p->getAttrByNum($Radius::Radius::EAP_MESSAGE);
    if (defined $eapmessage)
    {
	my $context = $self->getEAPContext($p);
	my ($code, $identifier, $length, $eaptype) = unpack('C C n C', $eapmessage);
	# If this is not identity and the last one went to a different proxy, drop it
	if ($eaptype != $Radius::EAP::EAP_TYPE_IDENTITY
	    && exists $context->{last_proxy_host}
	    && $context->{last_proxy_host} != $desthost)
	{
	    my $last_proxy_host = $context->{last_proxy_host};
	    $self->log($main::LOG_WARNING, "ProxyAlgorithm HashBalance declines to break up an EAP stream after failover from $last_proxy_host->{Name}:$last_proxy_host->{AuthPort}:$last_proxy_host->{AcctPort} to $desthost->{Name}:$desthost->{AuthPort}:$desthost->{AcctPort}", $p);
	    $p->{RadiusResult} = $main::REJECT;
	    return;
	}
	else
	{
	    $context->{last_proxy_host} = $desthost;
	}

    }

    $self->log($main::LOG_WARNING, "ProxyAlgorithm HashBalance Could not find a working host to proxy to", $p)
	unless $desthost;
    return $desthost;
}

#####################################################################
# Load balance
#
# Choose the next host for the loadbalancing algorithm
# Chooses the host with the smallest average processing time
sub chooseHost_loadbalance
{
    my ($self, $fp, $p) = @_;

    # Choose the host with the smallest average biassed
    # processing time
    my $smallesttime = 1000000000;
    my ($selectedhost);
    foreach my $host (@{$self->{Hosts}})
    {
	next unless $host->isWorking();
	next if $host->{BogoMips} == 0;
	# Gradually rehabilitate hosts with long times
	# If we dont do this, their response time will
	# never be remeasured.
	$host->{averageProcTime} -= $host->{averageProcTime} / 100;

	if ($host->{averageProcTime} < $smallesttime)
	{
	    $smallesttime = $host->{averageProcTime};
	    $selectedhost = $host;
	}
    }

    $self->log($main::LOG_WARNING, "ProxyAlgorithm LoadBalance Could not find a working host to proxy to", $p)
	if !$selectedhost;
    $fp->{LastSendUTime} = &Time::HiRes::time();
    return $selectedhost;
}

#####################################################################
# Called when a reply is successfully received and after it is relayed
# back to the NAS
sub succeeded_loadbalance
{
    my ($self, $host, $p, $op, $sp) = @_;

    # See how long it took to be processed, and adjust the load
    # balancing average processing time
    my $proc_time = &Time::HiRes::time() - $sp->{LastSendUTime};
    # Calculate a moving window average, biassed by BogoMips
    my $biassed_proc_time = $proc_time * $host->{BogoMips};
    $host->{averageProcTime} +=
	($biassed_proc_time - $host->{averageProcTime}) / 10;
}


#####################################################################
# Volume balance
#
# Choose the next host for the volumebalance algorithm
sub chooseHost_volumebalance
{
    my ($self, $fp, $p) = @_;

    my ($selectedhost);
    my $highestchance = 0;
    my $summips = 0;

    # First work out the total available BogoMips, and see if
    # there is a host with a chance of being selected
    foreach my $host (@{$self->{Hosts}})
    {
	next unless $host->isWorking() && $host->{BogoMips};
	$summips += $host->{BogoMips};
    }

    if ($summips == 0 || $fp->{hostRetries} >= @{$self->{Hosts}}) # No available hosts
    {
	$self->log($main::LOG_WARNING, "ProxyAlgorithm VolumeBalance Could not find a working host to proxy to", $p);
	return; # None found
    }

    # Now increment each hosts chances according to its available
    # Capacity, and choose the one that now has the highest chance
    # The total of all increments will be certainty (1)
    foreach my $host (@{$self->{Hosts}})
    {
	next unless $host->isWorking() && $host->{BogoMips};
	$host->{selectionChance} += ($host->{BogoMips} / $summips);
	if ($host->{selectionChance} > $highestchance)
	{
	    $highestchance = $host->{selectionChance};
	    $selectedhost = $host;
	}
    }

    # Now reduce the chance of the selected host by certainty (1)
    $selectedhost->{selectionChance} -= 1 if $selectedhost;
    $fp->{hostRetries}++;

    return $selectedhost;
}


#####################################################################
# Round robin
#
# Choose the next host for the round robin algorithm
# Chooses the 'next' available host.
#
# Do a real RoundRobin for a not-retried request
# and do a walk of the RR list for a retried request
# Bail out if no working hosts are found or we already
# tried all the hosts in a list.
#
# Note: hostRetries here is not index to Hosts array like in other
# proxy algorithms.
#
sub chooseHost_roundrobin
{
    my ($self, $fp, $p) = @_;

    my $i = 0; # If all are unavailable, bomb out
    my $host_index;

    # For a first try, find a working host and remember it if we need to retry it.
    if (not defined($fp->{firstHostTried})) {
	while ($i++ < @{$self->{Hosts}})
	{
	    $host_index = $self->{roundRobinCounter}++ % @{$self->{Hosts}};
	    my $host = $self->{Hosts}[$host_index];
	    next unless $host->isWorking();
	    $fp->{hostRetries} = 1;
	    $fp->{firstHostTried} = $host_index;
	    $fp->{lastHostTried} = $host_index;
	    return $host;
	}
	return; # None found
    }

    # This is a retry. Take the next host from the RR list
    # and try it. If we looped back to the host we tried as
    # first give up.
    while (1)
    {
	$host_index = ($fp->{lastHostTried}+1) % @{$self->{Hosts}};
	$fp->{lastHostTried} = $host_index;
	$self->log($main::LOG_INFO, "ProxyAlgorithm RoundRobin: Retry " . $fp->{hostRetries} . ", firstHostTried " . $fp->{firstHostTried} . ", lastHostTried " . $fp->{lastHostTried});
	last if ($host_index == $fp->{firstHostTried});
	my $host = $self->{Hosts}[$host_index];
	next unless $host->isWorking();
	$fp->{hostRetries}++;
	return $host;
    }

    $self->log($main::LOG_WARNING, "ProxyAlgorithm RoundRobin: Request was tried for " . $fp->{hostRetries} . " times. All alive server from the RoundRobin list were tried.");
    return; # None found
}

1;
