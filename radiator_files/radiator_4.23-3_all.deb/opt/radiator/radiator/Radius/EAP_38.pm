# EAP_38.pm
#
# Module for  handling Authentication via EAP type 38 
# (EAP-TNC)
#
# This module was obsolete in Raditor 4.21. This file will be removed
# in a future release.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2001 Open System Consultants
# $Id$

package Radius::EAP_38;
use strict;
use warnings;

# RCS version number of this module
$Radius::EAP_38::VERSION = '$Revision$';

#####################################################################
# Called by EAP.pm when the caller wants to know the EAP type name this class supports
sub type_name
{
    my ($classname) = @_;

    return 'TNC';
}

#####################################################################
# request
# Called by EAP.pm when a request is received for this protocol type
sub request
{
    my ($classname, $self, $context, $p, $data) = @_;

    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'Unexpected EAP request');
}

#####################################################################
# Called by EAP.pm when an EAP Response/Identity is received
sub response_identity
{
    my ($classname, $self, $context, $p) = @_;

    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'EAP-TNC type 38 is obsolete');
}

#####################################################################
# Called by EAP.pm when an EAP Response (other than Identity)
# is received
sub response
{
    my ($classname, $self, $context, $p, $type, $typedata) = @_;

    $self->eap_failure($p->{rp}, $context);

    return ($main::REJECT, 'EAP-TNC type 38 is obsolete');
}

1;
