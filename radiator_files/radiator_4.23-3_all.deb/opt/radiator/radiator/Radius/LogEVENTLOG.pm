# LogEVENTLOG.pm
#
# Log to a Windows Event Log
#
# Author: Sami Keski-Kasari (samikk@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::LogEVENTLOG;
use Radius::LogGeneric;
@ISA = qw(Radius::LogGeneric);
use Win32::EventLog;
use strict;
use warnings;

%Radius::LogEVENTLOG::ConfigKeywords =
('LogFormat' =>
 ['string', 'This optional parameter permits you to customize the log string. Any special formatting character is permitted. %0 is replaced with the message severity as an integer, %1 with the severity as a string, and %2 with the log message. ', 1],

 );

# RCS version number of this module
$Radius::LogEVENTLOG::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initialize instance
# variables
# that might get overridden when the config file is parsed.
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
}

#####################################################################
# Log a message
# $priority is the message priority, $s is the message
# $p is the current request packet, if any
# $trace_id is the tracing identifier
sub log
{
    my ($self, $priority, $s, $p, $trace_id) = @_;

    if ($self->willLog($priority, $p))
    {
	my $message;
	if (defined $self->{LogFormat})
	{
	    $message = Radius::Util::format_special
		($self->{LogFormat},
		 $p, undef,
		 $priority,
		 $Radius::Log::priorityToString[$priority],
		 $s,
		 $trace_id);
	}
	else
	{
	    $message = $s;
	}

	my %eventlogrecord = (
	    'Source' => 'Radiator',
	    'Strings' => $message,
	    'Data' => $message,
	    );

	if ($priority == $main::LOG_ERR)
	{
	    $eventlogrecord{EventID} = 1000;
	    $eventlogrecord{EventType} = EVENTLOG_ERROR_TYPE;
	}
	elsif ($priority == $main::LOG_WARNING)
	{
	    $eventlogrecord{EventID} = 1001;
	    $eventlogrecord{EventType} = EVENTLOG_WARNING_TYPE;
	}
	elsif ($priority == $main::LOG_NOTICE)
	{
	    $eventlogrecord{EventID} = 1002;
	    $eventlogrecord{EventType} = EVENTLOG_INFORMATION_TYPE;
	}
	elsif ($priority == $main::LOG_INFO)
	{
	    $eventlogrecord{EventID} = 1003;
	    $eventlogrecord{EventType} = EVENTLOG_INFORMATION_TYPE;
	}
	elsif ($priority == $main::LOG_DEBUG)
	{
	    $eventlogrecord{EventID} = 1004;
	    $eventlogrecord{EventType} = EVENTLOG_INFORMATION_TYPE;
	}
	elsif ($priority == $main::LOG_EXTRA_DEBUG)
	{
	    $eventlogrecord{EventID} = 1005;
	    $eventlogrecord{EventType} = EVENTLOG_INFORMATION_TYPE;
	}

	my $eventloghandle = Win32::EventLog->new("Radiator")
	    || warn "LogEVENTLOG: Could not open Event Log\n" ;
	my $output = $eventloghandle->Report(\%eventlogrecord)
	    || warn "LogEVENTLOG: Could not Report log entry\n" ;

	$eventloghandle->Close();
    }
}

1;
