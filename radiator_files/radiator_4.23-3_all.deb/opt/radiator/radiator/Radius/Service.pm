# Service.pm
#
# Object for handling service details
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::Service;
use strict;
use warnings;

# RCS version number of this module
$Radius::Service::VERSION = '$Revision$';

#####################################################################
sub new
{
    my ($class, $id, $name, $tenant_id) = @_;

    my $self = {};
    bless $self, $class;

    # Tenant id
    $self->{tenant_id} = $tenant_id;

    # Service id
    $self->{id} = $id;
    # Service name
    $self->{name} = $name;

    # Charging related attributes
    # Service price
    $self->{price} = undef;
    # Timestamp when the charging was confirmed by the customer (used in Subscription)
    $self->{confirmed_at} = undef;

    # Service pools
    $self->{pool_v4} = undef;
    $self->{pool_v6} = undef;

    # Check attributes
    $self->{check_attrs} = undef;

    # Reply attributes
    $self->{reply_attrs} = undef;

    # Service quotas
    $self->{quota_time_pre} = undef;
    $self->{quota_time_post} = undef;
    $self->{quota_octets_pre} = undef;
    $self->{quota_octets_post} = undef;

    # Allow service after exceeding quotas
    $self->{allow_to_exceed} = undef;

    # Disallow to resubscribe the service (automatically)
    $self->{disallow_resubscribe} = undef;

    # Link rates and policers (either numberic values or string names)
    $self->{rate_ul_throt} = undef;
    $self->{rate_ul} = undef;
    $self->{rate_ul_max} = undef;
    $self->{rate_dl_throt} = undef;
    $self->{rate_dl} = undef;
    $self->{rate_dl_max} = undef;

    # A flag indicating that object needs to be saved
    $self->{dirty} = 1;
    # A flag indicating that object is new
    $self->{new} = 0;

    # Timestamp when the object was created/provisioned
    $self->{created_at} = undef;
    # Timestamp when the object was last time saved
    $self->{saved_at} = undef;
    # Timestamp when the object was deleted
    $self->{deleted_at} = undef;
    # For how long a subscription is valid at maxmimum
    $self->{expiry} = undef;

    # Parent object
    $self->{parent} = undef;

    return $self;
}

sub new_from_service
{
    my ($class, $id, $name, $service) = @_;

    return undef unless $service;

    my $self = $class->new($id, $name, $service->{tenant_id});
    $self->set_from_service($service);
    $self->{new} = 1;

    return $self;
}

sub set_from_service
{
    my ($self, $service) = @_;

    $self->set_params($service->get_params());
    $self->set_quotas($service->get_quotas());
    $self->set_rates($service->get_rates());
    $self->set_backend($service->get_backend());

    return;
}

sub set_params
{
    my ($self, $price, $pool_v4, $pool_v6, $check_attrs, $reply_attrs, $no_confirmation, $expiry, $allow_to_exceed, $disallow_resubscribe) = @_;

    $self->{price} = $price;
    $self->{pool_v4} = $pool_v4;
    $self->{pool_v6} = $pool_v6;
    $self->{check_attrs} = $check_attrs;
    $self->{reply_attrs} = $reply_attrs;
    $self->{confirmed_at} = $no_confirmation;
    $self->{expiry} = $expiry;
    $self->{allow_to_exceed} = $allow_to_exceed;
    $self->{disallow_resubscribe} = $disallow_resubscribe;
    $self->{dirty} = 1;

    return;
}

sub get_params
{
    my ($self) = @_;

    return ($self->{price}, $self->{pool_v4}, $self->{pool_v6}, $self->{check_attrs}, $self->{reply_attrs}, $self->{confirmed_at}, $self->{expiry}, $self->{allow_to_exceed}, $self->{disallow_resubscribe});
}

sub set_quotas
{
    my ($self, $prepaid_time, $postpaid_time, $prepaid_data, $postpaid_data) = @_;

    $self->{quota_time_pre} = $prepaid_time if $prepaid_time;
    $self->{quota_time_post} = $postpaid_time if $postpaid_time;
    $self->{quota_octets_pre} = $prepaid_data if $prepaid_data;
    $self->{quota_octets_post} = $postpaid_data if $postpaid_data;
    $self->{dirty} = 1;

    return;
}

sub get_quotas
{
    my ($self) = @_;

    return ($self->{quota_time_pre}, $self->{quota_time_post}, $self->{quota_octets_pre}, $self->{quota_octets_post});
}

sub set_rates
{
    my ($self, $ul_throt, $ul_rate, $ul_max, $dl_throt, $dl_rate, $dl_max) = @_;

    $self->{rate_ul_throt} = $ul_throt;
    $self->{rate_ul} = $ul_rate;
    $self->{rate_ul_max} = $ul_max;
    $self->{rate_dl_throt} = $dl_throt;
    $self->{rate_dl} = $dl_rate;
    $self->{rate_dl_max} = $dl_max;
    $self->{dirty} = 1;

    return;
}

sub get_rates
{
    my ($self) = @_;

    return ($self->{rate_ul_throt}, $self->{rate_ul}, $self->{rate_ul_max}, $self->{rate_dl_throt}, $self->{rate_dl}, $self->{rate_dl_max});
}

sub set_backend
{
    my ($self, $backend, $get_cb, $save_cb, $del_cb) = @_;

    $self->{_backend} = $backend;
    $self->{_get_cb} = $get_cb;
    $self->{_save_cb} = $save_cb;
    $self->{_del_cb} = $del_cb;

    return;
}

sub get_backend
{
    my ($self) = @_;

    return ($self->{_backend}, $self->{_get_cb}, $self->{_save_cb}, $self->{_del_cb});
}

sub set_parent_backend
{
    my ($self, $backend, $get_cb, $save_cb, $del_cb) = @_;

    $self->{_parent_backend} = $backend;
    $self->{_parent_get_cb} = $get_cb;
    $self->{_parent_save_cb} = $save_cb;
    $self->{_parent_del_cb} = $del_cb;

    return;
}

sub get_parent_backend
{
    my ($self) = @_;

    return ($self->{_parent_backend}, $self->{_parent_get_cb}, $self->{_parent_save_cb}, $self->{_parent_del_cb});
}

sub get
{
    my ($self, $cb) = @_;

    unless ($self->{_backend} && $self->{_get_cb})
    {
	return 0;
    }

    my $rc = &{$self->{_get_cb}}($self->{_backend}, $self, undef, $cb);

    return $rc;
}

sub save
{
    my ($self, $cb) = @_;

    return 1 unless $self->{dirty};

    unless ($self->{_backend} && $self->{_save_cb})
    {
	return 0;
    }

    my $rc = &{$self->{_save_cb}}($self->{_backend}, $self, $cb);
    if ($rc && !$cb)
    {
	$self->{saved_at} = time();
	$self->{new} = 0;
	$self->{dirty} = 0;
    }

    return $rc;
}

sub save_parent
{
    my ($self, $cb) = @_;

    return 0 unless $self->{parent};
    return 1 unless $self->{parent}->{dirty};

    unless ($self->{parent}->{_parent_backend} && $self->{parent}->{_save_cb})
    {
	return 0;
    }

    my $rc = &{$self->{_save_cb}}($self->{_parent_backend}, $self->{parent}, $cb);
    if ($rc && !$cb)
    {
	$self->{parent}->{saved_at} = time();
	$self->{dirty} = 0;
    }

    return $rc;
}

sub expunge
{
    my ($self, $cb) = @_;

    unless ($self->{_backend} && $self->{_del_cb})
    {
	return 0;
    }

    my $rc = &{$self->{_del_cb}}($self->{_backend}, $self, $cb);
    if ($rc && !$cb)
    {
	$self->{deleted_at} = time();
	$self->{dirty} = 0;
    }

    return $rc;
}

sub get_parent
{
    my ($self, $cb) = @_;

    unless ($self->{_parent_backend} && $self->{_parent_get_cb})
    {
	return 0;
    }

    my $rc = &{$self->{_parent_get_cb}}($self->{_parent_backend}, \$self->{parent}, $self, $cb);

    return $rc;
}

sub str
{
    my ($self) = @_;

    my $str = ref($self) . "(";
    foreach my $k (sort keys %{$self})
    {
	$str .= " $k:'$self->{$k}'" if defined $self->{$k};
    }
    $str .= " )";

    return $str;
}

sub attr_keys
{
    my ($self) = @_;

    # 20 keys
    my @service_attr_keys = qw/tenant_id id name price check_attrs pool_v4 pool_v6
	reply_attrs expiry quota_time_pre quota_time_post quota_octets_pre
	quota_octets_post allow_to_exceed rate_ul_throt rate_ul rate_ul_max
	rate_dl_throt rate_dl rate_dl_max/;

    return @service_attr_keys;
}

sub attr_values
{
    my ($self, $null) = @_;

    my @array = ();

    my @service_attr_keys = $self->attr_keys();
    foreach my $service_attr_key (@service_attr_keys)
    {
	if ($null && !defined $self->{$service_attr_key})
	{
	    push(@array, 'NULL');
	}
	else
	{
	    push(@array, $self->{$service_attr_key});
	}
    }

    return @array;
}

sub is_new
{
    my ($self) = @_;

    return $self->{new};
}

sub is_free
{
    my ($self) = @_;

    return !$self->{price};
}

sub allow_to_exceed
{
    my ($self) = @_;

    return $self->{allow_to_exceed};
}

sub disallow_resubscribe
{
    my ($self) = @_;

    return $self->{disallow_resubscribe};
}

1;
