# DHCPPeer.pm
#
# Acts as a generic DHCP peer suitable for a client or server
#
# Author: Heikki Vatiainen (hvn@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::DHCPPeer;
@ISA = qw(Radius::Configurable);
use Radius::Configurable;
use Radius::Util;
use Radius::DHCP;
use Radius::Select;
use Radius::Log;
use Fcntl;
use strict;
use warnings;

# This is a hash of messages for which we are awaiting replies.  Each
# entry is a reference to a message which describes the requested DHCP
# information and any information required to handle the message and
# its future request or timeout.
my %pendingRequests;

%Radius::DHCPPeer::ConfigKeywords =
(
 'LocalPort' =>
 ['string', 'The UDP port to use when binding the LocalAdress. Defaults to 67.', 1],

 'LocalAddress' =>
 ['string', 'The bind address to use for the DHCP peer socket. Defaults to 0.0.0.0.', 1],

 'Synchronous' =>
 ['flag', 'All requests operate synchronously with the DHCP server and block until a reply is received or fails. Defaults to 0', 1],
);

# RCS version number of this module
$Radius::DHCPPeer::VERSION = '$Revision$';

#####################################################################
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initalize instance
# variables that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{Host} = '255.255.255.255';
    $self->{Port} = $Radius::DHCP::SERVER_PORT;
    $self->{LocalPort} = $Radius::DHCP::SERVER_PORT;

    main::addChildInitFn(\&childInit, $self);

    return;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    # Lets see if we have LocalAddress
    $self->get_local_address() unless $main::config->{FarmSize};

    return;
}

#####################################################################
# (Re)activate a new peer
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # If we are using server farm, we can not bind before fork
    $self->socketInit() unless $main::config->{FarmSize};

    return;
}

######################################################################
# Resolve the LocalAddress, possibly after FarmSize forking, to see if
# we can send anything
sub get_local_address
{
    my ($self) = @_;

    my $addr = Radius::Util::format_special($self->{LocalAddress});
    my $packed = $addr ? Socket::inet_aton($addr) : undef;
    unless ($packed)
    {
	$packed = Radius::Util::inet_pton($main::hostname);
	$self->log($main::LOG_WARNING, "DHCPPeer: No LocalAddress configured and can not resolve $main::hostname to an IP address. You must configure LocalAddress")
	    unless $packed;
	$self->log($main::LOG_INFO, "DHCPPeer: No LocalAddress configured, resolved hostname $main::hostname to LocalAddress " . Radius::Util::inet_ntop($packed))
	    if $packed;
    }

    return $packed;
}

#####################################################################
# This is called by the main (supervising) server when server farm is
# used. The function is called in each child after it is forked by
# forkFarmInstance
sub childInit
{
    my ($self) = @_;

    # Each child requires separate socket
    $self->socketInit();

    return;
}

#####################################################################
# Do class level initialization
sub socketInit
{
    my ($self) = @_;

    # May be reinitializing
    Radius::Select::remove_file(fileno($self->{Socket}), 1, undef, undef)
	if $self->{Socket};
    delete $self->{Socket};

    # The address we need to bind to
    $self->{dhcp_local_address_packed} = $self->get_local_address();
    return unless $self->{dhcp_local_address_packed};

    # We could have used FileHandle here, but this is much
    # more lightweight. It makes a reference to a TYPEGLOB
    # and Perl can use a typeglob ref as an IO handle
    my $s = do { local *FH };

    # Create a socket for us to send through
    unless (socket($s, Socket::PF_INET, Socket::SOCK_DGRAM, scalar getprotobyname('udp')))
    {
	$self->log($main::LOG_ERR, "DHCPPeer: Could not create DHCP socket: $!");
	return;
    }

    binmode($s); # Make safe in UTF environments
    unless (setsockopt($s, Socket::SOL_SOCKET, Socket::SO_REUSEADDR, 1))
    {
	$self->log($main::LOG_ERR, "DHCPPeer: Could not setsockopt(SO_REUSEADDR): $!");
	return;
    }

    my $port = $self->{LocalPort};
    unless (bind($s, Socket::pack_sockaddr_in($port, $self->{dhcp_local_address_packed})))
    {
	$self->log($main::LOG_ERR, "DHCPPeer: Could not bind to LocalAddress " . Socket::inet_ntoa($self->{dhcp_local_address_packed}) . ":$port: $!");
	return;
    }

    # REVISIT: Non blocking sockets work on windows with recent Perls
    if ($^O ne 'MSWin32')
    {
	# Win95 does not support fcntl or non-blocking sockets yet.
	unless (fcntl($s, F_SETFL, fcntl($s, F_GETFL, 0) | O_NONBLOCK))
	{
	    $self->log($main::LOG_ERR, "DHCPPeer: Could not fcntl(O_NONBLOCK) DHCP socket: $!");
	    return;
	}
    }

    # Set the socket to handle broadcasts.
    unless (setsockopt($s, Socket::SOL_SOCKET, Socket::SO_BROADCAST, 1))
    {
	$self->log($main::LOG_ERR, "DHCPPeer: Could not set DHCP socket to handle broadcasts: $!");
	return;
    }

    # The socket is now successfully set up for DHCP
    $self->{Socket} = $s;

    # Add this socket to the list in Radius::Select.
    Radius::Select::add_file
	(fileno($self->{Socket}), 1, undef, undef,
	 \&handle_dhcp_socket_read,
	 $self->{Socket}, $self);

    return;
}

#####################################################################
# Send or resend a DHCP message
sub send_dhcp_msg
{
    my ($self, $message) = @_;

    my $p = $message->{p};
    my $packet = Radius::DHCP::assemble_message($message->{values});

    # Notes: 1) we resolve the host just once in case it's a name that
    # resolves to multiple IPv4 addresses. 2) we also resolve the
    # destination again in case of a timeout. We might get a working
    # address this time.
    my $dest_ip_packed = Socket::inet_aton($message->{host});
    unless ($dest_ip_packed)
    {
	$self->log($main::LOG_WARNING, "DHCPPeer failed to resolved $message->{host} to an IPv4 address", $p);
	return ($main::IGNORE, 'Failed to resolve DHCP server address');
    }

    my $dest_ip = Socket::inet_ntoa($dest_ip_packed);
    my $destport = Socket::pack_sockaddr_in($message->{port}, $dest_ip_packed);

    # Save the resolved address for later. We can e.g. log it if we
    # handle request timeouts
    $message->{dest_ip} = $dest_ip;

    if (main::willLog($main::LOG_DEBUG, $p))
    {
	my $message_type_name = $Radius::DHCP::message_type_number_to_name{$message->{values}->{message_type}};
	$self->log($main::LOG_DEBUG, "Sending $message_type_name to $message->{host} ($dest_ip:$message->{port}) with xid $message->{values}->{xid}", $p);
    }

    # Some platforms (eg Linux) will produce "Connection refused" if
    # the desination does not have a port open, so ignore those kinds
    # of errors
    if (!send($self->{Socket}, $packet, 0, $destport))
    {
	$self->log($main::LOG_ERR, "DHCPPeer: send to $message->{host} ($dest_ip:$message->{port}) failed: $!", $p);
	# Note: we keep on going
    }

    # Exit now if no timeout handling and retransmissions are needed.
    unless ($message->{timeout})
    {
	return ($main::ACCEPT);
    }

    # Remember the message for handling the reply. We keep a hash
    # where the key is the address and port of the host we sent to,
    # concatenated with the xid
    my $key = "$dest_ip:$message->{port}:$message->{values}->{xid}";
    $pendingRequests{$key} = $message;

    # Arrange for retransmission timeout. We remember the timeout
    # handle so we can remove it if we get a reply
    $message->{timeouthandle} =
	Radius::Select::add_timeout(time() + $message->{timeout},
	   \&Radius::DHCPPeer::handle_timeout,
	   $self, $key, $p);

    if ($self->{Synchronous})
    {
        # Here we process replies until the request we are doing
        # has either been replied to or timed out
        # CAUTION: while this is happening, no other incoming requests
        # will be handled: If the remote server is down
        # you may get a serious performance hit
        # Wait for activity on the reply socket or timeouts
	my $waitfor = 0;
	my $found;
	vec($waitfor, fileno($self->{Socket}), 1) = 1;
	while (!defined $p->{DHCPResult})
	{
            # Wait up to a second for activity on the socket
	    select($found=$waitfor, undef, undef, 1)
		&& handle_dhcp_socket_read
		(fileno($self->{Socket}), $self->{Socket}, $self);
	    Radius::Select::process_timeouts();
	}
	return ($p->{DHCPResult});
    }

    $p->{proxied}++;
    return ($main::IGNORE, 'Waiting for DHCP');
}

#####################################################################
# This is called by Select::select, or when Synchronous is set, by
# send_dhcp_msg whenever our DHCP socket becomes readable. Read at
# most one packet from the socket and process it.
sub handle_dhcp_socket_read
{
    my ($fileno, $socket, $self) = @_;

    my ($whence, $rec);
    if ($whence = recv($socket, $rec, 8192, 0))
    {
	# Get the packet from the DHCP socket and disassemble it.
	my ($port, $addr) = Socket::unpack_sockaddr_in($whence);
	my $ip = Socket::inet_ntoa($addr);

	my $reply = Radius::DHCP::disassemble_packet($rec);
	$self->log($main::LOG_DEBUG, "Received DHCP message from $ip :\n" . Radius::DHCP::dump($reply));

	# Check the MAGIC_COOKIE to verify the contents
	if ($$reply{magic_cookie} ne $Radius::DHCP::MAGIC_COOKIE)
	{
	    $self->log($main::LOG_WARNING, "DHCPPeer: Broken DHCP packet received from $ip:$port");
	    return;
	}

	if ($$reply{op_code} == $Radius::DHCP::SERVER_OPCODE)
	{
	    # Get the message that was saved
	    my $xid = $$reply{xid};
	    my $key = "$ip:$port:$xid";
	    my $message = delete $pendingRequests{$key};

	    # Was the packet sent to the broadcast address?
	    if (!defined $message)
	    {
		my $bcast_ip = Socket::inet_ntoa(Socket::INADDR_BROADCAST);
		$key = "$bcast_ip:$port:$xid";
		$message = delete $pendingRequests{$key};
	    }

	    # Couldn't find a reference
	    if (!defined $message)
	    {
		$self->log($main::LOG_WARNING, "Unknown reply received in AddressAllocatorDHCP for request $xid from $ip:$port");
		return;
	    }

	    # Found the reference to message
	    my $p = $message->{p};

	    # Cross it off our timeout list
	    Radius::Select::remove_timeout($message->{timeouthandle})
		|| $self->log($main::LOG_ERR, "Timeout $message->{timeouthandle} was not in the timeout list");

	    # Process the reply. Return value tells us how to continue.
	    $self->log($main::LOG_DEBUG, "Received reply in AddressAllocatorDHCP for req $xid from $ip:$port", $p);
	    my ($result, $reason) = $self->handle_dhcp_server_reply($whence, $message, $reply);
	    return if $result == $main::IGNORE;

	    # When Synchronous is set, the caller is waiting for
	    # DHCPResult to become set. When this happens, the caller
	    # can return to Handler. Otherwise we call our method that
	    # does what is needed.
	    $self->{Synchronous} ?
		$p->{DHCPResult} = $result :
		$self->handle_non_synchronous_result($p, $result, $reason);

	    return;
	}
	elsif ($$reply{op_code} == $Radius::DHCP::CLIENT_OPCODE)
	{
	    $self->handle_dhcp_client_request($whence, $reply);
	    return;
	}

	# Can get our own previous request back here on some OSs
	$self->log($main::LOG_DEBUG, "Non-Server DHCP packet received in AddressAllocatorDHCP from $ip:$port");
	return;
    }

    # REVISIT: Catch errors with recv?
    return;
}

#####################################################################
# This is called from within Select::process_timeouts for each request
# we have sent but not received a reply within the timeout period
sub handle_timeout
{
    my ($handle, $self, $key) = @_;

    # Cross it off our pending list
    my $request = delete $pendingRequests{$key};
    unless ($request)
    {
	$self->log($main::LOG_ERR, "DHCPPeer: Timed out request with key $key not found");
	return;
    }

    my $values = $request->{values};
    my $p = $request->{p};
    my $secs = $request->{timeout};
    my $timeout = $request->{timeout} * $self->{TimeoutFactor};

    $self->log($main::LOG_DEBUG, "DHCPPeer: Request with key $key to $request->{host} ($request->{dest_ip}:$request->{port}) timed out", $p);
    if ($timeout <= $self->{TimeoutMaximum})
    {
	# Save the new timeout value and elapsed seconds
	$request->{timeout} = $timeout;
        $request->{values}->{secs} += $secs;

	$self->send_dhcp_msg($request);
    }
    else
    {
	$self->log($main::LOG_INFO, "DHCPPeer: No reply from DHCP server $request->{host} ($request->{dest_ip}:$request->{port})", $p);
	my ($result, $reason) = $self->handle_dhcp_server_timeout($request);

	# When Synchronous is set, the caller is waiting for
	# DHCPResult to become set. When this happens, the caller can
	# return to Handler. Otherwise we call our method that does
	# what is needed.
	$self->{Synchronous} ?
	    $p->{DHCPResult} = $result :
	    $self->handle_non_synchronous_result($p, $result, $reason);
    }

    return;
}

# When Asynchronous or Synchronous is unset, this is called when a
# reply either times out or is received.
sub handle_non_synchronous_result
{
    my ($self, $p, $result, $reason) = @_;

    my $ref = ref($self);
    $self->log($main::LOG_ERR, "$ref Does not implement handle_synchronous_result. Ignoring the received message.", $p);

    return;
}

1;
