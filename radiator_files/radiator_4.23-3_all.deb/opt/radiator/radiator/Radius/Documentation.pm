# Documentation.pm
#
# Module to encapsulate documentation of available Radidator 
# modules for use by ServerHTTP
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997-2001 Open System Consultants
# $Id$

package Radius::Documentation;
use strict;
use warnings;

# RCS version number of this module
$Radius::Documentation::VERSION = '$Revision$';

# Key is object ref type
# Value is documentaiton about the use of that type of object
%Radius::Documentation::objects =
(
 'AcctLogEVENTLOG' => 'Logs accounting messages to Windows Event Log.',

 'AcctLogFILE' => 'Logs accounting messages to a flat file.',

 'AcctLogGeneric' => '',

 'AcctLogSQL' => 'Logs accounting messages to an SQL database.',

 'AcctLogSYSLOG' => 'Logs accounting messages to a SYSLOG server',

 'AddressAllocatorDHCP' => 'Works in conjunction with &lt;AuthBy DYNADDRESS&gt; and a DHCP server to dynamically allocate IP addresses.',

 'AddressAllocatorGeneric' => '',
 'AddressAllocatorSQL' => 'Works in conjunction with &lt;AuthBy DYNADDRESS&gt; to allocate IP addresses from an SQL database. The default behaviour is to allocate the oldest unused address from the RADPOOL table. During deallocation, the address is marked is unused. Addresses that remain in use for more than DefaultLeasePeriod seconds are automatically reclaimed (this protects against lost Accounting Stop requests).',

 'AES' => '',
 'ApplePasswordServer' => '',
 'AttrList' => '',
 'AttrVal' => '',
 'AuthACE' => 'Performs authentication directly to an RSA Security Authentication manager (formerly SecurID ACE/Server). See www.rsasecurity.com for details. RSA Security Authentication Manager provides a token-based one-time password system. AuthBy ACE requires the Authen-ACE4 Perl module from CPAN (pre-built binaries for Windows are available from OSC). Obsoleted by AuthBy RSAAM',

 'AuthADSI' => 'Authenticates from Windows Active Directory, which is the user information database on Windows 2000. It uses ADSI (Active Directory Service Interface) to get user information from any Active Directory service provider available to your Windows 2000 system. It is only available on Windows 2000 platforms.',

 'AuthCDB' => 'Authenticates users from a user database stored in a CDB database file. CDB is a fast, reliable, lightweight package for creating and reading constant databases. More details about CDB can be found at http://cr.yp.to/cdb.html. It is implemented in AuthCDB.pm, which was contributed by Pedro Melo (melo@ip.pt). It does not log (but does reply to) accounting requests. To use AuthBy CDB, you must install the CDB_File package from CPAN ',

# 'AuthCRYPTOCARD' => '',
 'AuthDBFILE' => 'Authenticates users from a user database stored in a DBM file in the standard Merit DBM format. It does not log (but does reply to) accounting requests. DBM files can be built from flat file user databases with the builddbm utility (see Section 8.0 on page 244).',

# 'AuthDIGIPASS' => 'use SQLDigipass',
 'AuthDIGIPASSGeneric' => '',
 'AuthDNSROAM' => 'Proxies Radius requests to remote Radius and/or RadSec servers based on the Realm in the User-Name. The appropriate server to send to and the protocol to use is discovered through DNS lookups configured through the Resolver clause. You must include a &lt;Resolver&gt; clause in your configuration if you intend to use &lt;AuthBy DNSROAM&gt;.',

 'AuthDYNADDRESS' => 'Used to dynamically allocate IP addresses in conjunction with &lt;AddressAllocator xxx&gt; clauses. There are two Address Allocation engines provided. &lt;AddressAllocator SQL&gt; can allocate addresses out of an SQL database. &lt;AddressAllocator DHCP&gt; can allocate addresses from a DHCP server.',

# 'AuthEAP' => '',
 'AuthEMERALD' => 'Provides authentication and accounting using the popular Emerald ISP billing package (version 3 and earlier) from IEA (http://www.emerald.iea.com). Users of Emerald 4 should use &lt;AuthBy EMERALD4&gt;',

 'AuthEMERALD4' => 'Provides authentication and accounting using the popular Emerald ISP billing package (version 4 and later) from IEA (http://www.emerald.iea.com)',

 'AuthEXTERNAL' => 'Authenticates by passing all requests to an external program, which is responsible for determining how to handle the request.',

 'AuthFIDELIO' => 'Authenticates users from Micros-Fidelio Opera. Opera is a popular hotel Property Management System from Micros Fidelio (http://www.micros.com).',

 'AuthFILE' => 'Authenticates users by checking them against a flat file user database.',

 'AuthFREERADIUSSQL' => 'Handles authentication and accounting from a FreeRadius compatible SQL database. The default SQL queries use the standard FreeRadius tables radcheck, radreply, radgroupcheck, radgroupreply and radacct. ',

 'AuthGeneric' => '',

 'AuthGROUP' => 'Allows you to conveniently define and group multiple AuthBy clauses. This is most useful where you need to be able to have multiple sets of authentication clauses, perhaps with different AuthByPolicy settings for each group. You can use an AuthBy GROUP (containing any number of AuthBy clauses) anywhere that a single AuthBy clause is permitted. AuthBy GROUP can be nested to any depth.',

 'AuthHASHBALANCE' => 'Distributes RADIUS requests among a set of RADIUS servers in such a way such that multiple related requests from the same user (such as EAP handshakes etc) will go to the same server (unless that server fails). This prevents EAP handshakes being distributed  among multiple servers, which would otherwise cause the EAP handshake to be rejected or ignored.',

 'AuthHTGROUP' => 'Checks group membership according to an Apache htgroup file. Apache is a popular HTTP server, and supports flat group files for authenticating web access. With &lt;AuthBy HTGROUP&gt; Radiator can authenticate users against the same files that Apache uses, in order to provide a single source of authentication information for both Apache and Radiator.',

 'AuthIMAP' => 'Authenticates from an IMAP server. Requires the Mail::IMAPClient perl module version 2.2.5 or better, available from CPAN. AuthBy IMAP can support SSL or non-SSL connections to the IMAP server. Use of SSL connections requires IO::Socket::SSL from CPAN and OpenSSL. AuthBy IMAP only supports PAP authentication in incoming Radius requests. CHAP and MS-CHAP are not supported, since the plaintext password is not available within Radiator.',

 'AuthINTERNAL' => 'Allows you permanently predefine how to reply to a request, depending only on the type of request. You can specify whether to ACCEPT, REJECT, IGNORE or CHALLENGE each type of request. The default behaviour is to IGNORE all requests. You can override the behaviour of each fixed result with an optional Perl hook, in which case the hook will return the result code.',

 'AuthIPASS' => 'Deprecated. Do not use. The preferred method of interoperating with iPASS is to proxy outbound requests from Radiator to the iPASS radius server, using &lt;AuthBy RADIUS&gt;. ',

# 'AuthJRADIUS' => 'incomplete',

 'AuthKRB5' => 'Authenticates using the Kerberos 5 authentication system, which is available on most types of operating system. It authenticates afrom a previously defined Kerberos KDC (Key Distribution Centre). AuthBy KRB5 can authenticate PAP and TTLS-PAP. Accounting are ACCEPTed but discarded. Requires the Authen::Krb5 module version 1.3 or later from CPAN.',

 'AuthLDAP' => 'Deprecated. AuthBy LDAP2 should be used for preference, as this authenticator uses an old LDAP interface. Authenticates by connecting to an LDAP server. Requires Clayton Donley\'s Net::LDAPapi module version 1.42 or better (Available from CPAN). ',

 'AuthLDAP2' => 'Authenticates by connecting to an LDAP server. Users can be authenticated by fetching the plaintext password from the LDAP server, or by using the server to authenticate a plaintext password.',

 'AuthLDAP_APS' => 'Finds user details in a Mac OS-X Directory Server LDAP database, and then authenticates the user password against a Mac OS-X Apple Password Server.Requires Crypt::OpenSSL::Random Crypt::OpenSSL::RSA Crypt::OpenSSL::Bignum MIME::Base64 Digest::HMAC_MD5',

 'AuthLDAP_MSISDN' => 'Deprecated. Authenticates using an LDAP database and records accounting in an MSISDN database. Requires Net::LDAPapi',

 'AuthLDAPDIGIPASS' => 'Provides authentication of Vasco Digipass tokens (http://www.vasco.com) from an LDAP database.',

 'AuthLDAPRADIUS' => 'Proxies requests to a target Radius server. The target host is determined by a lookup in an LDAP database. This allows the easy management of large numbers of downstream radius servers, such as in a wholesale ISP.',

 'AuthLDAPSDK' => 'Deprecated. AuthBy LDAP2 should be used for preference, as this authenticator uses an old LDAP interface. Authenticates by connecting to an LDAP server. Requires Netscape\'s PerLDAP module and the Netscape Directory SDK',

 'AuthLOADBALANCE' => 'Load Balancing proxy module. Incoming Radius requests are distributed between all the listsed hosts acccording to the relative values of their BogoMips attributes and the time the remote server takes to process requests. ',

 'AuthLogFILE' => 'Logs authentication successes and failures to a flat file.',

 'AuthLogGeneric' => '',

 'AuthLogSQL' => 'Logs authentication successes and failures to an SQL database.',

 'AuthLogSYSLOG' => 'Logs authentication successes and failures to a SYSLOG server',

 'AuthLSA' => 'Provides authentication against user passwords in any Windows Active Directory or NT Domain Controller, by using the Windows LSA (Local Security Authority). Since it accesses LSA directly, it can authenticate dialup or wireless passwords with PAP, CHAP, MSCHAP, MSCHAPV2, LEAP and PEAP. AuthBy LSA is only available on Windows 2000, 2003 and XP. (Windows XP Home edition is not supported). It requires the Win32-Lsa perl module from Open System Consultants. ',

 'AuthMOBILEIP' => 'Handles authentication replies for 3GPP2 Mobile IP. Place this AuthBy after the user authentication AuthBy.',

 'AuthMULTICAST' => 'Sends copies of some or all Radius requests to a number of remote Radius servers.',

 'AuthNISPLUS' => 'Provides authentication from a NIS+ database. It looks for user information in an NIS+ table, and uses that information as check and reply items for the user. It does not log (but does reply to) accounting requests. You will need to have a basic understanding of NIS+ databases in order to configure AuthBy NISPLUS. AuthBy NISPLUS requires the NISPlus Perl module from CPAN.',

 'AuthNT' => 'Authenticates users with the NT User Manager or Primary Domain Controller. It is implemented in AuthNT.pm. It does not log (but does reply to) accounting requests. AuthBy NT can not work with CHAP or MSCHAP authentication. Available on both Windows and Unix',

 'AuthNTLM' => 'Authenticates against a Windows Domain Controller, using the ntlm_auth program, which is part of the Samba suite (www.samba.org). ntlm_auth runs on all Unix and Linux platforms, and therefore &lt;AuthBy NTLM&gt; can be used on Unix or Linux to authenticate to a Windows Domain Controller. ',

 'AuthOPIE' => 'Authenticates from OPIE (onetime passwords in everything), a one-time password system based on S/Key, and written by  Craig Metz, see http://www.inner.net/opie, version opie-2.4 or better. It also requires the Perl OPIE module OPIE-0.75 or better from ftp://pooh.urbanrage.com/pub/perl. OPIE is only supported in Unix platforms. It can be used with PAP, but not CHAP or MS-CHAP. It can also be used with EAP-One-Time-Passwords and EAP-Generic-Token-Card authentication in 802.1X wired and wireless networks.',

 'AuthOTP' => 'Provides extensible and customisable to support a range of One-Time-Password (OTP) schemes, including automatic password generation and sending of passwords through a back-channel such as SMS. AuthBy OPT is suitable for authenticating 802.1X Wired and Wirelss access with custom one-time-password and token card authentication systems. ',

 'AuthPAM' => 'Provides authentication via any method supported by PAM (Pluggable Authentication Modules) on your host. Requires that PAM be installed and configured on your host, and it also requires the Perl module Authen-PAM-0.04 or later (available from CPAN). ',

 'AuthPLATYPUS' => 'Provides authentication and accounting using the popular Platypus ISP billing package from Boardtown (http://www.boardtown.com). ',

 'AuthPOP3' => 'Authenticates from a POP3 server, according to RFC1939. It requires the Mail::POP3Client perl module version 2.9 or better, available from CPAN. Supports both plaintext and APOP authentication in the POP server.',

 'AuthPORTLIMITCHECK' => 'Applies usage limits for arbitrary groups of users. Requires that you have a &lt;SessionDatabase SQL&gt; defined in your Radiator configuration. ',

 'AuthPRESENCESQL' => 'Authenticates users from an SQL database and records presence (current user location) to an SQL database. Implements a special form of RADIUS Access-Request that allows user presence data to be retrieved by suitably authorised devices. Can be used with telephone and VOIP systems to automatically route telephone calls according to the users current location.',

 'AuthRADIUS' => 'Acts as a proxy RADIUS server. Forwards all authentication and accounting requests for to another (possibly remote) Radius server. If and when the remote radius server replies, the reply will be forwarded back to the client that originally sent the request.',

# 'AuthRADKEY' => 'Obsolete. Do not use.',

 'AuthRADMIN' => 'Provides authentication and accounting using the RAdmin User Administration package from Open System Consultants (https://www.open.com.au/radmin). RAdmin is a complete web-based package that allows you to maintain your Radius user and accounting details in an SQL database. You can add, change and delete users, examine connection history, control simultaneous login, get reports on modem usage and many other functions. The combination of Radiator and RAdmin provides a complete solution to your Radius user administration requirements.',


 'AuthRADSEC' => 'Proxies RADIUS requests to a &lt;ServerRADSEC&gt; clause on remote Radiator using the RadSec secure reliable RADIUS proxying protocol. It can be used instead of AuthBy RADIUS when proxing across insecure or unreliable networks such as the internet. See the reference manual for more details about the RadSec protocol.',

 'AuthRODOPI' => 'Obsolete. Recent versions of Rodopi require the AuthBy RODOPIAAA package from Rodopi. Provides authentication and accounting using the popular Rodopi ISP billing package (http://www.rodopi.com). The combination of Radiator and Rodopi provides a very powerful and easy to use ISP billing and user management system.',

 'AuthRODOPIAAA' => 'Provides authentication and accounting using the popular Rodopi ISP billing package (http://www.rodopi.com). The combination of Radiator and Rodopi provides a very powerful and easy to use ISP billing and user management system.',

 'AuthROUNDROBIN' => 'Load Balancing module. The first incoming Radius request is proxied to the first server listed, the next to the second listed etc., until the list is exhausted, then it starts again at the top of the list. If at any time a proxied request does not receive a reply from a remote server, that server is marked as unavailable until FailureBackoffTime seconds has elapsed. Meanwhile that request is retransmitted to the next host due to be used.',

 'AuthRSAAM' => 'Authenticates from an RSA Authenitcation Manager 7.1 or later server. RSA AM is a token authentication system from RSA Security. Supports SecureID token cards, static passwords and OnDemand tokencodes deliverd by SMS or email. It requires SOAP::Lite and all its prerequisites for SSL, including Crypt::SSLeay or IO::Socket::SSL+Net::SSLeay from CPAN. AuthBy RSAAM supports all the features provided by AuthBy ACE and AuthBy RSAMOBILE, and therefore obsoletes those modules',

 'AuthRSAMOBILE' => 'Authenticates from an RSA Mobile server. RSA Mobile is a token authentication system from RSA Security. During authentication, the user provides a password, then the RSA Mobile server sends a one-time-password by SMS, pager etc. When the correct one-time-password is entered, then the authentication succeeds. It requires SOAP::Lite and all its prerequisites from CPAN. Obsoleted by AuthBy RSAAM',

 'AuthSAFEWORD' => 'Authenticates users from a local or remote SafeWord PremierAccess (SPA) server. SafeWord PremierAccess and tokens are available from SecureComputing (http://www.securecomputing.com). Supports PAP, CHAP, TTLS-PAP, EAP-OTP and EAP-GTC. Supports password changing.  Supports fixed (static) passwords and SafeWord Silver and Gold tokens.',

 'AuthSASLAUTHD' => 'Authenticates against a saslauthd server running on the same host as Radiator. Saslauthd is a Unix authentication server program, part of the Cyrus SASL suite. It can be configured to authenticate from a variety of sources, including PAM, Kerberos, DCE, shadow password files, IMAP, LDAP, SIA or a special SASL user password file. It is part of the Cyrus SASL suite.',

# 'AuthSBAUTH' => '',
# 'AuthSMARTCARD' => '',

 'AuthSOAP' => 'Handles authentication and accounting by sending it to a remote Radius server over TCP using the SOAP protocol. Each Radius request is transformed into a SOAP request, which  is sent by HTTP or HTTPS to a remote SOAP server. The Remote SOAP server can be any implementation, but example SOAP server code is provided with Radiator. AuthBy SOAP can be useful in order to tunnel Radius requests througth ports 80 or 443 in a firewall, where UDP port 1645 is not permitted throught the firewall. It can also be used to improve reliabilty in some environments by using TCP rather than UDP. ',

 'AuthSQL' => 'Authenticates users from an SQL database, and stores accounting records to an SQL database. AuthBy SQL is very powerful and configurable, and has many parameters in order to customize its behaviour, so please bear with us. You will need to have some familiarity with SQL and relational databases in order to configure and use AuthBy SQL.',

 'AuthSQLDIGIPASS' => 'Provides authentication of Vasco Digipass tokens (http://www.vasco.com) from an SQL database.',

 'AuthSQLHOTP' => 'Provides authentication of HOTP (RFC 4226) one-time-passwords with the HOTP secret stored in an SQL database. Conforms to the HOTP requirements of OATH (http://www.openauthentication.org)',

 'AuthSQLRADIUS' => 'Proxies requests to a target Radius server. The target host is determined by a table lookup in an SQL database. This allows the easy management of large numbers of downstream radius servers, such as in a wholesale ISP. It inherits from both AuthBy SQL and AuthBy RADIUS.',

 'AuthSQLYUBIKEY' => 'Authenticates Yubikey tokens from Yubico (yubico.com) against token details from an SQL database. Requires Auth:Yubikey_Decrypter and Crypt::Rijndael',

 'AuthSYSTEM' => 'Provides authentication with your getpwnam and getgrnam system calls. On most Unix hosts, that will mean authentication from the same user database that normal user logins occur from, whether that be /etc/passwd, NIS, YP, NIS+ etc. It is implemented in AuthSYSTEM.pm. This allows you to hide whether its password files, NIS+, PAM or whatever else might be installed on your system. It is not supported on Win95 or NT, or on systems (such as Solaris) with shadow password files (unless Radiator runs with root permissions).',

 'AuthTACACSPLUS' => 'provides authentication via a TacacsPlus server. It supports authentication only, not accounting or authorization.',

 'AuthTEST' => 'Always accepts authentication requests, and ignores (but replies to) accounting requests. Useful for testing purposes, but you should be sure not to leave them lying around in your configuration file, otherwise you might find that users are able to be authenticated when you really didn\'t want them to. ',

# 'AuthTIERSQL' => '',

 'AuthUNIX' => 'Authenticates users from a user database stored in a standard Unix password file or similar format.',

 'AuthURL' => 'Authenticates using HTTP from any URL. It can use any given CGI or ASP, that validates username and password. It requires the Digest::MD5 and HTTP::Request and LWP::UserAgent perl modules in libwww-perl-5.63 or later package available from CPAN. Supports both GET and POST Method for http querystrings.',

 'AuthVOLUMEBALANCE' => 'Load Balancing module. Incoming Radius requests are distributed between all the listed hosts acccording to the relative values of their BogoMips attributes.',

 'AuthWIMAX' => 'Authenticates WiMAX requests from an SQL database, generates WiMAX mobility keys and maintains a DeviceSession table in SQL. Requires Digest::SHA',

 'BigInt' => '',

 'Client' => 'A Client defines one or more RADIUS clients that this server is willing to accept requests from. You must specify at least the client name/address and a shared Secret. The Secret must match the one configured into the client device.',

 'ClientListLDAP' => 'Allows you to specify your Radius clients in an LDAP database in addition to (or instead of) your Radiator configuration file.',

 'ClientListSQL' => 'Allows you to specify your Radius clients in an SQL database table in addition to (or instead of) your Radiator configuration file.',

 'Configurable' => '',
 'Context' => '',
 'DES' => '',
 'DHCP' => '',
 'DiaAttrList' => '',
 'DiaClient' => '',
 'DiaDict' => '',
 'Diameter' => '',
 'DiaMsg' => '',
 'DiaPeer' => '',
 'Dictionary' => '',
 'Documentation' => '',
 'EAP' => '',
 'EAP_13' => '',
 'EAP_15' => '',
 'EAP_17' => '',
 'EAP_21' => '',
 'EAP_25' => '',
 'EAP_26' => '',
 'EAP_38' => '',
 'EAP_4' => '',
 'EAP_43' => '',
 'EAP_46' => '',
 'EAP_47' => '',
 'EAP_5' => '',
 'EAP_6' => '',
 'Fidelio' => '',
 'Finger' => '',

 'Handler' => 'A Handler handles all requests that match a specific test against one or more attributes. The Name contains the test to make, such as NAS-IP-Addres=1.2.3.4. Special characters are supported. You can define one or moreAuthBy clauses that will be used to authenticate all requests sent to this Handler, and the AuthBys will be checked in order until the AuthByPolicy is met.',

 'Host' => 'A remote RADIUS host to which RADIUS requests will be proxied',

 'IEEEfp' => '',
 'Ldap' => '',
 'Log' => '',

 'LogEMERALD' => 'Saves log messages to an Emerald SQL database',

 'LogFILE' => 'Saves log messages to a flat file',

 'LogGeneric' => '',
 'Logger' => '',
 'LogSQL' => 'Saves log messages to an SQL database',

 'LogSYSLOG' => 'Send log messages to a SYSLOG server',

 'Mib' => '',

 'Monitor' => 'Enables external client programs to make an (authenticated) TCP connection to Radiator, and use that connection to monitor, probe, modify and collect statistics from Radiator. One such external client program is Radar, a real-time interactive GUI that permits monitoring, plotting of statistics and much more. See https://www.open.com.au/radar for more details.<br><p><b>Caution:</b>Careless configuration of Monitor can open security holes in your RADIUS server host. Use with care.',

 'MSCHAP' => '',
 'Nas' => '',
 'PBKDF' => '',
 'Predicate' => '',
 'Radius' => '',
 'RadpwtstGui' => '',
 'RadSec' => '',
 'RadsecHost' => 'A remote RadSec host to which RadSec requests will be proxied',
 'Rcrypt' => '',
 'RDict' => '',

 'Realm' => 'A Realm handles all requests that have a specific realm in the User-Name (the realm is the part following any @ sign in the User-Name). You can define one or moreAuthBy clauses that will be used to authenticate all requests for that Realm, and the AuthBys will be checked in order until the AuthByPolicy is met.',

 'Resolver' => 'Provides DNS and name resolution services for the AuthBy DNSROAM clause. It is only required and should only be used if you have an AuthBy DNSROAM clause in your configuration.',

 'AuthDNSROAM::Route' => 'A hardwired route for AuthBy DNSROAM. All requests that match the Realm will be forwarded using RadSec or RADIUS Protocol.',

 'Select' => '',

 'ServerConfig' => 'ServerConfig defines the behaviour of the Radiator RADIUS server as a whole, and is the starting point for configuring Radiator. For the simplest RADIUS server configuration, you should define at least one Client and at least one Realm. Inside the Realm, you should define at least one AuthBy to do the authentication',

 'ServerDIAMETER' => 'Tells Radiator to act as a Diameter to RADIUS gateway. All Diameter requests received through the gateway will be converted into equivalent RADIUS requests and despatched to a matching Realm or Handler for authentication',

# 'ServerFarm' => '',

 'ServerHTTP' => 'Provides an (authenticated) web interface, allowing Radiator to be monitored, inspected and reconfigured from a standard web browser.<p><b>Caution:</b>Careless configuration of ServerHTTP can open security holes in your RADIUS server host. Use with care.',

# Dont want this to appear in selection lists yet: just for internal use
# 'ServerRADIUS' => 'Provides services for listening for RADIUS requests',

 'ServerRADSEC' => 'Accepts RadSec connections from AuthBy RADSEC clauses in other Radiators and processes RADIUS requests sent over the RadSec connection in a similar way to how a Client clause received conventional UDP RADIUS requests. RadSec can be used to provide secure reliable proxying of RADIUS requests from one Radiator to another, even over insecure networks. See https://www.open.com.au/radiator/radsec-whitepaper.pdf for more information about RadSec. Incoming RADIUS requests received over this ServerRADSEC will be despatched to a matching Realm or Handler for authentication',

 'ServerTACACSPLUS' => 'Tells Radiator to act as a Tacacs+ server. Tacacs+ is an older Authentication, Authorization and Accounting (AAA) protocol developed by Cisco, and supported by some Cisco devices. It uses TCP connections between the client (usually some kind of router) and the Tacacs+ server. Incoming TACACS+ requests will be converted into equivalent RADIUS requests and despatched to a matching Realm or Handler for authentication',

 'SessDBM' => 'Specifies an external DBM file Session Database. The Session Database is used to hold information about current sessions as part of Simultaneous-Use limit checking. It can also be used by external utilities for querying the on-line user population If you don\'t specify a SessionDatabase clause, the database will be kept internal to radiusd, which is faster, but does not make the data available to other processes.',

 'SessGeneric' => '',

 'SessINTERNAL' => 'The default Session Database. Per-user session information is kept internally within the Radiator process.',

 'SessNULL' => 'This type of session database stores no session details, and always permits multiple logins. It is useful in environments with large user populations, and where no simultaneous-use prevention is required. &lt;SessionDatabase NULL&gt; uses much less memory and fewer CPU cycles than &lt;SessionDatabase INTERNAL&gt; (which is the default session database).',

 'SessSQL' => 'Specifies an external SQL Session Database for radiusd. The Session Database is used to hold information about current sessions as part of Simultaneous-Use limit checking. It can also be used by external utilities for querying the on-line user population. If you don\'t specify a SessionDatabase clause in your configuration file, the database will be kept internal to radiusd, which is faster, but can\'t be used to synchronize multiple instances of Radiator.',

 'SimpleClient' => '',
 'SimpleRadsecClient' => '',
 'SNMP' => '',
 'SNMPAgent' => 'Enables an SNMP Agent that will allow you to fetch statistics from Radiator using SNMP version 1. Radiator supports all the SNMP objects described in the draft IETF standard defined in draft-ietf-radius-servmib-04.txt, as well as in the RADIUS Authentication Server MIB defined in RFC 2619 and RADIUS Accounting Server MIB defined in RFC 2621. Only SNMP V1 is supported.',

 'SOAPRequest' => '',
 'SqlDb' => '',
 'StateMachine' => '',

 'StatsLogFILE' => 'Logs statistics to a flat file.',

 'StatsLogGeneric' => '',

 'StatsLogSQL' => 'Logs statistics to an SQL database. ',

 'Stream' => '',
 'StreamTLS' => '',
 'TacacsClient' => '',
 'Tacacsplus' => '',
 'TLS' => '',
 'TLSConfig' => '',
 'TNC' => '',
 'User' => '',
 'Util' => '',
 'VivaNetCustomerConfiguration' => '',
 'Win32Service' => '',

 );


$Radius::Documentation::license = << 'EOF';
Radiator Standard End User License Agreement Version 7.5
Last Changed 2018-09-26

Radiator Standard End User License Agreement ("License Agreement")

1. Scope of the License Agreement; Definitions
This License Agreement applies to the use of the Licensor's Software (both as defined below in
this Section) by the firm, company, corporation or other entity who has acquired a valid license
to use the Software ("Licensee"). If you have not acquired a valid license to use the Software,
you are not entitled to download, install or use the Software.

The Licensee represents and warrants that each person who downloads, installs and/or
otherwise takes the Software (or any later update, upgrade, modification or other release of the
Software, with which a modified or a new version of the License Agreement is provided or
presented) into use or otherwise accepts the License Agreement or a modified or new version
thereof is authorized to conclude a binding agreement on behalf of the Licensee and that the
Licensee is bound by the License Agreement and the modified or new version thereof. Where
the Software is replaced with a later update, upgrade, modification or other release of the
Software, with which a modified or a new version of the License Agreement is provided or
presented, the use of the Software is thereafter governed by the modified or new version of the
License Agreement.

"Licensor" means Radiator Software. Radiator Software is the primary business name of
Radiator Software Ltd and a business name used by Open System Consultants Pty Ltd.
Radiator Software Ltd and Open System Consultants Pty Ltd are jointly deemed as the
Licensor, and they both under their respective rights grant the license to the Licensee in
accordance with the terms of this License Agreement. Radiator Software Ltd and Open System
Consultants Pty Ltd are each entitled to use any and all rights of the Licensor and to enforce
any and all terms of this License Agreement separately, without the requirement of the other to
join the claim or action, or they may decide to use the rights of the Licensor and to enforce
terms of this License Agreement also jointly.

"Software" means the software of the Licensor that is licensed to the Licensee based on this
License Agreement. The definition of the Software includes also the modifications, fixes,
updates, upgrades and derivative works of the Software (together referred to as "Updates") that
may be provided to the Licensee by the Licensor or its authorized reseller or distribution partner,
unless other license terms accompany and govern the Licensee's use of the Update. Based on
this License Agreement, the Licensor is not committed to release or provide any Updates.

"Documentation" means usage and installation manuals and other documentation related to
the Software in written or electronic form, that are supplied to the Licensee or included in the
Software media or that otherwise accompany the Software.

"Intellectual Property Rights" means patents, right to inventions, trademarks, domain names,
rights in know-how, trade secrets, copyrights, database rights, rights related to copyrights, and
all other rights or forms of protection having equivalent or similar effect as any of the foregoing
which may now or at any time hereafter exist anywhere in the world, whether registered or not,
and including but not limited to any applications for grant of any of the foregoing.

"Operating Partner" means a third party who runs and operates the Software on its equipment
only on behalf of the Licensee and for the benefit of the Licensee.

"Specific License Terms" or "SLT" means specific license terms which the Licensor issues for
the purpose of the Licensee and which deviate from the Section "License Grant" of this License
Agreement. The Specific License Terms issued for the purpose of the Licensee are
incorporated in this License Agreement by reference.

BY DOWNLOADING, INSTALLING OR USING THE SOFTWARE, THE LICENSEE IS
CONSENTING TO BE BOUND BY THIS LICENSE AGREEMENT. IF THE LICENSEE DOES
NOT CONSENT TO BE BOUND BY ALL OF THE TERMS OF THIS LICENSE AGREEMENT,
THE LICENSEE IS NOT ENTITLED TO DOWNLOAD, INSTALL OR USE THE SOFTWARE.

2. License Grant
Subject to the Licensee's payment of the license fee payable for the license to use the Software,
the Licensee is granted a non-exclusive and non-transferable right to use the Software in the
Licensee's own internal operations in the Software's intended use as specified in the
Documentation. The Software is provided to the Licensee only in electronic form for download.
Unless otherwise consented to by the Licensor, each Software version or Update (as the case
may be) licensed to the Licensee will be made available to the Licensee only once.

The Licensee may install and use the Software on one (1) computer, whether that computer is
physical or virtual.

Unless terminated in accordance with Section 8 of this License Agreement and if not otherwise
stated in the Specific License Terms, the license granted herein is perpetual.

The Licensee's right to use the Software can be limited also by the Licensor's pricing terms,
which can for example set certain limits to capacity, number of transactions, other means of use
or volumes.

The Licensee may make one (1) back-up copy of the Software solely for back-up purposes,
provided that the Licensee affixes to such copies all copyright and proprietary notices that
appear on the original copy.

The Software may only be installed and operated on a computer that is owned by or leased to
the Licensee or its Operating Partner. The Licensee shall ensure that the Operating Partner
runs and operates the Software only on behalf of the Licensee and only for the benefit of the
Licensee. The Licensee shall be liable for the actions of the Operating Partner.

The Licensee and the Licensee's Operating Partner may use the Documentation internally in
order to support the above-mentioned licensed use of the Software only on behalf of and for the
benefit of the Licensee.

The requirement to pay a license fee might not apply to an evaluation license of the Software
granted to the Licensee, if the Licensor or its authorized reseller or distribution partner consents
in writing that the evaluation license is free of charge. Unless otherwise agreed to in writing by
the Licensor, evaluation licenses expire after thirty (30) calendar days from the date the
Software was downloaded by the Licensee or provided to the Licensee, whichever of these is
the earliest. On the expiry of the evaluation license, the Licensee agrees to either purchase a
Software license at the Licensor's list price in force at that time or to destroy all copies of the
Software and Documentation in the Licensee's possession, including any copies on back-up
tapes or other media.

Specific License Terms issued by the Licensor for the purpose of the Licensee prevail over the
terms of this License Agreement.

3. Restrictions
The Software and the Documentation are licensed, not sold. The Licensor reserves all rights not
expressly granted in this License Agreement.

Except as otherwise expressly set forth herein, the Licensee may not:
a) rent, lease, license, loan, assign, resell or otherwise transfer the Software or the
   Documentation or any copy thereof or to permit the Software or the Documentation to be
   used, directly or indirectly, by any third party;
b) use the Software to offer service bureau, time-sharing or other services to third parties;
c) disassemble, decompile, translate, decrypt or reverse engineer the Software;
d) modify or create derivative works of the Software or the Documentation;
e) use, reproduce or copy the Software or the Documentation;
f) otherwise compromise the Licensor's or its licensors' rights in the Software or the
   Documentation; or
g) remove any proprietary notices or labels from the Software or the Documentation.

4. Title and Intellectual Property Rights
Title, ownership and any and all Intellectual Property Rights in and to the Software and the
Documentation shall remain solely with the Licensor and/or its licensors. Without limiting the
foregoing, the Software and the Documentation are protected by copyright laws of Finland,
Australia and/or other countries and international copyright treaties.

5. Disclaimer of Warranty; Limitation of Liability
THE SOFTWARE AND THE DOCUMENTATION ARE PROVIDED "AS IS", WITHOUT
WARRANTY OF ANY KIND. THE LICENSOR DOES NOT MAKE, AND HEREBY DISCLAIMS,
ANY AND ALL EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
NON-INFRINGEMENT AND ANY WARRANTIES ARISING FROM A COURSE OF DEALING,
USAGE, OR TRADE PRACTICE. THE ENTIRE RISK AS TO THE QUALITY AND
PERFORMANCE OF THE SOFTWARE AND THE DOCUMENTATION IS BORNE BY THE
LICENSEE. SHOULD THE SOFTWARE OR THE DOCUMENTATION PROVE TO BE
DEFECTIVE, THE LICENSEE (AND NOT THE LICENSOR) ASSUMES THE ENTIRE COST
OF ANY SERVICE AND REPAIR. THIS DISCLAIMER OF WARRANTY CONSTITUTES AN
ESSENTIAL PART OF THE LICENSE AGREEMENT. THIS DISCLAIMER OF WARRANTY
SUPERSEDES ALL STATEMENTS IN MARKETING MATERIALS OR BROCHURES
RELATING THE SOFTWARE OR THE DOCUMENTATION AND NO STATEMENT IN
MARKETING MATERIALS OR BROCHURES BINDS THE LICENSOR.

THE WARRANTIES ARE PROVIDED IN ADDITION TO THE CONSUMER GUARANTEES
AND DO NOT OVERRIDE OR LIMIT CONSUMERS' RIGHTS UNDER THE AUSTRALIAN
CONSUMER LAW. UNDER THE AUSTRALIAN CONSUMER LAW, IF THERE IS A PROBLEM
WITH THE SOFTWARE THAT ENTITLES THE LICENSEE TO A REMEDY, THE LICENSOR
SHALL ONLY BE REQUIRED TO REPLACE OR REPAIR THE SOFTWARE SUPPLIED TO
THE LICENSEE.

UNDER NO CIRCUMSTANCES AND UNDER NO LEGAL THEORY (TORT, CONTRACT,
NEGLIGENCE OR OTHERWISE) SHALL THE LICENSOR BE LIABLE TO THE LICENSEE OR
ANY OTHER PERSON OR THIRD PARTY FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR
CONSEQUENTIAL OR PUNITIVE DAMAGES OF ANY CHARACTER INCLUDING, WITHOUT
LIMITATION, DAMAGES FOR LOSS OF GOODWILL, WORK STOPPAGE, COMPUTER
FAILURE OR MALFUNCTION, OR ANY COMMERCIAL DAMAGES OR LOSSES, EVEN IF
THE LICENSOR HAS BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGES OR
LOSSES. THE LICENSOR IS NOT LIABLE FOR CLAIMS MADE BY ANY THIRD PARTY OR
FOR LOSS OF DATA OR FOR COST OF COVER PURCHASE.

IN NO EVENT SHALL THE LICENSOR'S AGGREGATE COMBINED MAXIMUM LIABILITY
(INCLUDING BUT NOT LIMITED TO LIABILITY FOR DAMAGES AND POSSIBLE PRICE
RETURNS OR PRICE REDUCTIONS) ARISING OUT OF OR RELATED TO THE SOFTWARE,
THE DOCUMENTATION AND ANYTHING ELSE COVERED BY THIS LICENSE
AGREEMENT, FOR ANY AND ALL CAUSES OF ACTION OCCURRED DURING ANY
CALENDAR QUARTER, EXCEED THE AMOUNT OF THE FEES PAID TO THE LICENSOR
DURING THE SAID CALENDAR QUARTER FOR THE LICENSEE'S RIGHT TO USE THE
SOFTWARE GRANTED IN THIS LICENSE AGREEMENT. VALUE ADDED TAX OR OTHER
TAXES OR DUTIES ARE NOT TAKEN INTO ACCOUNT IN THE CALCULATION OF SUCH
FEES.

6. Assignment
The Licensor may assign the License Agreement to any third party at any time. The Licensee
shall not have the right to assign the License Agreement, or any of its duties, rights or
obligations based on the License Agreement, to any third party without the express written
consent of the Licensor.

7. Export
The Licensee shall follow all laws and regulations that apply to the export of the Software or the
Documentation. The Licensee agrees not to export or re-export the Software or the
Documentation in contradiction to any law or regulation.

8. Termination
The Licensor may terminate this License Agreement and consequently the Licensee's right to
use the Software and the Documentation in case the Licensee commits a breach of the License
Agreement.

On or expiry termination of the Licensee's right to use the Software, the Licensee shall destroy
all copies of the Software and Documentation in the Licensee's possession, including any
copies on back-up tapes or other media. Upon termination of the Licensee's right to use the
Software for any reason, the Licensee shall have no right to refund of the whole or part of any
license fee paid.

9. Miscellaneous
This License Agreement constitutes the complete agreement between the parties with respect
to the subject matter of the License Agreement and it supersedes all previous proposals and
marketing materials and other communications between the parties with respect to the subject
matter of the License Agreement. Except for the Specific License Terms possibly issued by the
Licensor for the purpose of the Licensee, modifications of this License Agreement are valid only
in signed written form. If any provision of this License Agreement is found to be contrary to law,
the other provisions of this License Agreement will remain in full force and effect and the
License Agreement shall be interpreted so as to best accomplish the objectives of the original
provision to the fullest extent allowed by law. Such invalid provision shall also be amended by
the parties so as to best accomplish the objectives of the original provision to the fullest extent
allowed by law. Upon any termination or expiry of this License Agreement, the Licensor's rights
based on this License Agreement shall survive. The same apply to such Licensee's obligations,
which by their nature contemplate effectiveness beyond the termination of the License
Agreement. Without limiting the foregoing, this Section "Miscellaneous" shall survive. This
License Agreement shall be governed by and construed under the laws of Finland, without
giving effect to the principles of conflicts of law. The application of the United Nations
Convention of Contracts for the International Sale of Goods is expressly excluded. Any dispute,
controversy or claim arising out of or relating to the License Agreement shall be finally settled by
arbitration in accordance with the Rules for Expedited Arbitration of the Finland Chamber of
Commerce. The arbitrator shall have at least a master's degree in law from a Finnish university
and the arbitrator shall be experienced in dispute resolution within ICT sector. The arbitration
shall take place in Helsinki, Finland, and shall be conducted in English. Notwithstanding the
above, the Licensor may seek equitable and/or injunctive relief to prevent or stop a violation of
the License Agreement, and the Licensor may select to bring an action based on the License
Agreement (such as based on breach or suspected breach of the License Agreement by the
Licensee) in any court having jurisdiction over the Licensee's domicile or any place where the
Licensee has assets.


EOF

1;
