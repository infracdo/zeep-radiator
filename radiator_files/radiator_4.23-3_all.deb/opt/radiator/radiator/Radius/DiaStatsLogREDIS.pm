# DiaStatsLogREDIS.pm
#
# Log DIAMETER statistics to Redis
#
# Author: Janne Redsven (janne@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::DiaStatsLogREDIS;
use strict;
use warnings;
our @ISA = qw(Radius::DiaStatsLogGeneric);
use Radius::DiaStatsLogGeneric;
use Radius::Gossip;
use Redis;

%Radius::DiaStatsLogREDIS::ConfigKeywords =
(
 'StatsKey' =>
 ['string', "Redis key to store statistics entries. Defaults to 'Radiator::DiaStatsLogREDIS'", 1],
);

$Radius::DiaStatsLogREDIS::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{StatsKey}	  = 'Radiator:DiaStatsLogREDIS';
    $self->{OutputFormat} = 'JSON';
    $self->{redis}	  = undef;

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    unless (defined $Radius::Gossip::handle &&
	    ref($Radius::Gossip::handle) eq 'Radius::GossipRedis')
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: GossipRedis is required, but no GossipRedis defined in '$main::config_file'");
    }
    else
    {
	$self->{redis} = \$Radius::Gossip::handle;
    }

    return;
}

sub logObject
{
    my ($self, $values) = @_;

    # Check that our Redis has been initialized.
    unless (defined $Radius::Gossip::handle &&
	    ref($Radius::Gossip::handle) eq 'Radius::GossipRedis')
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Cannot log statements. DiaStatsLog REDIS requires GossipRedis, but no GossipRedis defined in '$main::config_file'");
	return;
    }
    unless (defined $self->{redis} && defined ${$self->{redis}})
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Cannot log statements, ref. handle for REDIS is undefined");
	return;
    }

    my $key = Radius::Util::format_special($self->{StatsKey});
    my $time = time();
    my $object_id = $main::config->{Identifier};
    my $base_entry = $key;

    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}:: Logging DIAMETER statistic for '$object_id'");

    # If the output format is not text, encode our hash to configured format.
    if (lc($self->{OutputFormat}) ne 'text')
    {
	# Try to find name for application code.
	$values->{ApplicationID_text} = $Radius::DiaMsg::appcode_to_name{$values->{ApplicationID}}
	if $values->{stats_type} eq $Radius::DiaStatsLogGeneric::STATS_TYPE{peer} &&
	    exists $Radius::DiaMsg::appcode_to_name{$values->{ApplicationID}};

	# Cumulative counters. Adding counter entry to Redis.
	my $entry = {
	    log_type	       => "diameter",
	    timestamp	       => $time,
	    object_id	       => $object_id,
	    time_elapsed       => $self->{statistics}->{time_elapsed},
	    %{$values},
	};

	my $encoded = $self->format_output($entry);

	# Store values to Redis
	${$self->{redis}}->exec_call(
	    sub { $_[0]->{redis}->rpush($key, $encoded, $_[0]->get_redis_callback(sub {})); }
	    );

	return;
    }

    # If we reach this point, there has not been any log output.
    return;
}

1;
