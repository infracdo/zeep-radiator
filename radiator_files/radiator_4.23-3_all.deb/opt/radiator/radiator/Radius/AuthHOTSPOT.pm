# AuthHOTSPOT.pm
#
# Object for handling Hotspot subscriptions and authentications.
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::AuthHOTSPOT;
use strict;
use warnings;
our @ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use Radius::ServGeneric;
use Radius::SessGeneric;
use Radius::Util;

%Radius::AuthHOTSPOT::ConfigKeywords =
(
 'ServiceId' =>
 ['string', 'Specifies how to derive the Identifier of the Service to provision a subscription.', 0],

 'SubscriptionId' =>
 ['string', 'Specifies how to derive the Identifier of the Subscription to handle a request.', 0],

 'SessionId' =>
 ['string', 'Specifies how to derive the Identifier of the Session to handle a request.', 0],

 'ServiceAttribute' =>
 ['string', 'Specifies RADIUS attribute that is used to detect different services.', 0],

 'ServiceAttributePrefix' =>
 ['string', 'Specifies the prefix in ServiceAttribute. You need to specify this if there is possibility to have multiple RADIUS attributes that are defined to be ServiceAttribute', 0],

 'SubscriptionAttribute' =>
 ['string', 'Specifies RADIUS attribute that is used to detect different subscriptions.', 0],

 'SubscriptionAttributePrefix' =>
 ['string', 'Specifies the prefix in SubscriptionAttribute. You need to specify this if there is possibility to have multiple RADIUS attributes that are defined to be SubscriptionAttribute', 0],

 'SessionAttribute' =>
 ['string', 'Specifies RADIUS attribute that is used to detect different sessions.', 0],

 'SessionAttributePrefix' =>
 ['string', 'Specifies the prefix in SessionAttribute. You need to specify this if there is possibility to have multiple RADIUS attributes that are defined to be SessionAttribute', 0],

 'DefaultService' =>
 ['string', 'Specifies a name of default service when the request does not contain ServiceAttribute.', 0],

 'DefaultServiceDefinition' =>
 ['string', 'Defines the default service to use when no service definition was found.', 0],

 'ConfirmSubscription' =>
 ['flag', 'Use Access-Reject to ask for a confirmation of the upgrade or renewal charge. Disabled by default.', 1],

 'ConfirmationMessage' =>
 ['string', 'Specifies the message that will ask the guest to confirm the upgrade or renewal charge', 1],

 'PreProvisionSubscription' =>
 ['flag', 'Create a subscription externally before the authentication. Disabled by default.', 1],

 'PreProvisionSession' =>
 ['flag', 'Create a session when the authentication is accepted. Disabled by default.', 1],

 'AuthBy' =>
 ['formatobjectlist', 'Specifies which AuthBy will be used to authenticate users. Special formatting characters are permitted.', 0],

 'ServiceDatabase' =>
 ['string', 'Specifies which ServiceDatabase will be used to query service and subscription information. Special formatting characters are permitted.', 0],

 'SessionDatabase' =>
 ['string', 'Specifies which SessionDatabase will be used to query session information. Special formatting characters are permitted.', 0],

 'PoolIPv4Attribute' =>
 ['string', 'RADIUS attribute to return Service/Subscription IPv4 pool. Default value is \'PoolHint\'.', 1],

 'PoolIPv6Attribute' =>
 ['string', 'RADIUS attribute to return Service/Subscription IPv6 pool. Default value is \'PoolHint6\'.', 1],

 'UsageMonitoring' =>
 ['flag', 'Deplete Subscription quotas only based on RADIUS accounting.', 1],

 'ReplyWithBandwidthControl' =>
 ['flag', 'Add Service/Subscription bandwidth limit RADIUS attributes to the reply.', 1],

 'UploadRateAttribute' =>
 ['string', 'RADIUS attribute to return Service/Subscription Upload bandwidth limit. Default value is \'OSC-Upload-Rate\'.', 1],

 'DownloadRateAttribute' =>
 ['string', 'RADIUS attribute to return Service/Subscription Download bandwidth limit. Default value is \'OSC-Download-Rate\'.', 1],

 'ReplyWithDataQuota' =>
 ['flag', 'Add Service/Subscription data limit RADIUS attributes to the reply.', 1],

 'DataLimitAttribute' =>
 ['string', 'RADIUS attribute to return Service/Subscription data limit. Default value is \'OSC-Data-Limit\'.', 1],

 'DataLimitGigawordsAttribute' =>
 ['string', 'RADIUS attribute to return Service/Subscription data limit gigawords. Default value is \'OSC-Data-Limit-Gigawords\'.', 1],

 'ChargeHook' =>
 ['hook', 'A hook to modify a subscription charge.', 1],

 'ReplyAdjustHook' =>
 ['hook', 'A hook to adjust Access-Accept reply.', 1],

 'SessionQuotaSupplyFraction' =>
 ['integer', 'Percentage (1-100) of remaining Subscription quota to allocate for a session. Default value is 20.', 1],

 'SessionQuotaResupplyThreshold' =>
 ['integer', 'A percentage threshold (1-100) for session quota usage to resupply session quotas from a subscription. Default value is 80.', 1],

 'SessionQuotaResupplyTimeMin' =>
 ['string', 'Minimum amount of time quota to allocate from a subscription for a session. Default value is 10 minutes.', 1],

 'SessionQuotaResupplyDataMin' =>
 ['string', 'Minimum amount of data quota to allocate from a subscription for a session. Default value is 1 MB.', 1],
);

# RCS version number of this module
$Radius::AuthHOTSPOT::VERSION = '$Revision$';

#####################################################################
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    # Default service to use
    $self->{DefaultService} = 'default';
    $self->{DefaultServiceDefinition} = 'name:default price:0';

    # Templates to form different identifiers
    # Service
    $self->{ServiceId} = undef;
    $self->{ServiceAttribute} = undef;
    $self->{ServiceAttributePrefix} = undef;
    # Subscription
    $self->{SubscriptionId} = '%1';
    $self->{SubscriptionAttribute} = undef;
    $self->{SubscriptionAttributePrefix} = undef;
    # Session
    $self->{SessionId} = undef;
    $self->{SessionAttribute} = 'Acct-Session-Id';
    $self->{SessionAttributePrefix} = undef;

    # Confirm the subscription by authenticating again
    $self->{ConfirmSubscription} = 0;
    $self->{ConfirmationMessage} = "You are going to upgrade or renew your plan, please login again to confirm the charge.";

    # Create a subscription externally before the authentication
    $self->{PreProvisionSubscription} = 0;
    # Create a session after a successful authentication
    $self->{PreProvisionSession} = 0;

    # Deplete quotas based on the actual usage
    $self->{UsageMonitoring} = 0;
    $self->{UsageMonitoringWiMAX} = 0;

    $self->{PoolIPv4Attribute} = 'PoolHint';
    $self->{PoolIPv6Attribute} = 'PoolHint6';

    # Return bandwith policers within Access-Accept
    $self->{ReplyWithBandwidthControl} = 1;

    $self->{UploadRateAttribute} = 'OSC-Upload-Rate';
    $self->{DownloadRateAttribute} = 'OSC-Download-Rate';

    # Return remaining data quota within Access-Accept
    $self->{ReplyWithDataQuota} = 0;

    $self->{DataLimitAttribute} = 'OSC-Data-Limit';
    $self->{DataLimitGigawordsAttribute} = 'OSC-Data-Limit-Gigawords';

    $self->{SessionQuotaSupplyFraction} = 20;
    $self->{SessionQuotaResupplyThreshold} = 80;
    $self->{SessionQuotaResupplyTimeMin} = 10 * 60;
    $self->{SessionQuotaResupplyDataMin} = 1000 * 1000;

    return;
}

#####################################################################
sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    return;
}

#####################################################################
sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    $self->{_ServiceDatabase} = Radius::ServGeneric::find(Radius::Util::format_special($self->{ServiceDatabase}));
    $self->{_SessionDatabase} = Radius::SessGeneric::find(Radius::Util::format_special($self->{SessionDatabase}));
    if ($self->{_SessionDatabase})
    {
	my $quota_fraction = $self->{SessionQuotaSupplyFraction} / 100;
	$quota_fraction = 1 if $quota_fraction > 1;
	$quota_fraction = 0.01 if $quota_fraction <= 0;
	my $quota_threshold = $self->{SessionQuotaResupplyThreshold} / 100;
	$quota_threshold = 1 if $quota_threshold > 1;
	$quota_threshold = 0.01 if $quota_threshold <= 0;
	my $quota_time_left_threshold = Radius::Util::convert_from_time_suffix($self->{SessionQuotaResupplyTimeMin});
	my $quota_octets_left_threshold = Radius::Util::convert_from_metric_prefix($self->{SessionQuotaResupplyDataMin});
	$self->{_SessionDatabase}->set_quota_thresholds($quota_fraction, $quota_threshold, $quota_time_left_threshold, $quota_octets_left_threshold);
    }

    return;
}

#####################################################################
sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    # Authenticate the user and handle accounting
    my ($result, $reason) = $self->SUPER::handle_request($p, $dummy, $extra_checks);

    if ($p->code() eq 'Access-Request' && defined $result && $result == $main::ACCEPT)
    {
	# WiMAX based
	if ($self->{UsageMonitoringWiMAX})
	{
	    my $wimax_ppaq = $p->get_attr('WiMAX-PPAQ');
	    if ($wimax_ppaq)
	    {
		$reason = "WiMAX Prepaid Accounting Operation not currently supported";
		$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: $reason", $p);
		return ($result, $reason);
	    }
	}

	# If an existing subscription was found, don't try to use default service
	# when no other service is found.
	my $no_default_service = ($p->{internal_vars}->{hotspot_subscription}) ? 1 : 0;
	my $service = $self->get_service($p, $no_default_service);
	if (!$service && !$no_default_service)
	{
	    return ($main::REJECT, 'Service not found');
	}

	my $name = $p->{internal_vars}->{hotspot_username};
	my $id = $p->{internal_vars}->{hotspot_id};

	my $subscription = $self->get_subscription($p, $service, $name, $id);
	unless ($subscription)
	{
	    return ($main::REJECT, 'Acquiring Subscription failed');
	}

	my $resubscribe = 0;
	my $resubscribe_reason = '';

	unless ($subscription->is_new())
	{
	    unless ($subscription->is_valid())
	    {
		return ($main::REJECT, "Subscription '$subscription->{id}' expired") if $self->{PreProvisionSubscription};
		$resubscribe = 1;
		$resubscribe_reason = "Subscription '$subscription->{id}' expired";
	    }

	    if ($subscription->exceeded(!$self->{UsageMonitoring}))
	    {
		return ($main::REJECT, "Subscription '$subscription->{id}' quota exceeded") if $self->{PreProvisionSubscription};
		$resubscribe = 1;
		$resubscribe_reason = "Subscription '$subscription->{id}' quota exceeded";
	    }

	    if ($resubscribe)
	    {
		# Clear cached subscription
		delete $p->{internal_vars}->{hotspot_subscription};
		# Resubscribe
		unless ($service)
		{
		    $service = $self->get_service($p);
		    unless ($service)
		    {
			$service = $subscription->get_service();
		    }
		}
		if ($subscription->{parent_id} eq $service->{id})
		{
		    return ($main::REJECT, "$resubscribe_reason, resubscribing service '$service->{id}' disallowed by the subscription")
			if $subscription->disallow_resubscribe();
		    return ($main::REJECT, "$resubscribe_reason, resubscribing service '$service->{id}' disallowed")
			if $service->disallow_resubscribe();
		}
		$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: $resubscribe_reason, resubscribing", $p);
		$subscription = $self->get_subscription($p, $service, $name, $id, 0, 1);
		unless ($subscription)
		{
		    return ($main::REJECT, "$resubscribe_reason and resubscribing failed");
		}
	    }
	}

	# Get subscription's service if $service is undef
	unless ($service)
	{
	    $service = $subscription->get_service();
	}

	if ($self->{ConfirmSubscription} && !$subscription->is_free())
	{
	    # Confirm before charging?
	    if ($subscription->is_new() && !$subscription->is_confirmed())
	    {
		# Save Subscription
		my $rc = $subscription->save();
		if ($rc)
		{
		    # Return REJECT with ConfirmationMessage
		    my $confirmation_message = Radius::Util::format_special($self->{ConfirmationMessage}, $p, $self, $service->{id}, $service->{name});
		    return ($main::REJECT, $confirmation_message);
		}
		else
		{
		    $reason = "Saving Subscription '$subscription->{id}' failed";
		    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: $reason", $p) unless $rc;
		    return ($main::REJECT, $reason);
		}
	    }
	}

	unless ($subscription->is_charged())
	{
	    # charging also saves subscription
	    my $rc = $self->{_ServiceDatabase}->charge_subscription($name, $id, undef, $subscription, $self->can('charge_subscription'), $self, $p);
	    unless ($rc)
	    {
		return ($main::REJECT, "Charging Subscription '$subscription->{id}' failed");
	    }
	    my $subscription_info = '(';
	    $subscription_info .= "id:'$subscription->{id}' " if defined $subscription->{id};
	    $subscription_info .= "price:'$subscription->{charged_price}' " if defined $subscription->{charged_price};
	    $subscription_info .= "uref:'$subscription->{user_ref}' " if defined $subscription->{user_ref};
	    $subscription_info .= "cref:'$subscription->{charge_ref}' " if defined $subscription->{charge_ref};
	    $subscription_info .= ')';
	    $reason = "Subscribed to a service '$service->{name}' $subscription_info";
	}

	my $session;
	if ($self->{PreProvisionSession})
	{
	    $session = $self->get_session($p, $subscription, $name, $id);
	    unless ($session)
	    {
		return ($main::REJECT, 'Acquiring Session failed');
	    }
	    my $rc = $session->save();
	    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Saving a session failed: $session->{id}, $session->{name}", $p) unless $rc;
	    $rc = $subscription->save();
	    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Saving a subscription failed: $subscription->{id}, $subscription->{name}", $p) unless $rc;
	}

	# Get subscription's service if $service does not match the subscription
	if ($service && $subscription->{parent_id} ne $service->{id})
	{
	    $service = $subscription->get_service();
	}

	$self->adjustReply($p, $service, $subscription, $session);
    }

    return ($result, $reason);
}

#####################################################################
sub get_service
{
    my ($self, $p, $no_default) = @_;

    unless ($self->{_ServiceDatabase})
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: ServiceDatabase not configured", $p);
	return undef;
    }

    my ($service_id, $service);
    if ($p->{internal_vars}->{hotspot_service})
    {
	$service = $p->{internal_vars}->{hotspot_service};
	#$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: " . $service->str()) if $service;
	return $service;
    }

    if ($self->{ServiceAttribute})
    {
	if ($self->{ServiceAttributePrefix})
	{
	    my @service_attrs = $p->get_attr($self->{ServiceAttribute});
	    foreach my $service_attr (@service_attrs)
	    {
		next unless $service_attr =~ /^$self->{ServiceAttributePrefix}(.*)$/;
		$service_id = $1;
		last;
	    }
	}
	else
	{
	    $service_id = $p->get_attr($self->{ServiceAttribute});
	}
    }
    if (!$service_id && $self->{ServiceId})
    {
	$service_id = Radius::Util::format_special($self->{ServiceId}, $p, $self, $self->{Identifier});
    }
    if (!$service_id && !$no_default)
    {
	$service_id = $self->{DefaultService};
    }

    if ($service_id)
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Using service '$service_id'", $p);
	$service = $self->{_ServiceDatabase}->get_service($service_id, $service_id);
	unless ($service)
	{
	    $self->log($main::LOG_INFO, "$self->{log_class_identifier}: Service '$service_id' not found", $p);
	    if (($service_id ne $self->{DefaultService}) && !$no_default)
	    {
		$service = $self->{_ServiceDatabase}->get_service($self->{DefaultService}, $self->{DefaultService});
	    }
	    if (!$service && $self->{DefaultServiceDefinition} && !$no_default)
	    {
		$service_id = 'default';
		$service = $self->{_ServiceDatabase}->new_service_from_string($self->{DefaultServiceDefinition});
	    }
	}
	#$self->log($main::LOG_DEBUG, "AuthHOTSPOT: " . $service->str()) if $service;
    }

    return $service;
}

#####################################################################
sub get_subscription
{
    my ($self, $p, $service, $name, $id, $dont_create, $resubscribe) = @_;

    unless ($self->{_ServiceDatabase})
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: ServiceDatabase not configured", $p);
	return undef;
    }

    my ($subscription_id, $subscription);
    if ($p->{internal_vars}->{hotspot_subscription} && !$resubscribe)
    {
	$subscription = $p->{internal_vars}->{hotspot_subscription};
	#$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: " . $subscription->str()) if $subscription;
	return $subscription;
    }

    if ($self->{SubscriptionAttribute})
    {
	if ($self->{SubscriptionAttributePrefix})
	{
	    my @subscription_attrs = $p->get_attr($self->{SubscriptionAttribute});
	    foreach my $subscription_attr (@subscription_attrs)
	    {
		next unless $subscription_attr =~ /^$self->{SubscriptionAttributePrefix}(.*)$/;
		$subscription_id = $1;
		last;
	    }
	}
	else
	{
	    $subscription_id = $p->get_attr($self->{SubscriptionAttribute});
	}
    }
    if (!$subscription_id && $self->{SubscriptionId})
    {
	$subscription_id = Radius::Util::format_special($self->{SubscriptionId}, $p, $self, $self->{Identifier}, $name, $id);

	unless ($subscription_id)
	{
	    $subscription_id = 'Radiator';
	    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Subscription Id formed based on SubscriptionId was empty, using a fixed value '$subscription_id' as Subscription Id.", $p);
	}
    }

    unless ($resubscribe)
    {
	# See if there's an existing subscription
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Get a subscription '$subscription_id'", $p);
	$subscription = $self->{_ServiceDatabase}->get_or_create_subscription($subscription_id, $name, $service, 1);
    }

    if ($subscription)
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Using an existing subscription '$subscription_id' '$subscription->{parent_name}'", $p);
    }
    elsif (!$dont_create && !$self->{PreProvisionSubscription})
    {
	$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Create a subscription '$subscription_id'", $p);

	$subscription = $self->{_ServiceDatabase}->get_or_create_subscription($subscription_id, $subscription_id, $service, $dont_create, $resubscribe);

	unless ($subscription)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: Creating a subscription '$subscription_id' failed", $p);
	    return undef;
	}
    }
    #$self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: " . $subscription->str()) if $subscription;

    return $subscription;
}

#####################################################################
sub get_session
{
    my ($self, $p, $subscription, $name, $id, $dont_create) = @_;

    unless ($self->{_SessionDatabase})
    {
	$self->log($main::LOG_WARNING, "$self->{log_class_identifier}: SessionDatabase not configured", $p);
	return undef;
    }

    my $class;
    if ($p)
    {
	$class = $p->getAttrByNum($Radius::Radius::CLASS);
    }
    if (!$class && $p->{rp})
    {
	$class = $p->{rp}->getAttrByNum($Radius::Radius::CLASS);
    }
    if (!$class)
    {
	# Use AutoClass
	$class = $p->{rp}->{internal_vars}->{AutoClass};
    }

    my ($session_id, $session);
    if ($self->{SessionAttribute})
    {
	if ($self->{SessionAttributePrefix})
	{
	    my @session_attrs = $p->get_attr($self->{SessionAttribute});
	    foreach my $session_attr (@session_attrs)
	    {
		next unless $session_attr =~ /^$self->{SessionAttributePrefix}(.*)$/;
		$session_id = $1;
		last;
	    }
	}
	else
	{
	    $session_id = $p->get_attr($self->{SessionAttribute});
	}
    }
    if (!$session_id && $self->{SessionId})
    {
	$session_id = Radius::Util::format_special($self->{SessionId}, $p, $self, $self->{Identifier}, $name, $id, $class);
    }

    $session = $self->{_SessionDatabase}->get_or_create_session($session_id, $name, $subscription, $dont_create);
    unless ($session)
    {
	$self->log($main::LOG_ERR, "$self->{log_class_identifier}: Getting or creating a session '$session_id' failed", $p) unless $dont_create;
	return undef;
    }

    if (!$session->{class})
    {
	$session->{class} = $class;
    }
    #$self->log($main::LOG_DEBUG, "AuthHOTSPOT: " . $session->str()) if $session;

    return $session;
}

#####################################################################
sub handle_accounting
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    my ($result, $reason);
    if ($self->{_SessionDatabase})
    {
	my $name = $p->getUserName();
	my $session = $self->get_session($p, undef, $name, undef, 1);

	unless ($session)
	{
	    # No existing session found, create a new session
	    my $subscription = $self->get_subscription($p, undef, $name, undef, 1);
	    $session = $self->get_session($p, $subscription, $name);
	}

	if ($self->{_SessionDatabase}->handle_request($p, $session, $self->{_ServiceDatabase}))
	{
	    ($result, $reason) = ($main::ACCEPT, 'Updated Session with Accounting-Request');
	}
	else
	{
	    $self->log($main::LOG_WARNING, "$self->{log_class_identifier}: Updating Session with Accounting-Request failed");
	    ($result, $reason) = ($main::REJECT, 'Updating Session with Accounting-Request failed');
	}
    }
    else
    {
	($result, $reason) = $self->SUPER::handle_accounting($p, $dummy, $extra_checks);
    }

    return ($result, $reason);
}

#####################################################################
sub charge_subscription
{
    my ($name, $id, $price, $subscription, $self, $p) = @_;

    my ($user_ref, $charge_ref);
    if ($self->{ChargeHook})
    {
	($user_ref, $charge_ref, $price) = $self->runHook('ChargeHook', $p, $p, $name, $id, $price, $subscription);
    }
    else
    {
	$user_ref = $name;
    }

    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: Charging subscription price '$price' from user '$name'");

    return ($user_ref, $charge_ref, $price);
}

#####################################################################
sub adjustReply
{
    my ($self, $p, $service, $subscription, $session) = @_;

    unless ($service || $subscription)
    {
	$self->SUPER::adjustReply($p);
	return;
    }

    if ($session && $session->{class})
    {
	my $class = $p->{rp}->getAttrByNum($Radius::Radius::CLASS);
	$p->{rp}->add_attr('Class', $session->{class}) unless $class;
    }

    # Rates and policers
    my @rates = (undef, undef, undef, undef, undef, undef);
    # Reply attrs
    my $reply_attrs;

    if ($service)
    {
	@rates = $service->get_rates();
	if ($service->{pool_v4})
	{
	    # Service pool
	    $p->{rp}->add_attr($self->{PoolIPv4Attribute}, $service->{pool_v4});
	}
	if ($service->{pool_v6})
	{
	    # Service pool
	    $p->{rp}->add_attr($self->{PoolIPv6Attribute}, $service->{pool_v6});
	}
	if ($service->{reply_attrs})
	{
	    $reply_attrs = $service->{reply_attrs};
	}
    }

    if ($subscription->{reply_attrs})
    {
	$reply_attrs = $subscription->{reply_attrs};
    }
    if ($reply_attrs)
    {
	$p->{rp}->parse($reply_attrs);
    }

    my ($quota_exceeded, $prepaid, $postpaid) = (0, 0, 0);

    # Remaining time quota
    my @quotas_left = $subscription->get_quotas_left();
    my $time_left = undef;
    if (defined $quotas_left[0])
    {
	# Prepaid time quota
	$time_left = $quotas_left[0];
	$prepaid = 1;
    }
    if (!$time_left && defined $quotas_left[1])
    {
	# Postpaid time quota
	$time_left = $quotas_left[1];
	$postpaid = 1;
    }
    if (defined $time_left)
    {
	if ($time_left > 0)
	{
	    unless ($self->{UsageMonitoring})
	    {
		$time_left = $subscription->{created_at} + $time_left - time();
		# Close session immediately
		$time_left = 1 if $time_left <= 0;
	    }
	    $p->{rp}->add_attr('Session-Timeout', $time_left);
	    # Termination-Action = RADIUS-Request (1)
	    $p->{rp}->add_attr('Termination-Action', 1);
	}
	else
	{
	    $quota_exceeded = 1;
	}
    }

    # Remaining data quota
    my ($octets_left, $gigawords_left) = (undef, undef);
    if (defined $quotas_left[2])
    {
	# Prepaid octets quota
	$octets_left = $quotas_left[2];
	$prepaid = 1;
    }
    if (!$octets_left && defined $quotas_left[3])
    {
	# Postpaid octets quota
	$octets_left = $quotas_left[3];
	$postpaid = 1;
    }
    if (defined $octets_left)
    {
	if ($self->{ReplyWithDataQuota} && $octets_left > 0)
	{
	    ($octets_left, $gigawords_left) = Radius::Util::convert_to_gigawords($octets_left);
	    $p->{rp}->add_attr($self->{DataLimitAttribute}, $octets_left) if $octets_left;
	    $p->{rp}->add_attr($self->{DataLimitGigawordsAttribute}, $gigawords_left) if $gigawords_left;
	}
	else
	{
	    $quota_exceeded = 1;
	}
    }

    if ($self->{ReplyWithBandwidthControl})
    {
	if ($quota_exceeded)
	{
	    # Throttled rate (rate_ul_throt)
	    if ($rates[0])
	    {
		$p->{rp}->add_attr($self->{UploadRateAttribute}, $rates[0]);
	    }
	    # Throttled rate (rate_dl_throt)
	    if ($rates[3])
	    {
		$p->{rp}->add_attr($self->{DownloadRateAttribute}, $rates[3]);
	    }
	}
	elsif ($prepaid)
	{
	    # Prepaid rate (rate_ul_max)
	    if ($rates[2])
	    {
		$p->{rp}->add_attr($self->{UploadRateAttribute}, $rates[2]);
	    }
	    # Prepaid rate (rate_dl_max)
	    if ($rates[5])
	    {
		$p->{rp}->add_attr($self->{DownloadRateAttribute}, $rates[5]);
	    }
	}
	#elsif ($postpaid)
	else
	{
	    # Default/Postpaid rate (rate_ul)
	    if ($rates[1])
	    {
		$p->{rp}->add_attr($self->{UploadRateAttribute}, $rates[1]);
	    }
	    # Default/Postpaid rate (rate_dl)
	    if ($rates[4])
	    {
		$p->{rp}->add_attr($self->{DownloadRateAttribute}, $rates[4]);
	    }
	}
    }

    if ($self->{ReplyAdjustHook})
    {
	$self->runHook('ReplyAdjustHook', $p, $p, $p->{rp}, $time_left, $octets_left, $gigawords_left, $service, $subscription, $session, $self);
    }

    return;
}

#####################################################################
sub findUser
{
    my ($self, $look_for, $p, $rp, $orig_user_name, $defaultNumber, $user, $error) = @_;

    if (!$user && $error)
    {
	return ($user, $error);
    }
    elsif (!$user)
    {
	if ($self->{AuthBy})
	{
	    ($user, $error) = $self->{AuthBy}[0]->findUser($look_for, $p, $rp, $orig_user_name, $defaultNumber);
	}
	else
	{
	    $self->log($main::LOG_DEBUG, "$self->{log_class_identifier}: AuthBy not configured");
	    ($user, $error) = $self->SUPER::findUser($look_for, $p, $rp, $orig_user_name, $defaultNumber);
	}
    }

    my $id;
    if ($p)
    {
	$p->{internal_vars}->{hotspot_username} = $look_for;
	unless (defined $p->{internal_vars}->{hotspot_id})
	{
	    $p->{internal_vars}->{hotspot_id} = $p->decodedPassword();
	}
	$id = $p->{internal_vars}->{hotspot_id};
    }

    if ($user && !$error)
    {
	# Get service/subscription specific check and reply items
	my $check_attrs = '';
	my $service = $self->get_service($p, 1);
	if ($service)
	{
	    $p->{internal_vars}->{hotspot_service} = $service;
	    if ($service->{check_attrs})
	    {
		$check_attrs = $service->{check_attrs};
	    }
	}
	my $subscription = $self->get_subscription($p, $service, $look_for, $id, 1);
	if ($subscription)
	{
	    if (!$service || ($subscription->{parent_id} eq $service->{id}))
	    {
		$p->{internal_vars}->{hotspot_subscription} = $subscription;
		if ($subscription->{check_attrs})
		{
		    $check_attrs .= ",$subscription->{check_attrs}";
		}
	    }
	}

	$user->get_check->parse($check_attrs) if $check_attrs;
    }

    return ($user, $error);
}

#####################################################################
sub check_password
{
    my ($self, $p, $pw, $user, $encrypted) = @_;

    if ($self->{AuthBy})
    {
	return $self->{AuthBy}[0]->check_password($p, $pw, $user, $encrypted);
    }

    return $self->SUPER::check_password($p, $pw, $user, $encrypted);
}

#####################################################################
sub check_plain_password
{
    my ($self, $user, $submitted_pw, $pw, $p, $encrypted) = @_;

    if ($self->{AuthBy})
    {
	return $self->{AuthBy}[0]->check_plain_password($user, $submitted_pw, $pw, $p, $encrypted);
    }

    return $self->SUPER::check_plain_password($user, $submitted_pw, $pw, $p, $encrypted);
}

#####################################################################
sub check_chap
{
    my ($self, $p, $username, $pw, $chapid, $challenge, $response) = @_;

    if ($self->{AuthBy})
    {
	return $self->{AuthBy}[0]->check_chap($p, $username, $pw, $chapid, $challenge, $response);
    }

    return $self->SUPER::check_chap($p, $username, $pw, $chapid, $challenge, $response);
}

#####################################################################
sub check_mschap
{
    my ($self, $p, $username, $nthash, $challenge, $response,
	$usersessionkeydest, $lanmansessionkeydest, $context) = @_;

    if ($self->{AuthBy})
    {
	return $self->{AuthBy}[0]->check_mschap($p, $username, $nthash, $challenge, $response, $usersessionkeydest, $lanmansessionkeydest, $context);
    }

    return $self->SUPER::check_mschap($p, $username, $nthash, $challenge, $response, $usersessionkeydest, $lanmansessionkeydest, $context);
}

#####################################################################
sub check_mschapv2
{
    my ($self, $p, $username, $nthash, $challenge, $peerchallenge, $response,
	$mppekeys_dest, $authenticator_responsedest, $lanmansessionkeydest, $context) = @_;

    if ($self->{AuthBy})
    {
	return $self->{AuthBy}[0]->check_mschapv2($p, $username, $nthash, $challenge, $peerchallenge, $response, $mppekeys_dest, $authenticator_responsedest, $lanmansessionkeydest, $context);
    }

    return $self->SUPER::check_mschapv2($p, $username, $nthash, $challenge, $peerchallenge, $response, $mppekeys_dest, $authenticator_responsedest, $lanmansessionkeydest, $context);
}

1;
