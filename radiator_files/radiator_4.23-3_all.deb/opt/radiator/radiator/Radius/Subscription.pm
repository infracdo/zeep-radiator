# Subscription.pm
#
# Object for handling subscription details
#
# Author: Tuure Vartiainen (vartiait@radiatorsoftware.com)
# Copyright (C) 2018 Radiator Software Oy
# All Rights Reserved
# $Id$

package Radius::Subscription;
use strict;
use warnings;
our @ISA = qw(Radius::Service);
use Radius::Service;

# RCS version number of this module
$Radius::Subscription::VERSION = '$Revision$';

#####################################################################
sub new
{
    my ($class, $id, $name, $service_id, $service_name, $tenant_id) = @_;

    # Call Service class constructor
    my $self = $class->SUPER::new($service_id, $service_name, $tenant_id);

    # Copy Service class attributes into new attributes
    $self->{parent_id} = $self->{id};
    $self->{parent_name} = $self->{name};

    # Subscription id
    $self->{id} = $id;
    # Subscription name
    $self->{name} = $name;

    # Quotas
    $self->{quota_time_pre_left} = undef;
    $self->{quota_time_post_left} = undef;
    $self->{quota_octets_pre_left} = undef;
    $self->{quota_octets_post_left} = undef;

    # Incrementing counter for session refills
    $self->{refill_number} = undef;
    # Timestamp when session was last time topped up
    $self->{refilled_at} = undef;

    # User/Customer attributes
    $self->{user_name} = undef;
    $self->{user_ref} = undef;

    # Charging related attributes
    $self->{charged_at} = undef;
    $self->{charged_price} = undef;
    $self->{charge_ref} = undef;

    # Timestamp when session was last time updated
    $self->{updated_at} = undef;

    $self->{created_at} = time();

    return $self;
}

sub new_from_service
{
    my ($class, $id, $name, $service) = @_;

    return undef unless $service;

    my $self = $class->new($id, $name, $service->{id}, $service->{name}, $service->{tenant_id});
    $self->set_from_service($service);
    $self->{parent} = $service;
    $self->{new} = 1;
    $self->refill($self->{quota_time_pre}, $self->{quota_time_post}, $self->{quota_octets_pre}, $self->{quota_octets_post});
    $self->{charged_price} = $self->{price};
    $self->{dirty} = 1;

    return $self;
}

sub new_from_subscription
{
    my ($class, $id, $name, $subscription) = @_;

    return undef unless $subscription;

    my $self = $class->new($id, $name, $subscription->{tenant_id});
    $self->set_from_subscription($subscription);
    $self->{new} = 1;

    return $self;
}

sub get_service
{
    my ($self) = @_;

    $self->get_parent();

    return $self->{parent};
}

sub set_from_subscription
{
    my ($self, $subscription) = @_;

    # Copy params
    $self->set_params($subscription->get_params());
    # Copy user charge params
    $self->set_user_charge($subscription->get_user_charge());
    # Copy remaining quotas
    $self->set_quotas_left($subscription->get_quotas_left(1, undef, undef, 1));

    return;
}

sub set_user_charge
{
    my ($self, $user_name, $user_ref, $charged_at, $price, $charge_ref) = @_;

    $self->{user_name} = $user_name;
    $self->{user_ref} = $user_ref;
    $self->{confirmed_at} = (defined $charged_at) ? $charged_at : time();
    $self->{charged_at} = (defined $charged_at) ? $charged_at : time();
    $self->{created_at} = (defined $charged_at) ? $charged_at : time();
    $self->{charged_price} = (defined $price) ? $price : $self->{price};
    $self->{charge_ref} = $charge_ref;
    $self->{dirty} = 1;

    return;
}

sub get_user_charge
{
   my ($self) = @_;

   return ($self->{user_name}, $self->{user_ref}, $self->{charged_at}, $self->{charged_price}, $self->{charge_ref});
}

sub is_confirmed
{
    my ($self) = @_;

    return $self->{confirmed_at};
}

sub is_valid
{
    my ($self) = @_;

    return 1 unless $self->{expiry};
    return 1 unless $self->{created_at};

    return ($self->{created_at} > (time() - $self->{expiry}));
}

sub exceeded
{
    my ($self, $no_usage_monitoring) = @_;

    my $exceeded = 0;
    my @quota_usages = $self->get_quotas_left();

    # prepaid time
    if (defined $quota_usages[0] && $quota_usages[0] <= 0)
    {
	$exceeded = 1;
    }
    # postpaid time
    if ($exceeded && defined $quota_usages[1] && $quota_usages[1] > 0)
    {
	$exceeded = 0;
    }
    elsif (defined $quota_usages[1] && $quota_usages[1] <= 0)
    {
	$exceeded = 1;
    }

    # prepaid quota
    if (defined $quota_usages[2] && $quota_usages[2] <= 0)
    {
	$exceeded = 1;
    }
    # postpaid quota
    if ($exceeded && defined $quota_usages[3] && $quota_usages[3] > 0)
    {
	$exceeded = 0;
    }
    elsif (defined $quota_usages[3] && $quota_usages[3] <= 0)
    {
	$exceeded = 1;
    }

    if (!$exceeded && $no_usage_monitoring && $self->{created_at})
    {
	my $time_left = 0;
	$time_left += $quota_usages[0] if $quota_usages[0];
	$time_left += $quota_usages[1] if $quota_usages[1];

	# when not monitoring usage, see if the subscription is older than it's quota sum
	$exceeded = (time() >= ($self->{created_at} + $time_left));
    }

    return ($exceeded && !$self->{allow_to_exceed}) ? 1 : 0;
}

sub deplete
{
    my ($self, $quota_time_used, $quota_octets_used) = @_;

    my ($leaked_time, $leaked_octets) = (0, 0);

    my $type = ref($self);
    if (defined $quota_time_used)
    {
	if (defined $self->{quota_time_pre_left} && $quota_time_used)
	{
	    main::log($main::LOG_DEBUG, "$type: Depleting prepaid time quota $self->{quota_time_pre_left} - $quota_time_used");
	    $self->{quota_time_pre_left} -= $quota_time_used;
	    if ($self->{quota_time_pre_left} < 0)
	    {
		# quota_time_pre_left leaked
		$quota_time_used = -1 * $self->{quota_time_pre_left};
		$leaked_time = $quota_time_used;
		$self->{quota_time_pre_left} = 0;
	    }
	    else
	    {
		$quota_time_used = 0;
	    }
	    $self->{dirty} = 1;
	}

	if (defined $self->{quota_time_post_left} && $quota_time_used)
	{
	    main::log($main::LOG_DEBUG, "$type: Depleting postpaid time quota $self->{quota_time_post_left} - $quota_time_used");
	    $self->{quota_time_post_left} -= $quota_time_used;
	    $leaked_time = 0;
	    if ($self->{quota_time_post_left} < 0)
	    {
		$quota_time_used = -1 * $self->{quota_time_post_left};
		$leaked_time = $quota_time_used;
		$self->{quota_time_post_left} = 0;
	    }
	    else
	    {
		$quota_time_used = 0;
	    }
	    $self->{dirty} = 1;
	}

	if ($leaked_time)
	{
	    main::log($main::LOG_DEBUG, "$type: '$self->{id}' quota leaked $leaked_time seconds");
	}
    }

    if (defined $quota_octets_used)
    {
	if (defined $self->{quota_octets_pre_left} && $quota_octets_used)
	{
	    main::log($main::LOG_DEBUG, "$type: Depleting prepaid data quota $self->{quota_octets_pre_left} - $quota_octets_used");
	    $self->{quota_octets_pre_left} -= $quota_octets_used;
	    if ($self->{quota_octets_pre_left} < 0)
	    {
		$quota_octets_used = -1 * $self->{quota_octets_pre_left};
		$leaked_octets = $quota_octets_used;
		$self->{quota_octets_pre_left} = 0;
	    }
	    else
	    {
		$quota_octets_used = 0;
	    }
	    $self->{dirty} = 1;
	}

	if (defined $self->{quota_octets_post_left} && $quota_octets_used)
	{
	    main::log($main::LOG_DEBUG, "$type: Depleting postpaid data quota $self->{quota_octets_post_left} - $quota_octets_used");
	    $self->{quota_octets_post_left} -= $quota_octets_used;
	    $leaked_octets = 0;
	    if ($self->{quota_octets_post_left} < 0)
	    {
		$quota_octets_used = -1 * $self->{quota_octets_post_left};
		$leaked_octets = $quota_octets_used;
		$self->{quota_octets_post_left} = 0;
	    }
	    else
	    {
		$quota_octets_used = 0;
	    }
	    $self->{dirty} = 1;
	}

	if ($leaked_octets)
	{
	    main::log($main::LOG_DEBUG, "$type: '$self->{id}' quota leaked $leaked_octets bytes");
	}
    }

    return ($leaked_time, $leaked_octets);
}

sub supply_quotas
{
    my ($self, $quota_time_pre, $quota_time_post, $quota_octets_pre, $quota_octets_post) = @_;

    my $type = ref($self);
    if (defined $quota_time_pre)
    {
	$self->{quota_time_pre_left} += 0;
	main::log($main::LOG_DEBUG, "$type: Supplying prepaid time quota $self->{quota_time_pre_left} + $quota_time_pre");
	$self->{quota_time_pre_left} += $quota_time_pre;
    }
    if (defined $quota_time_post)
    {
	$self->{quota_time_post_left} += 0;
	main::log($main::LOG_DEBUG, "$type: Supplying postpaid time quota $self->{quota_time_post_left} + $quota_time_post");
	$self->{quota_time_post_left} += $quota_time_post;
    }
    if (defined $quota_octets_pre)
    {
	$self->{quota_octets_pre_left} += 0;
	main::log($main::LOG_DEBUG, "$type: Supplying prepaid data quota $self->{quota_octets_pre_left} + $quota_octets_pre");
	$self->{quota_octets_pre_left} += $quota_octets_pre;
    }
    if (defined $quota_octets_post)
    {
	$self->{quota_octets_post_left} += 0;
	main::log($main::LOG_DEBUG, "$type: Supplying postpaid data quota $self->{quota_octets_post_left} + $quota_octets_post");
	$self->{quota_octets_post_left} += $quota_octets_post;
    }

    $self->{dirty} = 1;

    return;
}

sub deplete_quotas
{
    my ($self, $quota_time_pre, $quota_time_post, $quota_octets_pre, $quota_octets_post) = @_;

    my $type = ref($self);
    if (defined $self->{quota_time_pre_left} && $quota_time_pre)
    {
	main::log($main::LOG_DEBUG, "$type: Depleting prepaid time quota $self->{quota_time_pre_left} - $quota_time_pre");
	$self->{quota_time_pre_left} -= $quota_time_pre;
    }
    if (defined $self->{quota_time_post_left} && $quota_time_post)
    {
	main::log($main::LOG_DEBUG, "$type: Depleting postpaid time quota $self->{quota_time_post_left} - $quota_time_post");
	$self->{quota_time_post_left} -= $quota_time_post;
    }
    if (defined $self->{quota_octets_pre_left} && $quota_octets_pre)
    {
	main::log($main::LOG_DEBUG, "$type: Depleting prepaid data quota $self->{quota_octets_pre_left} - $quota_octets_pre");
	$self->{quota_octets_pre_left} -= $quota_octets_pre;
    }
    if (defined $self->{quota_octets_post_left} && $quota_octets_post)
    {
	main::log($main::LOG_DEBUG, "$type: Depleting postpaid data quota $self->{quota_octets_post_left} - $quota_octets_post");
	$self->{quota_octets_post_left} -= $quota_octets_post;
    }

    $self->{dirty} = 1;

    return;
}

sub refill
{
    my ($self, $quota_time_pre, $quota_time_post, $quota_octets_pre, $quota_octets_post) = @_;

    $self->{refill_number} += 1;
    $self->{refilled_at} = time();
    $self->supply_quotas($quota_time_pre, $quota_time_post, $quota_octets_pre, $quota_octets_post);

    return;
}

sub set_quotas_left
{
    my ($self, $quota_time_pre_left, $quota_time_post_left, $quota_octets_pre_left, $quota_octets_post_left) = @_;

    $self->{quota_time_pre_left} = $quota_time_pre_left if defined $quota_time_pre_left;
    $self->{quota_time_post_left} = $quota_time_post_left if defined $quota_time_post_left;
    $self->{quota_octets_pre_left} = $quota_octets_pre_left if defined $quota_octets_pre_left;
    $self->{quota_octets_post_left} = $quota_octets_post_left if defined $quota_octets_post_left;
    $self->{dirty} = 1;

    return;
}

sub get_quotas_left
{
    my ($self, $fraction, $time_threshold, $octets_threshold, $copy) = @_;

    $fraction = 1 unless (defined $fraction && $fraction >= 0 && $fraction <= 1);
    my ($quota_time_pre, $quota_time_post, $quota_octets_pre, $quota_octets_post) = (undef, undef, undef, undef);

    my $postpaid_time_needed = 0;
    # Consume prepaid time quota first
    if (defined $self->{quota_time_pre_left})
    {
	$quota_time_pre = int($fraction * $self->{quota_time_pre_left});
	if (defined $time_threshold && $quota_time_pre < $time_threshold)
	{
	    if ($self->{quota_time_pre_left} >= $time_threshold)
	    {
		my $time_left = int($fraction * ($self->{quota_time_pre_left} - $time_threshold));
		$quota_time_pre = $time_threshold + $time_left;
	    }
	    else
	    {
		$quota_time_pre = $self->{quota_time_pre_left};
		$postpaid_time_needed = $time_threshold - $quota_time_pre;
		$time_threshold = $postpaid_time_needed;
	    }
	}
    }

    # Consume postpaid time quota after (possible) prepaid quota
    if (($copy || !$quota_time_pre || $postpaid_time_needed) && defined $self->{quota_time_post_left})
    {
	$quota_time_post = int($fraction * $self->{quota_time_post_left});
	if (defined $time_threshold && $quota_time_post < $time_threshold)
	{
	    if ($self->{quota_time_post_left} >= $time_threshold)
	    {
		my $time_left = int($fraction * ($self->{quota_time_post_left} - $time_threshold));
		$quota_time_post = $time_threshold + $time_left;
	    }
	    else
	    {
		$quota_time_post = $self->{quota_time_post_left};
	    }
	}
    }

    my $postpaid_octets_needed = 0;
    # Consume prepaid octets quota first
    if (defined $self->{quota_octets_pre_left})
    {
	$quota_octets_pre = int($fraction * $self->{quota_octets_pre_left});
	if (defined $octets_threshold && $quota_octets_pre < $octets_threshold)
	{
	    if ($self->{quota_octets_pre_left} >= $octets_threshold)
	    {
		my $octets_left = int($fraction * ($self->{quota_octets_pre_left} - $octets_threshold));
		$quota_octets_pre = $octets_threshold + $octets_left;
	    }
	    else
	    {
		$quota_octets_pre = $self->{quota_octets_pre_left};
		$postpaid_octets_needed = $octets_threshold - $quota_octets_pre;
		$octets_threshold = $postpaid_octets_needed;
	    }
	}
    }

    # Consume postpaid octets quota after (possible) prepaid quota
    if (($copy || !$quota_octets_pre || $postpaid_octets_needed) && defined $self->{quota_octets_post_left})
    {
	$quota_octets_post = int($fraction * $self->{quota_octets_post_left});
	if (defined $octets_threshold && $quota_octets_post < $octets_threshold)
	{
	    if ($self->{quota_octets_post_left} >= $octets_threshold)
	    {
		my $octets_left = int($fraction * ($self->{quota_octets_post_left} - $octets_threshold));
		$quota_octets_post = $octets_threshold + $octets_left;
	    }
	    else
	    {
		$quota_octets_post = $self->{quota_octets_post_left};
	    }
	}
    }

    return ($quota_time_pre, $quota_time_post, $quota_octets_pre, $quota_octets_post);
}

sub get_usage
{
    my ($self) = @_;

    return (0, 0);
}

sub update_from_session
{
    my ($self, $session) = @_;

    # Return remaining quotas from Session back to Subscription
    my @quotas_left = $session->get_quotas_left(1, undef, undef, 1);

    # Redact used time from subscription quota
    # Don't update octet quotas
    $self->set_quotas_left($quotas_left[0], $quotas_left[1], undef, undef);

    if ($session->is_ended())
    {
	# Supply remaining octet quotas
	# Don't supply time quotas
	my @reset_quotas = map { (defined $_) ? 0 : undef } @quotas_left;
	$session->set_quotas_left(@reset_quotas);
	$self->supply_quotas(undef, undef, $quotas_left[2], $quotas_left[3]);
	$session->reset_session();
	$session->expunge();
    }

    return;
}

sub is_charged
{
    my ($self) = @_;

    return $self->{charged_at};
}

sub is_depleted
{
    my ($self) = @_;

    my $time_left;
    if (defined $self->{quota_time_pre_left})
    {
	$time_left += $self->{quota_time_pre_left};
    }
    if ($self->{quota_time_post_left})
    {
	$time_left += $self->{quota_time_post_left};
    }
    if (defined $time_left && $time_left < 1)
    {
	return 1;
    }

    my $octets_left;
    if (defined $self->{quota_octets_pre_left})
    {
	$octets_left += $self->{quota_octets_pre_left};
    }
    if (defined $self->{quota_octets_post_left})
    {
	$octets_left += $self->{quota_octets_post_left};
    }
    if (defined $octets_left && $octets_left < 1)
    {
	return 1;
    }

    return 0;
}

sub attr_keys
{
    my ($self) = @_;

    # 27 keys
    my @subscription_attr_keys = qw/tenant_id id name parent_id parent_name
	check_attrs pool_v4 pool_v6 reply_attrs expiry allow_to_exceed
	quota_time_pre_left quota_time_post_left quota_octets_pre_left
	quota_octets_post_left refill_number refilled_at
	user_name user_ref charged_price charge_ref charged_at
	created_at confirmed_at deleted_at updated_at saved_at/;

    return @subscription_attr_keys;
}

sub attr_values
{
    my ($self, $null) = @_;
    my @array = ();

    my @subscription_attr_keys = $self->attr_keys();

    foreach my $subscription_attr_key (@subscription_attr_keys)
    {
	if ($null && !defined $self->{$subscription_attr_key})
	{
	    push(@array, 'NULL');
	}
	else
	{
	    push(@array, $self->{$subscription_attr_key});
	}
    }

    return @array;
}

1;
