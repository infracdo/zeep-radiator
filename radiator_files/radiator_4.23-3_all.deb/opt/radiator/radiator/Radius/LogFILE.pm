# LogFILE.pm
#
# Log to a file
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::LogFILE;
use Radius::LogGeneric;
@ISA = qw(Radius::LogGeneric);
use File::Path;
use File::Basename;
use strict;

%Radius::LogFILE::ConfigKeywords = 
('Filename'  => 
 ['string', 'The name of the file that will be logged to. The file name can include special path name characters as defined in "Special characters in file names and other parameters" in the Radiator Reference manual. The default is %L/logfile, i.e. a file named logfile in LogDir.', 0],

 'LogFormat' => 
 ['string', 'This optional parameter permits you to customize the log string. Any special formatting character is permitted. %0 is replaced with the message severity as an integer, %1 with the severity as a string, %2 with the log message, and %3 with the tracing identifier.', 1],

 );

# RCS version number of this module
$Radius::LogFILE::VERSION = '$Revision$';

# Catch recursion in calls to log. LogFILE needs its own private
# recursion protection, because runHook does $self->log()
my $in_log = 0;

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initialize instance 
# variables
# that might get overridden when the config file is parsed.
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{Filename} = '%L/logfile';
}

#####################################################################
# Log a message 
# $priority is the message priority, $s is the message
# $r is the current request packet, if any
sub log
{
    my ($self, $priority, $s, $p, $trace_id) = @_;

    # Catch recursion
    return if $in_log++;

#    print "Logger $self->{Identifier}, $priority, $s, $p\n";
    if ($self->{Filename} ne '' && $self->willLog($priority, $p))
    {
	#print "logging to $self->{Filename}\n";
	my $message;
	if (defined $self->{LogFormatHook})
	{
	    ($message) = $self->runHook('LogFormatHook', $p, $priority, $s, $p, $trace_id);
	}
	elsif (defined $self->{LogFormat})
	{
	    $message = &Radius::Util::format_special
		($self->{LogFormat},
		 $p, undef, 
		 $priority,
		 $Radius::Log::priorityToString[$priority],
		 $s,
		 $trace_id);
	}
	else
	{
	    $message = $self->format_ctime() . ': ' . $Radius::Log::priorityToString[$priority] . ': ' . $s;
	    $message =~ s/^/$trace_id /mg if $self->{LogTraceId}; # m for multiline message
	}

	my $filename = &Radius::Util::format_special($self->{Filename}, $p, undef, $priority, $s);
	&Radius::Util::append($filename, $message . "\n")
	    || warn "Log could not append '$message' to log file '$filename': $!";
    }
    $in_log = 0;
}

1;
