# AuthRADIATORLB.pm
#
# Obsolete, use AuthRADIATORPROXY.pm instead.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AuthRADIATORLB;
@ISA = qw(Radius::AuthRADIUSBYATTR);
use Radius::AuthRADIUSBYATTR;
use strict;
use warnings;

%Radius::AuthRADIATORLB::ConfigKeywords =
(
 'DynAuthPort' =>
 ['string',
  'Defines the default destination port to which send RADIUS requests of dynamic authorization. Defaults to 3799',
  2],

 'ProxyRequest' =>
 ['flag',
  'Use OSC Proxy instead of generating DYNAUTH request.',
  1],
);

# RCS version number of this module
$Radius::AuthRADIATORLB::VERSION = '$Revision$';

sub initialize {
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->log($main::LOG_WARNING, "AuthRADIATORLB is obsolete, use AuthRADIATORPROXY instead at '$main::config_file' line $.");

    main::addChildInitFn(\&childInit, $self);
}

sub check_config
{
    my ($self) = @_;

    $self->log($main::LOG_WARNING, "AuthRADIATORLB is obsolete, use AuthRADIATORPROXY instead at '$main::config_file' line $.");
}

sub childInit
{
    my ($self) = @_;

    $self->log($main::LOG_WARNING, "AuthRADIATORLB is obsolete, use AuthRADIATORPROXY instead at '$main::config_file' line $.");
}

sub chooseHost
{
    my ($self, $fp, $p) = @_;

    $self->log($main::LOG_WARNING, "AuthRADIATORLB is obsolete, use AuthRADIATORPROXY instead at '$main::config_file' line $.", $p);

    return undef;
}

1;
