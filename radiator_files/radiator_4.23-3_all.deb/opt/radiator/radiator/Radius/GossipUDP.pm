# GossipUDP.pm
#
# Gossip implementation using UDP.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2015 Open System Consultants
# $Id$

package Radius::GossipUDP;
@ISA = qw(Radius::Gossip);
use Radius::Gossip;
use Radius::Util;
use Radius::Select;
use Socket;
use Fcntl;
use Scalar::Util qw(refaddr);
use strict;
use warnings;

@Radius::GossipUDP::hostkeywords =
(
 'Port' =>
 ['string', 'Specifies the default UDP port on the destination Peer to which Radiator will send Gossip messages. The argument may be either a numeric port number or an alphanumeric service name as specified in /etc/services (or its moral equivalent on your system). The default port is 16450. Can be overridden for an individual peer inside its GossipUDPPeer clause.', 0],

 'Retries' =>
 ['integer', 'If Radiator does not get a reply from the peer within RetryTimeout seconds, it will by default retransmit the request up to this number of retries.', 1],

 'RetryTimeout' =>
 ['integer', 'Specifies the default number of seconds to wait for a reply before retransmitting if no reply is received from a peer. ', 1],

 'UseKeepaliveForFailureDetect' =>
 ['flag', 'If this flag is enabled, use keepalive request to determine that a target peer is failed when there is no reply. If not enabled use no reply to any type of request.', 1],

 'KeepaliveTimeout' =>
 ['integer', 'This optional integer specifies the maximum time in seconds that a peer can be idle before a keepalive request is sent. Defaults to 0 seconds. If set to 0, keepalives are not used.', 1],

 'NoKeepaliveTimeoutForChildInstances' =>
 ['flag', 'If this optional flag is enabled, only the first instance of a server farm will send a keepalive requests. Recommended when Gossip is used to relay reachability information. Not set by default.', 1],

 'MaxFailedRequests' =>
 ['integer', 'This optional parameter specifies how many requests must fail to receive a reply before the peer is marked as failed, and the FailureBackoffTime will be applied. The default is 1, which means that one ignored request will cause the peer to be marked as failed for FailureBackoffTime seconds.', 1],

 'MaxFailedGraceTime' =>
 ['integer', 'This optional parameter specifes the time period (in seconds) over which MaxFailedRequests failures will cause the target peer to be be assumed to be failed. Defaults to 0. After a peer is declared to be failed, no request will be forwarded to it until FailureBackoffTime seconds have elapsed.', 1],

 'FailureBackoffTime' =>
 ['integer', 'This optional parameter specifies how long a failed peer will be removed from the forwarding list. If no reply is received from a peer (after all the Retries have expired) for MaxFailedRequests consecutive times, it will be marked as failed for FailureBackoffTime seconds. After that time has expired, it will again be eligible for forwarding. The default is 0, which means that the host is always regarded as working', 1],

 'LocalAddress' =>
 ['string', 'This optional parameter specifies the local address(es) to bind the UDP socket. This in turn specifies what the IP source address will be in Gossip messages. Defaults to BindAddress (which defaults to 0.0.0.0, i.e. the default source address).', 1],

 'OutPort' =>
 ['string', 'If this optional parameter is set, it forces a particular source port number to be used for Gossip UDP.', 1],
 );

%Radius::GossipUDP::ConfigKeywords =
(
 'Hosts' =>
 ['objectlist', 'List of hardwired peers in order of transmission attempts.', 0],

 'DisableMTUDiscovery' =>
 ['flag',
  'Disables MTU discovery on platforms that support that behaviour (currently Linux only). This can be used to prevent discarding of certain large UDP packet fragments on supporting operating systems.',
  2],

 'MaxTargetHosts' =>
 ['integer',
  'Limits the number of different peers a message will be sent to in the case of no reply. Defaults to 0 which mean no limit: if the sending algorithm does not receive a reply from a peer, it will keep trying until all peers are exhausted.',
  2],

 'Gossip' =>
 ['flag',
  'Enables GossipUDP to send and listen for other Gossip notifications (e.g. GossipRedis) to/from other Radiator servers when any remote GossipUDP peer fails to reply. Defaults to disabled.',
  2],

 'GossipNoReply' =>
 ['flag',
  'If GossipNoReply is set, then a notification will be send when a remote peer fails to reply. Radiator server also increases a counter for failed requests when a notification is received. Defaults to enabled.',
  2],

 'GossipHostDown' =>
 ['flag',
  'If GossipHostDown is set, then a notification will be send when a remote peer is marked down. Radiator server also marks the remote peer down when a notification is received. Defaults to enabled.',
  2],

 'GossipHostUp' =>
 ['flag',
  'If GossipHostUp is set, then a notification will be send when a remote peer is marked up and alive again. Radiator server also marks the remote peer healthy when a notification is received. Defaults to enabled.',
  2],

  @Radius::GossipUDP::hostkeywords,
);

# RCS version number of this module
$Radius::GossipUDP::VERSION = '$Revision$';

my %sockets = ();
my %pending_requests = ();
my %pending_replies = ();

# Make sure we get reinitialized on sighup
push(@main::reinitFns, \&reinitialize);

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{Port} = 16450;
    $self->{OutPort} = 0;
    $self->{Retries} = 2;
    $self->{RetryTimeout} = 1;
    $self->{KeepaliveTimeout} = 3;
    $self->{LocalAddress} = $main::config->{BindAddress} || '0.0.0.0';
    $self->{MaxFailedRequests} = 2;
    $self->{MaxFailedGraceTime} = 0;

    # Register callbacks for this events
    $self->{GossipNoReply} = 1;
    $self->{GossipPeerDown} = 1;
    $self->{GossipPeerUp} = 1;

    $self->{ObjType} = 'Gossip'; # Auto register with Configurable

    # Include a message header in Gossip messages
    $self->{use_message_header} = 1;

    # Register callback that is called if FarmSize is configured
    main::addChildInitFn(\&childInit, $self);
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    $self->log($main::LOG_WARNING, "GossipUDP: No peers, Gossip not enabled and no GossipUDPPeer defined for GossipUDP in '$main::config_file'")
	unless $self->{Hosts} || $self->{Gossip};

    map { $self->log($main::LOG_WARNING, "UseKeepaliveForFailureDetect enabled with KeepaliveTimeout set to 0 for GossipUDPPeer $_->{Name}.") }
        grep { ($_->{UseKeepaliveForFailureDetect} && ! $_->{KeepaliveTimeout}) } @{$self->{Hosts}};

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    $Radius::Gossip::handle = $self unless defined $Radius::Gossip::handle;

    map { $_->set_keepalive_timeout() } @{$self->{Hosts}};

    $self->activate_gossip() if $self->{Gossip};

    # Perform GossipUDP peer discovery if Gossip is enabled and this is the only instance
    $self->discover() if $self->{Gossip} && ! $main::config->{FarmSize};

}

sub object
{
    my ($self, $file, $keyword, $name, @args) = @_;

    if ($keyword eq 'GossipUDPPeer')
    {
	$self->add_host($name, $file, @args);
	return 1;
    }

    return $self->SUPER::object($file, $keyword, $name, @args);
}

# Farm supervisor process call this after forking a new worker
sub childInit
{
    my ($self) = @_;

    map {
	$self->log($main::LOG_INFO, "GossipUDP: Disabling KeepaliveTimeout for farm child instance $main::farmInstance");
	$_->clear_keepalive_timeout();
	$_->{KeepaliveTimeout} = 0;
    } grep { $_->{NoKeepaliveTimeoutForChildInstances} && $main::farmInstance > 1 } @{$self->{Hosts}};

    # Send discover request from the last farm instance
    $self->discover() if $main::farmInstance == $main::config->{FarmSize};
    return;
}

# Register handlers for the Gossip message types we are interested in
sub activate_gossip
{
    my ($self) = @_;

    if ($self->{Gossip} && ! $Radius::Gossip::handle)
    {
        $self->log($main::LOG_WARNING, "No Gossip co-method defined for GossipUDP at '$main::config_file' line $.");
        return;
    }
    elsif ($self->{Gossip} && ref($Radius::Gossip::handle) ne 'Radius::GossipRedis')
    {
        $self->{Gossip} = 0;
        $self->log($main::LOG_WARNING, "Gossip co-method defined for GossipUDP at '$main::config_file' line $. is not GossipRedis");
        return;
    }

    $Radius::Gossip::handle->register_message_handle("GossipUDP-Peer-Request-Failed", sub {
        my ($message) = @_;

        my $my_id = "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self);
        return if ($message->{from_id} eq $my_id);

        foreach my $host (@{$self->{Hosts}})
        {
            if ($host->{Port} == $message->{port})
            {
                foreach my $address (@{$host->{Address}})
                {
                    my $host_address = unpack("H*", $address);
                    if ($host_address eq $message->{address_hex})
                    {
                        $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Gossip tells that peer $message->{address}:$message->{port} did not reply to '$message->{from}'");

                        if ($host->{UseKeepaliveForFailureDetect})
                        {
                            if ($message->{keepaliva_failed} && ! $host->{is_failed}
                            && ++$host->{failedRequests} >= $host->{MaxFailedRequests}
                            && $host->{start_failure_grace_time} <= time - $host->{MaxFailedGraceTime})
                            {
                            $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Peer $message->{address}:$message->{port} now has $host->{failedRequests} consecutive failures over $host->{MaxFailedGraceTime} seconds. Backing off until keepalive response");
                            $host->{is_failed} = 1;
                            }
                        }
                        elsif ($host->{FailureBackoffTime}
                        && ++$host->{failedRequests} >= $host->{MaxFailedRequests}
                        && $host->{start_failure_grace_time} <= time - $host->{MaxFailedGraceTime})
                        {
                            $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Peer $message->{address} now has $host->{failedRequests} consecutive failures over $host->{MaxFailedGraceTime} seconds. Backing off for $host->{FailureBackoffTime} seconds");
                            $host->{failedRequests} = 0;
                            $host->{backoff_until} = $host->{start_failure_grace_time} = time + $host->{FailureBackoffTime};
                            $host->{is_failed} = 1;
                        }
                    }
                }
            }
        }
        return;
    }) if $self->{GossipNoReply};

    $Radius::Gossip::handle->register_message_handle("GossipUDP-Peer-DOWN", sub {
        my ($message) = @_;

        my $my_id = "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self);
        return if ($message->{from_id} eq $my_id);

        foreach my $host (@{$self->{Hosts}})
        {
            if ($host->{Port} == $message->{port})
            {
                foreach my $address (@{$host->{Address}})
                {
                    my $host_address = unpack("H*", $address);
                    if ($host_address eq $message->{address_hex} && ! $host->{is_failed})
                    {
                        my $msg = "GossipUDP $self->{Identifier}: Gossip tells that peer $message->{address}:$message->{port} was declared failed by '$message->{from}'";

                        if ($host->{UseKeepaliveForFailureDetect})
                        {
                            $host->{is_failed} = 1;
                            $msg .= ". Backing off until Status-Server gets response";
                        }
                        else
                        {
                            # mark host dead for backoff time
                            $host->{failedRequests} = 0;
                            $host->{backoff_until} = $host->{start_failure_grace_time} = time + $host->{FailureBackoffTime};
                            $host->{is_failed} = 1;
                            $msg .= ". Backing off for $host->{FailureBackoffTime} seconds";
                        }
                        $self->log($main::LOG_INFO, $msg);
                    }
                }
            }
        }
        return;
    }) if $self->{GossipHostDown};

    $Radius::Gossip::handle->register_message_handle("GossipUDP-Peer-UP", sub {
        my ($message) = @_;

        my $my_id = "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self);
        return if ($message->{from_id} eq $my_id);

        foreach my $host (@{$self->{Hosts}})
        {
            if ($host->{Port} == $message->{port})
            {
                foreach my $address (@{$host->{Address}})
                {
                    my $host_address = unpack("H*", $address);
                    if ($host_address eq $message->{address_hex} && $host->{is_failed})
                    {
                        $host->set_keepalive_timeout();
                        $host->{failedRequests} = 0;
                        $host->{start_failure_grace_time} = $host->{backoff_until} = time;
                        if ($host->{is_failed})
                        {
                            $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Gossip tells that Peer $message->{address}:$message->{port} is responding again to '$message->{from}'");
                            $host->{is_failed} = 0;
                        }
                    }
                }
            }
        }
        return;
    }) if $self->{GossipHostUp};

    $Radius::Gossip::handle->register_message_handle("GossipUDP-Peer-JOIN", sub {
	my ($message) = @_;
	my $my_id = "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self);
	return if ($message->{from_id} eq $my_id);

	my $address = $message->{address};
	my $port = $message->{port};
	my %args;
	$args{Port} = $port if $port;
	if ($address)
	{
	    $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Gossip tells that Peer $message->{address}:$message->{port} joins in");
	    $self->add_host($address, undef, %args);
	}
	return;
    });

    $Radius::Gossip::handle->register_message_handle("GossipUDP-Peer-UNJOIN", sub {
	my ($message) = @_;
	my $my_id = "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self);
	return if ($message->{from_id} eq $my_id);

	my $address = $message->{address};
	my $port = $message->{port};
	return unless $address;
	my $i = 0;
	foreach my $host (@{$self->{Hosts}})
	{
	    if ($host->{Port} == $message->{port})
	    {
		foreach my $address (@{$host->{Address}})
		{
		    my $host_address = Radius::Util::inet_ntop($address);
		    if ($host_address eq $message->{address})
		    {
			$self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Gossip tells that Peer $message->{address}:$message->{port} unjoins");
			my $host = @{$self->{Hosts}}[$i];
			# take host off
			$host->{is_failed} = 1;
			$host->clear_keepalive_timeout() if $host->{keepaliveTimeoutHandle};
			if ($host->{keepalive_msg_id})
			{
			    my $ref = delete $pending_requests{$host->{keepalive_msg_id}};
			    if ($ref)
			    {
				my ($request) = @{$ref};
				if ($request)
				{
				    Radius::Select::remove_timeout($request->{TimeoutHandle})
					|| $self->log($main::LOG_ERR, "GossipUDP $self->{Identifier}: Timeout $request->{TimeoutHandle} was not in the timeout list");
				}
			    }
			    $host->{keepalive_msg_id} = undef;
			}
			Radius::Select::add_timeout(time + $self->{KeepaliveTimeout},
						    sub {
							my ($handle, $self, $refaddr) = @_;
							my @host_indexes = ();
							for (my $j = 0; $j < @{$self->{Hosts}}; $j++)
							{
							    if (refaddr(@{$self->{Hosts}}[$j]) eq $refaddr)
							    {
								# Check that host is still failed
								my $host = @{$self->{Hosts}}[$j];
								push(@host_indexes, $j) if $host->{is_failed};
							    }
							}
							if (@host_indexes)
							{
							    foreach my $j (@host_indexes)
							    {
								my $host = splice(@{$self->{Hosts}}, $j, 1);
								$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Removing GossipUDPPeer '$host->{Name}:$host->{Port}'");
								undef $host;
							    }
							}
						    },
						    $self, refaddr($host));
			$host->{KeepaliveTimeout} = 0;
			last;
		    }
		}
	    }
	    $i++;
	}
	return;
    });

    return;
}

sub discover {
    my ($self) = @_;
    # Send NFV-BEDBINT-Report gossip message
    my $gossip_message = {
	version => 1,
	type => "NFV-BEDBINT-Report",
	from	=> $main::hostname . "." . $main::farmInstance,
	from_id => "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self),
	timestamp => time(),
    };

    $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Discovering GossipUDPPeers through Gossip");
    $Radius::Gossip::handle->tell_others($gossip_message);

    return;
}

sub reinitialize
{
    %sockets = ();
    %pending_requests = ();
    %pending_replies = ();

    return;
}

sub handle_socket_read
{
    my ($fileno, $socket, $self) = @_;

    my ($received_data, $whence);
    if ($whence = recv($socket, $received_data, 65535, 0))
    {
	my ($s, $us) = Radius::Util::getTimeHires;
	my ($port, $addr) = Radius::Util::unpack_sockaddr_in($whence);
	my $ip = Radius::Util::inet_ntop($addr);

	if (length($received_data) > 12)
	{
	    #print unpack('H*', $received_data) . " from $ip:$port\n";
	    my ($msg_type, $msg_ttl, $keyid, $msg_counter, $time) = unpack('C C n N N', $received_data);
	    my $is_request = $msg_type & $Radius::Gossip::Message::REQUEST;
	    my $is_reply = !$is_request;
	    my $is_notification = $msg_type & $Radius::Gossip::Message::NOTIFICATION;
	    my $is_keepalive = $msg_type & $Radius::Gossip::Message::KEEPALIVE;

	    unless ($msg_ttl)
	    {
		$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Received a reply with a zero TTL from '$ip:$port'") if $self->{Debug};
		# drop the message?
		return;
	    }
	    else
	    {
		if ($self->{Debug} && ! $is_keepalive)
		{
		    my $msg_type = $is_request ? 'request' : 'reply';
		    $msg_type = $is_notification ? 'notification' : 'reply';
		    $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Received a $msg_type (" . $msg_counter.$time . ") from '$ip:$port'");
		}
	    }

	    if ($is_reply && ! $is_notification)
	    {
		my $is_loose_reply = $msg_type & $Radius::Gossip::Message::WAITING_SINGLE_REPLY;

		my $key = $msg_counter.$time;
		my $ref = delete $pending_requests{$key};
		unless($ref)
		{
		    $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Received unexpected reply from '$ip:$port'")
			if $self->{Debug} && ! $is_loose_reply;
		    return;
		}

		my ($request) = @{$ref};
		my $host = $request->{ThisHost};
		unless ($host)
		{
		    $self->log($main::LOG_WARNING, "GossipUDP $self->{Identifier}: Received a reply from an old host which has been removed");
		    return;
		}

		Radius::Select::remove_timeout($request->{TimeoutHandle})
		    || $self->log($main::LOG_ERR, "GossipUDP $self->{Identifier}: Timeout $request->{TimeoutHandle} was not in the timeout list");

		$host->{failedRequests} = 0;
		$host->{start_failure_grace_time} = $host->{backoff_until} = time;

		if ($host->{is_failed})
		{
		    $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Peer $ip:$port is responding again");
		    $host->{is_failed} = 0;

		    if ($self->{Gossip} && $self->{GossipHostUp} && $Radius::Gossip::handle)
		    {
			my $gossip_message = {
			    version => 1,
			    type    => "GossipUDP-Peer-UP",
			    from    => $main::hostname . "." . $main::farmInstance,
			    from_id => "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self),
			    host    => $host->{Name},
			    address => $ip,
			    address_hex => unpack("H*", $addr),
			    port => $host->{Port},
			    timestamp => time(),
			    backoff_time => $host->{FailureBackoffTime},
			    uses_keepalive => $host->{UseKeepaliveForFailureDetect},
			    failed_requests => $host->{failedRequests},
			};

			$self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Gossipping that peer $ip:$host->{Port} is responding again");
			$Radius::Gossip::handle->tell_others($gossip_message);
		    }
		}

		if ($is_keepalive)
		{
		    $host->{keepalive_msg_id} = undef;
		    return;
		}
	    }
	    else
	    {
		# incoming message is either request or notification
		if ($is_request)
		{
		    # Keepalive
		    if ($is_keepalive)
		    {
			$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: received keepalive request from $ip:$port, replying") if $self->{Debug};
			$msg_type &= 0xfe;
			substr($received_data, 0, 2) = pack('C C', $msg_type, $msg_ttl);
			if (! send($socket, $received_data, 0, $whence))
			{
			    $self->log($main::LOG_ERR, "GossipUDP $self->{Identifier}: sending keepalive reply to $ip:$port failed: $!");
			}

			return;
		    }
		    else
		    {
			# store ref for responding
			#$pending_replies{$msg_counter.$time} = [$socket, $whence];
		    }
		}
	    }

	    $self->handle_message_received($received_data);
	}
	else
	{
	    $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Received too short message from '$ip:$port'")
		if $self->{Debug};
	}
    }
}

sub handle_message_send
{
    my ($self, $destination, $message, $time_to_live, $callback) = @_;

    my $request = {
	Message => $message,
	Destination => $destination,
	msg_ttl => $time_to_live || 0x01,
	FirstTime => time,
    };

    if ($destination eq $Radius::Gossip::Destination::ALL)
    {
	foreach my $host (@{$self->{Hosts}})
	{
	    $self->send_host($host, $request) if (!$self->{MaxTargetHosts} || $request->{numTargetHosts}++ < $self->{MaxTargetHosts});
	}
    }
    else
    {
	$request->{numTargetHosts}++;
	my $host = $self->choose_host($request, $destination);
	$self->send_host($host, $request) if $host;
    }

    return;
}

sub handle_message_fetch
{
    my ($self, $destination, $callback) = @_;

    $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Fetching message from a destination '$destination' is not implemented")
	if $self->{Debug};

    my $message;

    return $message;
}

sub handle_message_publish
{
    my ($self, $message, $destination) = @_;

    if (defined $destination)
    {
	$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Sending a message to a group '$destination'")
	    if $self->{Debug};

	$self->handle_message_send($destination, $message);
    }
    else
    {
	$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Publishing a message to all peers")
	    if $self->{Debug};

	$self->handle_message_send($Radius::Gossip::Destination::ALL, $message);
    }

    return;
}

sub choose_host
{
    my ($self, $request, $destination) = @_;

    return unless defined $self->{Hosts};

    if (! defined $request->{hostRetries} && $destination &&
	$destination eq $Radius::Gossip::Destination::ANY)
    {
	$request->{hostRetries} = int(rand(scalar @{$self->{Hosts}}));
    }

    while ($request->{hostTried}++ < @{$self->{Hosts}})
    {
	my $host = $self->{Hosts}[$request->{hostRetries}++];
	$request->{hostRetries} = 0 if $request->{hostRetries} >= @{$self->{Hosts}};
	next unless $host->is_working();
	return $host;
    }

    return;
}

sub send_host
{
    my ($self, $host, $request) = @_;

    if (! defined $host->{Address})
    {
	$self->log($main::LOG_WARNING, "GossipUDPPeer '$host->{Name}' has no IP address. Unable to forward");
	return;
    }

    my $addr = @{$host->{Address}}[$host->{roundRobinCounter}++ % @{$host->{Address}}];
    my $ip = Radius::Util::inet_ntop($addr);
    my $destport = Radius::Util::pack_sockaddr_in($host->{Port}, $addr);

    my $socket = $self->get_socket($addr, $host);
    if (defined $socket)
    {
	my ($msg_type, $msg_id, $msg_counter, $time, $packet);
	if (! $request->{Keepalive} && $self->{use_message_header})
	{
	    ($msg_type, $msg_counter, $time) = unpack('C x3 N N', $request->{Message});
            $msg_id = $msg_counter . $time;
	    $packet = $request->{Message};
	}
	else
	{
	    $self->{msg_counter} = 1 if ++$self->{msg_counter} > 4294967295;
	    my $now = time;
	    $msg_id = $self->{msg_counter} . $now;
	    $msg_type = $Radius::Gossip::Message::KEEPALIVE | $Radius::Gossip::Message::REQUEST;
	    my $header = pack('C C n N N', $msg_type, 1, 0, $self->{msg_counter}, $now);
	    $packet = $header . $request->{Message};
	}
	my $is_request = $msg_type & $Radius::Gossip::Message::REQUEST;

	$request->{msg_id} = $msg_id;
	$request->{ThisHost} = $host;
	$request->{Packet} = $packet;
	$request->{Retries} = 0;
	$request->{Socket} = $socket;
	$request->{SendTo} = $destport;

	if ($is_request)
	{
	    $pending_requests{$msg_id} = [$request];

	    if ($request->{Keepalive})
	    {
		$host->{keepalive_msg_id} = $msg_id;
	    }
	}

	# DEBUG
	#print unpack('H*', $packet) . " to $ip:$host->{Port}\n";

	if (! send($socket, $packet, 0, $destport))
	{
	    main::log($main::LOG_ERR, "GossipUDP $self->{Identifier}: send to $ip:$host->{Port} failed: $!");
	}

	$request->{TimeoutHandle} =
	    Radius::Select::add_timeout
	    (time + $host->{RetryTimeout},
	     \&Radius::GossipUDP::handle_timeout,
	     $self, $request) if $is_request;
    }
    else
    {
	$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Unable to create or get a socket to send a message to '$ip'")
	    if $self->{Debug};
    }
}

sub handle_timeout
{
    my ($handle, $self, $request) = @_;

    my $host = $request->{ThisHost};
    return unless $host;

    my ($port, $addr) = Radius::Util::unpack_sockaddr_in($request->{SendTo});
    my $ip = Radius::Util::inet_ntop($addr);

    if ($request->{Retries}++ < $host->{Retries})
    {
	$self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Request to $ip:$port timed out, retransmitting (" . $request->{msg_id} . ")");

	if (! send($request->{Socket}, $request->{Packet}, 0, $request->{SendTo}))
	{
	    main::log($main::LOG_ERR, "GossipUDP $self->{Identifier}: send to $ip:$port failed: $!");
	}

	$request->{TimeoutHandle} =
	    Radius::Select::add_timeout
	    (time + $host->{RetryTimeout},
	     \&Radius::GossipUDP::handle_timeout,
	     $self, $request);
    }
    else
    {
	delete $pending_requests{$request->{msg_id}};
	$self->failed($host, $request);
    }
}

sub failed
{
    my ($self, $host, $request) = @_;

    my ($port, $addr) = Radius::Util::unpack_sockaddr_in($request->{SendTo});
    my $ip = Radius::Util::inet_ntop($addr);
    my $delay = time - $request->{FirstTime};
    my $msg = "GossipUDP $self->{Identifier}: No reply after $delay second(s) and $host->{Retries} retransmissions to $ip:$port (" . $request->{msg_id} . ")";
    my $host_down = 0;

    # Mark this host down if too many failures over too long a period of time
    if ($host->{UseKeepaliveForFailureDetect})
    {
	if ($request->{Keepalive}
	    && ! $host->{is_failed}
	    && ++$host->{failedRequests} >= $host->{MaxFailedRequests}
	    && $host->{start_failure_grace_time} <= time - $host->{MaxFailedGraceTime})
	{
	    $msg .= ". Now have $host->{failedRequests} consecutive failures over $host->{MaxFailedGraceTime} seconds. Backing off until keepalive gets response";
	    $host->{is_failed} = 1;
	    $host_down = 1;
	}
    }
    elsif ($host->{FailureBackoffTime}
	   && ++$host->{failedRequests} >= $host->{MaxFailedRequests}
	   && $host->{start_failure_grace_time} <= time - $host->{MaxFailedGraceTime})
    {
	$msg .= ". Now have $host->{failedRequests} consecutive failures over $host->{MaxFailedGraceTime} seconds. Backing off for $host->{FailureBackoffTime} seconds";
	$host->{failedRequests} = 0; # For when we restart transmissions
	$host->{backoff_until} = $host->{start_failure_grace_time} = time + $host->{FailureBackoffTime};
	$host->{is_failed} = 1;
	$host_down = 1;
    }

    unless ($request->{Keepalive})
    {
	my $host = (!$self->{MaxTargetHosts} || $request->{numTargetHosts}++ < $self->{MaxTargetHosts}) ? $self->choose_host($request) : undef;
	if ($host)
	{
	    $self->send_host($host, $request);
	}
	else
	{
	    my $delay = time - $request->{FirstTime};
	    $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Could not find a working peer to send a request after $delay seconds. Ignoring");
	    $self->log($main::LOG_INFO, "GossipUDP: Request was sent to " . $self->{MaxTargetHosts} . " hosts. MaxTargetHosts reached.")
		if ($self->{MaxTargetHosts} && $request->{numTargetHosts} >= $self->{MaxTargetHosts});
	}
    }

    $self->log($main::LOG_INFO, $msg);

    if ($self->{Gossip} && $Radius::Gossip::handle)
    {
	my $gossip_message = {
	    version => 1,
	    from    => $main::hostname . "." . $main::farmInstance,
	    from_id => "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self),
	    host    => $host->{Name},
	    address => $ip,
	    address_hex => unpack("H*", $addr),
	    port => $host->{Port},
	    timestamp => time(),
	    backoff_time => $host->{FailureBackoffTime},
	    uses_keepalive => $host->{UseKeepaliveForFailureDetect},
	    failed_requests => $host->{failedRequests},
	    keepalive_failed => $request->{Keepalive},
	};

	if ($self->{GossipNoReply})
	{
	    $gossip_message->{type} = "GossipUDP-Peer-Request-Failed";
	    $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Gossipping that Host $ip:$host->{Port} failed to reply");
	    $Radius::Gossip::handle->tell_others($gossip_message);
	}
	if ($self->{GossipHostDown} && $host_down)
	{
	    $gossip_message->{type} = "GossipUDP-Peer-DOWN";
	    $self->log($main::LOG_INFO, "GossipUDP $self->{Identifier}: Gossipping that Host $ip:$host->{Port} was marked down");
	    $Radius::Gossip::handle->tell_others($gossip_message);
	}
    }
}

sub get_socket
{
    my ($self, $dest_addr, $host) = @_;

    # Note: only the first suitable LocalAddress is used if there are multiple comma-sep addresses
    my @bind_address = split(/\s*,\s*/, Radius::Util::format_special($host->{LocalAddress}));

    my ($localaddr, $bind_address, $thisaddr, $pfamily);
    my $localport = $host->{OutPort};
    my $key;
    if (length($dest_addr) == 16)
    {
	# Want an IPV6 address, find a suitable socket to send from
	foreach (@bind_address)
	{
	    $localaddr = $2, last if /(^ipv6:)?(.*:.*)/i;
	}
	$localaddr = '::' unless defined $localaddr; # Fallback to anyhost
	# $localaddr is the name of the local addres, see if it already exists?
	$key = "$localaddr:$localport";
	return $sockets{$key} if exists $sockets{$key};

	# No, must continue and make one
	($thisaddr, $pfamily) = Radius::Util::pack_sockaddr_pton(Radius::Util::get_port($localport),
								 $localaddr);
    }
    else
    {
	# Want an IPV4 address, find a suitable socket to send from
	foreach (@bind_address)
	{
	    $localaddr = $_, last unless /:/; # Covers also ipv6: prefix
	}
	$localaddr = '0.0.0.0' unless defined $localaddr; # Fallback to anyhost
	# $localaddr is the name of the local addres, see if it already exists?
	$key = "$localaddr:$localport";
	return $sockets{$key} if exists $sockets{$key};

	# No, must continue and make one
	$thisaddr = scalar &Socket::sockaddr_in(Radius::Util::get_port($localport), Socket::inet_aton($localaddr));
	$pfamily = Socket::PF_INET;
    }

    # Need to make a new one:
    # This could have been done with FileHandle, but this is much
    # more lightweight. It makes a reference to a TYPEGLOB
    # and Perl can use a typeglob ref as an IO handle
    $self->log($main::LOG_DEBUG, "GossipUDP creates new local socket '$localaddr:$localport' for sending requests")
	if $self->{Debug};
    my $s = $sockets{$key} = do { local *FH };
    if (!socket($s, $pfamily, Socket::SOCK_DGRAM, scalar getprotobyname('udp')))
    {
	$self->log($main::LOG_ERR, "Could not create a socket in GossipUDP: $!");
	return;
    }
    binmode($s); # Make safe in UTF environments
    if (!bind($s, $thisaddr))
    {
	$self->log($main::LOG_ERR, "Could not bind to LocalAddress $localaddr port $localport in GossipUDP: $!");
	delete $sockets{$key};
	return;
    }

    # On some hosts, select sometimes incorrectly says that there
    # is a reply waiting, even when there isnt.
    # Set the socket non-blocking to prevent waiting forever
    if ($^O ne 'MSWin32')
    {
	# Windows does not support fcntl or non-blocking sockets yet.
	fcntl($s, F_SETFL,
	      fcntl($s, F_GETFL, 0) | O_NONBLOCK)
	    || die "Could not fcntl a socket in GossipUDP: $!";

	if ($main::config->{SocketQueueLength})
	{
	    # Note: your OS may also need to be configured to allow
	    # you to choose long socket queue lengths.
	    setsockopt($s,
		       &Socket::SOL_SOCKET,
		       &Socket::SO_RCVBUF,
		       $main::config->{SocketQueueLength})
		|| $self->log($main::LOG_WARNING,
			      "Could not set GossipUDP forwarding socket queue length $main::config->{SocketQueueLength}: $!");
	}
	# Maybe disable MTU discovery and enable Dont Frag. Only available on Linux
	if ($^O eq 'linux' && $self->{DisableMTUDiscovery})
	{
	    # Constants from /usr/include/bits/in.h
	    setsockopt($s,
		       0, # IPPROTO_IP
		       10, # IP_MTU_DISCOVER
		       0 ) # IP_PMTUDISC_DONT
		|| $self->log($main::LOG_WARNING, "Could not disable MTU discovery for GossipUDP socket: $!");
	}
    }

    Radius::Select::add_file(fileno($s), 1, undef, undef,
			     \&Radius::GossipUDP::handle_socket_read, $s, $self);

    return $s;
}

sub add_host
{
    my ($self, $name, $file, @args) = @_;

    # Don't add a same host twice, compare Name or Address & Port
    my %args_t = @args;
    $args_t{Port} = $self->{Port} unless exists $args_t{Port};
    my $add_host = 1;
    foreach my $host (@{$self->{Hosts}})
    {
	# Compare Name, Port and Addresses
	if ($host->{Name} eq $name)
	{
	    if (defined $args_t{Port} && $args_t{Port} != $host->{Port})
	    {
		$add_host = 1;
	    }
	    else
	    {
		$add_host = 0;
	    }
	}
	# Compare Port and Addresses
	elsif (defined $args_t{Port} && $args_t{Port} == $host->{Port})
	{
	    $add_host = 0 if (grep {$name eq $_ || (defined $args_t{Address} && $args_t{Address} eq $_)} @{$host->{Address}});
	}

	unless ($add_host)
	{
	    $host->set_keepalive_timeout();
	    $host->{failedRequests} = 0;
	    $host->{start_failure_grace_time} = $host->{backoff_until} = time;

	    if ($host->{is_failed})
	    {
		# If Host was marked failed, mark it active again
		$host->{is_failed} = 0;
		$self->log($main::LOG_INFO, "Marking GossipUDPPeer '$name' as active again.");
	    }
	    last;
	}
    }
    unless ($add_host)
    {
	$self->log($main::LOG_INFO, "Not adding GossipUDPPeer '$name' as it was already marked as joined.");
	return;
    }

    my $object = Radius::GossipUDPPeer->new
	($file, $name,
	 'Identifier'		      => $name || "Unknown",
	 'Port'			      => $self->{Port},
	 'Retries'		      => $self->{Retries},
	 'RetryTimeout'		      => $self->{RetryTimeout},
	 'MaxFailedRequests'	      => $self->{MaxFailedRequests},
	 'MaxFailedGraceTime'	      => $self->{MaxFailedGraceTime},
	 'FailureBackoffTime'	      => $self->{FailureBackoffTime},
	 'LocalAddress'		      => $self->{LocalAddress},
	 'OutPort'		      => $self->{OutPort},
	 'KeepaliveTimeout'	      => $self->{KeepaliveTimeout},
	 'UseKeepaliveForFailureDetect' => $self->{UseKeepaliveForFailureDetect},
	 'NoKeepaliveTimeoutForChildInstances' => $self->{NoKeepaliveTimeoutForChildInstances},
	 'Debug'		      => $self->{Debug},
	 'Parent'		      => $self,
	 @args
	);
    return unless $object;

    $object->activate();
    push(@{$self->{Hosts}}, $object);

    return $object;
}

sub add_hosts
{
    my ($self, $name, $file, @args) = @_;

    map {$self->add_host($_, $file, @args)} (split(/\s*,\s*/, Radius::Util::format_special($name)));
}

package Radius::GossipUDPPeer;
@Radius::GossipUDPPeer::ISA = qw(Radius::Configurable);

%Radius::GossipUDPPeer::ConfigKeywords =
(
 @Radius::GossipUDP::hostkeywords,
);

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{Port} = 16450;
    $self->{Retries} = 2;
    $self->{RetryTimeout} = 1;
    $self->{KeepaliveTimeout} = 3;
    $self->{MaxFailedRequests} = 2;
    $self->{MaxFailedGraceTime} = 0;
    $self->{OutPort} = 0;

    $self->{backoff_until} = 0;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Permit formatting chars in the host name
    my $name = Radius::Util::format_special($self->{Name});

    # If there are multiple addresses, remember them for round-robin
    my ($cname, $aliases, $addrtype, $length, @addrs) = Radius::Util::gethostbyname($name);

    if (!@addrs)
    {
	# Nothing in the DNS, try to convert from presentation to network
	$addrs[0] = Radius::Util::inet_pton($name);
	@addrs = () unless (defined $addrs[0] && $addrs[0] ne '');
    }

    if (!@addrs)
    {
	# still nothing!
	$self->log($main::LOG_WARNING, "GossipUDPPeer '$name' has no IP address at '$main::config_file' line $.");
	return;
    }

    @{$self->{Address}} = @addrs;
    $self->{Port} = Radius::Util::get_port($self->{Port});

    $self->{start_failure_grace_time} = time;

    $self->set_keepalive_timeout();
}

sub is_working
{
    my ($self) = @_;

    return ! $self->{is_failed} if $self->{UseKeepaliveForFailureDetect};

    return time() >= $self->{backoff_until};
}

sub send_keepalive
{
    my ($self) = @_;

    my $request = {
        Keepalive => 1,
        Message => "\x00",
        Destination => $self->{Name},
        msg_ttl => 1,
        FirstTime => time,
    };

    $self->{Parent}->send_host($self, $request);

    $self->set_keepalive_timeout();
}

sub handle_keepalive_timeout
{
    my ($handle, $self) = @_;

    $self->{keepaliveTimeoutHandle} = undef;

    $self->log($main::LOG_DEBUG, "GossipUDP $self->{Identifier}: Send keepalive to $self->{Name}:$self->{Port}") if $self->{Debug};

    $self->send_keepalive();
}

sub clear_keepalive_timeout
{
    my ($self) = @_;

    Radius::Select::remove_timeout($self->{keepaliveTimeoutHandle});
    $self->{keepaliveTimeoutHandle} = undef;
}

sub set_keepalive_timeout
{
    my ($self) = @_;

    return unless $self->{KeepaliveTimeout};

    # Reset our keepalive timeout
    $self->clear_keepalive_timeout() if $self->{keepaliveTimeoutHandle};

    # See if we need to perform keepalive on only one instance
    return if ($self->{NoKeepaliveTimeoutForChildInstances} && $main::farmInstance > 1);

    my $timeout = time + $self->{KeepaliveTimeout};
    if ($self->{is_failed} && $self->{FailureBackoffTime})
    {
	$timeout += $self->{FailureBackoffTime};
    }

    $self->{keepaliveTimeoutHandle} =
	Radius::Select::add_timeout
	($timeout,
	 \&handle_keepalive_timeout,
	 $self);
}

1;
