# AttrVal.pm
#
# This is a class for holding attribute value pairs. Handles multiple
# instances of the same attribute.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::AttrVal;
use strict;
use warnings;
use Radius::Log;

# RCS version number of this module
$Radius::AttrVal::VERSION = '$Revision$';

#####################################################################
sub new
{
    my ($class, $s) = @_;

    my $self = {};
    bless $self, $class;

    @{$self->{Attributes}} = (); # Define an empty array
    $self->parse($s) if defined $s;

    return $self;
}

#####################################################################
# Appends attribute ($name, $value) to this AttrVal. Returns the
# number of all attributes following the append.
sub add_attr
{
    my ($self, $name, $value) = @_;

    return push(@{$self->{Attributes}}, [ $name, $value ]);
}

#####################################################################
# If it was already there, return 1 else add it and return 0
sub add_if_not_exist_attr
{
    my ($self, $name, $value) = @_;

    # Bail if its already there
    map {return 1 if ($_->[0] eq $name)} @{$self->{Attributes}};

    # Not there, so add it
    push(@{$self->{Attributes}}, [ $name, $value ]);
    return 0;
}

#####################################################################
# Change the value of an attribute.
# If it was already there, change it return 1 else add it and return 0
sub change_attr
{
    my ($self, $name, $value) = @_;

    foreach (@{$self->{Attributes}})
    {
	if ($_->[0] eq $name)
	{
	    $_->[1] = $value;
	    return 1;
	}
    }

    # Not there, so add it
    push(@{$self->{Attributes}}, [ $name, $value ]);
    return 0;
}

#####################################################################
# Remove all instances of the attribute with the given name
# from the list
sub delete_attr
{
    my ($self, $name) = @_;

    for (my $i = 0; $i < @{$self->{Attributes}}; $i++)
    {
	splice(@{$self->{Attributes}}, $i--, 1)
	    if ($self->{Attributes}->[$i]->[0] eq $name);
    }
    return;
}

#####################################################################
# Remove attributes that cause fn to return true
# fn is called like fn($name, $value, @args)
sub delete_attr_fn
{
    my ($self, $fn, @args) = @_;

    for (my $i = 0; $i < @{$self->{Attributes}}; $i++)
    {
	splice(@{$self->{Attributes}}, $i--, 1)
	    if (&$fn($self->{Attributes}->[$i]->[0],
		     $self->{Attributes}->[$i]->[1],
		     @args));
    }
    return;
}

#####################################################################
# Appends all the items in the AttrVal pointed to by $list
# to this AttrVal. Returns the number of values following the append.
sub add_attr_list
{
    my ($self, $list) = @_;

    return push(@{$self->{Attributes}}, @{$list->{Attributes}});
}

#####################################################################
# Gets the values of the named attribute.
# returns a list of all the values
# if called in scalar context, returns the value of the first one found
sub get_attr
{
    my ($self, $name) = @_;

    return unless $name;

    return map {$_->[0] eq $name ? $_->[1] : ()} @{$self->{Attributes}}
        if wantarray;

    map {return $_->[1] if ($_->[0] eq $name)} @{$self->{Attributes}};
    return; # not found
}

#####################################################################
sub get_attr_val_n
{
    my ($self, $n) = @_;

    return unless $self->{Attributes}[$n];
    return @{$self->{Attributes}[$n]};
}

#####################################################################
# required for DefaultReply (and someday, DefaultCheck)  ##ptf
# Returns attribute count for all attributes, or count for specific attribute
sub attr_count
{
    my ($self, $attr) = @_;
    return scalar @{$self->{Attributes}} unless defined $attr;

    # Calculate attribute count
    unless (exists $self->{attr_count})
    {
	$self->{attr_count}->{$_->[0]}++ foreach (@{$self->{Attributes}});
    }
    return $self->{attr_count}->{$attr} if exists $self->{attr_count}->{$attr};
    return 0;
}

# Return attributes in a human readable format in a hash
sub get_attrs
{
    my ($self) = @_;
    my $attributes = {};

    foreach my $attribute (@{$self->{Attributes}})
    {
	if ($self->attr_count($attribute->[0]) > 1)
	{
	    push @{$attributes->{$attribute->[0]}}, pclean($attribute->[1]);
	}
	else
	{
	    $attributes->{$attribute->[0]} = pclean($attribute->[1]);
	}
    }
    return $attributes;
}

#####################################################################
# Parse out a text string consisting of attr=val pairs
# separated by commas
# add each attribute to $self
# Returns the number of pairs found in the string
# The val can have surrounding double quotes, which will be removed
# Use quotes if the value contains embedded commas. Escape embedded
# quotes with \
sub parse
{
    my ($self, $s) = @_;

    return 0 unless defined $s;
    my $count = 0;

    $s =~ s/\s*\z//s; # Strip trailing white space
    while ($s ne '')
    {
	$s =~ s/^[\s,]*//s; # Strip leading white space & commas
	if ($s =~ m/^([^ =]+) *= *"((\\"|[^"])*)",*/sg)
	{
	    # Quoted value
	    my ($attr, $value) = ($1, $2);
	    $s = substr($s, pos $s);
	    $value =~ s/\\"/"/sg; # Unescape quotes
	    $value =~ s/\\(\d{3})/chr(oct($1))/sge; # Convert escaped octal
	    push(@{$self->{Attributes}}, [ $attr, $value ]);
	    $count++;
	}
	elsif ($s =~ m/^([^ =]+) *= *([^,]*),*/sg)
	{
	    # Unquoted value
	    push(@{$self->{Attributes}}, [ $1, $2 ]);
	    $s = substr($s, pos $s);
	    $count++;
	}
	else
	{
	    main::log($main::LOG_ERR, "Bad attribute=value pair: $s");
	    last;
	}
	$s =~ s/^\s*//s; # Strip leading white space
    }
    return $count;
}

#####################################################################
# idem parse() but add attribute only if it does not exist before
# Contributed by Vincent Gillet <vgi@oleane.net>
sub parse_ifnotexist
{
    my ($self, $s) = @_;

    return 0 unless defined $s;
    my $count = 0;

    $s =~ s/\s*\z//s; # Strip trailing white space
    ATTRIBUT:
    while ($s ne '')
    {
	$s =~ s/^[\s,]*//s; # Strip leading white space & commas
	if ($s =~ m/^([^ =]+) *= *"((\\"|[^"])*)",*/sg)
	{
	    # Quoted value
	    my ($attr, $value) = ($1, $2);
	    foreach my $attrib_ref (@{$self->{Attributes}}) {
		if ($attrib_ref->[0] eq $attr) {
	    		$s = substr($s, pos $s);
	    		next ATTRIBUT;
	    	}
	    }
	    $value =~ s/\\"/"/sg; # Unescape quotes
	    push(@{$self->{Attributes}}, [ $attr, $value ]);
	    $s = substr($s, pos $s);
	    $count++;
	}
	elsif ($s =~ m/^([^ =]+) *= *([^,]*),*/sg)
	{
	    # Unquoted value
	    my ($attr, $value) = ($1, $2);
	    foreach my $attrib_ref (@{$self->{Attributes}}) {
		if ($attrib_ref->[0] eq $attr) {
	    		$s = substr($s, pos $s);
	    		next ATTRIBUT;
	    	}
	    }
	    push(@{$self->{Attributes}}, [ $attr, $value ]);
	    $s = substr($s, pos $s);
	    $count++;
	}
	else
	{
	    main::log($main::LOG_ERR, "Bad attribute=value pair: $s");
	    last;
	}
    }
    return $count;
}

#####################################################################
# Format the list in a pretty way and return it
# Every value is quoted
sub format        ## no critic (Subroutines::ProhibitBuiltinHomonyms)
{
    my ($self) = @_;

    my $ret;
    map {$ret .= "\t$_->[0] = \"" . pclean($_->[1]) . "\"\n"} @{$self->{Attributes}};
    return $ret;
}

#####################################################################
# Utility functions for printing/debugging
sub pdef { defined $_[0] ? $_[0] : "UNDEF"; } ## no critic (Subroutines::RequireArgUnpacking, Subroutines::RequireFinalReturn)

sub pclean
{
    my ($str) = @_;

    $str =~ s/([\000-\037\177-\377])/<${\ord($1)}>/sg;
    return $str;
}

1;
