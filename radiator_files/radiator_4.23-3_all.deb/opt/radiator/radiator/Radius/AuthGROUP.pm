# AuthGROUP.pm
#
# Object for handling Authentication and accounting groups
# Most of this is pinched from Handler.pm, which will eventually inherit 
# this behaviour from this module.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 1997 Open System Consultants
# $Id$

package Radius::AuthGROUP;
@ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use strict;

%Radius::AuthGROUP::ConfigKeywords = 
(
 'AuthByPolicy'                   => 
 ['string', 
  'Specifies whether and how to continue authenticating after each AuthBy', 
  0],

 'RewriteUsername'                => 
 ['stringarray', 
  'Perl expressions to alter the user name in authentication and accounting requests when they are handled by this GROUP. Perl substitution and translation expressions are supported',
  1],

 'AuthBy'                         => 
 ['objectlist', 
  'List of AuthBy clauses to be used to authenticate requests processed by the GROUP. Requests are processed by each AuthBy in order until AuthByPolicy is satisifed. ', 
  0],

 'StripFromRequest'               => 
 ['string', 
  'Strips the named attributes from the request before passing it to any authentication modules. The value is a comma separated list of attribute names. StripFromRequest removes attributes from the request before AddToRequest adds any to the request. ', 
  1],

 'AddToRequest'                   => 
 ['string', 
  'Adds attributes to the request before passing it to any authentication modules. Value is a list of comma separated attribute value pairs', 
  1],

 'AddToRequestIfNotExist'         => 
 ['string', 
  'Adds attributes to the request before passing it to any authentication modules. Unlike AddToRequest, an attribute will only be added if it does not already exist in the request. Value is a list of comma separated attribute value pairs ', 
  1],
 );

# RCS version number of this module
$Radius::AuthGROUP::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
# This is called by Configurabel during Configurable::new before
# the config file is parsed. Its a good place initalze 
# instance variables
# that might get overridden when the config file is parsed.
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize;
    $self->{AuthByPolicy} = 'ContinueWhileIgnore';
}

#####################################################################
# Handle a request
# This function is called for each packet. $p points to a Radius::
# packet
# REVISIT:should we fork before handling. There might be long timeouts?
sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    my $type = ref($self);
    $self->log($main::LOG_DEBUG, "Handling with $type: $self->{Identifier}", $p);

    # Trivial handling follows
    if ($p->code eq 'Access-Request')
    {
	return ($main::IGNORE, "Ignored due to IgnoreAuthentication")
	    if $self->{IgnoreAuthentication} ;
    }
    elsif ($p->code eq 'Accounting-Request')
    {
	return ($main::IGNORE, "Ignored due to IgnoreAccounting")
	    if $self->{IgnoreAccounting};

	my $status_type = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE);
	# If we have a HandleAcctStatusTypes and this type is not mentioned
	# Acknowledge it, but dont do anything else with it
	return ($main::ACCEPT, 'Accepted due to HandleAcctStatusTypes')
	    if defined $self->{HandleAcctStatusTypes}
	       && !exists $self->{HandleAcctStatusTypes}{$status_type};

	# If AccountingStartsOnly is set, only process Starts
	# Acknowledge and drop anything else
	return ($main::ACCEPT, 'Accepted due to AccountingStartsOnly')
	    if $self->{AccountingStartsOnly}
	       && $status_type ne 'Start';
	
	# If AccountingStopsOnly is set, only process Stops
	# Acknowledge and drop anything else
	return ($main::ACCEPT, 'Accepted due to AccountingStopsOnly')
	    if $self->{AccountingStopsOnly}
	       && $status_type ne 'Stop';

	# If AccountingAlivesOnly is set, only process Alives
	# Acknowledge and drop anything else
	return ($main::ACCEPT, 'Accepted due to AccountingAlivesOnly')
	    if $self->{AccountingAlivesOnly}
	       && $status_type ne 'Alive';
    }

    # Now we might fork before processing the request
    # Should only do this for "slow" authentication methods
    return ($main::IGNORE, 'Forked')
	if $self->{Fork} && !$self->handlerFork();

    $p->rewriteUsername($self->{RewriteUsername})
	if (defined $self->{RewriteUsername});

    # Add and strip attributes before handling. 
    map {$p->delete_attr($_)} (split(/\s*,\s*/, $self->{StripFromRequest}))
	if defined $self->{StripFromRequest};

    $p->parse(&Radius::Util::format_special($self->{AddToRequest}, $p))
	if defined $self->{AddToRequest};

    $p->parse_ifnotexist(&Radius::Util::format_special
			 ($self->{AddToRequestIfNotExist}, $p))
	if defined $self->{AddToRequestIfNotExist};

    return $self->runGroupAuthBys($p, $extra_checks);
}

#####################################################################
sub runGroupAuthBys
{
    my ($self, $p, $extra_checks, $result, $reason) = @_;

    my $type = ref($self);
    # $result can be IGNORE, ACCEPT or REJECT
    # If there's no handler, accounting will be ignored and other requests rejected
    $result = ($p->code eq 'Accounting-Request') ? $main::IGNORE : $main::REJECT;
    $reason = 'No AuthBy found';

    # Try all the AuthBy handlers in sequence until the AuthByPolicy
    # is satisfied
    # CAUTION: The AuthBy handler might fork
    my $continue = 1;

    # See if we had an AuthBy that had returned $main::ASYNC
    my $called_with_result = 0;
    if (defined $p->{prev_authby_result} && defined $p->{AuthBys} && $p->{AuthBys}->[-1]->[0] == $self)
    {
	++$called_with_result;
	$result = $p->{prev_authby_result};
	$reason = $p->{prev_authby_reason};

	# Call the PostAuthHook, if there is one
	$p->{prev_authby}->runHook('PostAuthHook', $p, \$p, \$p->{rp}, \$result, \$reason) if ($p->{prev_authby} && $p->{prev_authby}->{PostAuthHook});

	# Save result and reason. This makes possible to
	# use status of earlier AuthBy in the following AuthBy
	$p->{prev_authby_result} = $result;
	$p->{prev_authby_reason} = $reason;

	$self->log($main::LOG_DEBUG, "$type:$self->{Identifier} $p->{AuthBy}->{Identifier} result: $Radius::AuthGeneric::reasons[$result], $reason", $p);

	# Evaluate the AuthByPolicy
	$continue = 0 unless $self->evaluatePolicy($self->{AuthByPolicy}, $result);
    }

    my $this_authby = undef;
    my $i = 0;
    # Does the request have an array?
    if (defined $p->{AuthBys})
    {
	# Does the request have an index to the current AuthBy?
	if (defined $p->{current_AuthBy})
	{
	    $this_authby = $p->{AuthBys}->[$p->{current_AuthBy}];

	    # If we are the last element, continue
	    if ($p->{current_AuthBy} == $#{$p->{AuthBys}} && $this_authby->[0] == $self)
	    {
		# Store last result
		$this_authby->[3] = $p->{prev_authby_result};
		$this_authby->[4] = $p->{prev_authby_reason};

		# And delete an index pointer
		delete $p->{current_AuthBy};
	    }
	}
	else
	{
	    # Append this handler to the array
	    $this_authby = [$self, 0, undef, undef, undef];
	    push(@{$p->{AuthBys}}, $this_authby);
	}

	$i = defined $this_authby ? $this_authby->[1] : 0;
	my $latest_authby_type = ref(${$self->{AuthBy}}[$i]);
	if (defined $p->{current_AuthBy} && ($latest_authby_type eq 'Radius::AuthGROUP' || $latest_authby_type eq 'Radius::AuthHANDLER'))
	{
	    # Forward an index pointer to the next AuthBy in AuthBys stack
	    ++$p->{current_AuthBy};
	}
	else
	{
	    # If we are "fast forwarding" to the last element,
	    # when last AuthBy returned CHALLENGE during a last round, we must get back to it,
	    # otherwise run the next AuthBy
	    ++$i if ($called_with_result || (defined $this_authby->[3] && $this_authby->[3] != $main::CHALLENGE));
	}
    }

    for (; $continue && $self->{AuthBy} && $i < @{$self->{AuthBy}}; $i++)
    {
	$this_authby->[1] = $i;

	my $auth = ${$self->{AuthBy}}[$i];
	# Make sure the authby is updated with stats
	# TODO: FIXME: Insert Statistics into StatsTrail only once
	push(@{$p->{StatsTrail}}, $auth->{Statistics});

	# Remember which AuthBy was last to process the packet
	$p->{AuthBy} = $auth;

	($result, $reason) = $auth->handle_request($p, $p->{rp}, $extra_checks);

	if ($result == $main::ASYNC)
	{
	    # Save Identifier, result and reason. This makes possible to
	    # use status of earlier AuthBy in the following AuthBy
	    $p->{prev_authby_identifier} = $auth->{Identifier};
	    $p->{prev_authby_result} = $result;
	    $p->{prev_authby_reason} = $reason;

	    $self->log($main::LOG_DEBUG, "$type:$self->{Identifier} $auth->{Identifier} result: $Radius::AuthGeneric::reasons[$result], $reason", $p);
	    # Do not reply yet, wait for an answer
	    return ($result, $reason);
	}

	# Call the PostAuthHook, if there is one
	$auth->runHook('PostAuthHook', $p, \$p, \$p->{rp}, \$result, \$reason) if $auth->{PostAuthHook};

	# Save Identifier, result and reason. This makes possible to
	# use status of earlier AuthBy in the following AuthBy
	$p->{prev_authby_identifier} = $auth->{Identifier};
	$p->{prev_authby_result} = $result;
	$p->{prev_authby_reason} = $reason;

	# Reset, if needed, reason after it's been stored for subsequent AuthBys
	if ($result == $main::REJECT || $result == $main::REJECT_IMMEDIATE)
	{
	    $reason = $auth->{RejectReason} if (defined $auth->{RejectReason});
	}

	$self->log($main::LOG_DEBUG, "$type:$self->{Identifier} $auth->{Identifier} result: $Radius::AuthGeneric::reasons[$result], $reason", $p);

	# Evaluate the AuthByPolicy
	last unless $self->evaluatePolicy($self->{AuthByPolicy},$result);
    }

    # Check the DefaultSimultaneousUse
    if (defined $self->{DefaultSimultaneousUse}
	&& $p->code eq 'Access-Request'
	&& Radius::SessGeneric::find($p->{Handler}->{SessionDatabase})
	->exceeded($self->{DefaultSimultaneousUse}, $p->getUserName(), $p))
    {
	# If we are the last element, remove it
	if ($p->{AuthBys} && $p->{AuthBys}->[-1]->[0] == $self)
	{
	    pop(@{$p->{AuthBys}});
	    delete $p->{current_AuthBy};
	}

	return ($main::REJECT, "DefaultSimultaneousUse of $self->{DefaultSimultaneousUse} exceeded");
    }

    # Save result and reason
    $this_authby->[3] = $result;
    $this_authby->[4] = $reason;

    # When the result says there's no need to get back to us and we are the last element, remove it
    if ($result != $main::CHALLENGE &&
	$p->{AuthBys} && $p->{AuthBys}->[-1]->[0] == $self)
    {
	pop(@{$p->{AuthBys}});
    }

    $self->adjustReply($p) if ($result == $main::ACCEPT);

    return ($result, $reason);
}

#####################################################################
# This function may be called during operation to reinitialize 
# this module
# it is expected to reload any state, perhaps by rereading files, 
# reconnecting to a database or something like that.
# Its not actually called yet, but it as well to be 
# prepared for the day
# when it will be.
sub reinitialize
{
    my ($self) = @_;
}

1;
