# AcctLogFile.pm
#
# Specific class for logging accounting to a file
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AcctLogFILE;
use strict;
use warnings;
our @ISA = qw(Radius::AcctLogGeneric);
use Radius::AcctLogGeneric;
use Radius::Configurable;
use Radius::JSON qw(encode_json);
use File::Path;
use File::Basename;

%Radius::AcctLogFILE::ConfigKeywords =
(
 'LogFormat' =>
 ['string', 'This optional parameter specifies the format that is to be used to log accounting in Filename. You can use any of the special characters. %0 is replaced by the result, %1 by the reason string (usually an empty string for success) and %2 by tracing identifier string. Defaults to \'%l:%n:%{Acct-Session-Id}:%{Framed-IP-Address}:%{Calling-Station-Id}\'', 1],

 'Filename' =>
 ['string', 'This optional parameter specifies the name of the file where accounting log messages are to be written. Special formatting is supported. Defaults to %L/accounting.log. ', 0],

 'AcctLogOutputDef' =>
 ['stringarray', 'Optional parameter for JSON output. This parameter allows to map RADIUS attributes to JSON fields. The general format is: <p><pre><code>AcctLogOutputDef jsonattributename[, radiusattributename]</code></pre>. If radiusattributename is omitted, jsonattributename is used as RADIUS attribute. Special variables, such as %n, can also be used in radiusattributename', 0],

 'OutputFormat' =>
 ['enum', 'Format for the stats entries. Currently supported values are text and json. Default value is text.', 1, \@Radius::AcctLogFILE::OutputTypeEnum],
);

# RCS version number of this module
$Radius::AcctLogFILE::VERSION = '$Revision$';

# Output type enumeration
@Radius::AcctLogFILE::OutputTypeEnum = qw(text json);

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
    $self->{LogFormat} = '%l:%n:%{Acct-Session-Id}:%{Framed-IP-Address}:%{Calling-Station-Id}';
    $self->{Filename} = '%L/accounting.log';
    # Set default OutputFormat
    $self->{OutputFormat} = 'text';

    return;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    # Check that output formatter can be found
    $self->initialize_output_formatter();

    # Process AcctLogOutputDef to a hash containing JSON field and its mapped
    # RADIUS attribute.
    if ($self->{AcctLogOutputDef}) {
	my ($json_field, $radius_attr);
	foreach my $acctlogoutputdef_set (@{$self->{AcctLogOutputDef}})
	{
	    ($json_field,$radius_attr) = split (/,\s*/, $acctlogoutputdef_set);
	    $self->{acctlogoutputdef}->{$json_field} = $radius_attr;
	}
    }

    return;
}

#####################################################################
# Log an accounting message
# $result is $main::ACCEPT, $main::IGNORE, $main::REJECT, etc.
# $reason is the reason, $p is the request packet
sub acctlog
{
    my ($self, $result, $reason, $p) = @_;

    my $message;
    my $trace_id = $p->{trace_id};
    if (defined $self->{LogFormatHook})
    {
	($message) = $self->runHook('LogFormatHook', $p, $result, $reason, $p, $trace_id);
    }
    elsif (lc($self->{OutputFormat}) eq 'json')
    {
	my $time = Radius::Util::getTimeHires();
	my %message_fields = (
	    trace_id       => $trace_id,
	    time           => $time,
	    timestamp      => scalar localtime($time),
	    source_host    => $main::hostname,
	    type           => 'accounting',
	    );

	# Possibly add result and reject reason
	if (defined $result)
	{
	    $message_fields{result} = ($result == $main::ACCEPT ? 'accept' : 'reject');
	    $message_fields{reason} = $reason if $result == $main::REJECT;
	}
	# If there are processed AcctLogOutputDefs, process them.
	if (exists $self->{acctlogoutputdef}) {
	    foreach my $field (keys %{$self->{acctlogoutputdef}})
	    {
		# If there is only one value in the mapping, use that name
		my $attribute = (defined $self->{acctlogoutputdef}->{$field}) ?
		    $self->{acctlogoutputdef}->{$field} : $field;

		# Add possibility to use special formatting
		if ($attribute =~ /^%/) {
		    $message_fields{$field} = Radius::Util::format_special($attribute, $p, undef, $result, $reason, $trace_id);
		}
		# If there are more than 1 attributes, put them into an array.
		elsif ($p->attr_count($attribute) > 1)
		{
		    push @{$message_fields{$field}}, $p->get_attr($attribute);
		}
		else
		{
		    $message_fields{$field} = $p->get_attr($attribute);
		}
	    }
	}
	else
	{
	    %message_fields = (%message_fields, %{$p->get_attrs()});
	}
	eval { $message = encode_json(\%message_fields) };
	if ($@)
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: JSON encoding failed: $@");
	    return;
	}
    }
    else
    {
	$message = Radius::Util::format_special($self->{LogFormat}, $p, undef, $result, $reason, $trace_id);
    }
    my $filename = Radius::Util::format_special($self->{Filename}, $p, undef, $result, $reason);
    Radius::Util::append($filename, $message . "\n")
	|| warn "AcctLogFILE could not append '$message' to log file '$filename': $!";

    return;
}

#####################################################################
# Checks that output format can be handled correctly.
sub initialize_output_formatter
{
    my ($self) = @_;
    if (lc($self->{OutputFormat}) eq 'json')
    {
	unless (Radius::JSON::is_enabled())
	{
	    $self->log($main::LOG_ERR, "$self->{log_class_identifier}: JSON module was not found. Defaulting to text output.");
	    $self->{OutputFormat} = 'text';
	}
    }

    return;
}

1;
