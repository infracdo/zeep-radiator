# AcctLogEVENTLOG.pm
#
# Specific class for logging accounting to Windows Event Log
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AcctLogEVENTLOG;
@ISA = qw(Radius::AcctLogGeneric);
use Radius::AcctLogGeneric;
use Win32::EventLog;
use strict;
use warnings;

%Radius::AcctLogEVENTLOG::ConfigKeywords =
(
 'LogFormat' =>
 ['string', 'The format for success messages. You can use any of the special characters. %0 is replaced by the result, %1 by the reason string (usually an empty string for success) and %2 by tracing identifier string. Defaults to \'Accounting for user %n, Accounting-Session-Id: %{Acct-Session-Id}, Framed-IP-Address: %{Framed-IP-Address}, Calling-Station-Id: %{Calling-Station-Id}\'.', 1],

 );

# RCS version number of this module
$Radius::AcctLogEVENTLOG::VERSION = '$Revision$';

#####################################################################
# Do per-instance default initialization
# This is called by Configurable during Configurable::new before
# the config file is parsed. Its a good place initialize instance
# variables
# that might get overridden when the config file is parsed.
# Do per-instance default initialization. This is called after
# construction is complete
sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();
    $self->{LogFormat} = 'Accounting for user %n, Accounting-Session-Id: %{Acct-Session-Id}, Framed-IP-Address: %{Framed-IP-Address}, Calling-Station-Id: %{Calling-Station-Id}';
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();
    return;
}

#####################################################################
# Log an accounting message
# $result is $main::ACCEPT, $main::IGNORE, $main::REJECT, etc.
# $reason is the reason, $p is the request packet
sub acctlog
{
    my ($self, $result, $reason, $p) = @_;

    my $trace_id = $p->{trace_id};
    my $message = Radius::Util::format_special($self->{LogFormat}, $p, undef, $result, $reason, $trace_id);

    my $eventloghandle = Win32::EventLog->new("Radiator");
    unless ($evenloghandle)
    {
	main::log($main::LOG_WARNING, "AcctLogEVENTLOG: Could not open EventLog");
	return;
    }

    my %eventlogrecord = (
	'Source' => 'Radiator',
	'EventType' => EVENTLOG_INFORMATION_TYPE,
	'Category' => 'Accounting',
	'Strings' => $message,
	'Data' => $message,
	);

    $eventloghandle->Report(\%eventlogrecord)
	|| main::log($main::LOG_WARNING, "AcctLogEVENTLOG: Could not Report log entry");

    $eventloghandle->Close();
}

1;
