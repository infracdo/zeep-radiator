# AuthDYNAUTH.pm
#
# Object for creating DM and CoA requests.
#
# Author: Tuure Vartiainen (vartiait@open.com.au)
# Copyright (C) 2016 Open System Consultants
# $Id$

package Radius::AuthDYNAUTH;
use strict;
use warnings;
our @ISA = qw(Radius::AuthGeneric);
use Radius::AuthGeneric;
use Radius::Util;
use Radius::Client;
use Scalar::Util qw(refaddr);
use Radius::Radius;

%Radius::AuthDYNAUTH::ConfigKeywords =
(
 'RequestType' =>
 ['string', 'Defines what type of requests AuthBy DYNAUTH will send. Options are: Disconnect-Request (DM) and Change-Filter-Request (CoA)', 0],

 'NasAddrAttribute' =>
 ['stringarray', 'List of attributes in a request which can contain a NAS address to which dynauth Radius request will be sent. Value of last existed attribute will be used.', 0],

 'DynAuthSecret'     =>
 ['string', 'This defines the shared secret that will be used to encrypt RADIUS messages of dynamic authorization that are sent. DynAuthSecret can also be defined in <Client> definitions.', 1],

 'EncryptedDynAuthSecret'     =>
 ['string', 'This defines the shared secret that will be used to encrypt RADIUS messages of dynamic authorization that are sent. EncryptedDynAuthSecret can also be defined in <Client> definitions. EncryptedDynAuthSecret is in encrypted format and is preferred over DynAuthSecret.', 1],

 'DynAuthPort' =>
 ['string',
  'Defines a destination port to which send RADIUS requests of dynamic authorization. DynAuthPort can also be defined in <Client> definitions. Defaults to 3799',
  1],

 'DestinationAttribute' =>
 ['string',
  'Optional attribute to which AuthBy DYNAUTH stores destination information to where to send dynauth request. Used by AuthBy RADIUSBYATTR.', 1],

 'UseMessageAuthenticator' =>
 ['flag',
  'Adds a Message-Authenticator attribute to dynauth requests. Disabled by default.', 1],

 'RequireMessageAuthenticator' =>
 ['flag',
  'Requires dynauth replies to contain a (correct) Message-Authenticator attribute. Disabled by default.', 1],

 'DynAuthParamDef' =>
 ['stringhash', 'List of parameter definitions for AuthBy DYNAUTH. Format is: DynAuthParamDef  keyword,radiusattributename[,defaultvalue]', 2],

 'DynAuthAttribute' =>
 ['stringarray', 'List of attributes which NAS requires to identify a session when receiving a dynauth request. Dynauth request will contain these attributes. Format is: DynAuthAttribute  radiusattributename[,defaultvalue]', 0],

 'SessionDatabase' =>
 ['formatobjectlist', 'Specifies which SessionDatabase will be used to query session information. Special formatting characters are permitted.', 0],

 'NoSessionFetching' =>
 ['flag', 'Optional flag, which prevents user\'s session information to be fetched from SessionDatabase before sending a dynauth request.', 2],

 'NoSessionMapping' =>
 ['flag', 'Optional flag, which prevents session information from SessionDatabase to be mapped to dynauth request.', 2],

 'SessionCheck' =>
 ['stringhash', 'List of session attributes which are checked. Format is: SessionCheck sessionattribute,comparator,value[,formatted] . Supported comparators are eq,ne,ge,le', 1],

 'SessionCheckPolicy' =>
 ['string', 'Defines whether fail of single or all session checkers triggers sending dynauth request. Possible values are Any or All.', 1],

 'SessionCheckHook' =>
 ['hook', 'The hook will be called after SessionChecks have been evaluated. It can be used to implement custom or additional logic for session checking.', 1],

 'AccountingStopHandled' =>
 ['flag', 'Optional flag, which causes a dynauth request to be sent when an accounting stop is received.', 2],

 'MapAttribute' =>
 ['stringhash', 'This optional parameter allows you to specifiy how the session attributes from the SessionDatabase are to be placed in the DM or CoA request. Format is: MapAttribute	sessionattribute,radiusattribute', 1],

 'MapResultHook' =>
 ['hook', 'The hook will be called after the session information has been looked up from the SessionDatabase, and before Radiator has processed MapAttribute definitions.', 2],

 'Gossip' =>
 ['flag',
  'Enables AuthBy DYNAUTH to listen for gossip requests from other Radiator servers to originate dynauth Radius requests. Defaults to disabled.',
  2],

 'GossipPull' =>
 ['flag',
  'Enables AuthBy DYNAUTH to pull gossip requests from a queue. Defaults to disabled.',
  2],

 'GossipPullTimeout' =>
 ['integer',
  'How often to pull gossip requests from a queue. Defaults to every 20 seconds.',
  2],

 'GossipPullCount' =>
 ['integer',
  'How many gossip requests to pull from a queue at once. Defaults to 5.',
  2],

 'GossipReply' =>
 ['flag',
  'Enables AuthBy DYNAUTH to send a result of dynauth Radius request as a gossip message. Defaults to disabled.',
  2],

 'GossipPushReply' =>
 ['flag',
  'Enables AuthBy DYNAUTH to push a result of dynauth Radius request as a gossip message. Defaults to disabled.',
  2],
);

# RCS version number of this module
$Radius::AuthDYNAUTH::VERSION = '$Revision$';

sub initialize
{
    my ($self) = @_;

    $self->SUPER::initialize();

    $self->{RequestType} = 'Disconnect-Request';
    $self->{DynAuthPort} = 3799;
    # Default DestinationAttribute/HostsInfoAttribute for AuthBy RADIUSBYATTR
    $self->{DestinationAttribute} = "RadiusHosts";
    $self->{SessionCheckPolicy} = "Any";

    $self->{GossipPull} = 0;
    $self->{GossipPullTimeout} = 20;
    $self->{GossipPullCount} = 5;
    $self->{GossipReply} = 1;
    $self->{GossipPushReply} = 1;
}

sub check_config
{
    my ($self) = @_;

    $self->SUPER::check_config();

    # See if EncryptedSecret can be resolved
    if ($self->{EncryptedDynAuthSecret})
    {
	$self->log($main::LOG_ERR, "AuthDYNAUTH Could not decrypt EncryptedDynAuthSecret $self->{EncryptedDynAuthSecret}")
	    unless Radius::Util::decrypt_value(Radius::Util::format_special($self->{EncryptedDynAuthSecret}));
    }

    $self->log($main::LOG_WARNING, "Invalid RequestType '$self->{RequestType}' for AuthDYNAUTH in '$main::config_file'")
	unless ($self->{RequestType} eq 'Disconnect-Request' || $self->{RequestType} eq 'Change-Filter-Request');

    $self->log($main::LOG_INFO, "No SessionDatabase defined for AuthDYNAUTH in '$main::config_file'")
	unless defined $self->{SessionDatabase};

    return;
}

sub activate
{
    my ($self) = @_;

    $self->SUPER::activate();

    $self->{_decrypted_dynauth_secret} = Radius::Util::decrypt_value(Radius::Util::format_special($self->{EncryptedDynAuthSecret}))
	if $self->{EncryptedDynAuthSecret};

    $self->activate_gossip() if $self->{Gossip};
}

sub activate_gossip
{
    my ($self) = @_;

    require Radius::Gossip;

    if ($self->{Gossip} && ! $Radius::Gossip::handle)
    {
	$self->log($main::LOG_WARNING, "No Gossip method defined for AuthDYNAUTH at '$main::config_file' line $.");
	return;
    }

    if ($self->{GossipPull})
    {
	$Radius::Gossip::handle->register_pull_message_handle("AuthDYNAUTH-DynAuth-Request", $self->{GossipPullTimeout}, $self->{GossipPullCount}, sub {
	    my ($message) = @_;
	    $self->log($main::LOG_DEBUG, "Gossip: Received DynAuth-Request for user '$message->{username}'");
	    my ($result, $reason) = $self->send_dynauth(undef, $message->{username}, $message->{trace_id}, $message, 1);
	    if ($result == $main::REJECT)
	    {
		$self->send_gossip_reply($message, $result, $reason, $message->{trace_id});
	    }
	    return;
							      });

	$Radius::Gossip::handle->register_pull_message_handle("AuthDYNAUTH-UserDataChanged-Request", $self->{GossipPullTimeout}, $self->{GossipPullCount}, sub {
	    my ($message) = @_;
	    $self->log($main::LOG_DEBUG, "Gossip: Received UserDataChanged-Request for user '$message->{username}'");
	    my ($result, $reason) = $self->send_dynauth(undef, $message->{username}, $message->{trace_id}, $message, 1);
	    if ($result == $main::REJECT)
	    {
		$self->send_gossip_reply($message, $result, $reason, $message->{trace_id});
	    }
	    return;
							      });
    }
    else
    {
	$Radius::Gossip::handle->register_message_handle("AuthDYNAUTH-DynAuth-Request", sub {
	    my ($message) = @_;
	    $self->log($main::LOG_DEBUG, "Gossip: Received DynAuth-Request for user '$message->{username}'");
	    my ($result, $reason) = $self->send_dynauth(undef, $message->{username}, $message->{trace_id}, $message, 1);
	    if ($result == $main::REJECT)
	    {
		$self->send_gossip_reply($message, $result, $reason, $message->{trace_id});
	    }
	    return;
							 });

	$Radius::Gossip::handle->register_message_handle("AuthDYNAUTH-UserDataChanged-Request", sub {
	    my ($message) = @_;
	    $self->log($main::LOG_DEBUG, "Gossip: Received UserDataChanged-Request for user '$message->{username}'");
	    my ($result, $reason) = $self->send_dynauth(undef, $message->{username}, $message->{trace_id}, $message, 1);
	    if ($result == $main::REJECT)
	    {
		$self->send_gossip_reply($message, $result, $reason, $message->{trace_id});
	    }
	    return;
							 });
    }
}

#####################################################################
# We may have DynAuthSecret and EncryptedDynAuthSecret. We prefer the
# encrypted dynauth secret but only if it's been successfully decrypted
sub dynauth_secret
{
    my ($self) = @_;

    return defined $self->{_decrypted_dynauth_secret} ?
	$self->{_decrypted_dynauth_secret} :
	$self->{DynAuthSecret};
}

# Returns (result, reason)
sub handle_request
{
    my ($self, $p, $dummy, $extra_checks) = @_;

    my $type = ref($self);
    $self->log($main::LOG_DEBUG, "Handling with $type: $self->{Identifier}", $p);

    my $username = $p->getUserName;
    if ($p->code eq 'Access-Request')
    {
	return $self->send_dynauth($p);
    }
    elsif ($p->code eq 'Accounting-Request')
    {
	my $type = $p->getAttrByNum($Radius::Radius::ACCT_STATUS_TYPE);

	if (($type eq 'Start') || ($type eq 'Alive'))
	{
	    my $result = $self->check_session($username, $p);
	    # Allow modifying session check's result
	    $self->runHook('SessionCheckHook', $p, \$p, \$result) if $self->{SessionCheckHook};
	    if (! $result)
	    {
		$self->log($main::LOG_DEBUG, "AuthDYNAUTH $self->{Identifier}: Session check failed for user '$username', sending dynauth request", $p);
		return $self->send_dynauth($p);
	    }
	    else
	    {
		return ($main::ACCEPT, 'Session check succeeded');
	    }
	}
	elsif ($type eq 'Stop' && $self->{AccountingStopHandled})
	{
	    return $self->send_dynauth($p);
	}
	else
	{
	    return ($main::ACCEPT, 'Session stopped');
	}
    }
    elsif ($p->code eq 'Disconnect-Request' || $p->code eq 'Change-Filter-Request')
    {
	# Lookup session information and send dynauth request
	return $self->send_dynauth($p, undef, undef, undef, 1);
    }

    return ($main::ACCEPT, 'Not a relevant request type');
}

# Returns (result, reason)
sub send_dynauth
{
    my ($self, $p, $username, $trace_id, $message_hash, $get_sessions) = @_;

    my $params = {
	RequestType => $self->{RequestType},
	DestinationAttribute => $self->{DestinationAttribute},
	DynAuthSecret => $self->{DynAuthSecret},
	DynAuthPort => $self->{DynAuthPort},
	NoSessionMapping => $self->{NoSessionMapping},
	NoSessionFetching => $self->{NoSessionFetching},
	UseMessageAuthenticator => $self->{UseMessageAuthenticator},
	RequireMessageAuthenticator => $self->{RequireMessageAuthenticator},
	DestinationAddress => "",
    };

    if ($message_hash)
    {
	map { $params->{$_} = $message_hash->{$_} if defined $message_hash->{$_} } keys %{$params};
    }

    # Possible overwrite of params
    foreach my $attribute (sort keys %{$self->{DynAuthParamDef}})
    {
	my ($radiusattr, $default_value) = split (/,\s*/, $self->{DynAuthParamDef}{$attribute}, 2);
	my $value;
	$value = $p->get_attr($radiusattr) if $p;
	$value = $default_value unless defined $value;
	$params->{$attribute} = $value;
    }

    my $name = ($p) ? $p->getUserName : $username || "";

    my ($rc, $result, $reason, $backend_session_id);
    my @backend_session_ids = ();
    my ($dynauth_requests, $dynauth_requests_sent) = (1, 0);

    # Get sessions for user when asked for
    if ($get_sessions && $self->{SessionDatabase} && !$params->{NoSessionFetching})
    {
	unless ($name)
	{
	    $self->log($main::LOG_ERR, "AuthDYNAUTH $self->{Identifier}: Can not fetch user's sessions from SessionDatabase without a username", $p);
	    return ($main::REJECT, "Can not fetch user's sessions from SessionDatabase without a username");
	}

	($rc, @backend_session_ids) = $self->{SessionDatabase}[0]->sessionsForUser($name, $params->{DestinationAddress}, undef, 1);

	unless ($rc)
	{
	    $self->log($main::LOG_ERR, "AuthDYNAUTH $self->{Identifier}: Fetching sessions from SessionDatabase for user '$name' failed", $p);
	    return ($main::REJECT, "Fetching sessions from SessionDatabase for user '$name' failed");
	}
	else
	{
	    $dynauth_requests = scalar @backend_session_ids;
	    unless ($dynauth_requests)
	    {
		$self->log($main::LOG_INFO, "AuthDYNAUTH $self->{Identifier}: User '$name' has no sessions in SessionDatabase", $p);
	    }
	}
    }

    # Send one or more dynauth requests
    for ($dynauth_requests_sent = 0; $dynauth_requests_sent < $dynauth_requests; $dynauth_requests_sent++)
    {
	$backend_session_id = $backend_session_ids[$dynauth_requests_sent];
	($result, $reason) = $self->dispatch_dynauth($p, $name, $trace_id, $message_hash, $params, $backend_session_id);
	# Stop when rejected
	last if (!defined $result || $result == $main::REJECT || $result == $main::REJECT_IMMEDIATE);
    }

    $result = $main::REJECT unless (defined $result && $result != $main::REJECT_IMMEDIATE);
    $reason = 'No reason defined' unless defined $reason;

    unless ($result == $main::REJECT)
    {
	if ($dynauth_requests_sent > 1)
	{
	    $reason = "Created $dynauth_requests_sent DynAuthRequests and dispatched them to a Handler";
	}
	else
	{
	    $reason = "Created DynAuthRequest and dispatched it to a Handler";
	}
    }

    return ($result, $reason);
}

# Returns (result, reason)
sub dispatch_dynauth
{
    my ($self, $p, $name, $trace_id, $message_hash, $params, $backend_session_id) = @_;

    my $ap = Radius::Radius->new($main::dictionary);
    $ap->set_code($params->{RequestType});
    if ($p)
    {
	$ap->{Client} = $p->{Client};
	$ap->{StatsTrail} = $p->{StatsTrail};
	$ap->{outerRequest} = $p;
    }
    $ap->{trace_id} = ($p) ? $p->{trace_id} : $trace_id;
    $ap->set_authenticator(Radius::Util::random_string(16));
    # Dispatch dynauth request can be matched with <Handler DynAuthRequest=1>
    $ap->{DynAuthRequest}++;
    $ap->add_attr('Message-Authenticator', "\000" x 16)
	if $params->{UseMessageAuthenticator};
    # Whether reply must contain Message-Authenticator
    $ap->{RequireMessageAuthenticator} = $params->{RequireMessageAuthenticator};
    $ap->{RecvTime} = time;
    $ap->{replyFn} = [\&Radius::AuthDYNAUTH::replyFn, $self, $message_hash];
    $ap->{OriginalUserName} = $name;
    if ($backend_session_id)
    {
	$ap->{internal_vars}->{backend_session_id} = $backend_session_id;
    }

    my ($nas_id, $nas_port, $session_id);
    if (defined $message_hash && defined $message_hash->{DynAuthAttribute})
    {
	# Copy values from $message_hash to $ap
	foreach my $attribute (keys %{$message_hash->{DynAuthAttribute}})
	{
	    my $value = $message_hash->{DynAuthAttribute}->{$attribute};
	    $ap->add_attr($attribute, $value) if defined $value;
	}
	if (defined $message_hash->{DynAuthAttribute}->{'NAS-Identifier'})
	{
	    $nas_id = $message_hash->{DynAuthAttribute}->{'NAS-Identifier'};
	}
	if (defined $message_hash->{DynAuthAttribute}->{'NAS-Port'})
	{
	    $nas_port = $message_hash->{DynAuthAttribute}->{'NAS-Port'};
	}
	if ($self->{SessionDatabase})
	{
	    if (defined $message_hash->{DynAuthAttribute}->{$self->{SessionDatabase}[0]->{SessionIdentifier}})
	    {
		$session_id = $message_hash->{DynAuthAttribute}->{$self->{SessionDatabase}[0]->{SessionIdentifier}};
	    }
	}
    }

    # Copy values from $p to $ap
    foreach my $attribute (@{$self->{DynAuthAttribute}})
    {
	my ($radiusattr, $default_value) = split (/\s*,\s*/, $attribute, 2);
	my $value;
	$value = $p->get_attr($radiusattr) if $p;
	$value = $default_value unless defined $value;
	$ap->add_attr($radiusattr, $value);
    }

    # Map session information to $ap
    unless ($params->{NoSessionMapping})
    {
	if ($p)
	{
	    if ($p->{innerRequest})
	    {
		$self->log($main::LOG_ERR, "AuthDYNAUTH $self->{Identifier}: RADIUS request had innerRequest already defined when dispatching DynAuth request.", $p);
		return ($main::REJECT, 'RADIUS request had innerRequest already defined');
	    }
	    else
	    {
		$p->{innerRequest} = $ap;
	    }
	}

	# when provided, use $p for looking up a session
	$self->mapSessionData($name, $nas_id, $nas_port, $p || $ap, $session_id, $backend_session_id);
    }

    # Lookup destination address
    my $dest_addr;
    if ($params->{DestinationAddress})
    {
	$dest_addr = $params->{DestinationAddress};
    }
    else
    {
	foreach my $attribute (@{$self->{NasAddrAttribute}})
	{
	    my ($attr_name, $formatted) = split(/\s*,\s*/, $attribute, 2);
	    my $addr;
	    if ($formatted && lc($formatted) eq 'formatted')
	    {
		$addr = Radius::Util::format_special($attr_name, $p, $self, $p->getNasId()) if $p;
		$addr = Radius::Util::format_special($attr_name, $ap, $self, $ap->getUncachedNasId()) if (!$addr || $addr eq $Radius::Radius::UNKNOWN_NAS_ID);
	    }
	    else
	    {
		$addr = $p->get_attr($attr_name) if $p;
		$addr = $ap->get_attr($attr_name) unless $addr;
	    }
	    if ($addr)
	    {
		$dest_addr = $addr;
		last;
	    }
	}
    }

    # Add possible DestinationAttribute for AuthBy RADIUSBYATTR
    if ($params->{DestinationAttribute})
    {
	if ($dest_addr)
	{
	    my ($secret, $authport);

	    # Use values from $params if provided
	    $secret = $params->{DynAuthSecret} if $params->{DynAuthSecret};
	    $authport = $params->{DynAuthPort} if $params->{DynAuthPort};

	    # If there is no Client in $ap, check if one is configured.
	    if (! $ap->{Client})
	    {
		$ap->{RecvFromAddress} = Radius::Util::inet_pton($dest_addr) unless $ap->{RecvFromAddress};
		my $client = Radius::Client::find($ap);
		$ap->{Client} = $client if $client;
	    }

	    if ($ap->{Client})
	    {
		# Secret
		$secret = $ap->{Client}->dynauth_secret() unless defined $secret;
		$secret = $self->dynauth_secret() unless defined $secret;
		$secret = $ap->{Client}->secret() unless defined $secret;

		# DM/CoA port
		unless (defined $authport)
		{
		    if ($ap->{Client}->{DynAuthPort})
		    {
			$authport = $ap->{Client}->{DynAuthPort};
		    }
		    else
		    {
			$authport = $self->{DynAuthPort};
		    }
		}
	    }

	    $secret = $self->dynauth_secret() unless $secret;
	    $authport = $self->{DynAuthPort} unless $authport;

	    # attribute for AuthBy RADIUSBYATTR
	    $ap->add_attr($params->{DestinationAttribute}, "$dest_addr,$secret,$authport,$authport,$authport");
	}
	else
	{
	   $self->log($main::LOG_WARNING, "AuthDYNAUTH $self->{Identifier}: No DestinationAddress nor NasAddrAttribute defined for DynAuth request.", $p);
	}
    }

    $self->runHook('PreHandlerHook', $ap, \$ap);

    if ($ap->{Client})
    {
	# run VSA translations, if any
	$ap->{Client}->translateVSAsOut($ap) if $ap->{Client}->{VsaTranslateOut};
	$ap->{Client}->runHook('VsaTranslationHook', $ap, $p, 1, $ap) if $ap->{Client}->{VsaTranslationHook};
    }

    $self->log($main::LOG_EXTRA_DEBUG,"Created " . $ap->code() . ", Packet dump:\n" . $ap->dump, $p);
    my ($user, $realmName);
    ($user, $realmName) = split(/@/, $name) if $name;

    my ($handler, $result);
    foreach my $finder (@Radius::Client::handlerFindFn)
    {
	if ($handler = &$finder($ap, $user, $realmName))
	{
	    push(@{$p->{StatsTrail}}, $handler->{Statistics}) if $p;
	    ($result, undef) = $handler->handle_request($ap);
	    last;
	}
    }

    return ($main::REJECT, "No Handler found for DynAuthRequest")
	unless $handler;

    $ap->{proxied}++ if ($result && ($result == $main::IGNORE || $result == $main::ASYNC));
    $p->{proxied} = $ap->{proxied} if $p;

    return ($result, "Created DynAuthRequest and dispatched it to a Handler");
}

sub replyFn
{
    my ($ap, $self, $gossip_request, $result_ref, $reason_ref) = @_;

    my $request_code = $ap->code;
    my $trace_id = $ap->{trace_id};
    my $reply_code = $ap->{rp}->code;
    my $op = $ap->{outerRequest};
    $op->{proxied} = $ap->{proxied} if $op;
    my $result = $main::REJECT;
    my $reason;

    # Do VSA translations, if needed
    $ap->{Client}->translateVSAsIn($ap->{rp}) if $ap->{Client}->{VsaTranslateIn};
    $ap->{Client}->runHook('VsaTranslationHook', $ap->{rp}, $ap->{rp}, 0) if $ap->{Client}->{VsaTranslationHook};

    if (($request_code eq 'Disconnect-Request' && $reply_code eq 'Disconnect-Request-ACKed') ||
	($request_code eq 'Change-Filter-Request' && $reply_code eq 'Change-Filter-Request-ACKed'))
    {
	# TODO: FIXME: Should we be able to use reply attributes for something?

	# Clear session as no accounting stop will be send after DM
	if ($request_code eq 'Disconnect-Request' && $self->{SessionDatabase})
	{
	    my ($nas_id, $nas_port, $session_id, $framed_ip_address, $backend_session_id);

	    # Get values from $ap (DM/CoA request)
	    $nas_id = $ap->getNasId();
	    $nas_port = $ap->getAttrByNum($Radius::Radius::NAS_PORT);
	    $session_id = $ap->get_attr($self->{SessionDatabase}[0]->{SessionIdentifier});
	    $framed_ip_address = $ap->getAttrByNum($Radius::Radius::FRAMED_IP_ADDRESS);
	    if (defined $ap->{internal_vars} && $ap->{internal_vars}->{backend_session_id})
	    {
		$backend_session_id = $ap->{internal_vars}->{backend_session_id};
	    }

	    # Get values from $op (orig Radius request, if available)
	    if ($op)
	    {
		$nas_id = $op->getNasId() if ($nas_id eq $Radius::Radius::UNKNOWN_NAS_ID);
		$nas_port = $op->getAttrByNum($Radius::Radius::NAS_PORT) unless defined $nas_port;
		$session_id = $op->get_attr($self->{SessionDatabase}[0]->{SessionIdentifier}) unless $session_id;
		$framed_ip_address = $op->getAttrByNum($Radius::Radius::FRAMED_IP_ADDRESS) unless defined $framed_ip_address;
	    }
	    # Else try to get values from $gossip_request
	    elsif ($gossip_request && $gossip_request->{DynAuthAttribute})
	    {
		$nas_id = $gossip_request->{DynAuthAttribute}->{'NAS-Identifier'} if ($nas_id eq $Radius::Radius::UNKNOWN_NAS_ID);
		$nas_port = $gossip_request->{DynAuthAttribute}->{'NAS-Port'} unless defined $nas_port;
		$session_id = $gossip_request->{DynAuthAttribute}->{$self->{SessionDatabase}[0]->{SessionIdentifier}} unless $session_id;
	    }

	    $self->{SessionDatabase}[0]->delete($gossip_request->{username}, $nas_id, $nas_port, $op || $ap,
						$session_id, $framed_ip_address, $backend_session_id);
	}

	$result = $main::ACCEPT;
	$reason = 'Received ACK for DynAuthRequest';
    }
    else
    {
	$result = $main::REJECT;
	$reason = (defined $reason_ref) ? $$reason_ref : 'Received NACK for DynAuthRequest';
    }

    $self->send_gossip_reply($gossip_request, $result, $reason, $trace_id);

    $op->{Handler}->handlerResult($op, $result, $reason) if ($op && $op->{Handler} && $ap->{proxied});

    return;
}

sub send_gossip_reply
{
    my ($self, $gossip_request, $result, $reason, $trace_id) = @_;

    if (($self->{GossipReply} || $self->{GossipPushReply}) && $gossip_request)
    {
	my $gossip_reply = {
	    version => 1,
	    type    => $gossip_request->{type} . "-Reply",
	    from    => $main::hostname . "." . $main::farmInstance,
	    from_id => "$main::hostname." . $$ . ".$main::farmInstance." . refaddr($self),
	    msg_id => (defined $gossip_request) ? $gossip_request->{msg_id} : $trace_id,
	    timestamp => time(),
	    trace_id => $trace_id,
	    to_id => $gossip_request->{from_id},
	    username => $gossip_request->{username},
	    result => $Radius::AuthGeneric::reasons[$result],
	    reason => $reason,
	};

	$gossip_reply->{object_dn} = $gossip_request->{object_dn} if exists $gossip_request->{object_dn};
	$gossip_reply->{object_class} = $gossip_request->{object_dn} if exists $gossip_request->{object_dn};

	my $destination = $gossip_request->{from_id};

	if ($self->{GossipPushReply})
	{
	    $destination = $gossip_reply->{type};
	    $Radius::Gossip::handle->push($destination, $gossip_reply, undef, sub {});
	}
	else
	{
	    $Radius::Gossip::handle->tell($destination, $gossip_reply);
	}
    }

    return;
}

# Evaluates defined SessionChecks
# SessionCheckPolicy defines whether fail of a single (Any) or all (All)
# checks invalidates a session.
#
# returns 1 when checking succeeds
# returns 0 when checking fails
sub check_session
{
    my ($self, $username, $p) = @_;
    # Short circuit when the session has already been marked exceeded
    return !$p->{SessionExceeded} if exists $p->{SessionExceeded};
    return 0 unless $self->{SessionDatabase};
    my $session_data = $self->{SessionDatabase}[0]->getSessionData($username, undef, undef, $p);
    # If we are unable to get session data, return success
    unless ($session_data)
    {
	$self->log($main::LOG_WARNING, "AuthDYNAUTH $self->{Identifier}: Session check failed, unable to get session data for user '$username'", $p);
	return 1;
    }

    my $single_failure_policy = ($self->{SessionCheckPolicy} && lc($self->{SessionCheckPolicy}) eq 'any') ? 1 : 0 ;
    my $all_false = 1;

    foreach my $attribute (sort keys %{$self->{SessionCheck}})
    {
	return 0 if (! defined $session_data->{$attribute} && $single_failure_policy);
	next if (! defined $session_data->{$attribute});

	my ($cmp, $value, $formatted) = split (/,\s*/, $self->{SessionCheck}{$attribute}, 3);
	$cmp = lc($cmp);
	$value = Radius::Util::format_special($value, $p, $self)
	    if $formatted && $formatted eq 'formatted';

	my $numeric_cmp = ($value =~ /^\d+$/) ? 1 : 0;
	my $numeric_value = ($session_data->{$attribute} =~ /^\d+$/) ? 1 : 0;
	my $r;
	if ($numeric_cmp != $numeric_value)
	{
	    $r = 0;
	}
	else
	{
	    # supported comparators eq,ne,le,ge
	    if ($cmp eq 'eq')
	    {
		if ($numeric_cmp)
		{
		    $r = ($session_data->{$attribute} == $value) ? 1 : 0;
		}
		else
		{
		    $r = ($session_data->{$attribute} eq $value) ? 1 : 0;
		}
	    }
	    elsif ($cmp eq 'ne')
	    {
		if ($numeric_cmp)
		{
		    $r = ($session_data->{$attribute} != $value) ? 1 : 0;
		}
		else
		{
		    $r = ($session_data->{$attribute} ne $value) ? 1 : 0;
		}
	    }
	    elsif ($cmp eq 'le')
	    {
		if ($numeric_cmp)
		{
		    $r = ($session_data->{$attribute} <= $value) ? 1 : 0;
		}
		else
		{
		    $r = ($session_data->{$attribute} le $value) ? 1 : 0;
		}
	    }
	    elsif ($cmp eq 'ge')
	    {
		if ($numeric_cmp)
		{
		    $r = ($session_data->{$attribute} >= $value) ? 1 : 0;
		}
		else
		{
		    $r = ($session_data->{$attribute} ge $value) ? 1 : 0;
		}
	    }
	    else
	    {
		$r = 0;
	    }
	}

	#print "DEBUG: failing $attribute,$cmp,$value,$session_data->{$attribute} $numeric_cmp,$numeric_value $r\n" unless $r;
	return 0 if (!$r && $single_failure_policy);
	$all_false = 0 if $r;
	return 1 if (!$all_false && !$single_failure_policy);
    }

    return !($all_false && !$single_failure_policy);
}

# Called by the sessiondatabase when the session information has been looked up
sub sessionReady
{
    my ($self, $p, $result) = @_;

    my $ap;

    if ($p->{innerRequest})
    {
	$ap = $p->{innerRequest};
	$p->{innerRequest} = undef;
    }
    else
    {
	$ap = $p;
    }

    # map the results to the dynauth request
    $self->mapResult($result, $ap);
}

# Take a session information, and map it into Radius request attributes
sub mapResult
{
    my ($self, $result, $ap) = @_;

    # Allow modifying the results before mapping them
    $self->runHook('MapResultHook', $ap, $result);

    # Now go through the list of session results that
    # we have to map into radius request attributes
    foreach my $name (sort keys %{$self->{MapAttribute}})
    {
	# If there is a definition for this result,
	# and the corresponding radius request attribute
	# is not already set in the request, and we
	# actually have a value for it, then set it
	my $value = $result->{$name};
	if ($self->{MapAttribute}{$name}
	    && defined $value
	    && $value ne ''
	    && ! $ap->get_attr($name))
	{
	    # Handle multi instance values too
	    $value = [$value] unless (ref($value) eq 'ARRAY');
	    map { $ap->add_attr($self->{MapAttribute}{$name}, $_) } @$value;
	}
    }
}

sub mapSessionData
{
    my ($self, $name, $nas_id, $nas_port, $p, $session_id, $backend_session_id) = @_;
    return unless $self->{SessionDatabase};

    return $self->{SessionDatabase}[0]->mapSessionData($self, $name, $nas_id, $nas_port, $p, $session_id, $backend_session_id);
}

1;
