#!/usr/bin/env perl
#
# Creates index files for root and intermediate CAs. Index files are
# needed when testing OCSP with OpenSSL's ocsp server.
#
# $Id$

use Net::SSLeay;
use Getopt::Long;
use strict;
use warnings;

my ($opt_h, $opt_c, $opt_i, $opt_r, $opt_e);

GetOptions(
    'h'   => \$opt_h, # Usage
    'c'   => \$opt_c, # Trunacte and open, other wise append
    'i=s' => \$opt_i, # Index file name
    'e'   => \$opt_e, # Is expired, however, OpenSSL's OCSP app does not use this
    'r'   => \$opt_r, # Is revoked
) || usage();

usage() if $opt_h || @ARGV == 0;

my $index; my $mode = $opt_c ? '>' : '>>';
die "Can not open index file $opt_i\n" unless open($index, $mode, $opt_i);

Net::SSLeay::load_error_strings();
#print "Using Net::SSLeay $Net::SSLeay::VERSION with " . Net::SSLeay::SSLeay_version() . "\n";

foreach my $file (@ARGV)
{
    my $bio = Net::SSLeay::BIO_new_file($file, 'rb');
    die "BIO_new_file for $file failed: " . Net::SSLeay::print_errs() . "\n" unless ($bio);

    my $x509 = Net::SSLeay::PEM_read_bio_X509($bio);
    die "PEM_read_bio_X509 for $file failed: " . Net::SSLeay::print_errs() . "\n" unless ($x509);

    my $not_before = Net::SSLeay::X509_get_notBefore($x509);
    my $not_before_isotime = Net::SSLeay::P_ASN1_TIME_get_isotime($not_before);
    my ($yy, $mm, $dd, $HH, $MM, $SS) = ($not_before_isotime =~ /^..(\d\d)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)Z$/);
    my $expiry_time = "$yy$mm$dd$HH$MM$SS" . "Z";

    my $status = ($opt_r) ? 'R' : 'V';
    $status = 'E' if $opt_e;
    my $revocation_time = ($opt_r) ? $expiry_time : '';

    my $serial = Net::SSLeay::X509_get_serialNumber($x509);
    $serial = Net::SSLeay::P_ASN1_INTEGER_get_hex($serial);

    my $subject_name = Net::SSLeay::X509_get_subject_name($x509);
    my $subject_dn = Net::SSLeay::X509_NAME_oneline($subject_name);

    print $index "$status\t$expiry_time\t$revocation_time\t$serial\tunknown\t$subject_dn\n";
}

sub usage
{
    print "usage: $0 [-h] [-e] [-r] -i index_file FILE...\n";
    print "    -h      This help\n";
    print "    -c      Truncate the index file instead of appending\n";
    print "    -i=FILE Index file name\n";
    print "    -e      Create entry that is expired. Not used by OpenSSL's OCSP app\n";
    print "    -r      Create entry that is revoked\n";
    print "    FILE... Certificate file names for indexing\n";

    exit (0);
}
