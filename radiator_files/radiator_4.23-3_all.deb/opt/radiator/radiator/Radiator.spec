#
# RPM Spec file for Radiator on RH7, SuSE and similar
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2001-2004 Open System Consultants
# $Id$

# Allow us to control whether we are building Locked or UNlocked from the command line

# Disable the default LZMA compression on OpenSuSE, since it is not available on all platforms
%define _binary_payload w9.bzdio

%{!?DISTNAME:%define DISTNAME Radiator}
%{!?PERLVER:%define PERLVER 5.10.0}

Summary: Radiator Radius server
Name: %{DISTNAME}
Version: 4.23
Release: 1
Epoch: 42301
License: Proprietary, Open System Consultants Pty Ltd
Group: System/Servers
Source: %{name}-%{version}.tgz
URL: http://www.open.com.au/radiator/
Vendor: Open System Consultants Pty. Ltd.
Packager: Open System Consultants, Heikki Vatiainen <hvn@open.com.au>
AutoReqProv: no
Provides: Radiator
Requires: perl >= 5.6.0
Prefix: /usr


%description
Radiator Radius server provides RADIUS authentication through
a wide range of data sources, such as flat file, DBM, SQL, SecurID
LDAP, Unix Passwd, TACACS+, NT SAM, Active Directory, OPIE
NIS+, CDB, AFS Kerberos, PAM, RAdmin, global roaming (iPASS, GoRemote)
ISP billing (Emerald, Platypus, Rodopi, Optigold, Hawk-i, Billmax
Interbiller, Freeside).

%prep
%setup

%build
PREFIX=$RPM_BUILD_ROOT/%{prefix} perl Makefile.PL
make

%install
mkdir -p $RPM_BUILD_ROOT/bin
mkdir -p $RPM_BUILD_ROOT/var/log/radius
mkdir -p $RPM_BUILD_ROOT/etc/radiator
mkdir -p $RPM_BUILD_ROOT/etc/init.d
mkdir -p $RPM_BUILD_ROOT/usr/lib/perl5/
mkdir -p $RPM_BUILD_ROOT/usr/lib/perl5/site_perl
mkdir -p $RPM_BUILD_ROOT/usr/lib/perl5/vendor_perl
mkdir -p $RPM_BUILD_ROOT/usr/lib/perl5/site_perl/%PERLVER/Radius
mkdir -p $RPM_BUILD_ROOT/usr/lib64/perl5/
mkdir -p $RPM_BUILD_ROOT/usr/lib64/perl5/vendor_perl
make install
install -m644 goodies/linux-radius.cfg $RPM_BUILD_ROOT/etc/radiator/radius.cfg
install -m644 goodies/simple-users $RPM_BUILD_ROOT/etc/radiator/users
install -m644 dictionary $RPM_BUILD_ROOT/etc/radiator
install -m755 goodies/linux-radiator.init $RPM_BUILD_ROOT/etc/init.d/radiator
ln -fs /usr/lib/perl5/site_perl/%PERLVER/Radius $RPM_BUILD_ROOT/usr/lib/perl5/site_perl
ln -fs /usr/lib/perl5/site_perl/%PERLVER/Radius $RPM_BUILD_ROOT/usr/lib/perl5
ln -fs /usr/lib/perl5/site_perl/%PERLVER/Radius $RPM_BUILD_ROOT/usr/lib/perl5/vendor_perl
ln -fs /usr/lib/perl5/site_perl/%PERLVER/Radius $RPM_BUILD_ROOT/usr/lib64/perl5
ln -fs /usr/lib/perl5/site_perl/%PERLVER/Radius $RPM_BUILD_ROOT/usr/lib64/perl5/vendor_perl

%files
%attr(-, root, root) %doc doc
%attr(-, root, root) %doc goodies
%attr(-, root, root) %doc ppm
%attr(-, root, root) %doc certificates
%attr(-, root, root) %doc dictionary*
%config(noreplace) /etc/radiator/radius.cfg
%config(noreplace) /etc/radiator/users
%dir /var/log/radius
/usr/bin/builddbm
/usr/bin/radpwtst
/usr/bin/radiusd
/usr/bin/buildsql
/usr/lib/perl5/site_perl/%PERLVER/Radius
/usr/lib/perl5/site_perl/Radius
/usr/lib/perl5/Radius
/usr/lib/perl5/vendor_perl/Radius
/usr/lib64/perl5/Radius
/usr/lib64/perl5/vendor_perl/Radius
%config(noreplace) /etc/radiator/dictionary
%config(noreplace) /etc/init.d/radiator

%post
# Just in case they have a different perl version
#ln -fs /usr/lib/perl5/site_perl/5.8.3/Radius /usr/lib/perl5/site_perl/Radius
if [ -x /etc/rc.d/rc.M -a -x /etc/rc.d/rc.local ]; then
 # Slackware
 if ! grep -q 'radiator startup, added by rpm' /etc/rc.d/rc.local>/dev/null; then
  echo '# radiator startup, added by rpm' >> /etc/rc.d/rc.local
  echo 'if [ -x /etc/init.d/radiator ]; then' >> /etc/rc.d/rc.local
  echo '/etc/init.d/radiator start' >> /etc/rc.d/rc.local
  echo 'fi' >> /etc/rc.d/rc.local
 fi
else
 # LSB and similar
 # Try to be compatible with Cobalt and others:
 if [ -d /etc/rc.d/rc0.d ]; then
     rcbase=/etc/rc.d
 else
     rcbase=/etc
 fi
 # Add startup script
 for i in 0 1 2
 do 
    ln -sf ../init.d/radiator $rcbase/rc$i.d/K15radiator
 done
 for i in 2 3 4 5 6
 do 
    ln -sf ../init.d/radiator $rcbase/rc$i.d/S90radiator
 done
fi

%preun
if [ -x /etc/rc.d/rc.M  -a -x /etc/rc.d/rc.local ]; then
 # Slackware
 echo slackware
else
 # LSB and similar
 # Try to be compatible with Cobalt and others:
 if [ -d /etc/rc.d/rc0.d ]; then
     rcbase=/etc/rc.d
 else
     rcbase=/etc
 fi
 # Remove any links from startup dirs
 if [ $1 = 0 ]; then
     for i in 0 1 2 3 4 5 6
     do 
         rm -f $rcbase/rc$i.d/K15radiator $rcbase/rc$i.d/S90radiator
     done
     rm -rf /usr/lib/perl5/site_perl/*/Radius
     rm -rf /usr/lib/perl5/site_perl/Radius
     rm -rf /usr/lib/perl5/vendor_perl/Radius
     rm -rf /usr/lib/perl5/Radius
     rm -rf /usr/lib64/perl5/Radius
     rm -rf /usr/lib64/perl5/vendor_perl/Radius
 fi
fi

%changelog
* Mon Feb 26 2018 Heikki Vatiainen
  - Reverted the previous change
* Wed Feb 21 2018 Heikki Vatiainen
  - When building non-evaluation Radiator RPM, the RPM file will obsolete installed Radiator-Locked RPM so
	that Radiator can be upgraded from Radiator-Locked to Radiator.
* Thu Oct 27 2011 Mike McCauley
  - Fixed a problem which would cause /usr/lib64/perl5/ to be deleted if the Radiator RPM package was erased.
* Fri Sep 9 2011 Mike McCauley
  - Improvments to permit installation with recent 64 bit perls.
* Wed Sep 22 2010 Mike McCauley <mikem@open.com.au>
  - Fixed some problems with installed Radius paths
* Wed Sep 15 2010 Mike McCauley <mikem@open.com.au>
  - Disable LZMA compression (suse default at 11.0), use BZ2 instead
* Thu Aug 11 2010 Mike McCauley <mikem@open.com.au>
  - Update to perl 5.10.0 opensuse 11.1
* Thu Dec 24 2009 Mike McCauley <mikem@open.com.au>
  - Fixed problems with PERLVER
* Tue Nov 24 2009 "Bjoern A. Zeeb" <info@cksoft.de>
  - Auto-detect Perl version for site_local paths.
* Fri Nov 13 2009 Mike McCauley <mikem@open.com.au>
  - Added /usr/lib/perl5/vendor_perl/Radius to the install links for SLES 11
* Thu Mar 21 2009 Mike McCauley <mikem@open.com.au>
  - Replaced Serial tag with Epoch. Serial is obsolete.
* Wed Mar  9 2005 Mike McCauley <mikem@open.com.au>
  - Install on Debian: /usr/lib/perl5/site_perl/ is not in @INC, so add /usr/lib/perl5/Radius symlink
* Thu Nov 11 2004 Mike McCauley <mikem@open.com.au>
  - Improved behaviour when doing rpm -F install over an old version. The symlink in /usr/lib/perl5/site_perl/Radius
	could end up incorrect.
* Wed Oct 20 2004 Mike McCauley <mikem@open.com.au>
  - Improved install behaviour for Slackware
* Tue Oct  5 2004 Mike McCauley <mikem@open.com.au>
  - Name of the key-locked distribution file changed from Radiator-Demo to Radiator-Locked.
  - Added ppm directory to RPM dist
* Mon Aug  2 2004 Mike McCauley <mikem@open.com.au>
  - Improvements to handling perl versions in /usr/lib/perl5/site_perl/, and fixed doc ownership problems
* Tue May 20 2003 Mike McCauley <mikem@open.com.au>
  - Fixed problem with check-files and rpmbuild on RH8
* Fri Jul 16 2002 Mike McCauley <mikem@open.com.au>
  - Improve install compatibility with Cobalt etc rc directories
* Thu Mar 15 2002 Mike McCauley <mikem@open.com.au>
  - Further improvements for SuSE compat suggested by Alfredo Sola <alfredo@intelideas.com>
* Thu Feb 28 2002 Mike McCauley <mikem@open.com.au>
  - Include all dictionaries into doc area
* Tue Sep 11 2001 Mike McCauley <mikem@open.com.au>
  - Removed usage of chkconfig: its not on all systems
* Sun Jun  6 2001 Mike McCauley <mikem@open.com.au>
  - Improvements suggested by Gustav Foseid <gustavf@initio.no>

# This fixes a legacy problem with rpmbuild in RH8:
%undefine __check_files
